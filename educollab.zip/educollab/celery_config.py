import os
from config import mongousername, mongopassword, mongo_ip_address, mongo_database, CELERY_QUEUE
broker_url = CELERY_QUEUE
result_backend = 'mongodb://{0}:{1}@{2}:27017/{3}?authSource=admin'.format(mongousername, mongopassword, mongo_ip_address, mongo_database)
task_serializer = "json"
accept_content = ["json"]
result_serializer = "json"
enable_utc = True
worker_enable_remote_control = False
worker_pool_restarts = True
mongodb_backend_settings = {
        'taskmeta_collection': 'celery_taskmeta',
    }

broker_transport = "sqs"
broker_transport_options = {
            "region": "ap-south-1",
            "visibility_timeout": 3600,
            "polling_interval": 3600,
            "predefined_queues": {
                'celery': {
                    'url': CELERY_QUEUE,
                }

            }
        }
celery_imports = ("tasks",)