import time
import json
import requests
from authlib.jose import jwt
from requests import Response
import secrets
import string
import random
import datetime
import array
from config import ZOOM_EMAIL,ZOOM_API_KEY,ZOOM_API_SECRET

class Zoom :
    def __init__(self):
        self.api_key = ZOOM_API_KEY
        self.api_secret = ZOOM_API_SECRET
        self.userId = ZOOM_EMAIL
        self.base_url = "https://api.zoom.us/v2/"
        self.create_url = f"{self.base_url}/users/{self.userId}/meetings"
        self.jwt_token_exp = 1800
        self.jwt_token_algo = "HS256"

    def create_meeting(self, jwt_token: bytes,topic,agenda,meetingtype,starttime,duration,frequency,recurrence,week_day) -> Response:
        """function to create meetings"""
        alphabet = string.ascii_letters + string.digits
        password = ''.join(secrets.choice(alphabet) for i in range(10))


        body = {"topic": topic,
                "type": meetingtype,
                "start_time": starttime,
                "duration": duration,
                "timezone": "Asia/Kolkata",
                "password": password,
                "agenda": agenda,

                "settings": {"host_video": False,
                             "participant_video": False,
                             "cn_meeting": False,
                             "in_meeting": True,
                             "join_before_host": True,
                             "mute_upon_entry": True,
                             "auto_recording": "cloud"
                             }
                }

        if frequency != None:
            recurrencetype=frequency
            instances=recurrence
            if recurrencetype == 2:


                recurrence = {"recurrence": {"type": recurrencetype,
                                             "weekly_days": week_day,
                                             "end_times": instances}
                              }
                body.update(recurrence)

            elif recurrencetype == 1:
                recurrence = {"recurrence": {"type": recurrencetype,
                                             "end_times": instances}
                              }
                body.update(recurrence)



        r: Response = requests.post(self.create_url,
                                    headers={"Authorization":
                                                 f"Bearer {jwt_token.decode('utf-8')}"},
                                    json=body)


        if r.status_code == 201:
            response = json.loads(r.content)
            return response
        else:
            print(f"Failed!")
            return r

    def get_meeting(self, jwt_token: bytes,meetingId) -> Response:
        """function to get the meeting's details"""
        showOccur = False

        URL = f"{self.base_url}/meetings/{meetingId}"

        body: dict = {
                      "show_previous_occurrences": showOccur,
                      }

        r: Response = requests.get(URL,
                                   headers={"Authorization":
                                                f"Bearer {jwt_token.decode('utf-8')}"},
                                   json=body)
        return r

    def delete_meeting(self, jwt_token: bytes,meetingID,occurID) -> Response:
        """function to delete meeting"""
        reminder = True

        URL = f"{self.base_url}/meetings/{meetingID}"

        body: dict = {"occurrence_id": occurID,
                      "schedule_for_reminder": reminder,
                      }

        r: Response = requests.delete(URL,
                                      headers={"Authorization":
                                                   f"Bearer {jwt_token.decode('utf-8')}"},
                                      json=body)
        return r

    def get_participants(self, jwt_token: bytes,meetingUUID) -> Response:
        """function to get the list of participants"""

        URL = f"{self.base_url}/past_meetings/{meetingUUID}/participants"

        body: dict = {"page_size": 30,
                      "next_page_token": None
                      }

        r: Response = requests.get(URL,
                                   headers={"Authorization":
                                                f"Bearer {jwt_token.decode('utf-8')}"},
                                   json=body)
        return r

    def get_recording(self, jwt_token: bytes, meetingUUID) -> Response:
        """function to get the recordings"""
        URL = f"{self.base_url}/meetings/{meetingUUID}/recordings"

        r: Response = requests.get(URL,
                                   headers={"Authorization":
                                                f"Bearer {jwt_token.decode('utf-8')}"})
        return r

    def generate_jwt_token(self) -> bytes:
        """function to generate zoom jwt tokens"""
        iat = int(time.time())

        jwt_payload: dict = {"aud": None,
                             "iss": self.api_key,
                             "exp": iat + self.jwt_token_exp,
                             "iat": iat
                             }

        head: dict = {"alg": self.jwt_token_algo}

        jwt_token: bytes = jwt.encode(head, jwt_payload, self.api_secret)

        return jwt_token



