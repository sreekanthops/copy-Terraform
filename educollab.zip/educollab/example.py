from flask import Flask,jsonify,request
from services import Question_Bank
from model import User_Base as ub
from services.common import io

app = Flask(__name__)

@app.route('/',methods=['GET']) # http://www.example.com/store
def home():
    return 'Hello World!'

@app.route('/question',methods=['POST']) # http://www.example.com/store
def create_store():
    request_data = request.get_json()
    my_bank = Question_Bank()
    return_dictionary = my_bank.get_similar_questions(request_data['question'],request_data['langugage'])
    if len(return_dictionary) == 0:
        return_dictionary={'message':request_data['question']+' is posted on our marketplace! Thankyou!!'}

    return jsonify(return_dictionary)

@app.route('/user/<string:name>',methods=['GET']) # http://www.example.com/store/some_name/
def get_store(name):
    base = ub.User_Base()
    d = base.get_user(name)
    # print(d.__dict__)
    return io.MyJSONEncoder().encode(d.__dict__)

@app.route('/store/',methods=['GET']) # http://www.example.com/store/
def get_stores():
    pass

app.run(port=5000)
