from services.storage.s3_services import s3_storage
from pymongo import MongoClient
from config import mongo_database, mongo_ip_address, mongo_port, mongousername, mongopassword, \
    course_resource_expiry_in_sec


class Mongo_Connection():
    def __init__(self):
        self.client = \
        MongoClient('mongodb://%s:%s@%s:%s' % (mongousername, mongopassword, mongo_ip_address, mongo_port))[
            mongo_database]


s3_function = s3_storage()
mongo_session = Mongo_Connection()
