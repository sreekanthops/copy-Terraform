from bson.objectid import ObjectId

from db_wrapper.connection import mongo_session


class Update():
    def delete_data(self, collection, condition=None):
        """Delete records based on the condition and return the deleted information."""
        client = mongo_session.client[collection]
        deleted_info = client.remove(condition)
        return deleted_info

    def update_db_data(self, collection, condition=None, update_info=None, multi=False):
        """To update any document in the database."""
        client = mongo_session.client[collection]
        return client.update(condition, update_info, multi=multi)
