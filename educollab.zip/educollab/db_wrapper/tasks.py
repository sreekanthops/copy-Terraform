from pymongo import MongoClient
from config import mongo_database, mongo_ip_address, mongo_port, mongousername, mongopassword, \
    course_resource_expiry_in_sec
import pandas as pd
from bson.objectid import ObjectId
from bson.son import SON
import time
import traceback
from utils import misc

from db_wrapper.fetch_functions import Fetch
from db_wrapper.insert_functions import Insert
from db_wrapper.validation_functions import Validation
from db_wrapper.delete_update_functions import Update
from db_wrapper.connection import mongo_session
from db_wrapper.delete_update_functions import Update


class Mongo(Fetch, Insert, Validation, Update):
    def __init__(self):
        # self.Client = MongoClient('mongodb://%s:%s@%s:%s' % (mongousername, mongopassword, mongo_ip_address, mongo_port))[mongo_database]
        self.Client = mongo_session.client

    def get_all_data(self, collection, column_request_response_key_mapping=None):
        client = self.Client[collection]
        all_user_data = []
        for doc in client.find({}):
            doc["_id"] = str(doc['_id'])
            all_user_data.append(doc)

        req_res = {"message": all_user_data, "status": 200}

        if column_request_response_key_mapping:
            req_res = misc.mongo_columns_mapping_to_request_response_keys(mongo_data_res=req_res,
                                                                          column_request_response_key_mapping=column_request_response_key_mapping)
        return req_res

    def get_all_data_for_particular_fields(self, collection, columns):
        try:
            client = self.Client[collection]
            all_user_data = []
            for doc in client.find({}, columns):
                all_user_data.append(doc)
            return {"message": all_user_data, "status": 200}
        except Exception as e:
            print(e)
            return {"status": 400, "message": "error while fetching data from db"}

    def get_all_data_for_particular_condition_fields(self, collection, condition):
        try:
            client = self.Client[collection]
            all_user_data = []
            for doc in client.find(condition):
                doc["_id"] = str(doc['_id'])
                all_user_data.append(doc)
            return {"message": all_user_data, "status": 200}
        except Exception as e:
            print(e)
            return {"status": 400, "message": "error while fetching data from db"}

    def get_data_for_particular_columns_with_condition(self, collection, condition, columns=None,
                                                       column_request_response_key_mapping=None):
        client = self.Client[collection]
        all_user_data = []
        records = client.find(condition, columns) if columns else client.find(condition)
        for doc in records:
            doc["_id"] = str(doc['_id'])
            all_user_data.append(doc)
        req_res = {"message": all_user_data, "status": 200}

        if column_request_response_key_mapping:
            req_res = misc.mongo_columns_mapping_to_request_response_keys(mongo_data_res=req_res,
                                                                          column_request_response_key_mapping=column_request_response_key_mapping)
        return req_res

    def update_field_based_on_user_id(self, collection, id, field, value):
        try:
            client = self.Client[collection]
            up = client.update({"_id": ObjectId(id)}, {"$set": {field: value}})
            print(up)
            return {"message": "success", "status": 200, 'documents_updated': up['n']}
        except Exception as e:
            print(e)
            return {"message": "error in update query", "status": 400}

    def insert_documnet(self, collection, doc_to_insert):
        try:
            client = self.Client[collection]
            up = client.insert_one(doc_to_insert)
            print('doc_id ', up)
            return {"message": "success", "status": 200, "_id": up}
        except Exception as e:
            print(e)
            return {"message": "error in insert query", "status": 400}

    def insert_multiple_documents(self, collection, doc_to_insert):
        try:
            client = self.Client[collection]
            client.insert_many(doc_to_insert)
            # print('doc_id ', up['insertedId'])
            return {"message": "success", "status": 200}
        except Exception as e:
            print(e)
            return {"message": "error in insert query", "status": 400}

    def update_multiple_fields(self, collection, condition, set_columns):
        try:
            client = self.Client[collection]
            up = client.update(condition, {"$set": set_columns})
            return {"message": "success", "status": 200, 'document_updated': up['n']}
        except Exception as e:
            print(e)
            return {"message": "error in update query", "status": 400}

    def get_all_data_for_particular_fields_course_category_api(self, collection, columns):
        try:
            client = self.Client[collection]
            courses_categories_data = []
            for doc in client.find({}, columns):
                doc["_id"] = str(doc['_id'])
                doc["parent_id"] = str(doc['parent_id'])
                courses_categories_data.append(doc)
            return {"message": courses_categories_data, "status": 200}
        except Exception as e:
            print(e)
            return {"status": 400, "message": "error while fetching data from db"}

    def get_all_data_search_question_string_matching(self, collection):
        try:
            client = self.Client[collection]
            question_aray = []
            for doc in client.find({}):
                doc["_id"] = str(doc['_id'])
                doc["course_category_id"] = str(doc["course_category_id"])
                for answer in doc["answers"]:
                    answer["_id"] = str(answer["_id"])
                question_aray.append(doc)
            return {"message": question_aray, "status": 200}
        except Exception as e:
            return {"status": 400, "message": e}

    def get_question_video_info_search_question_string_matching_function(self, collection, condition):
        try:
            client = self.Client[collection]
            video_aray = []
            for doc in client.find(condition):
                doc["_id"] = str(doc['_id'])
                doc["Course_id"] = str(doc["Course_id"])
                doc["user_id"] = str(doc["user_id"])
                for question in doc["question_detail"]:
                    question["question_id"] = str(question["question_id"])
                video_aray.append(doc)
            return {"message": video_aray, "status": 200}
        except Exception as e:
            print(e)
            return {"status": 400, "message": "error while fetching data from db"}

    def add_to_an_array_field(self, collection, id, field, values_array):
        try:
            client = self.Client[collection]
            up = client.update({"_id": id}, {"$addToSet": {field: values_array}})
            print(up)
            return {"message": "success", "status": 200, 'document_updated': up['n']}
        except Exception as e:
            print(e)
            return {"message": "error in update query", "status": 400}

    def del_value_from_array(self, collection, id, field, value):
        try:
            client = self.Client[collection]
            up = client.update({"_id": id}, {"$pull": {field: value}})
            print(up)
            return {"message": "success", "status": 200, 'document_updated': up['n']}
        except Exception as e:
            print(e)
            return {"message": "error in update query", "status": 400}

    def get_email_forget_password_api(self, collection, condition, columns):
        try:
            client = self.Client[collection]
            email_id = ""
            for doc in client.find(condition, columns):
                email_id = doc['email']
            if email_id == "":
                return {"message": email_id, "status": 401}
            return {"message": email_id, "status": 200}
        except Exception as e:
            print(e)
            return {"status": 400, "message": "error while fetching data from db"}

    def get_valid_users_teacher_student_question(self, collection, condition, columns):
        try:
            client = self.Client[collection]
            user_id = []
            for doc in client.find(condition, columns):
                if 'subscribers' in doc:
                    for user in doc['subscribers']:
                        user_id.append(str(user['user_id']))
            return {"message": user_id, "status": 200}
        except Exception as e:
            traceback.print_exc()
            return {"status": 400, "message": [], "msg": "error while fetching data from db"}

    def get_question_data_teacher_student_question(self, collection, condition, columns):
        try:
            client = self.Client[collection]
            question_data = []
            for doc in client.find(condition, columns):
                dict = {'qus_title': doc['questions'], '_id': str(doc['_id'])}
                question_data.append(dict)
            return {"message": question_data, "status": 200}
        except Exception as e:
            traceback.print_exc()
            return {"status": 400, "message": [], "msg": "error while fetching data from db"}

    def get_category_name(self, collection, condition, columns):
        try:
            client = self.Client[collection]
            category_name = ""
            for doc in client.find(condition, columns):
                category_name = doc['name']
            return {"message": category_name, "status": 200}
        except Exception as e:
            print(e)
            return {"status": 400, "msg": "error while fetching data from db", "message": []}

    def get_user_teacher_student_question(self, collection, condition):
        try:
            client = self.Client[collection]
            user_id = ""
            for doc in client.find(condition):
                user_id = str(doc['_id'])
            return {"message": user_id, "status": 200}
        except Exception as e:
            print(e)
            return {"status": 400, "msg": "error while fetching data from db", "message": []}

    def get_answer_teacher_student_answer(self, collection, condition):
        try:
            client = self.Client[collection]
            answer_id = ""
            for doc in client.find(condition):
                answer_id = str(doc['_id'])
            return {"message": answer_id, "status": 200}
        except Exception as e:
            print(e)
            return {"status": 400, "msg": "error while fetching data from db", "message": []}

    def get_answer_info_teacher_student_answer(self, collection, condition):
        try:
            client = self.Client[collection]
            answer_info = []
            for doc in client.find(condition):
                dict = {"user_id": doc["user_id"], "Course_Category": doc['Course_Category'],
                        "Feedback": doc['Feedback'], "question_id": doc['question_id'], "Disliked": doc['Disliked'],
                        "Liked": doc['Liked'], "Rating": doc['Rating'], "_id": str(doc['_id']),
                        "approval_status": doc['approval_status'], "file_path": doc['file_path']}
                answer_info.append(dict)
            return {"message": answer_info, "status": 200}
        except Exception as e:
            print(e)
            return {"status": 400, "msg": "error while fetching data from db", "message": []}

    def get_username_teacher_student_answer(self, collection, condition, columns):
        try:
            client = self.Client[collection]
            user_name = ""
            for doc in client.find(condition, columns):
                user_name = doc['username']
            return {"message": user_name, "status": 200}
        except Exception as e:
            print(e)
            return {"status": 400, "msg": "error while fetching data from db", "message": []}

    def get_organisation_info_organisation_leaderboard(self, collection, condition):
        try:
            client = self.Client[collection]
            organisation_info = []
            rank = 0
            limit = 10
            current_coin = list(client.aggregate(condition))[0]['coin'] + 1
            for doc in list(client.aggregate(condition)):
                if limit == 0:
                    break
                if doc['coin'] < current_coin:
                    rank = rank + 1
                current_coin = doc['coin']
                doc['rank'] = rank
                doc['coin'] = float(round(doc['coin'], 2))
                organisation_info.append(doc)
                limit = limit - 1

            return {"message": organisation_info, "status": 200}
        except Exception as e:
            print(e)
            return {"status": 400, "msg": "error while fetching data from db", "message": []}

    def get_user_leaderboard_info_user_leaderboard(self, current_user_coin, user_id, collection, condition):
        try:
            client = self.Client[collection]
            user_info = []
            user_cursor = list(client.aggregate(condition))
            rank = [(user_cursor.index(doc) + 1) for doc in user_cursor if
                    float(round(doc['_id']['coin'], 2)) == float(round(current_user_coin, 2))][0]
            print('rankk,', rank)

            if rank <= 10:
                print('less than 10')
                for i in range(0, 10):
                    if i != rank:
                        user_info.append({"rank": i + 1, "score": float(round(user_cursor[i]['_id']['coin'], 2)),
                                          "total_student": len(user_cursor[i]['user_id']), "user_id": ""})
                    elif (i == rank):
                        user_info.append(
                            {"rank": i + 1, "score": float(round(user_cursor[i]['_id']['coin'], 2)),
                             "total_student": len(user_cursor[i]['user_id']), "user_id": user_id})
            elif rank > 10:
                print('greater than 10')
                for i in range(0, 5):
                    if i != rank:
                        user_info.append({"rank": i + 1, "score": float(round(user_cursor[i]['_id']['coin'], 2)),
                                          "total_student": len(user_cursor[i]['user_id']), "user_id": ""})

                ########## 2 above records ###########
                user_info.append(
                    {"rank": rank - 2, "score": float(round(user_cursor[rank - 3]['_id']['coin'], 2)),
                     "total_student": len(user_cursor[rank - 3]['user_id']),
                     "user_id": ""})
                user_info.append(
                    {"rank": rank - 1, "score": float(round(user_cursor[rank - 2]['_id']['coin'], 2)),
                     "total_student": len(user_cursor[rank - 2]['user_id']),
                     "user_id": ""})

                ########### current user ############
                user_info.append(
                    {"rank": rank, "score": float(round(user_cursor[rank - 1]['_id']['coin'], 2)),
                     "total_student": len(user_cursor[rank - 1]['user_id']),
                     "user_id": user_id})

                ############# 2 below records if there are any ##########

                if len(user_cursor) >= rank + 2:
                    print('inside')
                    user_info.append(
                        {"rank": rank + 1, "score": float(round(user_cursor[rank]['_id']['coin'], 2)),
                         "total_student": len(user_cursor[rank]['user_id']),
                         "user_id": ""})
                    user_info.append(
                        {"rank": rank + 2, "score": float(round(user_cursor[rank + 1]['_id']['coin'], 2)),
                         "total_student": len(user_cursor[rank + 1]['user_id']),
                         "user_id": ""})

                elif len(user_cursor) >= rank + 1:
                    user_info.append(
                        {"rank": rank + 1, "score": float(round(user_cursor[rank]['_id']['coin'], 2)),
                         "total_student": len(user_cursor[rank]['user_id']),
                         "user_id": ""})
                else:
                    pass

            return {"message": user_info, "status": 200}
        except Exception as e:
            print(e)
            return {"status": 400, "msg": "error while fetching data from db", "message": []}

    def answer_info_ask_question(self, collection, condition):
        try:
            client = self.Client[collection]
            answer_id = ""
            for doc in client.find(condition):
                answer_id = str(doc['_id'])
            return {"message": answer_id, "status": 200}
        except Exception as e:
            print(e)
            return {"status": 400, "msg": "error while fetching data from db", "message": ""}

    def store_question_araay_to_answer_ask_question(self, collection, condition, question_id, video_time):
        try:
            client = self.Client[collection]
            up = client.update(condition, {
                "$push": {"video_question": {"question_id": ObjectId(question_id), "video_time": video_time}}})
            return {"message": "", "status": 200}
        except Exception as e:
            print(e)
            return {"status": 400, "msg": "error while fetching data from db", "message": ""}

    def verify_course_store_video_state(self, collection, condition, columns):
        try:
            client = self.Client[collection]
            message = ""
            for doc in client.find(condition, columns):
                message = str(doc['_id'])
            return {"message": message, "status": 200}
        except Exception as e:
            print(e)
            return {"status": 400, "msg": "error while fetching data from db", "message": ""}

    def store_video_data_user_profile(self, collection, user_id, course_id, video_time, session_id):
        try:
            client = self.Client[collection]
            query_condition = {
                "_id": ObjectId(user_id),
                "course_video_states": {"$elemMatch":
                    {
                        "course_id": ObjectId(course_id),
                        "session_id": ObjectId(session_id)
                    }
                }
            }
            if client.find(query_condition).count() > 0:
                client.update(query_condition,
                              {"$set": {"course_video_states.$.video_time": int(video_time)}})
                message = {"message": "stored video state", "status": "Success"}
                return {"message": message, "status": 200}
            else:
                client.update({"_id": ObjectId(user_id)}, {"$push": {
                    "course_video_states": {
                        "course_id": ObjectId(course_id),
                        "video_time": int(video_time),
                        "session_id": ObjectId(session_id)}}})
                message = {"message": "stored video state", "status": "Success"}
                return {"message": message, "status": 201}
        except Exception as e:
            traceback.print_exc()
            return {"status": 500, "message": {"message": e, "status": "Failed"}}

    def insert_data_ask_question(self, collection, record):
        try:
            client = self.Client[collection]
            cursor = client.insert(record)
            return {"message": cursor, "status": 200}
        except Exception as e:
            print(e)
            return {"status": 400, "msg": "error while fetching data from db", "message": ""}

    def update_user_data_ask_question(self, collection, condition, push_info, increment_info):
        try:
            client = self.Client[collection]
            client.update(condition, {"$push": push_info})
            client.update(condition, {"$inc": increment_info})
            return {"message": client.find(condition), "status": 200}
        except Exception as e:
            print(e)
            return {"status": 400, "msg": "error while updating data from db", "message": ""}

    def update_course_subscription(self, collection, condition, push_pull_inc_info):
        try:
            client = self.Client[collection]
            client.update(condition, push_pull_inc_info)
            return {"message": "updated", "status": 200}
        except Exception as e:
            print(e)
            return {"status": 400, "msg": "error while updating data from db",
                    "Courses": {"Status": e, "Subscription_Status": None, "coin": None}}

    def get_previous_subscription_status(self, collection, condition, columns):
        try:
            client = self.Client[collection]
            if client.find(condition, columns).count() > 0:
                message = True
            else:
                message = False
            return {"message": message, "status": 200}
        except Exception as e:
            print(e)
            return {"status": 400, "msg": "error while fetching data from db",
                    "Courses": {"Status": e, "Subscription_Status": None, "coin": None}}

    def update_coins_and_previous_subscription_info(self, collection, condition, push_pull_inc_info):
        try:
            client = self.Client[collection]
            client.update(condition, push_pull_inc_info)
            return {"message": "updated_successfully", "status": 200}
        except Exception as e:
            print(e)
            return {"status": 400, "msg": "error while updating data from db",
                    "Courses": {"Status": e, "Subscription_Status": None, "coin": None}}

    def get_user_coin(self, collection, condition, columns):
        try:
            client = self.Client[collection]
            for doc in client.find(condition, columns):
                coins = float(round(doc['coin'], 2))
            return {"message": coins, "status": 200}
        except Exception as e:
            print(e)
            return {"status": 400, "msg": "error while fetching data from db",
                    "Courses": {"Status": e, "Subscription_Status": None, "coin": None}}

    def insert_doc_upload_resource(self, collection, record):
        try:
            client = self.Client[collection]
            cursor = client.insert(record)
            return {"resource_id": cursor, "status": 200}
        except Exception as e:
            print(e)
            return {"status": 400, "msg": "error while fetching data from db", "resource_id": ""}

    def fetch_s3_key_temp_uploaded_files(self, collection, condition, columns):
        try:
            client = self.Client[collection]
            for doc in client.find(condition, columns):
                s3_key = doc['s3_key']
            return {"message": s3_key, "status": 200}
        except Exception as e:
            print(e)
            return {"status": 400, "message": "error while fetching data from db"}


    def insert_files_resource_bank(self,collection,resource_id,temp_collection):
        client=self.Client[collection]
        temp_client = self.Client[temp_collection]
        temp_cursor = temp_client.find({"_id": resource_id})
        if not temp_cursor.count() > 0:
            return {"message": "File is not valid, Please check details.", "status": 400}
        for doc in temp_cursor:
            client.insert_one(
                {"_id": doc['_id'],
                 "s3_key": doc['s3_key'],
                 "uploaded_at": doc['uploaded_at'],
                 "user_id": doc['user_id'],
                 "module_name": doc['module_name']})
        up = [doc['_id'] for doc in client.find({"_id": resource_id})][0]
        return {"message": up, "status": 200}


    def delete_record_temp_uploaded_files(self, collection, id_list):
        try:
            client = self.Client[collection]
            client.remove({"_id": {"$in": id_list}})
            return {"message": "deleted_record", "status": 200}
        except Exception as e:
            print(e)
            return {"status": 400, "message": "error while fetching data from db"}

    def fetch_all_data_edit_course(self, collection, condition, collumns):
        try:
            client = self.Client[collection]
            course_resources = [doc for doc in client.find(condition, collumns)][0]
            return {"message": course_resources, "status": 200}
        except Exception as e:
            print(e)
            return {"status": 400, "message": "error while fetching data from db"}

    def insert_date_temp_delete_course_resource_edit_course(self, collection, temp_record, records_to_modify):
        try:
            client = self.Client[collection]
            temp_client = self.Client[temp_record]
            for doc in client.find({"_id": {"$in": records_to_modify}}):
                temp_client.insert_one(
                    {"_id": doc['_id'], "s3_key": doc['s3_key'], "uploaded_at": doc['uploaded_at'],
                     "user_id": doc['user_id'],
                     "module_name": doc['module_name'],
                     "expires_at": doc['uploaded_at'] + course_resource_expiry_in_sec})
            client.remove({"_id": {"$in": records_to_modify}})
            return {"message": "success", "status": 200}
        except Exception as e:
            print(e)
            return {"status": 400, "message": "error while inserting data in db"}

    def store_user_device_token_task(self, collection, user_id, deviceToken, jwt_expiry_time):
        try:
            client = self.Client[collection]
            if client.find({"user_device_tokens": {"$exists": True}}).count() > 0:
                client.update({"user_device_tokens.deviceToken": deviceToken},
                              {"$pull": {"user_device_tokens": {"deviceToken": deviceToken}}}, multi=True)
                # client.update({"user_device_tokens.jwt_expiry_time": {"$lt":time.time()}}, {"$pull": {"user_device_tokens":{"jwt_expiry_time": {"$lt":time.time()}}}}, multi=True)

            if client.find({"_id": ObjectId(user_id), "user_device_tokens": {"$exists": True}}).count() > 0:
                print('if')
                client.update({"_id": ObjectId(user_id)}, {"$addToSet": {
                    "user_device_tokens": {"deviceToken": deviceToken, "jwt_expiry_time": jwt_expiry_time}}})
            else:
                print('else')
                client.update({"_id": ObjectId(user_id)}, {
                    "$set": {"user_device_tokens": [{"deviceToken": deviceToken, "jwt_expiry_time": jwt_expiry_time}]}})
            return {"message": "Success", "status": 200}
        except Exception as e:
            print(e)
            return {"status": 400, "message": "error while updating data to db"}

    def get_device_tokens(self, collection, condition, columns):
        try:
            client = self.Client[collection]
            client.update({"user_device_tokens.jwt_expiry_time": {"$lt": time.time()}},
                          {"$pull": {"user_device_tokens": {"jwt_expiry_time": {"$lt": time.time()}}}}, multi=True)
            device_tokens = []
            for doc in client.find(condition, columns):
                for token in doc['user_device_tokens']:
                    print('current time', time.time())
                    if token['jwt_expiry_time'] > time.time():
                        device_tokens.append(token['deviceToken'])
            return {"message": device_tokens, "status": 200}
        except Exception as e:
            print(e)
            return {"status": 400, "message": "error while loading data from db"}

    def get_schedule_Assessment_info(self, collection, condition):
        try:
            client = self.Client[collection]
            assessment_list = []
            for doc in client.find(condition):
                assessment_list.append(doc)
            return {"message": assessment_list, "status": 200}
        except Exception as e:
            print(e)
            return {"status": 400, "msg": "error while fetching data from db", "message": []}

    def update_submission_course_work(self, collection, condition, update_info):
        try:
            client = self.Client[collection]
            client.update(condition, {"$push": update_info})
            return {"message": "Success", "status": 200}
        except Exception as e:
            print(e)
            return {"status": 400, "msg": "error while fetching data from db", "message": []}

    def find_student_Submission(self, collection, condtion):
        try:
            client = self.Client[collection]
            if client.find(condtion).count() > 0:
                present = True
            else:
                present = False
            return {"message": present, "status": 200}
        except Exception as e:
            print(e)
            return {"status": 400, "message": "error while fetching data from db"}

    def check_existance(self, collection, condition):
        client = self.Client[collection]
        if client.find(condition).count() > 0:
            message = True
        else:
            message = False
        return message

    def update_data_submissions(self, collection, condition, update_info):
        try:
            client = self.Client[collection]
            client.update(condition, update_info)
            return {"message": "Success", "status": 200}
        except Exception as e:
            print(e)
            return {"status": 400, "message": "error while updating data to db"}

    def delete_device_ids_answer_question(self, collection, condition, id_list):
        try:
            client = self.Client[collection]
            # client.update(condition,{ "$pull": {"user_device_tokens": {"$in": id_list}}},multi=True)
            client.update(condition, {"$pull": {"user_device_tokens": {"deviceToken": {"$in": id_list}}}}, multi=True)
            return {"message": "deleted_tokens", "status": 200}
        except Exception as e:
            print(e)
            return {"status": 400, "message": "error while fetching data from db"}

    def check_app_version(self, collection, condition_one, condition_two, condition_three, condition):
        try:
            client = self.Client[collection]
            if client.find(condition_one).count() > 0:
                for doc in client.find(condition, {"_id": 0}).sort([("appVersion", -1)]).limit(1):
                    return {"message": doc, "query_status": 200, "status": "UpdateRequired"}
            elif client.find(condition_two).count() > 0:
                for doc in client.find(condition, {"_id": 0}).sort([("appVersion", -1)]).limit(1):
                    return {"message": doc, "query_status": 200, "status": "UpdateAvailable"}
            elif client.find(condition_three).count() > 0:
                for doc in client.find(condition_three, {"_id": 0}).sort([("appVersion", -1)]).limit(1):
                    return {"message": doc, "query_status": 200, "status": "NoUpdate"}
            else:
                return {"query_status": 400, "message": "error while updating data to db"}
        except Exception as e:
            print(e)
            return {"query_status": 400, "message": "error while updating data to db"}


    def get_assessment_info(self, collection, condition):
        try:
            client = self.Client[collection]
            assessment_list = []
            for doc in client.find(condition):
                dict = {"_id": str(doc['_id']), "assessment_name": doc['assessment_name']}
                assessment_list.append(dict)
            return {"message": assessment_list, "status": 200}
        except Exception as e:
            return {"status": 400, "msg": "error while fetching data from db", "message": []}

    def get_roles_from_db(self, collection, columns):
        try:
            client = self.Client[collection]
            roles_list = []
            for doc in client.find({}, columns):
                roles_list.append(doc['name'])
            return {"message": roles_list, "status": 200}
        except Exception as e:
            traceback.print_exc()
            return {"status": 400, "msg": e, "message": []}

    def find_data_in_db(self, collection, condition, columns):
        try:
            client = self.Client[collection]
            if client.find(condition, columns).count() > 0:
                message = True
            else:
                message = False
            return {"message": message, "status": 200}
        except Exception as e:
            traceback.print_exc()
            return {"status": 500, "message": "error while fetching data from db"}

    def update_record_into_db(self, collection, condition, update_info):
        try:
            client = self.Client[collection]
            update_status = client.update(condition, update_info)
            return {"message": "success", "status": 200, "update_status": update_status}
        except Exception as e:
            traceback.print_exc()
            return {"status": 400, "message": e}

    def get_course_video_questions_task(self, collection, condition, columns):
        try:
            client = self.Client[collection]
            question_client = self.Client["question_bank"]
            questions_info = []
            for doc in client.find(condition, columns):
                for question in doc['question_detail']:
                    if question_client.find({"_id": question['question_id']},
                                            {"translated_question": 1, "_id": 0}).count() > 0:
                        question_text = question_client.find(
                            {"_id": question['question_id']},
                            {"translated_question": 1, "_id": 0})[0]['translated_question']
                    else:
                        question_text = ""
                    dict = {
                        "qus_id": str(question['question_id']),
                        "question_time": question['video_time'],
                        "qus_title": question_text}
                    questions_info.append(dict)
            return {"message": questions_info, "status": 200}
        except Exception as e:
            traceback.print_exc()
            return {"status": 500, "message": [], "msg": "error while fetching data from db"}

    def find_one_in_db(self, collection, condition, columns):
        try:
            client = self.Client[collection]
            if client.find_one(condition, columns):
                message = True
            else:
                message = False
            return {"message": message, "status": 200}
        except Exception as e:
            traceback.print_exc()
            return {"status": 500, "message": [], "msg": "error while fetching data from db"}

    def get_saved_assessment_list(self, collection, condition, page):
        try:
            client = self.Client[collection]
            assessment_list = []
            tags_collection = self.get_all_data("question_tags")['message']
            tags_dict = dict(map(lambda x: (str(x['_id']), x['tag']), tags_collection))

            global_tags_collection = self.get_all_data("global_tags")['message']
            global_tags_dict = dict(map(lambda x: (str(x['_id']), x['tag']), global_tags_collection))
            tags_dict.update((global_tags_dict))

            type_collection = self.get_all_data("question_type")['message']
            type_dict = dict(map(lambda x: (str(x['_id']), x['name']), type_collection))

            complexity_collection = self.get_all_data("question_complexity")['message']
            complexity_dict = dict(map(lambda x: (str(x['_id']), x['name']), complexity_collection))

            for doc in client.find(condition):
                doc['tags'] = [str(id) for id in doc['tags']]
                doc['course'] = []
                if doc['publish']:
                    doc['status'] = 'published'
                    course_collection = self.get_all_data_for_particular_condition_fields("courses_bank",
                                                                                          {"course_assessments._id":
                                                                                               doc['_id']}
                                                                                          )['message']
                    if course_collection:
                        course_set = set()
                        for course in course_collection:
                            # dict is unhashable need to use tuple to add in a set
                            course_obj = {"_id": str(course['_id']), "course": course['subject']}
                            course_set.add(tuple(course_obj.items()))
                            doc['course'] = [dict(tup) for tup in course_set]
                else:
                    doc['status'] = 'unpublished'
                questions = []
                for q in doc['questions']:
                    ques_coll = self.get_all_data_for_particular_condition_fields("add_questions",
                                                                                  {"_id": ObjectId(
                                                                                      q['question_id'])})['message']
                    if ques_coll:
                        ques_obj = ques_coll[0]
                        q['_id'] = str(q.pop("question_id"))
                        q['question'] = str(ques_obj['question'])
                        q['filtered_question'] = str(ques_obj['filtered_question'])
                        q['duration'] = ques_obj['duration']
                        q['complexity'] = {"_id": str(ques_obj['complexity']),
                                           "complexity": complexity_dict[str(ques_obj['complexity'])]}
                        q['questype'] = {"_id": str(ques_obj['questype']),
                                         "type": type_dict[str(ques_obj['questype'])]}
                        q['tags'] = [{"_id": str(t), "tag": tags_dict[str(t)]} for t in ques_obj['tags']]
                        if type_dict[str(ques_obj['questype'])] == 'Comprehension':
                            q['sub_qus'] = ques_obj['sub_qus']
                        else:
                            q['meta_data'] = ques_obj['meta_data']
                        questions.append(q)
                    else:
                        q['question_id'] = ""
                tags_lis = []
                for t in doc['tags']:
                    tags_obj = {}
                    tags_obj['_id'] = t
                    num_tags = self.get_all_data_for_particular_condition_fields("question_tags",
                                                                                 {"_id": ObjectId(t)})['message']
                    if num_tags:
                        tags_obj['tag'] = num_tags[0]['tag']
                    tags_lis.append(tags_obj)

                doc['tags'] = tags_lis

                doc['assessment_description'] = doc.get('assessment_description', "")

                if questions:
                    assessment_obj = {"_id": str(doc['_id']), "assessment_name": doc['assessment_name'],
                                      "assessment_type": doc['assessment_type'],
                                      "total_time": doc['total_time'], "tags": doc['tags'], "selectedQus": questions,
                                      "created_date": doc['created_date'], "status": doc['status'],
                                      "courses": doc['course'], "negativeMarking": doc['negative_marking'],
                                      "negativeValue": doc['negative_value'], "totalMarks": doc['total_marks'],
                                      "assignMarks": doc['assign_marks'], "user_id": doc['user_id'],
                                      "assessment_description" : doc['assessment_description']
                                      }
                    assessment_list.append(assessment_obj)
            assessment_list = sorted(assessment_list, key=lambda k: k['_id'], reverse=True)
            page = int(page)
            start_index = page * 10 - 10
            end_index = start_index + 10
            if len(assessment_list) < page * 10:
                end_index = start_index + len(assessment_list) % 10
            paged_assessment = assessment_list[start_index:end_index]
            return {"message": paged_assessment, "status": 200, "total_assessments": str(len(assessment_list))}

        except Exception as e:
            traceback.print_exc()
            return {"status": 400, "message": "error while fetching data from db", "total_assessments": "-1"}

    def insert_import_questions(self, records, collection):
        """
        insert aiken questions into collection with unique question_field,
        used upsert to insert a new document and update the old document
        """
        try:
            client = self.Client[collection]
            for doc in records:
                ques = doc['question']
                up = client.update({"question": ques}, {"$set": doc}, upsert=True)
            return {"message": "success", "status": 200}
        except Exception as e:
            traceback.print_exc()
            return {"message": "error in insert query", "status": 400}

    def update_data(self, collection, find_condition, update_info, update_condition):
        client = self.Client[collection]
        if client.find(find_condition).count() > 0:
            client.update(find_condition, update_info)
            return 200
        elif client.find(update_condition).count() > 0:
            client.update(update_condition, update_info)
            return 200
        else:
            return 500

    def delete_records(self, collection, condition):
        client = self.Client[collection]
        client.remove(condition)
        return 200

    def insert_data_temp_delete_project_resource(self, collection, temp_record, records_to_modify):
        client = self.Client[collection]
        temp_client = self.Client[temp_record]
        for doc in client.find({"_id": {"$in": records_to_modify}}):
            if doc.get("type") and doc["type"] == "text":
                continue
            temp_client.insert_one(
                {"_id": doc['_id'], "s3_key": doc['s3_key'], "uploaded_at": doc['uploaded_at'],
                 "user_id": doc['user_id'],
                 "module_name": doc['module_name'],
                 "expires_at": doc['uploaded_at'] + course_resource_expiry_in_sec})
        client.remove({"_id": {"$in": records_to_modify}})
        return 200

    def update_coin_record_into_db(self, collection, condition, update_info):
        try:
            user_info = ""
            client = self.Client[collection]
            update_status = client.update(condition, update_info)
            for doc in client.find(condition):
                user_info = doc["user_id"]
            return {"message": "success", "status": 200, "update_status": update_status, "user_info": user_info}
        except Exception as e:
            traceback.print_exc()
            return {"status": 400, "message": e}
