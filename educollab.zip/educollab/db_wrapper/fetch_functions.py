from bson.objectid import ObjectId
from bson import json_util
from config import course_resource_expiry_in_sec
from db_wrapper.connection import mongo_session


class Fetch():
    def check_existance_return_info(self, collection, condition=None, columns=None, return_keys=None, whole_doc=None):
        client = mongo_session.client[collection]
        if not client.find(condition).count():
            return None
        if return_keys:
            for doc in client.find(condition, columns).sort([("_id", -1)]):
                data = {}
                for key in return_keys:
                    data[key] = doc.get(key)
                return data
        if whole_doc:
            for doc in client.find(condition, columns):
                return doc
        for doc in client.find(condition, columns):
            return doc["_id"]

    def get_particular_key_value(self, collection, condition, return_info, all_docs=None):
        client = mongo_session.client[collection]
        response = []
        if all_docs:
            for data in client.aggregate([condition, return_info]):
                response.append(data)
            return response
        for doc in client.aggregate([condition, return_info]):
            return doc

    def access_specific_fields(self, collection, condition=None, columns=None, return_keys=None, sort_condition=("_id", -1)):
        client = mongo_session.client[collection]
        if not client.find(condition).count():
            return None
        response = []
        if return_keys:
            for doc in client.find(condition, columns).sort([sort_condition]):
                data = {}
                for key in return_keys:
                    data[key] = doc.get(key)
                response.append(data)
        else:
            for doc in client.find(condition, columns).sort([sort_condition]):
                response.append(doc)
        return response

    def fetch_all_records(self, collection, condition, columns=None):
        client = mongo_session.client[collection]
        if not client.find(condition).count():
            return None
        return client.find(condition, columns)

    def get_total_count(self, collection, condition):
        client = mongo_session.client[collection]
        if not client.find(condition).count():
            return None
        else:
            return client.find(condition).count()
