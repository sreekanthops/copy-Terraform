from bson.objectid import ObjectId

from config import course_resource_expiry_in_sec
from db_wrapper.connection import mongo_session



class Validation():
    pass
