from bson.objectid import ObjectId

from config import course_resource_expiry_in_sec
from db_wrapper.connection import mongo_session


class Insert():
    def insert_date_into_resource_and_temp_delete(self, collection, temp_record, records_to_modify, addition_keys_dict):
        try:
            client = mongo_session.client[collection]
            temp_client = mongo_session.client[temp_record]
            for doc in temp_client.find({"_id": {"$in": records_to_modify}}):
                if doc.get("s3_key", None) != None:
                    file_type = doc.get("s3_key", "").split(".").pop()

                else:
                    file_type = None
                insert_dict = {"_id": doc['_id'],
                               "s3_key": doc['s3_key'],
                               "uploaded_at": doc['uploaded_at'],
                               "user_id": doc['user_id'],
                               "module_name": doc['module_name'],
                               "expires_at": doc['expires_at'] + course_resource_expiry_in_sec,
                               "file_type":file_type
                                }

                insert_dict.update(addition_keys_dict[str(doc["_id"])])

                client.insert_one(insert_dict)
            temp_client.remove({"_id": {"$in": records_to_modify}})
            return {"message": "success", "status": 200}
        except Exception as e:
            print(e)
            return {"status": 400, "message": "error while inserting data in db"}

    def insert_date_into_resource_with_dict(self, collection, project_text_insert_list):
        try:
            inserted_document_ids = []
            client = mongo_session.client[collection]
            for doc in project_text_insert_list:
                insert_dict = doc
                response = client.insert_one(insert_dict)
                inserted_document_ids.append(ObjectId(response.inserted_id))
            return {"message": "success", "status": 200, "inserted_document_ids": inserted_document_ids}
        except Exception as e:
            return {"status": 400, "message": "error while inserting data in db"}

    def insert_docs_to_db(self, collection, docs):
        client = mongo_session.client[collection]
        response = client.insert_many(docs)
        return response

    def transfer_docs_another_collection(self, from_collection, to_collection, condition):
        client = mongo_session.client[from_collection]
        temp_client = mongo_session.client[to_collection]
        for doc in client.find(condition):
            temp_client.insert_one(
                {"_id": doc['_id'], "s3_key": doc['s3_key'], "uploaded_at": doc['uploaded_at'],
                 "user_id": doc['user_id'],
                 "module_name": doc['module_name'],
                 "expires_at": doc['uploaded_at'] + course_resource_expiry_in_sec})
        response = client.remove(condition)
        return response
