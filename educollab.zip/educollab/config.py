from os.path import expanduser
import boto3
from botocore.client import Config
import os
from elasticsearch import Elasticsearch
from elasticsearch import RequestsHttpConnection

mongo_database = os.getenv('MONGO_DATABASE')
print(mongo_database)
mongousername = os.getenv('MONGOUSERNAME')
mongopassword = os.getenv('MONGOPASSWORD')
# mongo_ip_address="127.0.0.1"
mongo_ip_address = os.getenv('MONGO_IP_ADDRESS')
mongo_port = os.getenv('MONGO_PORT')
tokenKey = os.getenv('TOKENKEY')
email_password = os.getenv('EMAIL_PASSWORD')
email_Address = os.getenv('EMAIL_ADDRESS')

secret_key = os.getenv('SECRET_KEY')

password_secret_key = os.getenv('PASSWORD_SECRET_KEY')
session_token_secret_key = os.getenv('SESSION_TOKEN_SECRET_KEY')
secret_otp_key = os.getenv('SECRET_OTP_KEY')
ZOOM_API_KEY=  os.getenv('ZOOM_API_KEY')
ZOOM_API_SECRET=os.getenv('ZOOM_API_SECRET')
ZOOM_EMAIL=os.getenv('ZOOM_EMAIL')
bucket = os.getenv('BUCKET')

SIMILARITY_THRESHOLD = 0.9
CHAT_PAGINATE_lIMIt = 50
QUESTION_BANK_PATH = 'D:\\educollab\\questions.txt'
CONTENT_BANK_PATH = 'D:\\educollab\\content.txt'
COMMENTS_BANK_PATH = 'D:\\educollab\\comments.txt'
RATING_BANK_PATH = 'D:\\educollab\\ratings.txt'
USER_BASE_PATH = 'D:\\educollab\\users.txt'
GLOVE_PATH = "/home/ritu/Downloads/glove.6B.50d.txt"
download_path = "/home/ritu/EDUCOLLAB/git/educollab/data"

home_dir = expanduser("~")
upload_path = home_dir + "/git/videos"

s3_connection = boto3.client('s3', region_name='ap-south-1', config=Config(signature_version='s3v4'))
s3_resource = boto3.resource('s3', region_name='ap-south-1', config=Config(signature_version='s3v4'))

supported_image_content_type = ['.jpeg', '.png', '.gif', '.jpg']
supported_video_content_type = ['.mp4', '.mov']
other_supported_content_type = ['.pdf', '.ipynb', '.py', '.zip', '.doc', '.docx', '.ppt', '.pptx', '.txt', '.xml',
                                '.rar', '.csv', '.mp3', '.xlsx']
supported_content_type_with_extension = {
    '.pptx': 'application/vnd.openxmlformats-officedocument.presentationml'
             '.presentation',
    '.ppt': 'application/vnd.ms-powerpoint',
    '.docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml'
             '.document',
    '.doc': 'application/msword',
    '.zip': 'application/zip',
    '.mp4': 'video/mp4',
    '.mov': 'video/quicktime',
    '.jpeg': 'image/jpeg',
    '.png': 'image/png',
    '.gif': 'image/gif',
    '.jpg': 'image/jpeg',
    '.pdf': 'application/pdf',
    '.ipynb': 'application/x-python-code',
    '.py': 'application/x-python-code',
    '.txt': ' plain/text',
    '.xml': 'application/xml',
    '.rar': 'application/x-rar-compressed, application/octet-stream',
    '.csv': 'text/csv',
    '.mp3': 'audio/mpeg',
    '.xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
}
# expiry limit for one day
course_resource_expiry_in_sec = 86400

jwt_session_token_expiry_limit_in_days = 30
otp_exp_limit_reset_min = 5

coins_given_on_signup = float(100)
coins_given_on_course_subscription = float(5)

redis_broker_url = os.getenv('REDIS_BROKER_URL')
jwt_encoding_algorithm = os.getenv('JWT_ENCODING_ALGORITHM')

elastic_search_server_url = os.getenv('ELASTIC_SEARCH_URL')
elastc_search_creds = (os.getenv('ELASTIC_SEARCH_CREDS_1'), os.getenv('ELASTIC_SEARCH_CREDS_2'))
es = Elasticsearch(elastic_search_server_url, http_auth=(elastc_search_creds), use_ssl=True, verify_certs=False,
                   connection_class=RequestsHttpConnection)
firebase_api_key = os.getenv('FIREBASE_API_KEY')
static_public_prefix_url = "https://{}.s3.amazonaws.com/".format(bucket)

question_complexity_score = {
    'veryeasy': 1,
    'easy': 2,
    'average': 3,
    'difficult': 4,
    'advanced': 5
}

storage_paths = [
    {
        "module_name": "course",
        "path": "course-resources/",
        "supported_content": supported_video_content_type +
                             supported_image_content_type +
                             other_supported_content_type
    },
    {
        "module_name": "question-image",
        "path": "question-images/",
        "supported_content": supported_image_content_type
    },
    {
        "module_name": "question-video",
        "path": "question-videos/",
        "supported_content": supported_video_content_type
    },
    {
        "module_name": "question-file",
        "path": "question_bank_files/",
        "supported_content": other_supported_content_type
    },
    {
        "module_name": "recorded-sessions",
        "path": "recorded-sessions/",
        "supported_content": supported_video_content_type
    },
    {
        "module_name": "group-photo",
        "path": "group_photos/",
        "supported_content": supported_image_content_type
    },
    {
        "module_name": "global-resources",
        "path": "add-resources/",
        "supported_content": supported_video_content_type +
                             supported_image_content_type +
                             other_supported_content_type
    },
    {
        "module_name": "group-photo",
        "path": "group_photos/",
        "supported_content": supported_image_content_type
    },
    {
        "module_name": "chat-files",
        "path": "chat-files/",
        "supported_content": supported_video_content_type +
                             supported_image_content_type +
                             other_supported_content_type
    },
    {
        "module_name": "global-resources",
        "path": "add-resources/",
        "supported_content": supported_video_content_type +
                             supported_image_content_type +
                             other_supported_content_type
    },
    {
        "module_name": "answer",
        "path": "answer-resources/",
        "supported_content": supported_image_content_type
    },
    {
        "module_name": "answer-videos",
        "path": "answer-videos/",
        "supported_content": supported_video_content_type
    },
    {
        "module_name": "answer-video-thumbnail",
        "path": "answer-video-thumbnail/",
        "supported_content": supported_image_content_type
    },
    {
        "module_name": "answer-image",
        "path": "answer-images/",
        "supported_content": supported_image_content_type
    },
    {
        "module_name": "answer-file",
        "path": "answer-files/",
        "supported_content": other_supported_content_type
    },
    {
        "module_name": "passion_project",
        "path": "passion-project-resources/",
        "supported_content": supported_video_content_type +
                             supported_image_content_type +
                             other_supported_content_type
    },
    {
        "module_name": "recorded-sessions",
        "path": "recorded-sessions/",
        "supported_content": supported_video_content_type
    },
    {
        "module_name": "profile-avatar",
        "path": "profile-avatar/",
        "supported_content": supported_image_content_type
    },
    {
        "module_name": "attendance",
        "path": "attendance/",
        "supported_content": ['.csv']
    },
    {
        "module_name": "resume",
        "path": "resume/",
        "supported_content": supported_video_content_type +
                             other_supported_content_type
    }
]

DEFAULT_AVATAR = "passion-project-resources/1595505700-5f182a3ae47d0ecfa23548ec.jpeg"
AVAILABLE_AVATARS = ['profile-avatar/1611914004-5e748a2d5fc288e9f69c5f86.png',
                     'profile-avatar/1611914007-5e748a2d5fc288e9f69c5f86.png',
                     'profile-avatar/1611914011-5e748a2d5fc288e9f69c5f86.png',
                     'profile-avatar/1611914014-5e748a2d5fc288e9f69c5f86.png',
                     'profile-avatar/1611914018-5e748a2d5fc288e9f69c5f86.png',
                     'profile-avatar/1611914021-5e748a2d5fc288e9f69c5f86.jpg',
                     'profile-avatar/1611914024-5e748a2d5fc288e9f69c5f86.png',
                     'profile-avatar/1611914028-5e748a2d5fc288e9f69c5f86.png',
                     'profile-avatar/1611914031-5e748a2d5fc288e9f69c5f86.png',
                     'profile-avatar/1611914035-5e748a2d5fc288e9f69c5f86.png',
                     'profile-avatar/1611914038-5e748a2d5fc288e9f69c5f86.png',
                     'profile-avatar/1611914042-5e748a2d5fc288e9f69c5f86.png']

EDUCOLLAB_ENVIRONMENT = os.getenv('EDUCOLLAB_ENVIRONMENT')
ES_USER_PROFILE_INDEX = "user_profile_{}".format(EDUCOLLAB_ENVIRONMENT.lower())
ES_QUESTION_INDEX = "assessment_questions_{}".format(EDUCOLLAB_ENVIRONMENT.lower())
ES_RESOURCE_BANK_INDEX = "resource_bank_{}".format(EDUCOLLAB_ENVIRONMENT.lower())

ASSESSMENT_VIEW_COMPONENTS = {
    'Type': 'type',
    'Option': 'options',
    'Answer': 'answer',
    'Marks': 'marks',
    'Complexity': 'complexity',
    'Tags': 'tags'
}
EMPTY_STRING = ""

SITE_NAME = 'edu-collab.com'
SITE_SCHEMES = {'dev': 'http',
                'qa': 'http',
                'stage': 'http',
                'prod': 'https'
                }

""" API Site Domain will be 
    Development -> dev.api.edu-collab.com 
    same for QA and Stage
    Production -> api.edu-collab.com
    WEB Site Domain will be 
    Development -> dev.edu-collab.com 
    same for QA and Stage
    Production -> edu-collab.com
"""
API_SITE_DOMAIN = '{subdomain}{dot_segment}api.{site_name}'.format(
                    subdomain=EDUCOLLAB_ENVIRONMENT if EDUCOLLAB_ENVIRONMENT != 'prod' else '',
                    site_name=SITE_NAME,
                    dot_segment='.' if EDUCOLLAB_ENVIRONMENT != 'prod' else ''
                    )
WEB_SITE_DOMAIN = '{subdomain}{dot_segment}{site_name}'.format(
                    subdomain=EDUCOLLAB_ENVIRONMENT if EDUCOLLAB_ENVIRONMENT != 'prod' else '',
                    site_name=SITE_NAME,
                    dot_segment='.' if EDUCOLLAB_ENVIRONMENT != 'prod' else ''
                    )

WEB_BASE_URL = "{}://www.{}".format(SITE_SCHEMES.get(EDUCOLLAB_ENVIRONMENT, 'http'), WEB_SITE_DOMAIN)
API_BASE_URL = "{}://{}".format(SITE_SCHEMES.get(EDUCOLLAB_ENVIRONMENT, 'http'), API_SITE_DOMAIN)

# PERMISSIONS WITH SLUGS
deactivate_course = "deactivate_course"
show_permissions = "show_all_permissions"

# images in offline assessments
if EDUCOLLAB_ENVIRONMENT == "prod":
    img_down_mob_path = "asset:/data/user/0/tatras.educollab/cache/libCachedImageData/"
else:
    img_down_mob_path = "asset:/data/user/0/tatras.educollab.{}/cache/libCachedImageData/".format(EDUCOLLAB_ENVIRONMENT)

DEFAULT_DT_FORMAT = '%Y-%m-%d %H:%M:%S.%f'
EVENTS_PRIORITY = {"high": "red",
                   "medium": "blue",
                   "low": "yellow"}
DEFAULT_TIME_ZONE = "Asia/Kolkata"

ZOOM_JWT_TOKEN_EXP = 1800
CELERY_QUEUE = os.getenv('CELERY_QUEUE')

TANGO_SERVER = os.getenv('TANGO_SERVER')
ES_VIDEO_TRANSCRIBE = "video_transcriptions_{}".format(EDUCOLLAB_ENVIRONMENT.lower())
# ES_GLOBAL_SEARCH = "global_search_{}".format(EDUCOLLAB_ENVIRONMENT.lower())
ES_GLOBAL_SEARCH_COURSE = "global_search_course_{}".format(EDUCOLLAB_ENVIRONMENT.lower())
ES_GLOBAL_SEARCH_QUESTION = "global_search_question_{}".format(EDUCOLLAB_ENVIRONMENT.lower())
ES_GLOBAL_SEARCH_SESSION = "global_search_session_{}".format(EDUCOLLAB_ENVIRONMENT.lower())
ES_GLOBAL_SEARCH_MOSAIC = "global_search_mosaic_{}".format(EDUCOLLAB_ENVIRONMENT.lower())
