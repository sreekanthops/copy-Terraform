from .es_utils import get_connection
import json
import os
from six import add_metaclass
from elasticsearch import Elasticsearch
from future.utils import with_metaclass
from abc import ABCMeta


class DocumentMeta(type):
    def __new__(cls, name, bases, attrs):
        path = attrs.get('__path__', __file__)
        attrs['__path__'] = os.path.dirname(os.path.realpath(path))
        return super(DocumentMeta, cls).__new__(cls, name, bases, attrs)


@add_metaclass(DocumentMeta)
class DocumentMixin():
    __doc_type__ = '_doc'
    __using__ = 'default'

    @classmethod
    def _get_using(cls, using=None):
        return using or cls.__using__

    @classmethod
    def _get_connection(cls, using=None):
        return get_connection(cls._get_using(using))

    @classmethod
    def create_index(cls):
        schema = os.path.join(cls.__path__, 'schema.json')
        print("creating index = '{}'".format(cls.__index__), schema)

        with open(schema) as fp:
            mapping = json.load(fp)

        cls._get_connection().indices.create(cls.__index__, mapping)

    @classmethod
    def delete_index(cls):
        print("deleting index:{}".format(cls.__index__))
        return cls._get_connection().indices.delete(index=cls.__index__, ignore=[400, 404])

    @classmethod
    def get_index(cls):
        return cls._get_connection().indices.get(index=cls.__index__)

    @classmethod
    def put_example(cls):
        example = os.path.join(cls.__path__, 'example.json')
        print("pushing example for = '{}'".format(cls.__index__))

        with open(example) as fp:
            example = json.load(fp)

        return cls._get_connection().index(index=cls.__index__, doc_type=cls.__doc_type__, body=example)


class EmbeddingsMixin(DocumentMixin):

    def get_knn(self, query_vector=[], k=10, column='vector'):
        query = {
            "size": k,
            "query": {
                "knn": {
                    "{}".format(column): {
                        "vector": query_vector,
                        "k": k
                    }
                }
            }
        }

        res = self._get_connection().search(index=self.__index__, doc_type=self.__doc_type__, body=query)
        for doc in res['hits']['hits']:
            yield doc['_id'], doc['_score']

