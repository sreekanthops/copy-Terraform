from .test_embeddings import TestEmbeddings
