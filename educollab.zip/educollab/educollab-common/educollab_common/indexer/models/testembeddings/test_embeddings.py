import json
from ...document import EmbeddingsMixin


class TestEmbeddings(EmbeddingsMixin):
    __index__ = 'test_embeddings'
    __path__ = __file__
    __doc_type__ = '_doc'
    __using__ = 'default'

    def __init__(self, vectorizer='tfidf'):
        self._vectorizer = vectorizer

