from ...document import DocumentMixin


class TestDocument(DocumentMixin):
    __index__ = 'test_document'
    __path__ = __file__
    __doc_type__ = '_doc'
    __using__ = 'default'

    def __init__(self):
        pass

    def insert_example(self):
        return self._get_connection().index(index=self.__index__, doc_type=self.__doc_type__, \
            body={"url":"example.com", "content":"This is example content"})