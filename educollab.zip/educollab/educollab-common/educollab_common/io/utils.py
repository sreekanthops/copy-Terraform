from contextlib import contextmanager
import warnings
import sys

try:
    import cPickle as _pickle
except ImportError:
    import pickle as _pickle

def pickle(obj, fname, protocol=2):
    with open(fname, 'wb') as fout:  
        _pickle.dump(obj, fout, protocol=protocol)


def unpickle(fname):
    with open(fname, 'rb') as f:
        if sys.version_info > (3, 0):
            return _pickle.load(f, encoding='latin1')
        else:
            return _pickle.loads(f.read())

@contextmanager
def ignore_deprecation_warning():
    """Contextmanager for ignoring DeprecationWarning."""
    with warnings.catch_warnings():
        warnings.filterwarnings("ignore", category=DeprecationWarning)
        yield
        
