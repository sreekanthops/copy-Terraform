import requests
from copy import copy, deepcopy
from requests import HTTPError, RequestException


class Api:
    """ Generic class to wrap web APIs """
    params_to_etag = {}
    etag_to_response = {}

    def __init__(self, url, path):
        self.path = path
        self.url = url
        self.identity = None

    def request(self, params):
        self.build_path(params)
        self.old_params = copy(params)
        return self.send(params)

    def get_data(self, response):
        try:
            return response.json()
        except Exception:
            return response.text

    def add_content_type(self, headers):
        if not headers.__contains__("Content-Type"):
            headers["Content-Type"] = "application/json" 

    def send(self, params, no_refresh=False):
        query_data = frozenset(params.get('query', {}).items())
        params_key = (params.get('path'), query_data)
        etag = self.params_to_etag.get(params_key)

        method = params.get("method", "GET")
        headers = self.build_headers(params)
        data = self.build_data(params)
        json_body = self.build_json(params)
        query = self.build_query(params)
        url = self.build_url(params)

        if etag:
            headers['If-None-Match'] = etag

        response = requests.request(
            method, url, headers=headers, params=query,
            data=data, json=json_body, timeout=(3.05, 100)
        )
        if response.status_code == 304:
            # Etag matched, use response previously cached
            response = self.etag_to_response[etag]
        elif 'ETag' in response.headers:
            etag = response.headers['ETag'].strip('"')
            # Cache response for future lookup when we receive a 304
            self.params_to_etag[params_key] = etag
            self.etag_to_response[etag] = response

        return self.get_response(response, no_refresh)


    def get_response(self, response, no_refresh=False):
        data = self.get_data(response)

        if 200 <= response.status_code < 300:
            return data
        else:
            raise HTTPError(data, response=response)

    def build_headers(self, params):
        headers = params.get("headers", {})
        self.add_content_type(headers)
        params["headers"] = headers
        return headers

    def build_data(self, params):
        return params.get("data")

    def build_json(self, params):
        json = params.get("json")
        if json and params["headers"]["Content-Type"] == "application/json":
            for k, v in json.items():
                if v == "":
                    json[k] = None
            params["json"] = json
        return json

    def build_query(self, params):
        return params.get("query")

    def build_path(self, params):
        path = params.get("path", "")
        params["path"] = self.path + path
        return params["path"]

    def build_url(self, params):
        path = params.get("path", "")
        version = params.get("version", "")
        return self.url + "/" + version + "/" + path
