from ..educollab_common.indexer.models import TestDocument, TestEmbeddings
from ..educollab_common.indexer.es_utils import create_connection
import json


if __name__ == '__main__':
    
    create_connection('default' , hosts=['https://search-educollab-5ymf37y2crmc2b3hih4ulardv4.ap-south-1.es.amazonaws.com'])

    # test_document = TestDocument()
    # test_document.delete_index()
    # test_document.create_index()
    # test_document.insert_example()

    test_embeddings = TestEmbeddings()
    test_embeddings.delete_index()
    test_embeddings.create_index()
    test_embeddings.put_example()