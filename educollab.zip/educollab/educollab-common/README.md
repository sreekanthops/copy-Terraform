# Common Utils

## Install via pip
pip install -e .


##  Setup in the PYTHONPATH
export PYTHONPATH=${PYTHONPATH}:$HOME/educollab/educollab-common/
