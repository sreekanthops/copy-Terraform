import numpy as np
from nltk.tokenize import sent_tokenize,word_tokenize
from nltk.stem import WordNetLemmatizer
from nltk.corpus import stopwords


stop_words = set(stopwords.words('english'))
lemmatizer = WordNetLemmatizer()


from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression


class Model:

  def __init__(self):
    self.tfidf = TfidfVectorizer(sublinear_tf=True, min_df=4, norm='l2', ngram_range=(1, 2), stop_words='english')
    self.lr = LogisticRegression(max_iter=5000)

  def fit(self, x, y):

    x_vec = self.tfidf.fit_transform(x)
    self.lr.fit(x_vec, y)

  def commentPreProcessing(self, comment):
    comment = comment.lower()

    # Performing Tokenization
    sentences = sent_tokenize(comment)

    words = []

    for sentence in sentences:
      c_words = word_tokenize(sentence)

      for w in c_words:
        if w not in words:
          words.append(w)

    # Performing Lemmatization and stopword removal.
    words = [lemmatizer.lemmatize(w) for w in words if w not in stop_words]

    comment = ' '.join(w for w in words)
    return comment

  def predict(self, comment):

    comment = self.commentPreProcessing(comment)
    comm_list = []
    comm_list.append(comment)
    xt_vec = self.tfidf.transform(comm_list)

    pred = self.lr.predict(xt_vec)


    if pred[0] == 0:
      return "Non Toxic"
    else:
      return "Toxic"