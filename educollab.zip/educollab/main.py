import flask
from routes.api import api_app
from routes.course_apis import course_apis
from routes.questions_apis import question_apis
from routes.permissions_related_apis import permissions_apis
from routes.notifictaions_apis import notifications_apis
from routes.search import search_apis
from routes.general_apis import general_apis
from routes.passion_projects import passion_project_api
from flask_cors import CORS
from config import upload_path
from routes.organisation_apis import organisation_apis
from routes.user_apis import user_apis
from routes.assessment import assessment_api
from routes.team import teams_api
from routes.course_work import coursework_api
from routes.events import events_api
from routes.report import report_apis
from routes.user import users_apis
from routes.resource_bank import resource_bank_app
from routes.zoom_webhooks import zoom_webhook
from routes.taxonomy_api import taxonomy_category_api
from routes.transcription import transcript_apis
from routes.global_search import global_search_api
from routes.homepage import homepage_api
from routes.Questions import my_question_api
from routes.chat_api import chat_apis

app = flask.Flask(__name__)

app.config['UPLOAD_FOLDER'] = upload_path
CORS(app)
app.register_blueprint(api_app)
app.register_blueprint(resource_bank_app)
app.register_blueprint(course_apis)
app.register_blueprint(question_apis)
app.register_blueprint(permissions_apis)
app.register_blueprint(notifications_apis)
app.register_blueprint(search_apis)
app.register_blueprint(organisation_apis)
app.register_blueprint(general_apis)
app.register_blueprint(passion_project_api)
app.register_blueprint(user_apis)
app.register_blueprint(assessment_api)
app.register_blueprint(teams_api)
app.register_blueprint(coursework_api)
app.register_blueprint(events_api)
app.register_blueprint(report_apis)
app.register_blueprint(users_apis)
app.register_blueprint(zoom_webhook)
app.register_blueprint(taxonomy_category_api)
app.register_blueprint(transcript_apis)
app.register_blueprint(global_search_api)
app.register_blueprint(homepage_api)
app.register_blueprint(my_question_api)
app.register_blueprint(chat_apis)


@app.route('/healthcheck')
def healthcheck():
    return "ok"


if __name__ == "__main__":
    app.run(host="0.0.0.0", debug=True)
