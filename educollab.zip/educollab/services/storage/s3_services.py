import traceback

from pymongo import MongoClient
import pandas as pd
from bson.objectid import ObjectId
from bson.son import SON
from werkzeug.utils import secure_filename
import os
import config


class s3_storage():
    def __init__(self):
        self.Connection = config.s3_connection
        self.resource_connection = config.s3_resource

    def upload_data_to_s3_private(self, file, Content_Type, unique_key=None, folder_name=None, file_extension=None, s3_key=None):
        try:
            try:
                filename = secure_filename(file.filename)
                file.save(os.path.join(filename))
            except:
                filename = file

            s3_path = folder_name + unique_key + file_extension if unique_key else s3_key

            self.Connection.upload_file(filename, config.bucket, s3_path,
                                        ExtraArgs={'ContentType': Content_Type})

            upload_response = self.Connection.head_object(Bucket=config.bucket,
                                                          Key=s3_path)

            if upload_response['ResponseMetadata']['HTTPStatusCode'] == 200:
                s3_link = self.Connection.generate_presigned_url('get_object',
                                                                 Params={
                                                                     'Bucket': config.bucket,
                                                                     'Key': s3_path},
                                                                 ExpiresIn=604800)
                os.remove(filename)
                return {"status": 200,
                        "message": "uploaded data to s3",
                        "s3_link": s3_link,
                        "s3_key": s3_path}
            else:
                os.remove(filename)
                return {"status": 500,
                        "message": "Somrthing went wrong while uploading data to s3",
                        "s3_link": "",
                        "s3_key": ""}
        except Exception as e:
            traceback.print_exc()
            return {"status": 500,
                    "message": "Somrthing went wrong while uploading data to s3",
                    "detail": e.__str__()}

    def upload_data_to_s3_public(self, file, unique_key, folder_name, file_extension, Content_Type):
        try:
            s3_permanent_public_link = ""
            filename = secure_filename(file.filename)
            file.save(os.path.join(filename))

            upload_file_name = unique_key + file_extension

            self.Connection.upload_file(filename, config.bucket, folder_name + upload_file_name,
                                        ExtraArgs={'ContentType': Content_Type, 'ACL': "public-read"})

            upload_response = self.Connection.head_object(Bucket=config.bucket, Key=folder_name + upload_file_name)
            if upload_response['ResponseMetadata']['HTTPStatusCode'] == 200:
                s3_permanent_public_link = config.static_public_prefix_url + folder_name + upload_file_name

                os.remove(filename)
                return {"status": 200, "message": "uploaded data to s3", "s3_link": s3_permanent_public_link,
                        "s3_key": folder_name + upload_file_name}
            else:
                os.remove(filename)
                return {"status": 400, "message": "error while uploading data to s3", "s3_link": "",
                        "s3_key": ""}

        except Exception as e:
            return {"status": 400, "message": "error while uploading data to s3"}

    def delete_s3_data(self, filename):
        print('inside celery task')
        # client.delete_object(Bucket='mybucketname', Key='myfile.whatever')
        response = config.s3_connection.delete_object(Bucket=config.bucket, Key=filename)
        print(response)
        if (response['ResponseMetadata']['HTTPStatusCode'] == 204):
            return True
        else:
            return False

    def generate_presigned_url_from_s3(self, s3_key):
        try:
            s3_link = self.Connection.generate_presigned_url('get_object',
                                                             Params={
                                                                 'Bucket': config.bucket,
                                                                 'Key': s3_key},
                                                             ExpiresIn=604800)
            return s3_link, 200
        except Exception as e:
            # print(e)
            return "", 400

    def _key_existing_size__list(self, key):
        """return the key's size if it exist, else None
        :param key: path of file in s3 bucket"""
        response = self.Connection.list_objects_v2(
            Bucket=config.bucket,
            Prefix=key,
        )
        for obj in response.get('Contents', []):
            if obj['Key'] == key:
                return obj['Size']

    def create_multipart_upload_id(self, s3_key):
        """use only if file size is greater than 5mb as
           it is the minimum limit to use multipart upload functionality of s3"""
        mpu = self.Connection.create_multipart_upload(Bucket=config.bucket,
                                                      Key=s3_key)
        mpu_id = mpu["UploadId"]
        return mpu_id

    def upload_chunk(self, chunk_data, mpu_id, s3_key, part_index):
        part = self.Connection.upload_part(
            Body=chunk_data,
            Bucket=config.bucket,
            Key=s3_key,
            UploadId=mpu_id,
            PartNumber=part_index)
        part = {"PartNumber": part_index, "ETag": part["ETag"]}
        return part

    def complete_multipart_upload(self, mpu_id, parts, s3_key):
        """response format:
        {'ResponseMetadata': {'RequestId': '',
                              'HostId': '',
                              'HTTPStatusCode': 200,
                              'HTTPHeaders': {'x-amz-id-2': '',
                                              'x-amz-request-id': '',
                                              'date': 'Tue, 27 Jul 2021 10:18:31 GMT',
                                              'content-type': 'application/xml',
                                              'transfer-encoding': 'chunked',
                                              'server': 'AmazonS3'},
                              'RetryAttempts': 0},
         'Location': '',
         'Bucket': '',
         'Key': '',
         'ETag': ''}"""
        result = self.Connection.complete_multipart_upload(
            Bucket=config.bucket,
            Key=s3_key,
            UploadId=mpu_id,
            MultipartUpload={"Parts": parts})
        if result["ResponseMetadata"].get("HTTPStatusCode") != 200:
            return False
        return True
    
    def upload_file_to_s3_public(self, file_, unique_key, folder_name, file_extension, Content_Type):
        try:
            s3_permanent_public_link = ""

            upload_file_name = unique_key + file_extension

            self.Connection.upload_file(file_, config.bucket, folder_name + upload_file_name,
                                        ExtraArgs={'ContentType': Content_Type, 'ACL': "public-read"})

            upload_response = self.Connection.head_object(Bucket=config.bucket, Key=folder_name + upload_file_name)
            if upload_response['ResponseMetadata']['HTTPStatusCode'] == 200:
                s3_permanent_public_link = config.static_public_prefix_url + folder_name + upload_file_name

                os.remove(file_)
                return {"status": 200, "message": "uploaded data to s3", "s3_link": s3_permanent_public_link,
                        "s3_key": folder_name + upload_file_name}
            else:
                os.remove(file_)
                return {"status": 400, "message": "error while uploading data to s3", "s3_link": "",
                        "s3_key": ""}

        except Exception as e:
            return {"status": 400, "message": "error while uploading data to s3"}

    def upload_presigned_url(self, s3_key):
        try:
            url = self.Connection.generate_presigned_url(
                ClientMethod='put_object',
                Params={'Bucket': config.bucket, 'Key': s3_key},
                ExpiresIn=3600)
            return url, 200
        except Exception as e:
            # print(e)
            return "", 400

    def get_size_s3key(self, s3_key):
        try:
            size_obj = self.resource_connection.Object(config.bucket, s3_key)
            file_size = size_obj.content_length
            file_size = file_size/1024
            return file_size, 200
        except Exception as e:
            # print(e)
            return 0, 400
