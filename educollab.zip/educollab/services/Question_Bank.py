from model import Question_Bank as qb
import config

class Question_Bank(object):

    def get_similar_questions(question,language):
        original_question = language
        if language != 'English':
            english_question = Question_Bank.translate_question(question, language)
        else:
            english_question = question
        return qb.close_match(english_question)

    def get_open_questions(self):
        pass

    @staticmethod
    def translate_question(question,language):
        return question