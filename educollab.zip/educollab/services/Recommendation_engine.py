# -*- coding: utf-8 -*-


"""
  Building recommendation engine
"""
from mongo_connection import connection
from bson import ObjectId


def fetch_user_asked_questions(user_id):
    """we will fetch user asked questions to create a profile here"""
    collection=connection.user_profile
    user_asked_question=[]
    question_collection=connection.question_bank
    try:
        user_data=[]
        user_cursor=collection.find({"_id": ObjectId(user_id)})
        for user_info in user_cursor:
            user_data=user_info["questions"]
        for question_id in user_data:
            _id=question_id["_id"]
            question_cursor=question_collection.find({"_id":ObjectId(_id)})
            for question_asked in question_cursor:
                try:
                    user_asked_question.append(question_asked["translated_question"])

                except Exception as e:
                    print(e)
                    pass

    except Exception as e:
        user_asked_question = None
    return user_asked_question


def fetch_answered_questions(user_id):
    """we will fetch user asked questions which are approved to create a profile here"""
    collection=connection.user_profile
    user_answered_question=[]
    answer_collection=connection.answer_bank
    question_collection=connection.question_bank
    try:
        user_data=[]
        user_cursor=collection.find({"_id": ObjectId(user_id)})
        for user_info in user_cursor:
            user_data=user_info["answers"]
        for answer_id in user_data:
            _id=answer_id["_id"]

            answer_cursor=answer_collection.find({"_id":_id})
            for  answer in answer_cursor:
                try:
                    if answer['approval_status']==1:
                        question_id=answer['question_id']
                        question_cursor = list(question_collection.find({"_id": ObjectId(question_id)}))
                        user_answered_question.append({"question":question_cursor[0]["translated_question"],"question_id":str(question_cursor[0]['_id'])})

                except Exception as e:
                    print(e)
                    pass

    except Exception as e:
        user_answered_question = None
    return user_answered_question
