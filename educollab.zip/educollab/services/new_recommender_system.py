from sklearn.feature_extraction.text import TfidfVectorizer
import numpy as np
from sklearn.metrics.pairwise import linear_kernel
import random
from mongo_connection import connection
from bson import ObjectId
import config

def rs_check(user_id):
    check = connection['question_tracking'].find_one({"user_id":user_id})
    if check:
        return True
    else:
        return False

def get_recommendation(string, questions, cosine_sim):
    idx = questions.index(string)
    sim_scores = list(enumerate(cosine_sim[idx]))
    sim_scores = sorted(sim_scores, key=lambda x: x[1], reverse=True)
    sim_scores = sim_scores[1:6]
    indices = [i[0] for i in sim_scores]
    return list(set(questions[x] for x in indices))

def recommender_system(user_id):

    Questions = connection['question_bank'].find({"user_id": {"$nin": ['celery_service']}})
    questions = []
    questions_id = []
    for x in Questions:
        questions.append(x['questions'])
        questions_id.append(x['_id'])

    tfidf = TfidfVectorizer(stop_words='english')
    tfidf_matrix = tfidf.fit_transform(np.array(questions))
    cosine_sim = linear_kernel(tfidf_matrix, tfidf_matrix)
    user_specific_questions = connection['question_tracking'].find({"user_id":user_id})
    user_specific_questions = [ObjectId(x['question_id']) for x in user_specific_questions]
    user_question_bank = connection['question_bank'].aggregate(
        [{ "$match": { "_id": { "$in": user_specific_questions  }} },{
        "$group" : 
            {"_id" : {"questions":"$questions"}
                }}
        ])
    questions_seen_by_user = [x['_id']['questions'] for x in user_question_bank]
    questions_set = []
    for x in questions_seen_by_user:
        try:
            questions_set.extend(get_recommendation(x, questions, cosine_sim))
        except:
            continue
    questions_set = random.sample(list(set(questions_set)), 5)
    questions_set_ids = [questions_id[questions.index(x)] for x in questions_set]

    output_data = []
    for x in questions_set_ids:
        temp_dict = {}
        try:
            data_cursor = connection['question_bank'].find({"_id": ObjectId(x)})
        except:
            continue
        for data in data_cursor:
            temp_dict['Course_Category'] = data['Course_Category']
            temp_dict['question'] = data['questions']
            temp_dict['_id'] = str(data['_id'])
            temp_dict['reward'] = float(data['reward'])
            temp_dict['question_image_path'] = data['question_image_path']
            if data['question_image_path'] and data['question_image_path'] != "null" and data['question_image_path'] != "None":
                temp_dict['question_image_path'] = config.s3_connection.generate_presigned_url('get_object',
                                                                                Params={'Bucket': config.bucket,
                                                                                        'Key': data[
                                                                                            'question_image_path']},
                                                                                ExpiresIn=604800)
            

            if data.get("course_id"):
                temp_dict['course_id'] = str(data["course_id"])
                temp_dict['course_session_id'] = str(data["course_session_id"])
                temp_dict['resume_video'] = data["video_time"]
            else:
                temp_dict['course_id'] = ""
                temp_dict['course_session_id'] = ""
                temp_dict['resume_video'] = ""
        output_data.append(temp_dict)    
                      
    return output_data

