from mongo_connection import connection
collection=connection.user_profile
from db_wrapper.tasks import Mongo
mongo_session=Mongo()


def organization_leaderborad():
    """to calculate organization ranking"""
    ranking_data = mongo_session.get_organisation_info_organisation_leaderboard(
        collection="user_profile",
        condition=[{"$group": {"_id": {"organisation": "$organisation"},
                               "coin": {"$sum": '$coin'}}},
                   {"$sort": {"coin": -1}}])
    status = ranking_data['status']
    ranking_list = ranking_data['message']

    organisation_ranking = list()
    for iter in range(len(ranking_list)):
        organisation_name = ranking_list[iter]["_id"]["organisation"]
        score_count = ranking_list[iter]['coin']
        organisation_ranking.append({"organisation": organisation_name,
                                     "score": score_count,
                                     "rank": ranking_list[iter]['rank']})

    return organisation_ranking, status
