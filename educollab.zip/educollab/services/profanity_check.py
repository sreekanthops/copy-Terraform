from better_profanity import profanity


def check_profanity(comment):
    """to check the profanity"""
    bad_word_list=["stupid","dump","crap","shit"]
    profanity_result=profanity.contains_profanity(comment)
    if profanity_result==True:
        return profanity_result
    else:
        comment = comment.lower()
        comment = comment.split()
        count = 0
        word = ""
        for iter in range(len(comment)):
            if (comment[iter] in bad_word_list):
                word = word + " " + comment[iter]
                count += 1
        if count>0:
            profanity_result=True
        else:
            profanity_result=False
    return profanity_result