# from model import User_Base
from mongo_connection import connection
from bson import ObjectId
from db_wrapper.tasks import Mongo

mongo_session = Mongo()


# class User_Leaderboard(object):
#
#     def get_leaderboard(self, num_members):
#         self.users = User_Base.get_user_base()


def user_ranking(user_id, current_user_name, current_user_coin):
    """ranking of students on the basis of coins"""
    user_info_with_id = mongo_session.get_user_leaderboard_info_user_leaderboard(
        current_user_coin=current_user_coin,
        user_id=user_id,
        collection="user_profile",
        condition=[{"$group": {"_id": {"coin": "$coin"},
                               "user_id": {"$push": "$_id"}}},
                   {"$sort": {"_id.coin": -1}}])
    status = user_info_with_id['status']
    user_list = user_info_with_id['message']
    return user_list, status
