class Embedding(object):
    def __init__(self):
        self.val = ''

    @staticmethod
    def get_embedding(text):
        vect = VectorizerFactory.factory('GloveVectorizer')
        vect.fit([text])
        vect.load()
        return vect.predict(text).tolist()

from abc import ABC, abstractmethod
from sklearn.feature_extraction.text import TfidfVectorizer
from config import GLOVE_PATH
import numpy as np
import re

class Vectorizer(ABC):
    vectorizer = None
    idf_ = None
    vocabulary_ = None

    @abstractmethod
    def predict(self, text):
        pass

    @abstractmethod
    def fit(self, data):
        pass

    def info(self):
        return self.__name__

class VectorizerFactory(object):
    # Create based on class name:
    @staticmethod
    def factory(vector_type):
        if vector_type == "TFIDFVectorizer": return TFIDFVectorizer()
        if vector_type == "Word2VecVectorizer": return Word2VecVectorizer()
        if vector_type == "GloveVectorizer": return GloveVectorizer()
        assert 0, "Bad vectorizer creation: " + vector_type

class TFIDFVectorizer(Vectorizer):
    def predict(self, text):
        return self.vectorizer.transform([text])

    def predict_bulk(self, texts):
        return self.vectorizer.transform(texts)

    def fit(self, data):
        self.vectorizer = TfidfVectorizer(norm=None,analyzer='word',stop_words='english')
        self.vectorizer.fit(data)
        self.idf_ = self.vectorizer.idf_
        self.vocabulary_ = self.vectorizer.vocabulary_

    def fit_transform(self, data):
        self.vectorizer = TfidfVectorizer()
        return self.vectorizer.fit_transform(data)


class Word2VecVectorizer(Vectorizer):
    def predict(self, text):
        pass

    def fit(self, data):
        pass

class GloveVectorizer(Vectorizer):

    def __init__(self):
        self.dim_glove = 50
        self.array_w = []
        self.my_embeds = []

    def load(self, path=GLOVE_PATH, dim=50):
        self.dim_glove = dim
        w2v = {}
        with open(path.format(self.dim_glove), "r", encoding="utf8") as lines:
            for line in lines:
                word = line.split()[0]
                if word in self.vectorizer.vectorizer.vocabulary_:
                    this_embed = np.array(list(map(float, line.split()[1:])))
                    w2v[word] = this_embed

        for word, index in sorted(list(self.vectorizer.vectorizer.vocabulary_.items()), key=lambda x: x[1]):
            if word in w2v:
                self.my_embeds.append(w2v[word])
            else:
                self.my_embeds.append(np.zeros(self.dim_glove))

    def fit(self, data):
        # fit a vectorizer to get the word weights for combining word vectors to get doc2vec
        self.vectorizer = VectorizerFactory.factory('TFIDFVectorizer')
        self.vectorizer.fit(data)
        self.idf_ = self.vectorizer.vectorizer.idf_
        self.vocabulary_ = self.vectorizer.vectorizer.vocabulary_

    def predict(self, text):
        my_vectors = self.vectorizer.vectorizer.transform([text])
        return my_vectors.dot(np.array(self.my_embeds))/np.sum(my_vectors,axis=1)

    def predict_bulk(self, texts):
        my_vectors = self.vectorizer.vectorizer.transform(texts)
        return my_vectors.dot(np.array(self.my_embeds))

