import json
import datetime

from services.common import errors
from flask import Response
from bson import ObjectId

class ResponseObject:
    def __init__(self, result, status="Success", **kwargs):
        self.status = status
        self.result = result
        if 'error_code' in kwargs and 'message' not in kwargs:
            self.error = dict(code=errors.unknown_error, message=errors.unknown_error_msg)
        if 'error_code' in kwargs and 'message' in kwargs:
            self.error = dict(code=kwargs['error_code'], message=kwargs['message'])
        else:
            self.error = None

    def get_dict(self):
        output = dict(status=self.status, result=self.result, error=self.error)
        return output

from json import JSONEncoder
from model import Question

class MyJSONEncoder(JSONEncoder):
    def default(self, obj):
        if isinstance(obj,Question.Question):
            return obj.__dict__
        return JSONEncoder.default(self, obj)

# class JSONEncoder(json.JSONEncoder):
#     def default(self, o):
#         if isinstance(o, ObjectId):
#             return str(o)
#         if isinstance(o, datetime.datetime):
#             return str(o)
#         return json.JSONEncoder.default(self, o)


def jsonize(data={}, status_code=200, **kwargs):
    resp = ResponseObject(data, **kwargs)
    resp_dict = resp.get_dict()
    json_encoded = JSONEncoder().encode(resp_dict)
    json_dict = json.loads(json_encoded)
    if json_dict['error'] is not None :
        json_dict['code'] = json_dict['error']['code']
        json_dict['message'] = json_dict['error']['message']
    json_dict.pop('error')
    return Response(status=status_code, response=json.dumps(json_dict), mimetype='application/json')
