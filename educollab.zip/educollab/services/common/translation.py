# -*- coding: utf-8 -*-


"""
    common translation pieces
"""

from googletrans import Translator


def question_translation(question,dest="en"):
    """Using this to translate question """
    translator=Translator()
    translation=translator.translate(question,dest)
    translated_question=translation.text
    print(translated_question,"transdldflk")
    return translated_question,dest