unknown_error = 'unknown_error'
unknown_error_msg = "An unknown exception occurred."
