# -*- coding: utf-8 -*-

"""JWT token and session management will be handled in this file  """
import jwt
from config import tokenKey

def get_user_id(auth_token):
    """given an authentication token we would want to fetch the user information"""
    auth_response = authenticate_token(auth_token=auth_token)
    if auth_response['token_ok']:
        payload = auth_response['payload']
        user_obj_id = payload['_id']
        return user_obj_id
    else:
        return None

def authenticate_token(auth_token):
    try:
        auth_token = auth_token.split(' ')[-1]
        payload = jwt.decode(auth_token, tokenKey)
        if payload:
            return {"token_ok": True, "payload": payload}
    except Exception as e:
        print('exception logged',e)
        return {"token_ok": False}
