import traceback
from model import general
from flask import request, Response, json, Blueprint, jsonify
from model.User import login
from routes.exception import InvalidUsage
from services.storage.s3_services import s3_storage

s3_function = s3_storage()
from config import AVAILABLE_AVATARS
from Zoom_Package import Zoom

general_apis = Blueprint("general_api", __name__)


@general_apis.route("/upload-resource", methods=['POST'])
@login
def upload_resource(role, organisation, permissions, login_user_other_details):
    try:
        files = request.files
        user_id = login_user_other_details['_id']
        module_name = request.args['module_name']

    except KeyError as e:
        traceback.print_exc()
        return Response(json.dumps({"message": "Bad Request", "detail": e.__str__()}), mimetype='application/json',
                        status=400)
    try:
        response_data = general.upload_resource_to_s3(files=files,
                                                      module_name=module_name,
                                                      user_id=user_id)
        response = {"message": "File uploaded successfully", "resource_info": response_data}
        return Response(json.dumps(response), mimetype='application/json', status=201)

    except InvalidUsage as e:
        error = {"message": e.message, "status": e.status_code}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])

    except Exception as e:
        traceback.print_exc()
        error = {"message": "Internal server error", "status": 500, "detail": e.__str__()}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])


@general_apis.route('/get-avatars', methods=['GET'])
@login
def fetch_avatars(role, organisation, permissions, login_user_other_details):
    try:
        avatar_s3_url = []
        for avatar in AVAILABLE_AVATARS:
            response_data, status_code = s3_function.generate_presigned_url_from_s3(avatar)
            avatar_s3_url.append({"url": response_data,
                                  "path": avatar})
        return Response(json.dumps({"resource_info": avatar_s3_url}),
                        mimetype='application/json',
                        status=200)
    except Exception as e:
        traceback.print_exc()
        data = {"detail": e.__str__(),
                "message": "Oops! Something went wrong, Please try again later."}
        return Response(json.dumps(data), mimetype='application/json', status=500)


@general_apis.route('/delete_resource', methods=['POST'])
@login
def delete_resource_api(role, organisation, permissions, login_user_other_details):
    try:
        s3_key = request.args.get('s3_key')
        data = request.json
    except KeyError as e:
        traceback.print_exc()
        return Response(json.dumps({"message": "Bad Request", "detail": e.__str__()}), mimetype='application/json',
                        status=400)
    try:
        response_data = False
        if s3_key:
            response_data = s3_function.delete_s3_data(filename=s3_key)
        if data:
            for s3_path in data["deleted_files"]:
                response_data = s3_function.delete_s3_data(filename=s3_path)
        if response_data:
            return Response(json.dumps({"message": "Successfully deleted", "status": 200}),
                            mimetype='application/json',
                            status=200)
        else:
            return Response(json.dumps({"message": "Not able to delete right now", "status": 400}),
                            mimetype='application/json',
                            status=400)
    except Exception as e:
        traceback.print_exc()
        data = {"detail": e.__str__(),
                "message": "Oops! Something went wrong, Please try again later."}
        return Response(json.dumps(data), mimetype='application/json', status=500)



