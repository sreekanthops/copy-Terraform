import traceback
from model.zoom.zoom_webhooks import add_joined_participant, add_uuid_to_occurrence_id, process_zoom_meeting
from flask import request, Response, json, Blueprint

from routes.exception import InvalidUsage

zoom_webhook = Blueprint("zoom_webhook", __name__)


@zoom_webhook.route("/zoom-meeting/participant/joined", methods=["POST"])
def add_live_zoom_attendance():
    """
        Zoom webhook to get all the participants details who joined the meeting.
    """
    try:
        account_id = request.json["payload"]["account_id"]
        other_details = request.json["payload"]["object"]
        response = add_joined_participant(account_id=account_id,
                                          other_details=other_details)
        return Response(json.dumps(response), mimetype='application/json', status=201)

    except KeyError as e:
        traceback.print_exc()
        data = {"message": "Missing mandatory information in Request Payload",
                "detail": e.__str__()}
        return Response(json.dumps(data), mimetype='application/json', status=400)

    except Exception as e:
        traceback.print_exc()
        data = {"detail": e.__str__(),
                "message": "Oops! Internal Server Error, Please try again later."}
        return Response(json.dumps(data), mimetype='application/json', status=500)


@zoom_webhook.route("/recording_uploaded_trigger", methods=['POST'])
def upload_session_resource():
    """
    Zoom Webhook: to know when the recording is completed for particular zoom meeting.
    """
    try:
        event = request.json
        meeting_id = int(event["payload"]["object"]["id"])
        uuid = event["payload"]["object"]["uuid"]
        response_data = process_zoom_meeting(meeting_id=meeting_id,
                                             uuid=uuid,
                                             response=event,
                                             module_name="recorded-sessions")
        return Response(json.dumps(response_data), mimetype='application/json', status=201)

    except InvalidUsage as e:
        traceback.print_exc()
        error = {"message": e.message, "detail": e.message}
        return Response(json.dumps(error), mimetype='application/json', status=e.status_code)

    except Exception as e:
        traceback.print_exc()
        error = {"message": "Internal server error, please try again later.",
                 "detail": e.__str__()}
        return Response(json.dumps(error), mimetype='application/json', status=500)


@zoom_webhook.route("/end_meeting_trigger", methods=['POST'])
def end_session():
    try:
        event = request.json
        meeting_id = int(event["payload"]["object"]["id"])
        # new generated uuid after the meeting occurrence
        uuid = event["payload"]["object"]["uuid"]
        response = add_uuid_to_occurrence_id(meeting_id=meeting_id,
                                                     uuid=uuid,
                                                     event=event)
        return Response(json.dumps(response), mimetype='application/json', status=201)

    except Exception as e:
        traceback.print_exc()
        error = {"message": "Internal server error, Please try again later.",
                 "detail": e.__str__()}
        return Response(json.dumps(error), mimetype='application/json', status=500)
