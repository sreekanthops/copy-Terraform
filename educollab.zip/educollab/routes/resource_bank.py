from flask import request, Response, json, Blueprint, jsonify
from db_wrapper.tasks import Mongo
from model.User import login
from utils.elasticsearch.resource_bank import search_resources
from model import Resource_bank as res_bank

mongo_session = Mongo()

import traceback
from routes.exception import InvalidUsage
from services.storage.s3_services import s3_storage

s3_function = s3_storage()

resource_bank_app = Blueprint("resource_bank_api", __name__)


@resource_bank_app.route('/resource-bank', methods=['GET'])
@login
def resource_bank(role, organisation, permissions, login_user_other_details):
    user_id = login_user_other_details['_id']
    if request.args.get('file_type'):
        file_type = request.args.get('file_type')
    else:
        file_type = ""
    page = int(request.args.get('page'))
    try:
        response, total_pages = res_bank.get_all_resources(file_type=file_type, page=page, role=role, user_id=user_id)
        data = {"response": response, "total_pages": total_pages, "current_page": page}
        return Response(json.dumps(data), mimetype='application/json', status=200)

    except InvalidUsage as e:
        traceback.print_exc()
        error = {"message": e.message}
        return Response(json.dumps(error), mimetype='application/json', status=e.status_code)

    except Exception as e:
        traceback.print_exc()
        response = {"message": "Internal server error", "status": 500, "detail": e.__str__()}
        return Response(json.dumps(response), mimetype='application/json', status=response['status'])


@resource_bank_app.route('/search-resource', methods=['GET'])
@login
def search_resource_bank(role, organisation, permissions, login_user_other_details):
    try:
        query = request.args.get('query')
        user_id = login_user_other_details['_id']
        if request.args.get("type"):
            file_type = request.args.get("type")
            response = search_resources(data=query, filetype=file_type, role=role, user_id=user_id)
        else:
            response = search_resources(data=query, role=role, user_id=user_id)
        return Response(json.dumps(response), mimetype='application/json', status=200)

    except InvalidUsage as e:
        traceback.print_exc()
        error = {"message": e.message}
        return Response(json.dumps(error), mimetype='application/json', status=e.status_code)

    except Exception as e:
        traceback.print_exc()
        response = {"message": "Internal server error", "status": 500, "detail": e.__str__()}
        return Response(json.dumps(response), mimetype='application/json', status=response['status'])


@resource_bank_app.route('/resource-bank/edit', methods=['POST'])
@login
def edit_resource_bank(role, organisation, permissions, login_user_other_details):
    """Superadmin/teacher can edit the resource such as add description and title."""
    user_id = login_user_other_details['_id']
    try:
        data = request.json
        tags = data['tags']
        description = data["description"]
        resource_id = data["resource_id"]
        title = data["title"]
        instance_id = data['instance_id']
    except KeyError:
        traceback.print_exc()
        data = {"status": 400, "message": "Please check request data."}
        return Response(json.dumps(data), mimetype='application/json', status=400)
    try:
        response_message = res_bank.edit_resource_bank(resource_id=resource_id,
                                                       role=role,
                                                       user_id=user_id,
                                                       tags=tags,
                                                       description=description,
                                                       title=title,
                                                       instance_id=instance_id)
        return Response(json.dumps(response_message), mimetype='application/json', status=201)
    except InvalidUsage as e:
        traceback.print_exc()
        error = {"message": e.message, "detail": e.message}
        return Response(json.dumps(error), mimetype='application/json', status=e.status_code)
    except Exception as e:
        traceback.print_exc()
        error = {"detail": e.__str__(), "message": "Oops! something went wrong, Please try again later."}
        return Response(json.dumps(error), mimetype='application/json', status=500)


@resource_bank_app.route('/resource-bank/delete', methods=['DELETE'])
@login
def delete_resource_bank(role, organisation, permissions, login_user_other_details):
    """Superadmin/teacher can delete the resource."""
    user_id = login_user_other_details['_id']
    try:
        resource_id = request.args.get("resource_id")
        instance_id = request.args.get('instance_id')
    except KeyError:
        traceback.print_exc()
        data = {"status": 400, "message": "Please check request data."}
        return Response(json.dumps(data), mimetype='application/json', status=400)
    try:
        response_message = res_bank.delete_resource_bank(resource_id=resource_id,
                                                         role=role,
                                                         user_id=user_id,
                                                         instance_id=instance_id)
        return Response(json.dumps(response_message), mimetype='application/json', status=201)
    except InvalidUsage as e:
        traceback.print_exc()
        error = {"message": e.message, "detail": e.message}
        return Response(json.dumps(error), mimetype='application/json', status=e.status_code)
    except Exception as e:
        traceback.print_exc()
        error = {"detail": e.__str__(), "message": "Oops! something went wrong, Please try again later."}
        return Response(json.dumps(error), mimetype='application/json', status=500)


@resource_bank_app.route('/resource-bank/add', methods=['POST'])
@login
def add_resource_bank(role, organisation, permissions, login_user_other_details):
    """Superadmin/teacher can delete the resource."""
    user_id = login_user_other_details['_id']
    try:
        data = request.json
        resource_id = data["resource_id"]
        title = data["title"]
        tags = data["tags"]
        description = data["description"]
    except KeyError:
        traceback.print_exc()
        data = {"status": 400, "message": "Please check request data."}
        return Response(json.dumps(data), mimetype='application/json', status=400)
    try:
        response_message = res_bank.add_resources(resource_id=resource_id,
                                                  role=role,
                                                  user_id=user_id,
                                                  title=title,
                                                  tags=tags,
                                                  description=description)
        return Response(json.dumps(response_message), mimetype='application/json', status=201)
    except InvalidUsage as e:
        traceback.print_exc()
        error = {"message": e.message, "detail": e.message}
        return Response(json.dumps(error), mimetype='application/json', status=e.status_code)
    except Exception as e:
        traceback.print_exc()
        error = {"detail": e.__str__(), "message": "Oops! something went wrong, Please try again later."}
        return Response(json.dumps(error), mimetype='application/json', status=500)
