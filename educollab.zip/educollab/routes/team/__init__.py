from flask import Blueprint

teams_api = Blueprint('teams', __name__)

from routes.team import course_work
