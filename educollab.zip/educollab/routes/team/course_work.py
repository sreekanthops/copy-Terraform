from routes.exception import InvalidUsage
from routes.team import teams_api
from flask import request, Response, json, redirect
from model.User import login
import model.team.team_creation as team_creation
import traceback


@teams_api.route('/course-work/teams', methods=["Post"])
@login
def create_course_work_team(role, organisation, permissions, login_user_other_details):
    user_id = login_user_other_details["_id"]
    try:
        data = request.get_json()
        group_type = data["group_type"]
        course_work_id = data["course_work_id"]
        course_instance_id = data["course_instance_id"]
        course_id = data["course_id"]
        team_info = data["team_info"]
        reset = data["reset"]
    except KeyError as key_err:
        traceback.print_exc()
        data = {"status": 400, "message": "Please check request data.", "detail": key_err.__str__()}
        return Response(json.dumps(data), mimetype='application/json', status=400)
    try:
        message = team_creation.create_team(
            role=role,
            user_id=user_id,
            group_type=group_type,
            course_work_id=course_work_id,
            course_id=course_id,
            course_instance_id=course_instance_id,
            team_info=team_info,
            reset=reset
        )
        response = {"message": message}
        return Response(json.dumps(response), mimetype='application/json', status=200)
    except InvalidUsage as e:
        traceback.print_exc()
        error = {"message": e.message, "status": e.status_code}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])

    except Exception as e:
        traceback.print_exc()
        response = {"message": "Internal server error.", "detail": e.__str__()}
        return Response(json.dumps(response), mimetype='application/json', status=500)


@teams_api.route('/course-work/teams/invite', methods=["Get"])
def update_approval_status():
    try:
        course_instance_id = request.args["course_instance_id"]
        course_work_id = request.args["course_work_id"]
        team_name = request.args["team_name"]
        response = request.args["response"]
        user_id = request.args["user_id"]
        course_id = request.args["course_id"]
    except KeyError as key_err:
        traceback.print_exc()
        data = {"status": 400, "message": "Please check request data.", "detail": key_err.__str__()}
        return Response(json.dumps(data), mimetype='application/json', status=400)
    redirect_status = request.args.get("redirect")
    try:
        response_data, status = team_creation.update_member_approval(
            user_id=user_id,
            course_work_id=course_work_id,
            course_instance_id=course_instance_id,
            response=response,
            team_name=team_name,
            redirect_status=redirect_status,
            course_id=course_id)
        if status == 302:
            return redirect(response_data, code=302)
        else:
            response = {"message": response_data}
            return Response(json.dumps(response), mimetype='application/json', status=status)
    except Exception as e:
        traceback.print_exc()
        response = {"message": "Internal server error.", "detail": e.__str__()}
        return Response(json.dumps(response), mimetype='application/json', status=500)
