from flask import request, Response, json, Blueprint, jsonify
from model.User import login
import model.User as User
import traceback
from model import roles
from routes.exception import InvalidUsage

permissions_apis = Blueprint("permissions_api", __name__)


@permissions_apis.route('/permissions', methods=['GET'])
@login
def show_all_permissions(role, organisation, permissions, login_user_other_details):
    try:
        res = User.show_all_permission(permissions=permissions)
        return Response(json.dumps(res), mimetype='application/json', status=res['status'])
    except InvalidUsage as e:
        traceback.print_exc()
        data = {"detail": e.message,
                "message": e.message,
                "status": e.status_code}
        return Response(json.dumps(data), mimetype='application/json', status=e.status_code)

    except Exception as e:
        error = {"message": "Internal Server Error.", "status": 500, "detail": e.__str__()}
        return Response(json.dumps(error), mimetype='application/json', status=500)


@permissions_apis.route('/permissions/roles', methods=['GET'])
@login
def get_roles_permission(role, organisation, permissions, login_user_other_details):
    try:
        res = User.get_roles_permissions(permissions=permissions)
        return Response(json.dumps(res), mimetype='application/json', status=res['status'])
    except InvalidUsage as e:
        traceback.print_exc()
        data = {"detail": e.message,
                "message": e.message,
                "status": e.status_code}
        return Response(json.dumps(data), mimetype='application/json', status=e.status_code)

    except Exception as e:
        traceback.print_exc()
        error = {"message": "Internal Server Error.", "status": 500, "detail": e.__str__()}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])


@permissions_apis.route('/permissions/roles', methods=['PATCH'])
@login
def remove_or_add_permissions(role, organisation, permissions, login_user_other_details):
    try:
        permissions_data = request.get_json()
        permissions_slug = permissions_data['permissions_slug']
        add_or_del_flag = permissions_data['flag']
        update_role_id = permissions_data['role_id']
        res = User.add_or_remove_permissions_for_role(permissions=permissions, permissions_slug=permissions_slug,
                                                           add_or_del_flag=add_or_del_flag,
                                                           update_role_id=update_role_id)
        return Response(json.dumps(res), mimetype='application/json', status=res['status'])
    except InvalidUsage as e:
        traceback.print_exc()
        data = {"detail": e.message,
                "message": e.message,
                "status": e.status_code}
        return Response(json.dumps(data), mimetype='application/json', status=e.status_code)

    except Exception as e:
        traceback.print_exc()
        error = {"message": e.__str__(), "status": 500}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])


@permissions_apis.route('/roles', methods=['GET'])
@login
def fetch_roles(role, organisation, permissions, login_user_other_details):
    try:
        roles_list, message, api_status = roles.fetch_roles_info(role=role)
        response = {"message": message, "roles_info": roles_list}
        return Response(json.dumps(response), mimetype='application/json', status=api_status)
    except Exception as e:
        traceback.print_exc()
        error = {"message": e.__str__(), "status": 500}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])


@permissions_apis.route('/add_role', methods=['POST'])
@login
def add_new_role(role, organisation, permissions, login_user_other_details):
    try:
        data = request.get_json()
        new_role = data['display_name']
    except KeyError:
        traceback.print_exc()
        error = {"message": "please check request data", "status": 400, "data": {}}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])
    try:
        data, message, api_status = roles.add_new_role(new_role=new_role, user_role=role)
        response = {"message": message, "status": api_status, "data": data}
        return Response(json.dumps(response), mimetype='application/json', status=api_status)
    except Exception as e:
        traceback.print_exc()
        error = {"message": e.__str__(), "status": 500, "data": {}}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])
