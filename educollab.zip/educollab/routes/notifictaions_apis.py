from flask import request,Response,json,Blueprint,jsonify
import model.User as User
from model.User import login
import model.Notification as Notifictaion

notifications_apis = Blueprint("notification_api", __name__)

@notifications_apis.route("/add_update_user_device_token",methods=['POST'])
@login
def add_update_user_device_token(role,organisation,permissions,login_user_other_details):
    try:
        deviceToken = request.json['deviceToken']
        user_id = login_user_other_details['_id']
        session_token = request.headers.get('session_token')
        status,payload = User.get_expiry_jwt_session_token(session_token)
        jwt_expiry_time = payload['exp']
        response,api_status=Notifictaion.store_user_device_token(deviceToken=deviceToken,user_id=user_id,jwt_expiry_time = jwt_expiry_time)
        return Response(json.dumps(response), mimetype='application/json', status=api_status)

    except Exception as e:
        print("exception", e)
        error = {"status": "internal server error"}
        return Response(json.dumps(error), mimetype='application/json', status=500)

@notifications_apis.route("/check_app_version",methods=['POST'])
@login
def check_app_version(role,organisation,permissions,login_user_other_details):
    try:
        appVersion = request.json['appVersion']
        response,api_status=Notifictaion.check_app_version_function(appVersion=appVersion)
        return Response(json.dumps(response), mimetype='application/json', status=api_status)

    except Exception as e:
        return Response(json.dumps({"status": e.__str__(), "launchUrl": "", "appVersion":""}), mimetype='application/json', status=400)