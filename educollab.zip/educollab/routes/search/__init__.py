from flask import Blueprint
search_apis = Blueprint('search', __name__)

from routes.search import course_work

