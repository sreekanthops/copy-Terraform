from routes.exception import InvalidUsage
from routes.search import search_apis
from flask import request, Response, json
from model.User import login
from model import course_work
import traceback


@search_apis.route('/course_work/search', methods=["GET"])
@login
def search_course_work(role, organisation, permissions, login_user_other_details):
    try:
        course_works = course_work.fetch_course_works(role=role, organisation=organisation)
        response = {"message": "Success", "course_works": course_works}
        return Response(json.dumps(response), mimetype='application/json', status=200)

    except InvalidUsage as e:
        traceback.print_exc()
        data = {"detail": e.message,
                "message": e.message,
                "status": e.status_code}
        return Response(json.dumps(data), mimetype='application/json', status=e.status_code)
    except Exception as e:
        traceback.print_exc()
        response = {"message": "Internal server error, Please try again later.", "detail": e.__str__()}
        return Response(json.dumps(response), mimetype='application/json', status=500)
