from flask import Blueprint

users_apis = Blueprint('users', __name__)

from routes.user import settings
