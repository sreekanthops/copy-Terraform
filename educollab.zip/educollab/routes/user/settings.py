import json
import traceback

from routes.exception import InvalidUsage
from routes.user import users_apis
from flask import request, Response
from model.User import login
from model.user.settings import validate_zoom_keys, get_user_zoom_accounts, delete_zoom_account, edit_zoom_account, get_available_zoom_accounts
from db_wrapper.tasks import Mongo

mongo_session = Mongo()


@users_apis.route("/user/settings/apps", methods=["POST"])
@login
def users_authenticate(role, organisation, permissions, login_user_other_details):
    """
        To store JWT API and SECRET KEY for every user into the database.
        JWT App provides an api and secret key to access various features of zoom.
    """
    try:
        data = request.json
        app = data["app"]
        jwt_api_key = data["content"]["api_key"]
        jwt_secret_key = data["content"]["secret_key"]
        app_email = data["app_email"]
        permissions = data["content"]["permissions"]
        if app != "zoom":
            return Response(json.dumps({"message": "Please select available Apps only."}),
                            mimetype='application/json',
                            status=400)
        if not app_email:
            return Response(json.dumps({"message": "Please specify the Email to link with Zoom."}),
                            mimetype='application/json',
                            status=400)
    except KeyError as e:
        traceback.print_exc()
        data = {"message": "Please check request data.",
                "detail": e.__str__()}
        return Response(json.dumps(data), mimetype='application/json', status=400)
    try:
        message = validate_zoom_keys(zoom_email=app_email,
                                     jwt_api_key=jwt_api_key,
                                     jwt_secret_key=jwt_secret_key,
                                     user_id=login_user_other_details['_id'],
                                     permissions=permissions,
                                     organisation=login_user_other_details["organisation_id"])
        return Response(json.dumps({"message": message}),
                        mimetype='application/json',
                        status=201)
    except InvalidUsage as e:
        traceback.print_exc()
        data = {"message": e.message}
        return Response(json.dumps(data), mimetype='application/json', status=e.status_code)

    except Exception as e:
        traceback.print_exc()
        data = {"detail": e.__str__(),
                "message": "Oops! Something is wrong, Please try again later."}
        return Response(json.dumps(data), mimetype='application/json', status=500)


@users_apis.route("/user/settings/apps", methods=["GET"])
@login
def get_app_accounts(role, organisation, permissions, login_user_other_details):
    """
        To get all the zoom accounts user has associated with the Edu-Collab.
        Also fetch the usage rights of the zoom credentials.

        ------------------------
        Labels : Who can use your account:
                a. Co-authors of the courses, you are part of.(slug: co_authors)
                b. Anyone in your organization.(slug: public_to_org)
                c. Collaborators on Passion Projects or Group Coursework(slug: collaborators)

        ---------------------------------------

        if course id is given then send all the available zoom accounts which includes:
        1. Co-authors accounts(if they have given the access)
        2. Organisation's account to which user belong

    """
    try:
        course_id = request.args.get("course_id")
        if course_id:
            response = get_available_zoom_accounts(course_id=course_id,
                                                   user_id=login_user_other_details['_id'],
                                                   role=role,
                                                   organisation=login_user_other_details["organisation_id"])
            data = {"user_id": login_user_other_details["_id"],
                    "username": login_user_other_details["username"],
                    "organisation": organisation,
                    "email": login_user_other_details["email"],
                    "apps": {"zoom": response}
                    }
            message = "Zoom Accounts retrieved successfully" if data else "No Zoom Account is available right now."
        else:
            data = get_user_zoom_accounts(user_id=login_user_other_details['_id'])
            message = "Zoom Accounts retrieved successfully" if data else "No Zoom Account is linked to {email}".format(
                        email=login_user_other_details["email"])
        return Response(json.dumps(
            {
                "message": message,
                "response": data}),
            mimetype='application/json',
            status=200)
    except InvalidUsage as e:
        traceback.print_exc()
        data = {"message": e.message}
        return Response(json.dumps(data), mimetype='application/json', status=e.status_code)

    except Exception as e:
        traceback.print_exc()
        data = {"detail": e.__str__(),
                "message": "Oops! Something is wrong, Please try again later."}
        return Response(json.dumps(data), mimetype='application/json', status=500)


@users_apis.route("/user/settings/apps", methods=["DELETE"])
@login
def delete_app_account(role, organisation, permissions, login_user_other_details):
    """
        To delete the stored zoom account associated with the user profile.
    """
    try:
        app = request.args["app"]
        jwt_api_key = request.args["api_key"]
        jwt_secret_key = request.args["secret_key"]
        # as + encode the space in url encoding for now we will replace a space in email with + sign manually
        app_email = request.args["app_email"]
        app_email = app_email.replace(" ", "+")
        if app != "zoom":
            return Response(json.dumps({"message": "Please select available Apps only."}),
                            mimetype='application/json',
                            status=400)
        if not app_email:
            return Response(json.dumps({"message": "Please specify the Email to delete the zoom account."}),
                            mimetype='application/json',
                            status=400)
    except KeyError as e:
        traceback.print_exc()
        data = {"message": "Please check request data.",
                "detail": e.__str__()}
        return Response(json.dumps(data), mimetype='application/json', status=400)
    try:
        message = delete_zoom_account(zoom_email=app_email,
                                      jwt_api_key=jwt_api_key,
                                      jwt_secret_key=jwt_secret_key,
                                      user_id=login_user_other_details['_id'],
                                      organisation=login_user_other_details["organisation_id"])
        return Response(json.dumps({"message": message}),
                        mimetype='application/json',
                        status=200)
    except InvalidUsage as e:
        traceback.print_exc()
        data = {"message": e.message}
        return Response(json.dumps(data), mimetype='application/json', status=e.status_code)

    except Exception as e:
        traceback.print_exc()
        data = {"detail": e.__str__(),
                "message": "Oops! Something is wrong, Please try again later."}
        return Response(json.dumps(data), mimetype='application/json', status=500)


@users_apis.route("/user/settings/apps", methods=["PATCH"])
@login
def edit_app_account(role, organisation, permissions, login_user_other_details):
    """
        To edit the access rights for the specific zoom account associated with the user profile.
        ------------------------
        Labels(access rights) : Who can use your account:
                a. Co-authors of the courses, you are part of.(slug: co_authors)
                b. Anyone in your organization.(slug: public_to_org)
                c. Collaborators on Passion Projects or Group Coursework(slug: collaborators)

    """
    try:
        data = request.json
        app = data["app"]
        jwt_api_key = data["content"]["api_key"]
        jwt_secret_key = data["content"]["secret_key"]
        app_email = data["app_email"]
        permissions = data["content"]["permissions"]
        if app != "zoom":
            return Response(json.dumps({"message": "Please select available Apps only."}),
                            mimetype='application/json',
                            status=400)
        if not app_email:
            return Response(json.dumps({"message": "Please specify the Email to change the access rights."}),
                            mimetype='application/json',
                            status=400)
    except KeyError as e:
        traceback.print_exc()
        data = {"message": "Please check request data.",
                "detail": e.__str__()}
        return Response(json.dumps(data), mimetype='application/json', status=400)
    try:
        message = edit_zoom_account(zoom_email=app_email,
                                    jwt_api_key=jwt_api_key,
                                    jwt_secret_key=jwt_secret_key,
                                    user_id=login_user_other_details['_id'],
                                    permissions=permissions,
                                    organisation=login_user_other_details["organisation_id"])
        return Response(json.dumps({"message": message}),
                        mimetype='application/json',
                        status=200)
    except InvalidUsage as e:
        traceback.print_exc()
        data = {"message": e.message}
        return Response(json.dumps(data), mimetype='application/json', status=e.status_code)

    except Exception as e:
        traceback.print_exc()
        data = {"detail": e.__str__(),
                "message": "Oops! Something is wrong, Please try again later."}
        return Response(json.dumps(data), mimetype='application/json', status=500)

