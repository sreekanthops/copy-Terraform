import ast
import time

from flask import request, Response, json, Blueprint, jsonify
from numpy import double
from pymongo import message
from model.User import login_user
from model import general
from db_wrapper.tasks import Mongo
from model.User import login
from flask_cors import CORS, cross_origin
import model.Question as Question
import model.Content as Content
import model.User as User
import model.course_session as course_session
import services.common.translation as translation
import services.Similar_questions as Similar_questions
import services.School_Leaderboard as School_leaderboard
import services.Recommendation_engine as recommendation_engine
import services.profanity_check as Profanity_Detection
import services.User_Leaderboard as User_Leaderboard
from model.User import OAuth_login
import mongo_connection
from bson import ObjectId
from werkzeug.wsgi import FileWrapper
from io import BytesIO
import re
import csv
import io
import os
import config
from model import general
from model.general import get_urls_for_resources
from utils.elasticsearch.resource_bank import search_resources

mongo_session = Mongo()
import traceback
from utils.elasticsearch.user import index_profile_data, update_user_profile_index
from routes.exception import InvalidUsage
import pandas as pd
from services.storage.s3_services import s3_storage
from services.new_recommender_system import recommender_system, rs_check

s3_function = s3_storage()

api_app = Blueprint("api", __name__)


@api_app.route("/logout", methods=["POST"])
@login
def logout(role, organisation, permissions, login_user_other_details):
    try:

        user_id = login_user_other_details['_id']
        data = request.get_json()
        deviceToken = data['deviceToken']
        status = User.logout_end_session(user_id=user_id, deviceToken=deviceToken)
        if (status == True):
            return jsonify({'message': 'You successfully logged out'})
        else:
            return jsonify({'message': 'You are already Logout!'})
    except Exception as e:
        print('exception logged', e)
        data = {"status": 400, "message": "COULD NOT Logged Out"}
        return Response(json.dumps(data), mimetype='application/json', status=400)


@api_app.route('/login', methods=['POST'])
def login_api():
    """
        This api helps the user to login into their account
        :return: Response according to success or failure in the login process
    """
    try:
        data = request.get_json()
        email = data['username'].strip()
        password = data['password']
        provider = data['provider']
        access_token = data['access_token']
        if email:
            response_message, login_data = login_user(useremail=email.lower(), password=password)
            session_token = response_message[1]
            role = login_data['role']
            roles_permissions = mongo_session.get_data_for_particular_columns_with_condition(collection='roles',
                                                                                             condition={"name": role},
                                                                                             columns={"permissions": 1,
                                                                                                      "_id": 1})
            roles_permissions = roles_permissions['message'][0]['permissions']
            response_data, status_code = s3_function.generate_presigned_url_from_s3(login_data["profile_pic"])
            response_message = {"message": response_message[0], "username": login_data["username"],
                                "first_name": login_data['name'], "last_name": login_data['last_name'],
                                "user_id": login_data["_id"], "Email_ID": login_data["email"],
                                "Session_token": session_token, "coins": float(round(login_data["coin"], 2)),
                                "role": role, "permissions": roles_permissions,
                                "avatar_path": login_data["profile_pic"], "avatar_url": response_data}
            return Response(json.dumps(response_message), mimetype='application/json', status=200)
        else:
            if provider == 'facebook':
                response_message, login_data = OAuth_login(provider=provider, access_token=access_token).facebook()
                response_message = {"message": response_message, "User_name": login_data["name"],
                                    "user_id": login_data["_id"], "Email_ID": login_data["email"],
                                    "Session_token": login_data['session_token']}
                return Response(json.dumps(response_message), mimetype='application/json', status=200)

            elif provider == 'google':
                response_message, login_data = OAuth_login(provider=provider, access_token=access_token).google()
                response_message = {"message": response_message, "User_name": login_data["name"],
                                    "user_id": login_data["_id"], "Email_ID": login_data["email"],
                                    "Session_token": login_data['session_token']}
                return Response(json.dumps(response_message), mimetype='application/json', status=200)
            else:
                data = {"message": "Bad Request.",
                        "detail": "Invalid login request"}
                return Response(json.dumps(data), mimetype='application/json', status=400)

    except InvalidUsage as e:
        traceback.print_exc()
        error = {"message": e.message}
        return Response(json.dumps(error), mimetype='application/json', status=e.status_code)

    except Exception as e:
        traceback.print_exc()
        data = {"message": "Oops! Something went wrong. Sorry for the inconvenience caused",
                "detail": e.__str__()}
        return Response(json.dumps(data), mimetype='application/json', status=500)


@api_app.route('/profile_avatar', methods=['GET'])
@login
def get_profile_avatar(role, organisation, permissions, login_user_other_details):
    try:
        user_id = login_user_other_details['_id']
        print(user_id)
        profile_pic = User.get_user_profile_image(user_id=user_id)
        return Response(json.dumps(profile_pic), mimetype='application/json', status=200)
    except InvalidUsage as e:
        data = {"message": e.message}
        return Response(json.dumps(data), mimetype='application/json', status=e.status_code)
    except Exception as e:
        print('exception logged', e)
        data = {"message": "Oops! Something went wrong. Sorry for the inconvenience caused",
                "detail": e.__str__()}
        return Response(json.dumps(data), mimetype='application/json', status=400)


@api_app.route('/generate_username', methods=['GET'])
@login
def generate_username_api(role, organisation, permissions, login_user_other_details):
    try:
        data = request.json
        first_name = data['first_name']
        last_name = data['last_name']
    except KeyError:
        traceback.print_exc()
        data = {"status": 400, "message": "Please check all the request data"}
        return Response(json.dumps(data), mimetype='application/json', status=400)
    try:
        if role != "super_admin":
            raise InvalidUsage("You are not authorised to register new users to educollab.", 403)
        response_message = User.username_generate(first_name=first_name, last_name=last_name)
        return Response(json.dumps({"message": response_message}), mimetype='application/json', status=201)

    except InvalidUsage as e:
        traceback.print_exc()
        data = {"detail": e.message,
                "message": e.message,
                "status": e.status_code}
        return Response(json.dumps(data), mimetype='application/json', status=e.status_code)

    except Exception as e:
        traceback.print_exc()
        data = {"status": 500, "message": "Something went wrong, Please try again later", "detail": e.__str__()}
        return Response(json.dumps(data), mimetype='application/json', status=500)


@api_app.route('/signup', methods=['POST'])
@login
def signup_api(role, organisation, permissions, login_user_other_details):
    try:
        data = request.get_json()
        register_email = data['email']
        first_name = data['first_name']
        last_name = data['last_name']
        register_password = data['password']
        organisation_name = data['organisation']
        org_type = data['org_type']
        grade = data['grade']
        username = data['username']
        reg_role = data['role']
    except KeyError:
        traceback.print_exc()
        data = {"status": 400, "message": "Please check all the request data"}
        return Response(json.dumps(data), mimetype='application/json', status=400)
    try:
        if role != "super_admin":  # using slug
            raise InvalidUsage("You are not authorised to register new users to educollab.", 403)

        if not (register_email and first_name and organisation_name and
                org_type and grade and reg_role):
            raise InvalidUsage("Please fill all details", 400)

        # validate roles
        if not mongo_session.check_existance(collection="roles",
                                             condition={"name": reg_role}):
            raise InvalidUsage("Selected role hasn't been registered with Educollab.", 400)
        # validate organisation type
        if not mongo_session.check_existance(collection="organisations_type",
                                             condition={"slug": org_type}):
            raise InvalidUsage("Selected organisation type hasn't been registered with Educollab.", 400)

        # validate organisation
        organisation_exist = mongo_session.check_existance_return_info(collection="organisations",
                                                                       condition={"slug": organisation_name},
                                                                       columns={"name": 1, "slug": 1, "_id": 1},
                                                                       return_keys=["name", "_id", "slug"])

        if not organisation_exist:
            raise InvalidUsage("Selected organisation hasn't been registered with Educollab.", 400)

        organisation_id = organisation_exist["_id"]
        organisation_name = organisation_exist["name"]
        response_data, signup_data = User.add_user(email_address=register_email.lower(),
                                                   first_name=first_name,
                                                   last_name=last_name,
                                                   password=register_password,
                                                   organisation=organisation_name,
                                                   organisation_id=organisation_id,
                                                   grade=grade,
                                                   username=username,
                                                   org_type=org_type,
                                                   role=reg_role)

        response_message = {
            "Status": response_data,
            "user_id": signup_data["_id"],
            "Email_ID": signup_data["email"],
            "coin": signup_data["coin"],
            "username": signup_data["username"],
            "role": signup_data['role']
        }
        # TODO - Report to admins / ADD celery task -- Abhishek Lomsh
        response_ES, status = index_profile_data(id=signup_data["_id"],
                                                 first_name=first_name,
                                                 last_name=last_name,
                                                 organisation_name=organisation_name,
                                                 username=signup_data["username"],
                                                 institute_type=org_type,
                                                 role=reg_role,
                                                 avatar=config.DEFAULT_AVATAR)
        if status == 500:
            return Response(json.dumps({"detail": response_ES,
                                        "message": "We ran into some problem. Please try again later."}),
                            mimetype='application/json', status=500)
        return Response(json.dumps({"message": response_message}), mimetype='application/json', status=201)

    except InvalidUsage as e:
        traceback.print_exc()
        data = {"detail": e.message,
                "message": e.message,
                "status": e.status_code}
        return Response(json.dumps(data), mimetype='application/json', status=e.status_code)

    except Exception as e:
        traceback.print_exc()
        data = {"status": 500, "message": "Something went wrong, Please try again later", "detail": e.__str__()}
        return Response(json.dumps(data), mimetype='application/json', status=500)


@api_app.route('/Forget_password', methods=['POST'])
def forget_password_api():
    try:
        data = request.get_json()
        register_email = data['email']
        response_data = User.forget_password(email_address=register_email)
        if response_data:
            response_message = {"otp": response_data}
            return Response(json.dumps(response_message), mimetype='application/json', status=200)
    except InvalidUsage as e:
        data = {"message": e.message}
        return Response(json.dumps(data), mimetype='application/json', status=e.status_code)
    except Exception as e:
        print('exception logged', e)
        data = {"message": "Oops! Something went wrong. Sorry for the inconvenience caused",
                "detail": e.__str__()}
        return Response(json.dumps(data), mimetype='application/json', status=400)


@api_app.route('/verify_OTP', methods=['POST'])
def verify_OTP():
    data = request.get_json()
    encoded_otp = request.headers.get('otp')
    response, status_code = User.match_otp(user_email=data["email"], otp=data["otp"], encoded_otp=encoded_otp)
    return Response(json.dumps(response), mimetype='application/json', status=status_code)


@api_app.route('/reset_password', methods=['POST'])
def reset_password_api():
    try:
        data = request.get_json()
        registeremail = data['email']
        password = data['password']
        confirm_password = data['confirm_password']
        response_data, status_code = User.reset_password(email_address=registeremail, new_password=password,
                                                         confirm_password=confirm_password)
        response_message = {"Status": response_data}
        return Response(json.dumps(response_message), mimetype='application/json', status=status_code)
    except Exception as e:
        print('exception logged', e)
        data = {"status": 400, "message": "COULD NOT connect"}
        return Response(json.dumps(data), mimetype='application/json', status=400)


@api_app.route('/my_profile', methods=['GET'])
@login
def user_profile_api(role, organisation, permissions, login_user_other_details):
    try:
        user_id = login_user_other_details['_id']
        response_data = User.User_Profile(user_id=user_id)
        if response_data:
            response_message = {"Status": response_data}
            return Response(json.dumps(response_message), mimetype='application/json', status=200)
        else:
            data = {"status": 400, "message": "Not authorized user"}
            return Response(json.dumps(data), mimetype='application/json', status=400)
    except Exception as e:
        print('exception logged', e)
        data = {"status": 400, "message": "COULD NOT connect"}
        return Response(json.dumps(data), mimetype='application/json', status=400)


@api_app.route('/edit_user_profile', methods=['POST'])
@login
def edit_profile_api(role, organisation, permissions, login_user_other_details):
    """
    This api is use to edit user profile
    :param role:
    :param organisation:
    :param permissions:
    :param login_user_other_details:
    :return:
    """
    try:
        user_id = login_user_other_details['_id']
        update_field = request.json
        name = update_field['first_name']
        last_name = update_field['last_name']
        mobile = update_field['mobile']
        profile_pic = update_field['avatar_url']
        username = update_field['username']
    except KeyError:
        error = {"status": "Key Error"}
        return Response(json.dumps(error), mimetype='application/json', status=400)
    try:
        status, response_data = User.update_user_profile(user_id=user_id, name=name, last_name=last_name,
                                                         mobile=mobile, profile_pic=profile_pic, username=username)

        response_message = {"message": response_data}
        update_user_profile_index(_id=user_id, first_name=name, last_name=last_name,
                                  username=username, avatar=profile_pic)
        return Response(json.dumps(response_message), mimetype='application/json', status=200)
    except InvalidUsage as e:
        data = {"status": e.status_code, "message": e.message}
        return Response(json.dumps(data), mimetype='application/json', status=e.status_code)
    except Exception as e:
        traceback.print_exc()
        data = {"status": 500, "message": "COULD NOT connect"}
        return Response(json.dumps(data), mimetype='application/json', status=500)


@api_app.route('/signup/bulk', methods=["POST"])
@cross_origin()
@login
def signup_bulk(role, organisation, permissions, login_user_other_details):
    """
        This api is use to bulk sign up the users.
        :param role:role of the user who is doing bulk sign up.
        :param organisation: org of the user who is doing bulk sign up.
        :param permissions: permissions of the user who is doing bulk sign up.
        :param login_user_other_details: other details of the user who is doing bulk sign up.
        """
    # uploader is the user who is using sign up bulk to register users in educollab.
    error_list = []
    success_list = []
    try:
        org_type = request.form['org_type']
        bulk_org = request.form['organisation']
        bulk_role = request.form['role']
        file = request.files['file']
        default_courses = request.form['courses']
    except KeyError as error:
        traceback.print_exc()
        data = {"message": "Please check request data.",
                "detail": error.__str__(),
                "error_list": error_list,
                "success_list": success_list}
        return Response(json.dumps(data), mimetype='application/json', status=400)
    if not (org_type or bulk_org or bulk_role or file.filename):
        return Response(json.dumps({"message": "Please check request data.",
                                    "detail": "Please fill all the data in the form correctly.",
                                    "error_list": error_list,
                                    "success_list": success_list
                                    }),
                        mimetype='application/json',
                        status=400)
    try:
        if role != "super_admin":  # using slug
            raise InvalidUsage("You are not authorised to register new users to educollab.", 403)

        # validate roles
        if not mongo_session.check_existance(collection="roles",
                                             condition={"name": bulk_role}):
            raise InvalidUsage("Selected role hasn't been registered with Educollab.", 400)
        # validate organisation type
        if not mongo_session.check_existance(collection="organisations_type",
                                             condition={"slug": org_type}):
            raise InvalidUsage("Selected organisation type hasn't been registered with Educollab.", 400)

        # validate organisation
        organisation_exist = mongo_session.check_existance_return_info(collection="organisations",
                                                                       condition={"slug": bulk_org},
                                                                       columns={"name": 1, "slug": 1, "_id": 1},
                                                                       return_keys=["name", "_id", "slug"])

        if not organisation_exist:
            raise InvalidUsage("Selected organisation hasn't been registered with Educollab.", 400)

        organisation_id = organisation_exist["_id"]
        bulk_org = organisation_exist["name"]
        pd_dt_frame = pd.read_csv(file)
        pd_dt_frame["Last_Name"].fillna("", inplace=True)
        pd_dt_dict = pd_dt_frame.to_dict('records')
        usersdetails = pd_dt_dict
        response_list = User.add_bulk_user(usersdetails,
                                           organisation=bulk_org,
                                           organisation_id=organisation_id,
                                           org_type=org_type,
                                           role=bulk_role,
                                           default_courses=default_courses)
        if len(response_list) == 3:
            res_messages, signup_datum, user_ids = response_list[0], response_list[1], response_list[2]
            for res_message, signup_data, details in zip(res_messages, signup_datum, usersdetails):
                # index represents student number and row represents that student's information
                try:

                    response_ES, ES_status = index_profile_data(id=signup_data["_id"],
                                                                first_name=details["First_Name"],
                                                                last_name=details["Last_Name"],
                                                                organisation_name=signup_data["organisation"],
                                                                username=signup_data["username"],
                                                                institute_type=org_type,
                                                                role=bulk_role,
                                                                avatar=config.DEFAULT_AVATAR)
                    if ES_status == 500:
                        return Response(json.dumps({"message": "We ran into some problem. Please try again later.",
                                                    "detail": response_ES,
                                                    "error_list": error_list,
                                                    "success_list": success_list}), mimetype='application/json',
                                        status=500)
                except InvalidUsage as e:
                    message = e.message + " for %s" % (
                                usersdetails["First_Name"] + " " + usersdetails["Last_Name"] + ".")
                    error_list.append(message)
                    continue
                success_list.append(res_message)
            response_message = {"message": "Bulk Signup is successfully completed.",
                                "error_list": error_list,
                                "success_list": success_list}
            return Response(json.dumps(response_message), mimetype='application/json', status=200)
        else:
            error_list = response_list[0]
            response_message = {"message": "Bulk Signup unsuccessful.",
                                "error_list": error_list,
                                "success_list": success_list}
            return Response(json.dumps(response_message), mimetype='application/json', status=500)
    except InvalidUsage as e:
        traceback.print_exc()
        data = {"message": e.message,
                "error_list": error_list,
                "success_list": success_list
                }
        return Response(json.dumps(data), mimetype='application/json', status=e.status_code)
    except Exception as e:
        traceback.print_exc()
        data = {"message": "We ran into some problem. Please try again later.",
                "detail": e.__str__(),
                "error_list": error_list,
                "success_list": success_list
                }
        return Response(json.dumps(data), mimetype='application/json', status=500)


@api_app.route('/questions', methods=['POST'])
@login
def ask_question_api(role, organisation, permissions, login_user_other_details):
    user_id = login_user_other_details['_id']
    try:
        coordinates = request.form.get("coordinates")
        if coordinates:
            coordinates = ast.literal_eval(request.form["coordinates"])
        asked_question = request.form['question']
        coins = float(request.form['coins'])
        language = request.form['language']
        category_id = request.form['category_id']
        question_image = request.files.get('question_image', '')
        question_video = request.files.get('video_path', '')
        answer_id = request.form['answer_id']
        video_time = request.form['video_time']
        course_id = request.form['course_id']
        session_id = request.form['course_session_id']
        if not asked_question and coins and language and category_id:
            raise Exception("Please check request data.")
    except KeyError:
        traceback.print_exc()
        data = {"status": 400, "message": "Please check request data."}
        return Response(json.dumps(data), mimetype='application/json', status=400)

    if not coins >= 1:
        response_message = {"Status": "Failed",
                            "question_id": "",
                            "message": "Reward should be greater than or equal to 1"}
        return Response(json.dumps(response_message), mimetype='application/json', status=402)

    try:
        check_reward_status = User.check_coins(coins_for_question=coins, user_id=user_id)
        if not (type(check_reward_status) == bool and check_reward_status):
            response_message = {"Status": "Failed",
                                "question_id": "",
                                "message": "Insufficient balance to give reward"}
            return Response(json.dumps(response_message), mimetype='application/json', status=402)
        if language != "en":
            translated_question, converted_language = translation.question_translation(asked_question)
        else:
            translated_question = asked_question

        profanity = Profanity_Detection.check_profanity(translated_question)
        if type(profanity) == bool and profanity:
            response_message = {"Status": "Failed",
                                "question_id": "",
                                "message": "Oops can't add this question."}
            return Response(json.dumps(response_message), mimetype='application/json', status=422)

        # ask question on answers
        if answer_id and video_time:
            print("answers")
            answer_info = mongo_session.answer_info_ask_question(collection="answer_bank",
                                                                 condition={"_id": ObjectId(answer_id)})
            if not answer_info['message'] == answer_id:
                data = {"Status": "Failed",
                        "question_id": "",
                        "message": answer_info['msg']}
                return Response(json.dumps(data), mimetype='application/json', status=409)
            question_data, available_coins, s3_link, video_s3_link, message, notification_status = Question.ask_question(
                question=asked_question,
                user_id=user_id,
                language=language,
                translated_question=translated_question,
                coins=coins,
                category_id=category_id,
                question_image=question_image,
                question_video=question_video,
                coordinates=coordinates)
            store_status = Question.store_answer_info(answer_id, video_time, str(question_data))
            response_message = {"Status": "Success",
                                "question_id": str(question_data),
                                "message": "Question Added Successfully",
                                "avail_coin": available_coins,
                                "question_image_path": s3_link,
                                "video_path": video_s3_link,
                                "notification_status": notification_status}

        elif course_id and session_id and int(video_time) >= 0:
            question_data, available_coins, s3_link, video_s3_link, message, store_status, session_video_link, \
            session_file_id = course_session.ask_question(
                question=asked_question,
                user_id=user_id,
                language=language,
                translated_question=translated_question,
                coins=coins,
                category_id=category_id,
                question_image=question_image,
                question_video=question_video,
                course_id=course_id,
                session_id=session_id,
                video_time=video_time,
                coordinates=coordinates)
            response_message = {"Status": "Success",
                                "question_id": str(question_data),
                                "message": "Question Added Successfully",
                                "avail_coin": available_coins,
                                "question_image_path": s3_link,
                                "video_path": video_s3_link,
                                "session_video_link": session_video_link,
                                "session_file_id": session_file_id, }
        elif not (answer_id or video_time and course_id and session_id):
            question_data, available_coins, s3_link, video_s3_link, message, notification_status = Question.ask_question(
                question=asked_question,
                user_id=user_id,
                language=language,
                translated_question=translated_question,
                coins=coins,
                category_id=category_id,
                question_image=question_image,
                question_video=question_video,
                coordinates=coordinates)
            store_status = 200
            response_message = {"Status": "Success",
                                "question_id": str(question_data),
                                "message": "Question Added Successfully",
                                "avail_coin": available_coins,
                                "question_image_path": s3_link,
                                "video_path": video_s3_link,
                                "notification_status": notification_status}
        else:
            raise Exception("cannot process your request, please check your request data.")
        if not (question_data and store_status == 200):
            raise Exception("Some Internal error occurred Please try again later.")
        return Response(json.dumps(response_message), mimetype='application/json', status=200)
    except Exception as e:
        traceback.print_exc()
        response_message = {"Status": "Failed",
                            "question_id": "",
                            "message": e.__str__()}
        response = Response(json.dumps(response_message), mimetype='application/json', status=500)
        return response


@api_app.route('/answer/feedback', methods=['POST'])
@login
def submit_answer_feedback(role, organisation, permissions, login_user_other_details):
    """to give feedback/comments on answers."""
    user_id = login_user_other_details['_id']
    try:
        data = request.json
        answer_id = data['answer_id']
        feedback = data['feedback']
    except KeyError:
        traceback.print_exc()
        data = {"status": 400, "message": "Please check request data."}
        return Response(json.dumps(data), mimetype='application/json', status=400)
    try:
        profanity = Profanity_Detection.check_profanity(feedback)
        if profanity:
            data = {"status": "Failed",
                    "detail": "Profanity detected in the comment.",
                    "message": "Can't add this comment, make sure your comment is respectful."}
            return Response(json.dumps(data), mimetype='application/json', status=400)
        else:
            question_id = Question.add_answer_feedback(feedback=feedback,
                                                       user_id=user_id,
                                                       answer_id=answer_id)
            response_message = {"status": "Success",
                                "response": {"question_id": str(question_id)},
                                "message": "Thanks for your valuable feedback."}
            return Response(json.dumps(response_message), mimetype='application/json', status=201)
    except InvalidUsage as e:
        traceback.print_exc()
        error = {"message": e.message, "detail": e.message}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])
    except Exception as e:
        traceback.print_exc()
        error = {"detail": e.__str__(), "message": "Oops! something went wrong, Please try again later."}
        return Response(json.dumps(error), mimetype='application/json', status=500)


# To comment on questions
@api_app.route('/question/feedback', methods=['POST'])
@login
def submit_question_feedback(role, organisation, permissions, login_user_other_details):
    """to give feedback/comments on answers."""
    user_id = login_user_other_details['_id']
    try:
        data = request.json
        question_id = data['question_id']
        feedback = data['feedback']
    except KeyError:
        traceback.print_exc()
        data = {"status": 400, "message": "Please check request data."}
        return Response(json.dumps(data), mimetype='application/json', status=400)
    try:
        profanity = Profanity_Detection.check_profanity(feedback)
        if profanity:
            data = {"status": "Failed",
                    "detail": "Profanity detected in the comment.",
                    "message": "Can't add this comment, make sure your comment is respectful."}
            return Response(json.dumps(data), mimetype='application/json', status=400)
        else:
            question_id = Question.add_question_feedback(feedback=feedback,
                                                         user_id=user_id,
                                                         question_id=question_id, role=role)
            if question_id:

                response_message = {"status": "Success",
                                    "response": {"question_id": str(question_id)},
                                    "message": "Thanks for your valuable feedback."}
            else:
                response_message = {"status": "Failed",
                                    "message": "Only teacher can add feedback."}
            return Response(json.dumps(response_message), mimetype='application/json', status=201)
    except InvalidUsage as e:
        traceback.print_exc()
        error = {"message": e.message, "detail": e.message}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])
    except Exception as e:
        traceback.print_exc()
        error = {"detail": e.__str__(), "message": "Oops! something went wrong, Please try again later."}
        return Response(json.dumps(error), mimetype='application/json', status=500)


@api_app.route('/submit_rating', methods=['POST'])
@login
def submit_rating(role, organisation, permissions, login_user_other_details):
    try:
        data = request.json
        answer_id = data['answer_id']
        course_id = data['course_id']
        user_id = login_user_other_details['_id']
        rating = float(data['rating'])
        review = data.get('review', None)
    except KeyError:
        traceback.print_exc()
        data = {"status": 400, "message": "Please check request data."}
        return Response(json.dumps(data), mimetype='application/json', status=400)
    try:
        response_data, rating_type, average_rating, individual_rating = Question.add_rating(rating=rating,
                                                                                            user_id=user_id,
                                                                                            answer_id=answer_id,
                                                                                            course_id=course_id,
                                                                                            review=review)
        if rating_type == 'answer':
            response_message = {"Status": "Thanks for rating",
                                "question_id": str(response_data),
                                "User_rating": average_rating}
        elif rating_type == 'course':
            response_message = {"Status": "Thanks for rating",
                                "course_id": str(response_data),
                                "User_rating": average_rating,
                                "individual_rating": individual_rating}
        return Response(json.dumps(response_message), mimetype='application/json', status=200)
    except Exception as e:
        traceback.print_exc()
        response_data = {"message": "Something went wrong, Please try again later",
                         "detail": e}
        response = Response(json.dumps(response_data), mimetype='application/json', status=500)
        return response


@api_app.route('/submit_like_dislike', methods=['POST'])
@login
def submit_like_dislike_api(role, organisation, permissions, login_user_other_details):
    user_id = login_user_other_details['_id']
    try:
        data = request.json
        answer_id = data['answer_id']
        status = data['status']
    except KeyError as e:
        error = {"message": "Bad Request", "status": 400, "detail": e.__str__()}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])

    try:
        response_data, like_status, dislike_status = Question.like_dislike_status(status=status,
                                                                                  user_id=user_id,
                                                                                  answer_id=answer_id)
        message = "Thanks for Your valuable feedback" if like_status or dislike_status else "You can always give " \
                                                                                            "feedback later. "
        response_message = {"Status": message,
                            "question_id": str(response_data),
                            "Liked": like_status,
                            "Disliked": dislike_status}
        return Response(json.dumps(response_message), mimetype='application/json', status=200)
    except InvalidUsage as e:
        error = {"message": e.message, "status": e.status_code, "detail": e}
        return Response(json.dumps(error), mimetype='application/json', status=e.status_code)

    except Exception as e:
        traceback.print_exc()
        error = {"message": "Internal server error", "status": 500, "detail": e.__str__()}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])


@api_app.route('/answers/comments/like_dislike', methods=['POST'])
@login
def answer_comment_like_dislike_api(role, organisation, permissions, login_user_other_details):
    user_id = login_user_other_details['_id']
    try:
        data = request.json
        answer_id = data['answer_id']
        comment_id = data['comment_id']
        status = data['status']
        is_true = data.get('is_true', False)
    except KeyError as e:
        error = {"message": "Bad Request", "status": 400, "detail": e.__str__()}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])

    try:
        response_data, like_status, dislike_status = Question.answer_comment_like_dislike(status=status,
                                                                                          user_id=user_id,
                                                                                          comment_id=comment_id,
                                                                                          answer_id=answer_id,
                                                                                          is_true=is_true)
        message = "Thanks for Your valuable feedback" if like_status or dislike_status else "You can always give " \
                                                                                            "feedback later. "
        response_message = {"Status": message,
                            "question_id": str(response_data),
                            "Liked": like_status,
                            "Disliked": dislike_status}
        return Response(json.dumps(response_message), mimetype='application/json', status=200)
    except InvalidUsage as e:
        error = {"message": e.message, "status": e.status_code, "detail": e}
        return Response(json.dumps(error), mimetype='application/json', status=e.status_code)

    except Exception as e:
        traceback.print_exc()
        error = {"message": "Internal server error", "status": 500, "detail": e.__str__()}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])


@api_app.route('/create_test', methods=['POST'])
@login
def test(role, organisation, permissions, login_user_other_details):
    data = request.json
    user_id = login_user_other_details['_id']
    answer_id = data["answer_id"]
    question_list = data["question_list"]
    answer_list = data["answer_list"]
    try:
        test_id = Question.create_test(user_id=user_id, question_list=question_list, answer_id=answer_id,
                                       answer_list=answer_list)
        response_message = {"Status": "Test Created succesfully", "question_id": str(test_id)}
        return Response(json.dumps(response_message), mimetype='application/json', status=200)
    except Exception as e:
        print('exception logged', e)
        data = {"status": 400, "message": "COULD NOT create test"}
        return Response(json.dumps(data), mimetype='application/json', status=400)


@api_app.route('/test_submission', methods=['POST'])
@login
def submit_test(role, organisation, permissions, login_user_other_details):
    """users giving test """
    data = request.json
    user_id = login_user_other_details['_id']
    test_id = data["test_id"]
    answer = data["answer"]
    try:
        test_response = Question.test_submission(answer=answer, user_id=user_id, test_id=test_id)
        response_message = {"Status": "Test Submission Succesful", "question_id": str(test_id)}
        return Response(json.dumps(response_message), mimetype='application/json', status=200)
    except Exception as e:
        print('exception logged', e)
        data = {"status": 400, "message": "Test submission failed"}
        return Response(json.dumps(data), mimetype='application/json', status=400)


@api_app.route("/my_answers", methods=["GET"])
@login
def my_answers(role, organisation, permissions, login_user_other_details):
    """To serve the answers that user has given on other's questions"""
    user_id = login_user_other_details['_id']
    ans_filter = request.args.get('answer_type')
    categories = request.args.get('categories')
    if categories:
        cat_filter = categories.split(",")
    else:
        cat_filter = []
    try:
        answers = Content.fetch_answers(user_id=user_id, ans_filter=ans_filter, cat_filter=cat_filter)
        return_msg = "Keep helping others by answering more questions." if answers else "You did not answer any question, " \
                                                                                        "Hurry answer now. "
        response_message = {"message": return_msg,
                            "response": answers}
        return Response(json.dumps(response_message), mimetype='application/json', status=200)
    except InvalidUsage as e:
        traceback.print_exc()
        error = {"message": e.message, "detail": e.message}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])
    except Exception as e:
        traceback.print_exc()
        data = {"message": "Oops! something went wrong, Please check your answers after some time.",
                "detail": e.__str__()}
        return Response(json.dumps(data), mimetype='application/json', status=500)


@api_app.route("/answers", methods=["GET"])
@login
def answer_data(role, organisation, permissions, login_user_other_details):
    """To find the details of an answer."""
    user_id = login_user_other_details['_id']
    try:
        answer_id = request.args['answer_id']
        comment_filter = request.args.get("comment_filter", "")
    except KeyError as e:
        error = {"message": "Bad Request", "status": 400, "detail": e.__str__()}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])
    try:
        response_data = Content.fetch_answer_details(answer_id=answer_id, user_id=user_id, comment_filter=comment_filter)
        data = {"message": "Answer meta data has been retrieved successfully",
                "response": response_data}
        return Response(json.dumps(data), mimetype='application/json', status=200)
    except InvalidUsage as e:
        traceback.print_exc()
        error = {"message": e.message, "detail": e.message}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])
    except Exception as e:
        traceback.print_exc()
        data = {"detail": e.__str__(), "message": "Oops! something went wrong, Please try again later."}
        return Response(json.dumps(data), mimetype='application/json', status=500)


@api_app.route("/recommend_questions", methods=["POST"])
@login
def recommend_questions(role, organisation, permissions, login_user_other_details):
    user_id = login_user_other_details['_id']
    try:
        data = request.get_json()
        count = int(data["count"])
    except KeyError:
        traceback.print_exc()
        data = {"status": 400, "message": "Please check request data."}
        return Response(json.dumps(data), mimetype='application/json', status=400)
    try:
        try_rs = rs_check(user_id)
        if try_rs:
            try:

                user_questions = mongo_session.get_all_data_for_particular_condition_fields(collection="user_profile",
                                                                                            condition={"_id": ObjectId(
                                                                                                user_id)},
                                                                                            )["message"][0]

                if user_questions["questions"]:
                    user_questions_id = [str(user_question["_id"]) for user_question in user_questions["questions"]]

                answers = recommender_system(user_id)

                if user_questions_id:
                    for ind, ans in enumerate(answers):
                        ans_id = ans["_id"]
                        if ans_id in user_questions_id:
                            answers.pop(ind)

            except:
                answered_questions = recommendation_engine.fetch_answered_questions(user_id)
                answers = Similar_questions.botone(user_id, count, answered_questions)

            chat_unread = mongo_session.check_existance(collection="messages",
                                                        condition={"receivers": User.User_Profile(user_id=user_id,
                                                                                                  application_type='webapp')[
                                                            'username'],
                                                                   "is_read": False,
                                                                   "$and": [{"is_group": {"$exists": True}},
                                                                            {"is_group": False}]})
            chat_unread_group = mongo_session.check_existance(collection='messages',
                                                              condition={
                                                                  "receiver_status":
                                                                      {"$elemMatch": {"$and": [
                                                                          {"_id": ObjectId(user_id)},
                                                                          {"status": False}
                                                                      ]}
                                                                      }})
            if not chat_unread and not chat_unread_group:
                unread = False
            else:
                unread = True
            response_message = {"Status": "200", "answers": answers, "new_message": unread}
            return Response(json.dumps(response_message), mimetype='application/json', status=200)

        else:
            answered_questions = recommendation_engine.fetch_answered_questions(user_id)
            answers = Similar_questions.botone(user_id, count, answered_questions)
            chat_unread = mongo_session.check_existance(collection="messages",
                                                        condition={"receivers": User.User_Profile(user_id=user_id,
                                                                                                  application_type='webapp')[
                                                            'username'],
                                                                   "is_read": False,
                                                                   "$and": [{"is_group": {"$exists": True}},
                                                                            {"is_group": False}]})
            chat_unread_group = mongo_session.check_existance(collection='messages',
                                                              condition={
                                                                  "receiver_status":
                                                                      {"$elemMatch": {"$and": [
                                                                          {"_id": ObjectId(user_id)},
                                                                          {"status": False}
                                                                      ]}
                                                                      }})
            if not chat_unread and not chat_unread_group:
                unread = False
            else:
                unread = True
            response_message = {"Status": "200", "answers": answers, "new_message": unread}
            return Response(json.dumps(response_message), mimetype='application/json', status=200)

    except Exception as e:
        traceback.print_exc()
        response_data = {"message": e.__str__()}
        response = Response(json.dumps(response_data), mimetype='application/json', status=500)
        return response


@api_app.route("/User_Leaderboard", methods=["GET"])
@login
def user_leaderboard(role, organisation, permissions, login_user_other_details):
    user_id = login_user_other_details['_id']
    current_user_name = login_user_other_details['username']
    current_user_coin = login_user_other_details['coin']
    try:
        ranking, status = User_Leaderboard.user_ranking(user_id, current_user_name, current_user_coin)
        response_message = {"Status": status,
                            "Ranking": ranking}
        return Response(json.dumps(response_message), mimetype='application/json', status=status)

    except InvalidUsage as e:
        traceback.print_exc()
        error = {"message": e.message, "detail": e.message}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])

    except Exception as e:
        data = {"message": "Something went wrong, Please try again later.",
                "detail": e.__str__()}
        return Response(json.dumps(data), mimetype='application/json', status=500)


@api_app.route("/School_Leaderboard", methods=["GET"])
@login
def school_leaderboard(role, organisation, permissions, login_user_other_details):
    user_id = login_user_other_details['_id']
    try:
        ranking, status = School_leaderboard.organization_leaderborad()
        response_message = {"Status": status, "Ranking": ranking}
        return Response(json.dumps(response_message), mimetype='application/json', status=status)

    except InvalidUsage as e:
        traceback.print_exc()
        error = {"message": e.message, "detail": e.message}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])

    except Exception as e:
        traceback.print_exc()
        data = {"message": "Something went wrong, Please try again later.",
                "detail": e.__str__()}
        return Response(json.dumps(data), mimetype='application/json', status=500)


@api_app.route("/answer/verification", methods=["Post"])
@login
def verify_answer(role, organisation, permissions, login_user_other_details):
    """Verify the given answer and set its status as approved, if verified."""
    user_id = login_user_other_details['_id']
    try:
        data = request.json
        answer_id = data["answer_id"]
        question_id = data["question_id"]
        status = data["status"]
    except KeyError:
        traceback.print_exc()
        data = {"status": 400, "message": "Please check request data."}
        return Response(json.dumps(data), mimetype='application/json', status=400)
    try:
        status, message, reward_coins, available_coin, notification_status = Question.answer_verification(
            question_id=question_id,
            answer_id=answer_id,
            user_id=user_id,
            status=status)
        if status == "Already Approved":

            response_message = {"message": message,
                                "response": {"status": status.lower(),
                                             "reward": reward_coins,
                                             "total_coins": available_coin,
                                             "notification_status": notification_status}}
            status_status = 400
        else:
            response_message = {"message": message,
                                "response": {"status": status.lower(),
                                             "reward": reward_coins,
                                             "total_coins": available_coin,
                                             "notification_status": notification_status}}
            status_status = 201

        return Response(json.dumps(response_message), mimetype='application/json', status=status_status)
    except InvalidUsage as e:
        traceback.print_exc()
        error = {"message": e.message, "detail": e.message}
        return Response(json.dumps(error), mimetype='application/json', status=e.status_code)
    except Exception as e:
        traceback.print_exc()
        error = {"detail": e.__str__(), "message": "Oops! something went wrong, Please try again later."}
        return Response(json.dumps(error), mimetype='application/json', status=500)


@api_app.route("/course_suggestions", methods=["Get"])
@login
def course_suggestion(role, organisation, permissions, login_user_other_details):
    course_subject = request.args.get("Course_Category")
    user_id = login_user_other_details['_id']
    try:
        response = Content.course_recommendation(course_subject)
        return Response(json.dumps(response), mimetype='application/json', status=200)
    except Exception as e:
        print('exception logged', e)
        data = {"status": 400, "message": "Error"}
        return Response(json.dumps(data), mimetype='application/json', status=400)


@api_app.route("/course_content", methods=["Post"])
@login
def course_recommendation(role, organisation, permissions, login_user_other_details):
    user_id = login_user_other_details['_id']
    data = request.json
    subject = data["Course"]
    course_id = data["Course_id"]

    try:
        # courses = Content.course_details(subject=subject, course_id=course_id, user_id=user_id, permissions=permissions)
        courses = "API is deprecated"
        response_message = {"Status": "200", "Courses_Recommendations": courses}
        return Response(json.dumps(response_message), mimetype='application/json', status=200)

    except Exception as e:
        traceback.print_exc()
        data = {"status": 400, "message": e.__str__()}
        return Response(json.dumps(data), mimetype='application/json', status=400)


@api_app.route("/my_courses", methods=["Get"])
@login
def suscribed_courses(role, organisation, permissions, login_user_other_details):
    try:
        user_id = login_user_other_details['_id']
        courses = Content.subscribed_course_details(user_id=user_id)
        if courses:
            response_message = {"Status": "200", "Courses": courses}
            return Response(json.dumps(response_message), mimetype='application/json', status=200)
        else:
            response_message = {"Status": "200", "Courses": ""}
            return Response(json.dumps(response_message), mimetype='application/json', status=200)


    except Exception as e:
        print('exception logged', e)
        data = {"status": 400, "message": "Error"}
        return Response(json.dumps(data), mimetype='application/json', status=400)


@api_app.route('/submit_feedback_subscribe_course', methods=['POST'])
@login
def submit_feedback_course(role, organisation, permissions, login_user_other_details):
    data = request.json
    course_id = data['course_id']
    user_id = login_user_other_details['_id']
    feedback = data['feedback']
    try:
        profanity = Profanity_Detection.check_profanity(feedback)
        # profanity = Question.question_profanity_check(feedback)
        if profanity == True:
            response_message = {"Status": "Failed", "course_id": "", "Message": "Oops can't add this comment"}
            return Response(json.dumps(response_message), mimetype='application/json', status=200)
        else:
            response_data = Content.add_feedback_subscribed_course(feedback=feedback, user_id=user_id,
                                                                   course_id=course_id)
            response_message = {"Status": "Success", "course_id": str(response_data), "Message": "Thanks for feedback"}
        return Response(json.dumps(response_message), mimetype='application/json', status=200)
    except Exception as e:
        print('exception logged', e)
        data = {"status": 400, "message": "COULD NOT add feedback"}
        return Response(json.dumps(data), mimetype='application/json', status=400)


@api_app.route('/close_question', methods=['POST'])
@login
def close_question(role, organisation, permissions, login_user_other_details):
    data = request.json
    question_id = data['question_id']
    question_status = data['question_status']
    user_id = login_user_other_details['_id']
    try:
        question_status, available_coin, message = Question.question_deactivate(question_id, question_status, user_id)
        if question_status == "closed":
            status = 200
            response_message = {"Status": "success", "question_status": question_status,
                                "Available_coin": available_coin, "Message": message}
        elif question_status == "Already Closed":
            response_message = {"Message": message}
            status = 500
        else:
            response_message = {"Message": message}
            status = 200
        return Response(json.dumps(response_message), mimetype='application/json', status=status)
    except Exception as e:
        traceback.print_exc()
        print('exception logged', e)
        data = {"status": 400, "message": "COULD NOT closed the question"}
        return Response(json.dumps(data), mimetype='application/json', status=400)


@api_app.route('/report_bug', methods=['Post'])
@login
def report(role, organisation, permissions, login_user_other_details):
    # data=request.json
    user_id = login_user_other_details['_id']
    type = request.form['type']
    description = request.form['description']
    report = request.files['report']
    application_type = request.form['Application_Type']
    try:
        response_message = Content.report(user_id=user_id, type=application_type, description=description,
                                          report=report, report_type=type.lower())
        if response_message:
            return Response(json.dumps(response_message), mimetype='application/json', status=200)
        else:
            data = {"status": 400, "message": "COULD NOT report"}
            return Response(json.dumps(data), mimetype='application/json', status=400)
    except Exception as e:
        print('exception logged', e)
        data = {"status": 400, "message": "COULD NOT report"}
        return Response(json.dumps(data), mimetype='application/json', status=400)


@api_app.route('/update_bug_status', methods=['Patch'])
@login
def update_bug_report(role, organisation, permissions, login_user_other_details):
    data = request.get_json()
    user_id = login_user_other_details['_id']
    bug_id = data['_id']
    try:
        response_message = Content.report_bug_status_update(role, bug_id)
        return Response(json.dumps(response_message), mimetype='application/json', status=200)
    except InvalidUsage as e:
        traceback.print_exc()
        data = {"status": e.status_code,
                "message": e.message}
        return Response(json.dumps(data), mimetype='application/json', status=e.status_code)
    except Exception as e:
        print('exception logged', e)
        data = {"status": 400, "message": "COULD NOT UPDATE"}
        return Response(json.dumps(data), mimetype='application/json', status=400)


@api_app.route("/bug_list", methods=["Get"])
@login
def bug_list(role, organisation, permissions, login_user_other_details):
    user_id = login_user_other_details['_id']
    try:
        response = Content.get_bugs(user_id, role)
        return Response(json.dumps(response), mimetype='application/json', status=200)
    except InvalidUsage as e:
        traceback.print_exc()
        data = {"status": e.status_code,
                "message": e.message}
        return Response(json.dumps(data), mimetype='application/json', status=e.status_code)
    except Exception as e:
        print('exception logged', e)
        data = {"status": 400, "message": "Internal Server Error, Please try again later."}
        return Response(json.dumps(data), mimetype='application/json', status=400)


@api_app.route('/video_answer_question', methods=['POST'])
@login
def video_answer_api(role, organisation, permissions, login_user_other_details):
    data = request.get_json()
    user_id = login_user_other_details['_id']
    asked_question = data['question']
    course_id = data['course_id']
    week = data['week']
    week_index = data['week_index']
    language = data["language"]
    subject = data["subject"]
    video_time = int(data["time"])
    coins = int(data['coins'])
    # question_id=data['question_id']
    answer_id = data['answer_id']
    try:
        check_reward_status = User.check_coins(coins_for_question=coins, user_id=user_id)
        if check_reward_status == True:
            pass
        else:
            response_message = {"Status": "Info", "question_id": "", "Message": "Insufficient balance to give reward"}
            return Response(json.dumps(response_message), mimetype='application/json', status=200)
        if language != "en":
            translated_question, converted_language = translation.question_translation(asked_question)
        else:
            translated_question = asked_question

        question_data, available_coins, image_s3_link, video_s3_link, message, notification_status = Question.\
            ask_question(question=asked_question, user_id=user_id,
                         language=language,
                         translated_question=translated_question,
                         coins=coins, category_id="",
                         question_image="", question_video="")
        if question_data:
            question_id = str(question_data)
            print(question_id)
            Content.video_answer_question(user_id, course_id, week, week_index, asked_question, question_id, video_time,
                                          answer_id)
            # response=Content.weekly_detail(course_id=course_id,week=data['week'],week_index=data['week_index'],user_id=user_id,video_time=video_time)
            # response = response['Content_detail']
            response = {}
            response['Status'] = 'Success'
            response['Message'] = 'Question added successfully'
            response['avail_coin'] = available_coins
            # print(response)
            return Response(json.dumps(response), mimetype='application/json', status=200)

        else:
            data = {"status": 400, "message": "COULD NOT Add Question"}
            return Response(json.dumps(data), mimetype='application/json', status=400)

    except Exception as e:
        print('exception logged', e)
        data = {"status": 400, "message": "COULD NOT ASk Question"}
        return Response(json.dumps(data), mimetype='application/json', status=400)


@api_app.route('/teacher_student_question', methods=['POST'])
@login
def teacher_student_ques_api(role, organisation, permissions, login_user_other_details):
    data = request.get_json()
    user_id = login_user_other_details['_id']
    course_category_id = data['course_category_id']
    # subject = data['subject']
    role = data['role']
    try:
        response_data, message = User.teacher_student_question(course_category_id=course_category_id, role=role,
                                                               teacher_id=user_id)
        # response_data, message = User.teacher_student_question(subject=subject, role=role, teacher_id=user_id)
        response = {"questions": response_data, "message": message}
        return Response(json.dumps(response), mimetype='application/json', status=200)

    except Exception as e:
        print('exception logged', e)
        data = {"status": 400, "message": "COULD NOT SHOW DATA"}
        return Response(json.dumps(data), mimetype='application/json', status=400)


@api_app.route('/teacher_student_answer', methods=['POST'])
@login
def teacher_student_ans_api(role, organisation, permissions, login_user_other_details):
    data = request.get_json()
    user_id = login_user_other_details['_id']
    course_category_id = data['course_category_id']
    # subject = data['subject']
    role = data['role']
    try:
        response_data, message = User.teacher_student_answer(course_category_id=course_category_id, role=role,
                                                             teacher_id=user_id)
        response = {"message": message, "answers": response_data}
        return Response(json.dumps(response), mimetype='application/json', status=200)

    except Exception as e:
        print('exception logged', e)
        data = {"status": 400, "message": "COULD NOT SHOW DATA"}
        return Response(json.dumps(data), mimetype='application/json', status=400)


@api_app.route('/update_question', methods=['POST'])
@login
def update_question_api(role, organisation, permissions, login_user_other_details):
    user_id = login_user_other_details['_id']
    new_question = request.form.get('question')
    language = request.form.get('language')
    category_id = request.form.get('category_id')
    question_id = request.form.get('question_id')
    question_image = request.files.get('question_image')
    delete_image_status = request.form.get('delete_image')
    question_video = request.files.get('video_path')
    delete_video_status = request.form.get('delete_video')
    coordinates = request.form.get('coordinates')
    if coordinates:
        coordinates = ast.literal_eval(coordinates)
    try:
        question_detail, message = Question.update_question(
            new_question=new_question,
            user_id=user_id,
            language=language,
            category_id=category_id,
            question_id=question_id,
            question_image=question_image,
            delete_image_status=delete_image_status,
            question_video=question_video,
            delete_video_status=delete_video_status,
            coordinates=coordinates,
            role=role)
        if question_detail and message:
            response_message = {"Status": "Success", "Message": message, "Reward": question_detail['reward'],
                                "Question": question_detail['questions'], "_id": str(question_detail['_id']),
                                "user_id": question_detail['user_id'],
                                "Course_Category": question_detail['Course_Category'],
                                "Timestamp": question_detail['Timestamp']}
            return Response(json.dumps(response_message), mimetype='application/json', status=200)
        else:
            data = {"status": 400, "message": message}
            return Response(json.dumps(data), mimetype='application/json', status=400)
    except Exception as e:
        print('exception logged', e)
        data = {"status": 400, "message": "COULD NOT ASk Question"}
        return Response(json.dumps(data), mimetype='application/json', status=400)


@api_app.route('/all_users_list', methods=['GET'])
@login
def users_list(role, organisation, permissions, login_user_other_details):
    """Provides users info present in our database, works for super admin and school admin"""
    try:
        users_data = User.get_users_info(role=role,
                                         organisation=organisation)
        return Response(json.dumps(users_data), mimetype='application/json', status=200)
    except InvalidUsage as e:
        traceback.print_exc()
        error = {"message": e.message, "status": e.status_code}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])
    except Exception as e:
        error = {"message": "Internal server error", "status": 500, "detail": e.__str__()}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])


@api_app.route('/all_users_list_new', methods=['GET'])
@login
def users_list_new(role, organisation, permissions, login_user_other_details):
    """Provides users info present in our database, works for super admin and school admin"""
    try:
        page = request.args.get('page', "")
        user_role = request.args.get("user_role", "")
        users_data = User.get_users_list(
                                            role=role, 
                                            organisation=organisation,
                                            page=page,
                                            user_role=user_role
                                        )

        return Response(json.dumps(users_data), mimetype='application/json', status=200)
    except InvalidUsage as e:
        traceback.print_exc()
        error = {"message": e.message, "status": e.status_code}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])
    except Exception as e:
        error = {"message": "Internal server error", "status": 500, "detail": e.__str__()}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])


@api_app.route('/users_list/export', methods=['POST'])
@login
def export_user_list(role, organisation, permissions, login_user_other_details):
    data = request.json
    start = data['start']
    end = data['end']
    try:
        users_data = User.get_users_info(role=role,
                                         organisation=organisation)
        if start and end:
            start = int(start)
            end = int(end)
            users_data = users_data[start - 1:end - 1]
        users_df = User.get_users_csv(users_data)
        users_df.index += 1
        output = BytesIO()
        users_df.to_excel(output, startrow=0, merge_cells=True, sheet_name="Sheet_1", engine='openpyxl')
        output.seek(0)
        file_wrapper = FileWrapper(output)
        headers = {
            'Content-Disposition': 'attachment; filename="{}"'.format('Users list.xlsx')
        }
        return Response(file_wrapper,
                        mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                        direct_passthrough=True,
                        headers=headers)
    except InvalidUsage as e:
        traceback.print_exc()
        error = {"message": e.message, "status": e.status_code}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])
    except Exception as e:
        error = {"message": "Internal server error", "status": 500, "detail": e.__str__()}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])


@api_app.route('/activate_deactivate_user', methods=['GET'])
@login
def activate_deactivate_user(role, organisation, permissions, login_user_other_details):
    """It is to activate or deactivate any user in database."""
    try:
        other_user_id = request.args['other_user_id']
        active = request.args['active']
    except KeyError as key_err:
        traceback.print_exc()
        data = {"status": 400, "message": "Please check request data.", "detail": key_err.__str__()}
        return Response(json.dumps(data), mimetype='application/json', status=400)
    try:
        res = User.change_user_status(role=role,
                                      other_user_id=other_user_id,
                                      active=active)
        return Response(json.dumps(res), mimetype='application/json', status=200)

    except InvalidUsage as e:
        traceback.print_exc()
        error = {"message": e.message, "status": e.status_code}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])

    except Exception as e:
        traceback.print_exc()
        response = {"message": "Internal server error", "status": 500, "detail": e.__str__()}
        return Response(json.dumps(response), mimetype='application/json', status=response['status'])


@api_app.route('/edit_questions', methods=['POST'])
@login
def edit_questions(role, organisation, permissions, login_user_other_details):
    """Superadmin/teacher can edit the question such as title."""
    user_id = login_user_other_details['_id']
    try:
        data = request.json
        text = data["text"]
        question_id = data["question_id"]
    except KeyError:
        traceback.print_exc()
        data = {"status": 400, "message": "Please check request data."}
        return Response(json.dumps(data), mimetype='application/json', status=400)
    try:
        response_message = Question.edit_questions(question_id=question_id,
                                                   role=role,
                                                   user_id=user_id,
                                                   text=text,
                                                   )
        return Response(json.dumps(response_message), mimetype='application/json', status=201)
    except InvalidUsage as e:
        traceback.print_exc()
        error = {"message": e.message, "detail": e.message}
        return Response(json.dumps(error), mimetype='application/json', status=e.status_code)
    except Exception as e:
        traceback.print_exc()
        error = {"detail": e.__str__(), "message": "Oops! something went wrong, Please try again later."}
        return Response(json.dumps(error), mimetype='application/json', status=500)


@api_app.route('/upload_url', methods=['POST'])
@login
def get_upload_url(role, organisation, permissions, login_user_other_details):
    user_id = login_user_other_details['_id']
    module_name = request.args.get('module_name')
    data = request.json
    files = data['files']
    try:
        unique_key = 'chat-files/' + str(int(time.time())) + '-' + str(user_id) + '.png'
        s3_url = get_urls_for_resources(module_name=module_name,
                                        files=files,
                                        user_id=user_id)
        response_message = {'url': s3_url}
        return Response(json.dumps(response_message), mimetype='application/json', status=201)
    except InvalidUsage as e:
        traceback.print_exc()
        error = {"message": e.message, "detail": e.message}
        return Response(json.dumps(error), mimetype='application/json', status=e.status_code)
    except Exception as e:
        traceback.print_exc()
        error = {"detail": e.__str__(), "message": "Oops! something went wrong, Please try again later."}
        return Response(json.dumps(error), mimetype='application/json', status=500)
