import traceback
from model import organisation as organisations

from flask import request, Response, json, Blueprint, jsonify
import model.User as User
from model.User import login
from routes.exception import InvalidUsage

organisation_apis = Blueprint("organisation_api", __name__)


@organisation_apis.route("/organisations", methods=['GET'])
@login
def get_organisations(role, organisation, permissions, login_user_other_details):
    try:
        data = organisations.fetch_organisations()
        response = {"message": "success", "data": data}
        return Response(json.dumps(response), mimetype='application/json', status=200)

    except Exception as e:
        traceback.print_exc()
        error = {"message": "Internal server error. Unable to retrieve organisations"}
        return Response(json.dumps(error), mimetype='application/json', status=500)


@organisation_apis.route("/organisations", methods=['POST'])
@login
def add_organisation(role, organisation, permissions, login_user_other_details):
    try:
        data = request.get_json()
        new_org = data['name']
    except KeyError:
        traceback.print_exc()
        error = {"message": "Please check request data", "status": 400, "data": []}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])
    try:
        data = organisations.add_organisation(role=role,
                                              user_id=login_user_other_details['_id'],
                                              new_org=new_org,organisation_type_id=data['org_type_id'])
        response = {"message": "success", "data": data}
        return Response(json.dumps(response), mimetype='application/json', status=201)
    except InvalidUsage as e:
        error = {"message": e.message, "status": e.status_code}
        return Response(json.dumps(error), mimetype='application/json', status=e.status_code)
    except Exception as e:
        traceback.print_exc()
        error = {"message": "Oh no! Something bad happened. Please try again later.", "status": 500}
        return Response(json.dumps(error), mimetype='application/json', status=500)


@organisation_apis.route("/organisations", methods=['PATCH'])
@login
def edit_organisation(role, organisation, permissions, login_user_other_details):
    try:
        data = request.get_json()
        new_org = data['name']
        organisation_id=data['org_id']
        organisation_type=data['org_type_id']
    except KeyError:
        traceback.print_exc()
        error = {"message": "Please check request data", "status": 400, "data": []}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])
    try:
        data = organisations.edit_organisation(role=role,
                                              user_id=login_user_other_details['_id'],
                                              new_org=new_org,organisation_id=organisation_id,new_type=organisation_type)
        response = {"message": "success", "data": data}
        return Response(json.dumps(response), mimetype='application/json', status=200)
    except InvalidUsage as e:
        error = {"message": e.message, "status": e.status_code}
        return Response(json.dumps(error), mimetype='application/json', status=e.status_code)
    except Exception as e:
        traceback.print_exc()
        error = {"message": "Oh no! Something bad happened. Please try again later.", "status": 500}
        return Response(json.dumps(error), mimetype='application/json', status=500)


@organisation_apis.route("/organisations/types", methods=['GET'])
@login
def organisations_types(role, organisation, permissions, login_user_other_details):
    """To get the information related to organisation's type. whether it is school, college or anything else."""
    try:
        if role != "super_admin":  # slug
            raise InvalidUsage("You don't have permission to access this functionality.", 403)
        data = organisations.fetch_organisations_type()
        return Response(json.dumps(data), mimetype='application/json', status=200)
    except InvalidUsage as e:
        error = {"message": e.message, "status": e.status_code}
        return Response(json.dumps(error), mimetype='application/json', status=e.status_code)
    except Exception as e:
        traceback.print_exc()
        error = {"message": "Oh no! Something bad happened. Please try again later.",
                 "status": 500,
                 "detail": e.__str__()}
        return Response(json.dumps(error), mimetype='application/json', status=500)
