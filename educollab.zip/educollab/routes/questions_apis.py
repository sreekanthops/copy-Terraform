from flask import request, Response, json, Blueprint, jsonify
from numpy import double
from pymongo import message
from model.User import login_user
from flask_cors import CORS, cross_origin
import model.Question as Question
import model.Content as Content
import model.User as User
from model.User import login
import services.common.translation as translation
import services.Similar_questions as Similar_questions
import services.School_Leaderboard as School_leaderboard
import services.Recommendation_engine as recommendation_engine
import services.profanity_check as Profanity_Detection
import services.User_Leaderboard as User_Leaderboard
from model.User import OAuth_login
import mongo_connection
from bson import ObjectId
import re
import csv
import io
import os
import config
import traceback
import magic as file_checker
from db_wrapper.tasks import Mongo
from model.tracking.questions import user_ques_history

mongo_session = Mongo()
from utils.elasticsearch.question import search_question
from routes.exception import InvalidUsage

question_apis = Blueprint("question_api", __name__)


@question_apis.route("/search/questions", methods=['Get'])
@login
def search_question_string_matching(role, organisation, permissions, login_user_other_details):
    user_id = login_user_other_details['_id']
    grade = login_user_other_details['grade']
    organisation = login_user_other_details['organisation']
    institute_type = login_user_other_details['institute_type']
    try:
        search_text = request.args['search_text']
        # sort_by_coins = False
        # filter_dict = {}
        #
        # if "sort_by_coins" in request.json:
        #     sort_by_coins = eval(request.json['sort_by_coins'])
        # if "status" in request.json:
        #     filter_dict = {"status":eval(request.json['status'])}
    except KeyError:
        traceback.print_exc()
        data = {"Status": 400, "Message": "Please check request data"}
        return Response(json.dumps(data), mimetype='application/json', status=400)
    try:
        question_data, api_status = Question.search_question_string_matching(institute_type=institute_type,
                                                                             organisation=organisation,
                                                                             grade=grade,
                                                                             search_text=search_text,
                                                                             role=role,
                                                                             user_id=user_id)
        return Response(json.dumps(question_data), mimetype='application/json', status=api_status)
    except Exception as e:
        traceback.print_exc()
        error = {"message": e.__str__(), "status": 500}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])


@question_apis.route("/get_tags", methods=['GET'])
def add_question_tags_res():
    try:
        status, tags = Question.fetch_question_tags()
        if status == 200:
            return Response(json.dumps(tags), mimetype='application/json', status=status)

        else:
            return Response(json.dumps(tags), mimetype='application/json', status=status)

    except Exception as e:
        print("exception", e)
        error = {"message": "internal server error", "status": 500}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])


@question_apis.route("/tags/search", methods=['GET'])
def search_tags_ap1():
    try:
        search_text = request.args["search_text"]
        status, tags = Question.search_tags(search_text=search_text)
        if status == 200:
            return Response(json.dumps(tags), mimetype='application/json', status=status)
        else:
            return Response(json.dumps(tags), mimetype='application/json', status=status)

    except Exception as e:
        print("exception", e)
        error = {"message": "internal server error", "status": 500}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])


@question_apis.route("/add-question", methods=['POST'])
@login
def add_question(role, organisation, permissions, login_user_other_details):
    """
    This api is used to add a new question
    """
    if role == 'student':
        error = {"message": "student user not allowed to add question", "status": 403}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])

    try:
        type_collection = mongo_session.get_all_data("question_type")['message']
        type_dict = dict(map(lambda x: (str(x['_id']), x['value']), type_collection))
    except Exception as e:
        return Response(json.dumps({"message": "failed", "detail": e.__str__()}), mimetype='application/json',
                        status=400)

    try:
        data = request.get_json()
        user_id = login_user_other_details['_id']
        complexity = data['complexity']
        course_id = data['course']
        question = data['question']
        tags = data['tags']
        duration = data['duration']
        ques_type = data['type']
        marks = data['marks']

        if type_dict[str(ques_type)] == 'comprehension':
            sub_qus = data['sub_qus']
            meta_data = []

        elif type_dict[str(ques_type)] == 'fib':
            meta_data = data['meta_data']
            if not meta_data[0]['answer']:
                if not meta_data[0]['answer_max_len']:
                    return jsonify({"message": "answer and answer_max_len cannot be blank."}), 500
                else:
                    return jsonify({"message": "answer cannot be blank."}), 500
            else:
                if not meta_data[0]['answer_max_len']:
                    return jsonify({"message": "answer_max_len cannot be blank."}), 500
                elif meta_data[0]['answer_max_len'] == str(len(meta_data[0]['answer'])):
                    sub_qus = []
                else:
                    return jsonify({"message": "answer_max_len must be the no. of characters of answer."}), 500

        else:
            meta_data = data['meta_data']
            if meta_data:
                check = 0
                for ans in meta_data:
                    if ans['answer'] == False:
                        check += 1
                if check == len(meta_data):
                    return jsonify({"message": "One answer must be True."}), 500
                else:
                    sub_qus = []

        if not question:
            error = {"message": "Question is required.", "status": 400}
            return Response(response=json.dumps(error), mimetype='application/json', status=error['status'])
        else:
            question_data, api_status = Question.insert_question(user_id=user_id, course_id=course_id,
                                                                 question=question,
                                                                 tags=tags, complexity=complexity, meta_data=meta_data,
                                                                 ques_type=ques_type, duration=duration,
                                                                 sub_qus=sub_qus, marks=marks)
            return Response(json.dumps(question_data), mimetype='application/json', status=api_status)

    except Exception as e:
        traceback.print_exc()
        error = {"message": "Internal server error", "status": 500, "detail": e.__str__()}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])


@question_apis.route('/search_add_questions', methods=['GET'])
@login
def search_add_questions(role, organisation, permissions, login_user_other_details):
    if role == 'student':
        error = {"message": "student user not allowed", "status": 403}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])
    question_tag = request.args.get('question_tag')
    try:
        question_data = search_question(question_tag=question_tag, organisation=organisation)
        return Response(json.dumps(question_data), mimetype='application/json', status=200)

    except Exception as e:
        traceback.print_exc()
        error = {"message": "internal server error", "status": 500}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])


@question_apis.route("/get_complexities", methods=['GET'])
def add_question_complexity_res():
    try:
        (status, complexity) = Question.fetch_question_complexities()
        if status == 200:
            return Response(json.dumps(complexity), mimetype='application/json', status=status)

        else:
            return Response(json.dumps(complexity), mimetype='application/json', status=status)

    except Exception as e:
        print("exception", e)
        error = {"message": "internal server error", "status": 500}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])


@question_apis.route("/get_questype", methods=['GET'])
def add_question_type_res():
    try:
        (status, type) = Question.fetch_question_type()
        if status == 200:
            return Response(json.dumps(type), mimetype='application/json', status=status)

        else:
            return Response(json.dumps(type), mimetype='application/json', status=status)

    except Exception as e:
        print("exception", e)
        error = {"message": "internal server error", "status": 500}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])


@question_apis.route("/upload_files_add_question", methods=['POST'])
@login
def upload_files_add_question(role, organisation, permissions, login_user_other_details):
    try:
        file_path = request.files.get('file_path')
        user_id = login_user_other_details['_id']

        uploaded_data, status = Question.upload_files_questionbank(user_id=user_id, file_path=file_path)

        if status == 200:
            return Response(json.dumps(uploaded_data), mimetype='application/json', status=status)
        else:
            return Response(json.dumps(uploaded_data), mimetype='application/json', status=status)

    except Exception as e:
        print("exception", e)
        error = {"message": "internal server error", "status": 500}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])


@question_apis.route("/edit_question", methods=['POST'])
@login
def edit_question(role, organisation, permissions, login_user_other_details):
    if role == 'student':
        error = {"message": "students are not allowed to edit questions", "status": 403}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])

    try:

        type_collection = mongo_session.get_all_data("question_type")['message']
        type_dict = dict(map(lambda x: (str(x['_id']), x['value']), type_collection))

        data = request.get_json()
        user_id = login_user_other_details['_id']
        complexity = data['complexity']
        course_id = data['course']
        question = data['question']
        tags = data['tags']
        duration = data['duration']
        ques_type = data['type']
        question_id = data['_id']
        import_ques = data['in_import_table']
        marks = data['marks']

        if type_dict[str(ques_type)] == 'comprehension':
            sub_qus = data['sub_qus']
            meta_data = []
        else:
            meta_data = data['meta_data']
            sub_qus = []

        res, status = Question.update_question_db(user_id=user_id, course_id=course_id, question=question, tags=tags,
                                                  complexity=complexity, duration=duration, question_id=question_id,
                                                  meta_data=meta_data, ques_type=ques_type, import_ques=import_ques,
                                                  sub_qus=sub_qus, marks=marks)

        return Response(json.dumps(res), mimetype='application/json', status=status)

    except Exception as e:
        print("exception", e)
        error = {"message": "internal server error", "status": 500}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])


@question_apis.route("/create_assessment", methods=['POST'])
@login
def create_assessment(role, organisation, permissions, login_user_other_details):
    """
       This Api is used to insert an Assessment in the Database
       """
    if role == 'student':
        error = {"message": "student user not allowed", "status": 403}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])
    try:
        user_id = login_user_other_details['_id']
        req_data = request.get_json()
        assessment_name = req_data['assessment_name']
        assessment_type = req_data['assessment_type']
        total_time = req_data['total_time']
        tags = req_data['tags']
        questions = req_data['selectedQus']
        publish = req_data['publish']
        negative_marking = req_data['negativeMarking']
        negative_value = req_data['negativeValue']
        total_marks = req_data['totalMarks']
        assign_marks = req_data['assignMarks']
        assessment_description = req_data.get('assessment_description', '')
        res = Question.insert_created_assessment(user_id=user_id, assessment_name=assessment_name,
                                                 type=assessment_type, total_time=total_time, tags=tags,
                                                 questions=questions, publish=publish,
                                                 negative_marking=negative_marking,
                                                 negative_value=negative_value,
                                                 assign_marks=assign_marks, total_marks=total_marks,
                                                 org_name=organisation, assessment_description=assessment_description)
        return Response(json.dumps(res), mimetype='application/json', status=201)

    except InvalidUsage as e:
        error = {"message": e.message, "status": e.status_code}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])
    except Exception as e:
        traceback.print_exc()
        error = {"message": "internal server error", "status": 500}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])


@question_apis.route('/edit_assessment', methods=['POST'])
@login
def edit_assessment(role, organisation, permissions, login_user_other_details):
    if role == 'student':
        error = {"message": "student user not allowed to edit assessment", "status": 403}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])
    try:
        user_id = login_user_other_details["_id"]
        req_data = request.get_json()
        assessment_name = req_data['assessment_name']
        assessment_id = req_data['_id']
        assessment_type = req_data['assessment_type']
        questions = req_data['selectedQus']
        total_time = req_data['total_time']
        tags = req_data['tags']
        publish = req_data['publish']
        negative_marking = req_data['negativeMarking']
        negative_value = req_data['negativeValue']
        total_marks = req_data['totalMarks']
        assign_marks = req_data['assignMarks']
        created_by = req_data['user_id']
        assessment_description = req_data.get('assessment_description', '')
        res_data = Question.update_assessment(user_id=user_id, assessment_id=assessment_id,
                                              assessment_name=assessment_name, assessment_type=assessment_type,
                                              tags=tags, questions=questions, total_time=total_time,
                                              publish=publish, negative_marking=negative_marking,
                                              negative_value=negative_value, assign_marks=assign_marks,
                                              total_marks=total_marks, org_name=organisation, created_by=created_by, 
                                              assessment_description=assessment_description)
        return Response(json.dumps(res_data), mimetype='application/json', status=200)

    except InvalidUsage as e:
        error = {"message": e.message, "status": e.status_code}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])

    except Exception as e:
        traceback.print_exc()
        error = {"message": "internal server error", "status": 500}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])


@question_apis.route("/get_saved_assessment", methods=['GET'])
@login
def get_saved_assessment(role, organisation, permissions, login_user_other_details):
    if role == 'student':
        error = {"message": "student user not allowed", "status": 403}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])
    try:
        user_id = login_user_other_details['_id']
        page = request.args.get("current_page")
        published = request.args.get("type")
        res, status = Question.saved_assessment_info(user_id, page, published)
        return Response(json.dumps(res), mimetype='application/json', status=status)
    except Exception as e:
        traceback.print_exc()
        error = {"message": "internal server error", "status": 500}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])


@question_apis.route("/assessment", methods=['DELETE'])
@login
def delete_current_assessment(role, organisation, permissions, login_user_other_details):
    if role == 'student':
        error = {"message": "student user not allowed", "status": 403}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])
    try:
        user_id = login_user_other_details['_id']
        assessment_id = request.args.get("assessment_id")
        res, status = Question.delete_assessment(user_id, assessment_id)
        return Response(json.dumps(res), mimetype='application/json', status=status)
    except InvalidUsage as e:
        traceback.print_exc()
        data = {"detail": e.message,
                "message": e.message,
                "status": e.status_code}
        return Response(json.dumps(data), mimetype='application/json', status=e.status_code)
    except Exception as e:
        traceback.print_exc()
        error = {"message": "internal server error", "status": 500}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])


@question_apis.route("/assessment/search", methods=['Get'])
@login
def search_all_assessment(role, organisation, permissions, login_user_other_details):
    if role == 'student':
        error = {"message": "student user not allowed", "status": 403}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])
    try:
        user_id = login_user_other_details["_id"]
        search_text = request.args['search_text']
        page = request.args['page']
    except KeyError:
        traceback.print_exc()
        data = {"Status": 400, "Message": "Please check request data"}
        return Response(json.dumps(data), mimetype='application/json', status=400)
    try:
        question_data, api_status = Question.search_assessment(search_text=search_text,
                                                                user_id=user_id,
                                                                page=int(page))
        return Response(json.dumps(question_data), mimetype='application/json', status=api_status)
    except Exception as e:
        traceback.print_exc()
        error = {"message": e.__str__(), "status": 500}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])


@question_apis.route("/schedule_assessment_list", methods=['GET'])
def schedule_asssessment_list():
    try:
        # res, api_status = Question.list_schedule_assessment()
        res, api_status = "This API is deprecated", 200
        return Response(json.dumps(res), mimetype='application/json', status=api_status)

    except Exception as e:
        print("exception", e)
        error = {"message": "internal server error", "status": 500}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])


@question_apis.route("/get_assessment_list", methods=['GET'])
@login
def assessment_list(role, organisation, permissions, login_user_other_details):
    try:

        user_id = login_user_other_details['_id']

        if role == 'stduent':
            error = {"message": "student user not allowed", "status": 403}
            return Response(json.dumps(error), mimetype='application/json', status=error['status'])

        else:
            res, api_status = Question.get_list_assessments(user_id)
            return Response(json.dumps(res), mimetype='application/json', status=api_status)

    except Exception as e:
        print("exception", e)
        error = {"message": "internal server error", "status": 500}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])


@question_apis.route('/questions/answer', methods=['POST'])
@login
def submit_answer(role, organisation, permissions, login_user_other_details):
    """This to submit the answers given by users on someone else's question.
       video: contains video_path and thumbnails in form of s3_keys.
    """
    # Note : user can not answer his/her own question.
    user_id = login_user_other_details['_id']
    try:
        data = request.get_json()
        question_id = data['question_id']
        speech_text = data['speech_text']
        answer_html = data['answer_html']
        video_info = data.get('video', {})
        answer_image = data.get('answer_image', [])
        answer_video = data.get('answer_video', [])
        answer_doc = data.get('answer_doc', [])
        coordinates = list(data.get('coordinates', []))
    except KeyError as err:
        traceback.print_exc()
        data = {"message": "Please check all the request data.",
                "detail": err.__str__()}
        return Response(json.dumps(data), mimetype='application/json', status=400)
    try:
        response = Question.submit_answer(question_id=question_id,
                                          user_id=user_id,
                                          answer_html=answer_html,
                                          speech_text=speech_text,
                                          video_info=video_info,
                                          coordinates=coordinates,
                                          answer_image=answer_image,
                                          answer_video=answer_video,
                                          answer_doc=answer_doc
                                          )
        return Response(json.dumps(response), mimetype='application/json', status=201)

    except InvalidUsage as e:
        traceback.print_exc()
        error = {"message": e.message, "detail": e.message}
        return Response(json.dumps(error), mimetype='application/json', status=e.status_code)
    except Exception as e:
        traceback.print_exc()
        data = {"detail": e.__str__(), "message": "Oops! something went wrong, Please try again later."}
        return Response(json.dumps(data), mimetype='application/json', status=500)


@question_apis.route("/similar_questions", methods=["GET"])
@login
def similar_questions(role, organisation, permissions, login_user_other_details):
    grade = login_user_other_details['grade']
    org_type = login_user_other_details['institute_type']
    try:
        question_id = request.args['question_id']
        search_text = request.args['search_text']

        user_id = login_user_other_details['_id']
    except KeyError:
        traceback.print_exc()
        data = {"status": 400, "message": "Please check request data."}
        return Response(json.dumps(data), mimetype='application/json', status=400)
    try:
        question_data, api_status = Question.search_similar_questions(
            question_id=question_id,
            org_type=org_type,
            grade=grade,
            search_text=search_text,
            role=role,
            user_id=user_id)
        return Response(json.dumps(question_data), mimetype='application/json', status=200)
    except InvalidUsage as e:
        traceback.print_exc()
        error = {"message": e.message, "detail": e.message}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])
    except Exception as e:
        traceback.print_exc()
        error = {"detail": e.__str__(), "message": "Oops! something went wrong, Please try again later."}
        return Response(json.dumps(error), mimetype='application/json', status=500)


@question_apis.route("/upload_questions", methods=['POST'])
@login
def upload_aiken_moodle_questions(role, organisation, permissions, login_user_other_details):
    """
    this api parse aiken and moodle format questions and upload it in database
    """
    if role == 'student':
        error = {"message": "student user not allowed to add questions", "status": 403}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])
    try:
        file_path = request.files.get('file_path')
        qtype = request.form.get('ques_type')
        file_type = file_checker.from_buffer(file_path.read(1024), mime=True)

    except Exception as e:
        traceback.print_exc()
        error = {"message": "file read error", "status": 500}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])
    try:
        user_id = login_user_other_details['_id']
        if file_type == "text/plain" or file_type == 'text/csv' or file_type == 'application/csv':
            format_questions_fn = Question.aiken_format_questions
        # elif file_type == "text/xml":
        #     format_questions_fn = Question.moodle_format_questions
        else:
            raise IOError
        data, api_status = format_questions_fn(file_path=file_path, qtype=qtype, user_id=user_id)
        return Response(json.dumps(data, default=str), mimetype='application/json', status=api_status)

    except InvalidUsage as e:
        error = {"message": e.message, "status": e.status_code}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])
    
    except IOError as e:
        error = {"message": "only text and xml files are allowed", "status": 400}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])

    except Exception as e:
        traceback.print_exc()
        error = {"message": "internal server error", "status": 500}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])


@question_apis.route("/get_import_questions", methods=['GET'])
@login
def import_question_list(role, organisation, permissions, login_user_other_details):
    if role == 'student':
        error = {"message": "student user not allowed", "status": 403}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])
    try:
        user_id = login_user_other_details['_id']
        res_data, api_status = Question.import_question_info(user_id=user_id)
        return Response(json.dumps(res_data), mimetype='application/json', status=api_status)

    except Exception as e:
        print("exception", e)
        error = {"message": "internal server error", "status": 500}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])


@question_apis.route("/questions", methods=["GET"])
@login
def fetch_answers(role, organisation, permissions, login_user_other_details):
    """1. To fetch details and answers of a particular question, if question id is provided.
       2. To fetch questions on a particular session if course id a nd session id is provided.
       3. To fetch user specific questions, if user id is given."""
    user_id = login_user_other_details['_id']
    question_id = request.args.get('id')
    session_id = request.args.get('course_session_id')
    course_id = request.args.get('course_id')
    user_specific = request.args.get('user_specific')
    try:
        if question_id:
            # add question to user tracking
            user_ques_history(user_id, question_id)
            response_data = Content.answer_to_questions(question_id=question_id)
            message = "Data has been retrieved successfully."
        else:
            response_data = Content.get_questions_info(session_id=session_id,
                                                       course_id=course_id,
                                                       user_specific=user_specific,
                                                       user_id=user_id)
            message = "Questions has been retrieved successfully." if response_data else "No questions to show, start " \
                                                                                         "collaborating. "
        data = {"message": message,
                "response": response_data}
        return Response(json.dumps(data), mimetype='application/json', status=200)
    except InvalidUsage as e:
        traceback.print_exc()
        error = {"message": e.message, "detail": e.message}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])
    except Exception as e:
        traceback.print_exc()
        response_data = {"detail": e.__str__(),
                         "message": "Oops! something went wrong, please try again later."}
        response = Response(json.dumps(response_data), mimetype='application/json', status=500)
        return response


@question_apis.route("/delete_questions", methods=['DELETE'])
@login
def delete_questions(role, organisation, permissions, login_user_other_details):
    """
    this api will delete questions
    """
    try:
        question_id = request.args.get("question_id")
        answer_id = request.args.get("answer_id") if request.args.get("answer_id") else None
        user_id = login_user_other_details['_id']
        message = Question.delete_question(user_id, role, question_id, answer_id)

        return Response(json.dumps(message), mimetype='application/json', status=message["status"])

    except KeyError as e:
        error = {"message": "Question_id not found", "status": 400}

    except Exception as e:
        traceback.print_exc()
        error = {"message": "internal server error", "status": 500}
    return Response(json.dumps(error), mimetype='application/json', status=error['status'])


@question_apis.route("/delete_answers",methods=['DELETE'])
@login
def delete_answers(role, organisation, permissions, login_user_other_details):
    """
    this api will delete answers
    """
    try:
        answer_id = request.args.get("answer_id")
        question_id = request.args.get("question_id") if request.args.get("question_id") else None
        user_id = login_user_other_details['_id']
        message = Question.delete_answer(user_id, role, question_id, answer_id)

        return Response(json.dumps(message), mimetype='application/json', status=message["status"])

    except KeyError as e:
        error = {"message": "Answer_id not found", "status": 400}

    except Exception as e:
        traceback.print_exc()
        error = {"message": "internal server error", "status": 500}
    return Response(json.dumps(error), mimetype='application/json', status=error['status'])


@question_apis.route("/delete_add_questions", methods=['DELETE'])
@login
def delete_questions_add(role,organisation,permissions,login_user_other_details):
    """
    this api will delete add questions
    """
    try:
        question_id = request.args.get("question_id")
        user_id = login_user_other_details['_id']
        message = Question.delete_add_question(user_id, role, question_id)

        return Response(json.dumps(message), mimetype='application/json', status=message["status"])

    except KeyError as e:
        error = {"message": "Question_id not found", "status": 400}

    except InvalidUsage as e:
        traceback.print_exc()
        error = {"message": e.message, "status": e.status_code}

    except Exception as e:
        traceback.print_exc()
        error = {"message": "internal server error", "status": 500}

    return Response(json.dumps(error), mimetype='application/json', status=error['status'])


@question_apis.route("/add_upload_questions",methods=['POST'])
@login
def add_upload_question(role,organisation,permissions,login_user_other_details):
    try:
        data = request.get_json()
        question_data = data['data']
        user_id = login_user_other_details['_id']
        message, api_status = Question.add_uploaded_ques(user_id=user_id, role=role, organisation= organisation, question_data=question_data)
        return Response(json.dumps({"message": message}), mimetype='application/json', status=api_status)

    except InvalidUsage as e:
        traceback.print_exc()
        error = {"message": e.message, "status": e.status_code}

    except Exception as e:
        traceback.print_exc()
        error = {"message": "internal server error", "status": 500}
    return Response(json.dumps(error), mimetype='application/json', status=error['status'])