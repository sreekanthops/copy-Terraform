import traceback
from flask import request, Response, json, Blueprint, jsonify
from model import taxonomy
from model.User import login
from routes.exception import InvalidUsage

taxonomy_category_api = Blueprint("tag_category_api", __name__)


@taxonomy_category_api.route("/edit_taxonomy", methods=["Patch"])
@login
def taxonomy_edit(role, organisation, permissions, login_user_other_details):
    """Purpose: To edit subject category in db with provided id."""
    try:
        data = request.get_json()
        tag_id = data["id"]
        category_name = data["category_name"]

    except KeyError:
        traceback.print_exc()
        data = {"status": 400, "message": "Please check request data."}
        return Response(json.dumps(data), mimetype='application/json', status=400)

    try:
        status_message, api_status = taxonomy.edit_tag(role=role,
                                                       tag_id=tag_id,
                                                       category_name=category_name)
        response_message = {"status": api_status, "message": status_message}
        response = Response(json.dumps(response_message), mimetype='application/json',
                            status=response_message['status'])
        return response

    except InvalidUsage as e:
        traceback.print_exc()
        data = {"detail": e.message,
                "message": e.message,
                "status": e.status_code}
        return Response(json.dumps(data), mimetype='application/json', status=e.status_code)

    except Exception as e:
        traceback.print_exc()
        response_data = {"detail": e.__str__(), "message": "Oops! Something went wrong, Please try again later."}
        response = Response(json.dumps(response_data), mimetype='application/json', status=500)
        return response


@taxonomy_category_api.route("/add_taxonomy", methods=["Post"])
@login
def taxonomy_add(role, organisation, permissions, login_user_other_details):
    """Purpose: To add new subject category in db."""
    try:
        data = request.get_json()
        category_name = data["category_name"]
        parent_id = data.get("parent_id", None)

    except KeyError:
        traceback.print_exc()
        data = {"status": 400, "message": "Please check request data."}
        return Response(json.dumps(data), mimetype='application/json', status=400)

    try:
        status_message, api_status = taxonomy.add_tag(role=role,
                                                      parent_id=parent_id,
                                                      category_name=category_name)
        response_message = {"status": api_status, "message": status_message}
        response = Response(json.dumps(response_message), mimetype='application/json',
                            status=response_message['status'])
        return response

    except InvalidUsage as e:
        traceback.print_exc()
        data = {"detail": e.message,
                "message": e.message,
                "status": e.status_code}
        return Response(json.dumps(data), mimetype='application/json', status=e.status_code)

    except Exception as e:
        traceback.print_exc()
        response_data = {"detail": e.__str__(), "message": "Oops! Something went wrong, Please try again later."}
        response = Response(json.dumps(response_data), mimetype='application/json', status=500)
        return response


@taxonomy_category_api.route("/get_taxonomy", methods=["GET"])
@login
def taxonomy_get(role, organisation, permissions, login_user_other_details):
    """Purpose: to fetch all subject category from db."""
    try:
        status_message, api_status = taxonomy.get_tag(role=role)
        response_message = {"status": api_status, "message": status_message}
        response = Response(json.dumps(response_message), mimetype='application/json',
                            status=response_message['status'])
        return response

    except InvalidUsage as e:
        traceback.print_exc()
        data = {"detail": e.message,
                "message": e.message,
                "status": e.status_code}
        return Response(json.dumps(data), mimetype='application/json', status=e.status_code)

    except Exception as e:
        traceback.print_exc()
        response_data = {"detail": e.__str__(), "message": "Oops! Something went wrong, Please try again later."}
        response = Response(json.dumps(response_data), mimetype='application/json', status=500)
        return response

