from flask import Blueprint
transcript_apis = Blueprint("transcript_api", __name__)
from routes.transcription.main import *