import traceback
from flask import request, Response, json
from model.transcription import video_transcript
from model.User import login
from routes.exception import InvalidUsage
from routes.transcription import transcript_apis


@transcript_apis.route("/transcript", methods=["Patch"])
@login
def transcript_edit(role, organisation, permissions, login_user_other_details):
    """Purpose: To edit video transcription in db with provided id."""
    try:
        user_id = login_user_other_details['_id']
        data = request.get_json()
        s3_key = data["s3_key"]
        suggestion = data["suggestion"]
        transcript_status = data["status"]
        starttime = data["starttime"]
        endtime = data["endtime"]

    except KeyError:
        traceback.print_exc()
        data = {"status": 400, "message": "Please check request data."}
        return Response(json.dumps(data), mimetype='application/json', status=400)

    try:
        status_message, api_status = video_transcript.transcript_update(user_id=user_id,
                                                                        s3_key=s3_key,
                                                                        role=role,
                                                                        suggestion=suggestion,
                                                                        transcript_status=transcript_status,
                                                                        starttime=starttime,
                                                                        endtime=endtime)
        response_message = {"status": api_status, "message": status_message}
        response = Response(json.dumps(response_message), mimetype='application/json',
                            status=response_message['status'])
        return response

    except InvalidUsage as e:
        traceback.print_exc()
        data = {"detail": e.message,
                "message": e.message,
                "status": e.status_code}
        return Response(json.dumps(data), mimetype='application/json', status=e.status_code)

    except Exception as e:
        traceback.print_exc()
        response_data = {"detail": e.__str__(), "message": "Oops! Something went wrong, Please try again later."}
        response = Response(json.dumps(response_data), mimetype='application/json', status=500)
        return response