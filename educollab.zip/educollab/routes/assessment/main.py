from io import BytesIO
import pdfkit

from routes.assessment import assessment_api
from flask import request, Response, json
from model.User import login
from model.assessment import utils
import traceback
from routes.exception import InvalidUsage
from model.Question import indian_standard_time
from datetime import datetime
from utils.misc import is_empty
from db_wrapper.tasks import Mongo
mongo_session = Mongo()
from bson import ObjectId
from model.course_work_wrapper import submissions
import model.Question as Question
from utils.misc import send_confirmation_email
# from xhtml2pdf import pisa


@assessment_api.route("/assessment-view", methods=['POST'])
@login
def view_assessment(role, organisation, permissions, login_user_other_details):
    """
        This api provides view of particular assessment along with selected components
    """
    try:
        req_data = request.get_json()
        assessment_id = req_data['assessment_id']
        components = req_data['dropdownlist']
    except KeyError:
        traceback.print_exc()
        error = {"message": "bad request", "status": 400}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])
    try:
        user_id = login_user_other_details['_id']
        res_data = utils.view_assessment(assessment_id=assessment_id, components=components, user_id=user_id)
        return Response(json.dumps(res_data), mimetype='application/json', status=200)
    except InvalidUsage as e:
        error = {"message": e.message, "status": e.status_code}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])
    except Exception as e:
        traceback.print_exc()
        error = {"message": "internal server error. Unable to get assessment", "status": 500}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])


@assessment_api.route("/assessment/generatePdf", methods=['POST'])
@login
def generate_pdf_assessment(role, organisation, permissions, login_user_other_details):
    """
    This api generates pdf for the assessment id provided
    """
    try:
        req_data = request.get_json()
        assessment_id = req_data['assessment_id']
        components = req_data['dropdownlist']
    except KeyError:
        traceback.print_exc()
        error = {"message": "bad request", "status": 400}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])
    try:
        user_id = login_user_other_details['_id']
        response, output = utils.create_table_for_assessment(assessment_id=assessment_id,
                                                             components=components,
                                                             user_id=user_id)
        res_data = utils.display_assessment(user_id=user_id, assessment_id=assessment_id)['assessment']
        output.seek(0)
        pdf = BytesIO()
        response = pdfkit.from_string(output.getvalue(), pdf.getvalue())
        filename = res_data['assessment_name'] + ".pdf"
        headers = {
            'Content-Type': 'application/pdf',
            'Content-Disposition': f'inline; filename={filename}'
        }
        return Response(response, mimetype='application/pdf', headers=headers, status=200)
    except InvalidUsage as e:
        error = {"message": e.message, "status": e.status_code}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])
    except Exception as e:
        traceback.print_exc()
        error = {"message": "internal server error. Unable to get assessment", "status": 500}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])


@assessment_api.route("/assessment-feedback", methods=['GET'])
@login
def get_assessment_feedback(role, organisation, permissions, login_user_other_details):
    """
    This api provides the teacher feedback of assessment given by student.
    """
    try:
        assessment_id = request.args['assessment_id']
        assessment_result_id = request.args.get('assessment_result_id')
        course_id = request.args['course_id']
        schedule_id = request.args.get('schedule_id')
        required_user = request.args.get('user_id')
        topic_id = request.args["topic_id"]
        course_session_id = request.args["course_session_id"]
        device = request.args.get("device", "web")
    except KeyError:
        error = {"message": "Bad Request", "status": 400}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])
    try:
        user_id = login_user_other_details['_id']
        res_data = utils.get_assessment_submission_student(user_id=user_id,
                                                           assessment_id=assessment_id,
                                                           schedule_id=schedule_id,
                                                           course_id=course_id,
                                                           required_user=required_user,
                                                           topic_id=topic_id,
                                                           course_session_id=course_session_id,
                                                           assessment_result_id=assessment_result_id,
                                                           role=role,
                                                           device=device)
        return Response(json.dumps(res_data), mimetype='application/json', status=200)
    except InvalidUsage as e:
        error = {"message": e.message, "status": e.status_code}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])
    except Exception as e:
        traceback.print_exc()
        error = {"message": "Internal server error. Unable to get assessment", "status": 500, "detail": e.__str__()}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])


@assessment_api.route("/upcoming-assessments", methods=['GET'])
@login
def get_student_upcoming_assessments(role, organisation, permissions, login_user_other_details):
    """
    This api gives all the assessments of courses subscribed by the students
    """
    try:
        user_id = login_user_other_details['_id']
        subscribed_courses = login_user_other_details.get('subscribed_courses')
        if not subscribed_courses:
            subscribed_courses = []
        res_data = utils.get_upcoming_assessments(user_id=user_id, subscribed_courses=subscribed_courses)
        return Response(json.dumps(res_data), mimetype='application/json', status=200)

    except InvalidUsage as e:
        error = {"message": e.message, "status": e.status_code}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])

    except Exception as e:
        traceback.print_exc()
        error = {"message": "internal server error. Unable to get assessments", "status": 500, "detail": e.__str__()}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])


@assessment_api.route("/assessment-status", methods=['GET'])
@login
def get_student_submitted_assessment(role, organisation, permissions, login_user_other_details):
    """
    This api gives the list of all submitted assessment of a user with status for the current month.
    """
    try:
        user_id = login_user_other_details['_id']
        timestamp = indian_standard_time()
        current_time = datetime.strptime(timestamp, "%d %b %Y, %I:%M %p")
        month = current_time.month
        year = current_time.year
        starting_date = datetime.strptime("{year}:{month}:1T00:00".format(year=year, month=month)
                                          , "%Y:%m:%dT%H:%M")

        time_period = (starting_date, current_time)
        assessments_list = utils.get_assessments_in_time_period(user_id=user_id, time_period=time_period)
        return Response(json.dumps({"assessments": assessments_list}), mimetype='application/json', status=200)

    except Exception as e:
        traceback.print_exc()
        error = {"message": "Internal server error, Unable to get assessment.",
                 "detail": e.__str__()}
        return Response(json.dumps(error), mimetype='application/json', status=500)


@assessment_api.route("/assessments/submission/remarks", methods=['POST'])
@login
def give_remarks_on_submissions(role, organisation, permissions, login_user_other_details):
    """
    This api is used by teacher to give remarks to the user's submissions for a particular assessment.
    """
    checker_id = login_user_other_details['_id']
    try:
        req_data = request.get_json()
        schedule_id = req_data.get("schedule_assessment_id", None)
        topic_id = req_data['topic_id']
        session_id = req_data['course_session_id']
        assessment_id = req_data['assessment_id']
        course_id = req_data['course_id']
        remark = req_data.get('remark','')
        user_id = req_data['user_id']
        question_id = req_data['question_id']
        grade = str(req_data['grade'])
        assessment_result_id = req_data['assessment_result_id']
        # if (is_empty(grade) and is_empty(remark)) or (not is_empty(grade) and not is_empty(remark)):
        if (is_empty(grade) and is_empty(remark)):
            error = {"message": "Bad Request", "detail": "Please enter either a remark or grade.", "status": 400}
            return Response(json.dumps(error), mimetype='application/json', status=error['status'])

        if not is_empty(grade):
            grade = str(int(grade))

    except ValueError as e:
        traceback.print_exc()
        error = {"message": "Bad Request", "detail": e.__str__(), "status": 400}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])
    except KeyError as e:
        traceback.print_exc()
        error = {"message": "Bad Request", "detail": e.__str__(), "status": 400}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])
    try:
        res_data = utils.add_remark(user_id=user_id,
                                    question_id=question_id,
                                    remark=remark,
                                    course_id=course_id,
                                    assessment_id=assessment_id,
                                    session_id=session_id,
                                    topic_id=topic_id,
                                    schedule_id=schedule_id,
                                    checker_id=checker_id,
                                    assessment_result_id=assessment_result_id,
                                    grade=grade,
                                    role=role)
        response = {"message": res_data}
        return Response(json.dumps(response), mimetype='application/json', status=201)

    except InvalidUsage as e:
        error = {"message": "Could not add remark. Please try again later. Contact support if the problem persists.",
                 "detail": e.message,
                 "status": e.status_code}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])
    except Exception as e:
        traceback.print_exc()
        error = {"message": "Internal server error", "detail": e.__str__(), "status": 500}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])


@assessment_api.route("/assessments/submission/users", methods=['GET'])
@login
def users_info(role, organisation, permissions, login_user_other_details):
    """
    This api provides the teacher feedback of assessment given by student.
    """
    try:
        assessment_id = request.args['assessment_id']
        course_id = request.args['course_id']
        schedule_id = request.args.get('schedule_id')
    except KeyError:
        error = {"message": "Bad Request", "status": 400}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])
    try:
        res_data = utils.submit_assess_user_info(role=role,
                                                 assessment_id=assessment_id,
                                                 schedule_id=schedule_id,
                                                 course_id=course_id)
        response = {"message": "Data retrieved successfully.",
                    "response": res_data}
        return Response(json.dumps(response), mimetype='application/json', status=200)

    except InvalidUsage as e:
        error = {"message": e.message, "status": e.status_code}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])

    except Exception as e:
        traceback.print_exc()
        error = {"message": "Internal server error", "detail": e.__str__(), "status": 500}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])


@assessment_api.route("/assessments/submission/question-detail", methods=['GET'])
@login
def assessment_question_poll(role, organisation, permissions, login_user_other_details):
    """
    This api provides full information about the question answered by students in the assessment. Currently it will work
    for multiple choice questions only.
    """
    try:
        assessment_id = request.args['assessment_id']
        course_id = request.args['course_id']
        course_session_id = request.args['course_session_id']
        topic_id = request.args['topic_id']
        schedule_id = request.args.get('schedule_id')
    except KeyError:
        error = {"message": "Bad Request", "status": 400}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])
    try:
        res_data = utils.assessment_questions_detail(role=role,
                                                     assessment_id=assessment_id,
                                                     schedule_id=schedule_id,
                                                     course_id=course_id,
                                                     topic_id=topic_id,
                                                     course_session_id=course_session_id)
        response = {"message": "Data retrieved successfully.",
                    "questions": res_data}
        return Response(json.dumps(response), mimetype='application/json', status=200)

    except InvalidUsage as e:
        error = {"message": e.message, "status": e.status_code}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])
    except Exception as e:
        traceback.print_exc()
        error = {"message": "Internal server error", "status": 500, "detail": e.__str__()}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])


@assessment_api.route("/assessment", methods=['GET'])
@login
def get_assessment(role, organisation, permissions, login_user_other_details):
    schedule_assessment_id = request.args.get('schedule_assessment_id')
    assessment_id = request.args.get('assessment_id')
    try:
        if schedule_assessment_id:
            schedule_assessment_data = mongo_session.get_schedule_Assessment_info(collection="schedule_assessment",
                                                                                  condition={"_id": ObjectId(
                                                                                      schedule_assessment_id)}
                                                                                  )['message'][0]
            assessment_id = schedule_assessment_data['assessment_id']

        # Bad request if both parameters are None
        if schedule_assessment_id is None and assessment_id is None:
            raise KeyError
        user_id = login_user_other_details['_id']
        res_data = utils.display_assessment(user_id=user_id,
                                            schedule_assessment_id=schedule_assessment_id,
                                            assessment_id=assessment_id)
        return Response(json.dumps(res_data), mimetype='application/json', status=200)

    except InvalidUsage as e:
        traceback.print_exc()
        error = {"message": e.message, "status": e.status_code, "detail": e.__str__()}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])

    except KeyError as e:
        error = {"message": "Bad Request", "status": 400, "detail": e.__str__()}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])

    except Exception as e:
        traceback.print_exc()
        error = {"message": "Internal server error", "status": 500, "detail": e.__str__()}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])


@assessment_api.route("/submit-assessment", methods=['POST'])
@login
def submit_assessment(role, organisation, permissions, login_user_other_details):
    """
    This api is used to submit assessment.
    """
    try:
        req_data = request.get_json()
        if "schedule_assessment_id" in req_data.keys():
            schedule_assessment_id = req_data['schedule_assessment_id']
        else:
            schedule_assessment_id = None
        topic_id = req_data['topic_id']
        course_session_id = req_data['course_session_id']
        assessment_id = req_data['assessment_id']
        user_id = login_user_other_details['_id']
        questions = req_data['questions']
        status = req_data['status']
        course_id = req_data['course_id']
        submitted_time = req_data['submitted_time']
    except KeyError:
        traceback.print_exc()
        error = {"message": "bad request", "status": 400}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])

    try:
        res_data = utils.submit_assessment(user_id=user_id, questions=questions, assessment_id=assessment_id,
                                           schedule_id=schedule_assessment_id, status=status, course_id=course_id,
                                           topic_id=topic_id, course_session_id=course_session_id,
                                           submitted_time=submitted_time, role=role)
        try:
            send_confirmation_email(login_user_other_details=login_user_other_details,
                                    report_name=res_data["message"], template_path="assessement_submission",
                                    subject="Assessment: "+res_data["assessment_name"])
        except:
        # testing temporary fix of 500 error
            raise ValueError()

        status = 201
        if res_data["status"] == "deactivated":
            status = 400
        return Response(json.dumps(res_data), mimetype='application/json', status=status)
    except InvalidUsage as e:
        error = {"message": e.message, "status": e.status_code}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])
    
    except ValueError as e: # error while sending email ack
        error = {"message": "Submitted successfully but there was some problem generating your email acknowledgement.", "status": 400}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])
    except Exception as e:
        traceback.print_exc()
        error = {"message": "Internal server error", "status": 500, "detail": e.__str__()}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])

