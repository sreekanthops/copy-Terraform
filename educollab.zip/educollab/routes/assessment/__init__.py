from flask import Blueprint
assessment_api = Blueprint('assessment', __name__)
from routes.assessment.main import *