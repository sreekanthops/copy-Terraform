import flask
from flask import request, Response, json, Blueprint, jsonify
from numpy import double
from sklearn.utils import resample
from model.User import login_user
from flask_cors import CORS, cross_origin
import model.Question as Question
import model.Content as Content
import model.User as User
from model.User import login, encryption_function
import services.common.translation as translation
import services.Similar_questions as Similar_questions
import services.School_Leaderboard as School_leaderboard
import services.Recommendation_engine as recommendation_engine
import services.profanity_check as Profanity_Detection
import services.User_Leaderboard as User_Leaderboard
from model.User import OAuth_login
import mongo_connection
from bson import ObjectId
import re
import csv
import io
import os
import config
import traceback
import model.course_work as course_work_file
import model.course as course_utils
import model.course_session as course_sessions
import model.course_sessions.course_sessions as course_session
from model.courses import refactored_topics, refactored_courseworks
from routes.exception import InvalidUsage
from utils.elasticsearch.user import update_user_profile_index
from model.course_work_wrapper import cw_instance as cw_instance_utils

from utils.misc import validate_ObjectId, send_email_to_user
from model.course_topic import fetch_course_zoom_recordings, add_zoom_record_as_sessions

import model.courses.refactored_topics as refactored_topics
from db_wrapper.tasks import Mongo

mongo_session = Mongo()
course_apis = Blueprint("course_api", __name__)


@course_apis.route('/make_course_universal', methods=['POST'])
@login
def make_course_universal(role, organisation, permissions, login_user_other_details):
    try:
        course_id_json = request.get_json()
        course_id = course_id_json['course_id']
        response = Content.change_course_universal(course_id=course_id,
                                                   permissions=permissions)
        return Response(json.dumps(response), mimetype='application/json',
                        status=200)
    except InvalidUsage as e:
        error = {"message": e.message}
        return Response(json.dumps(error), mimetype='application/json', status=e.status_code)
    except Exception as e:
        traceback.print_exc()
        error = {"message": "Internal server error.",
                 "detail": e.__str__()}
        return Response(json.dumps(error), mimetype='application/json', status=500)


@course_apis.route('/make_course_universal', methods=['PATCH'])
@login
def make_course_universal_patch(role, organisation, permissions, login_user_other_details):
    try:
        course_id_json = request.get_json()
        course_id = course_id_json['course_id']
        toggle =  course_id_json['toggle']
        response = Content.edit_course_universal(course_id=course_id,
                                                   permissions=permissions,
                                                   toggle=toggle)
        return Response(json.dumps(response), mimetype='application/json',
                        status=200)
    except InvalidUsage as e:
        error = {"message": e.message}
        return Response(json.dumps(error), mimetype='application/json', status=e.status_code)
    except Exception as e:
        traceback.print_exc()
        error = {"message": "Internal server error.",
                 "detail": e.__str__()}
        return Response(json.dumps(error), mimetype='application/json', status=500)


@course_apis.route("/courses", methods=["Post"])
@login
def course_insertion(role, organisation, permissions, login_user_other_details):
    """Purpose: To upload a course in db after validating and processing provided details in the payload."""
    try:
        data = request.get_json()
        course_category_id = data['course_category_id']
        subject = data['subject']
        learning_objectives = data['learning_objectives']
        banner_img = data['banner_img']
        authors = data['authors']
        instructors = data['instructors']
        editors = data['editors']
        # teaching assistant for post exams duties
        teach_assis = data['teach_assis']
        organisations = data['organisations']
        live_sessions = data['live_sessions']
        topics = data['topics']
        course_assessments = data['course_assessments']
        course_work = data['course_work']
        course_resources = data['course_resources']
        course_status = data['status']
        course_class = data.get('course_class', None)
        requirement = data.get('requirement', "")
        what_will_you_learn = data.get('what_will_you_learn', "")
    except KeyError:
        traceback.print_exc()
        data = {"status": 400, "message": "Please check request data."}
        return Response(json.dumps(data), mimetype='application/json', status=400)
    try:
        data, message = course_utils.upload_course(
            course_category_id=course_category_id,
            subject=subject,
            learning_objectives=learning_objectives,
            banner_img=banner_img,
            authors=authors,
            instructors=instructors,
            editors=editors,
            teach_assis=teach_assis,
            organisations=organisations,
            live_sessions=live_sessions,
            topics=topics,
            course_assessments=course_assessments,
            course_work=course_work,
            course_resources=course_resources,
            role=role,
            user_id=login_user_other_details['_id'],
            course_status=course_status,
            course_class_id= course_class,
            requirement= requirement,
            what_will_you_learn= what_will_you_learn)
        response_data = {"message": message, "course_info": data}
        response = Response(json.dumps(response_data), mimetype='application/json', status=201)
        return response

    except InvalidUsage as e:
        traceback.print_exc()
        data = {"detail": e.message,
                "message": e.message,
                "status": e.status_code}
        return Response(json.dumps(data), mimetype='application/json', status=e.status_code)

    except Exception as e:
        traceback.print_exc()
        response_data = {"detail": e.__str__(),
                         "message": "Internal server error, Please try again later."}
        response = Response(json.dumps(response_data), mimetype='application/json', status=500)
        return response


@course_apis.route('/super_admin_edit_user_profile', methods=['POST'])
@login
def edit_user_profile(role, organisation, permissions, login_user_other_details):
    try:
        data = request.get_json()
        other_user_id = data["user_id"].strip()
        other_user_role = data["role"].strip()
        other_user_organisation = data["organisation"].strip()
        other_user_grade = str(data['grade']).strip()
        other_user_institute_type = data['org_type'].strip()
        other_user_email_id = data['email'].strip().lower()
        password = data['password']
        original_password = password
    except KeyError as e:
        traceback.print_exc()
        error = {"message": "Bad Request", "status": 400, "details": e.__str__()}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])
    try:
        if role != "super_admin":  # using slug
            raise InvalidUsage("You are not authorised to use this service.", 403)
        # get user_organisation name from slug
        if password:
            if len(password) < 8 or len(password) > 30 or password.isspace():
                raise InvalidUsage("Password length should be greater than 8.", 409)
            encoded_password = password.encode("utf-8")
            password = encryption_function(encoded_password)
        res, previous_user_info, new_org = Content.edit_user_profile(user_id=other_user_id,
                                                                     user_role=other_user_role,
                                                                     user_org=other_user_organisation,
                                                                     user_grade=other_user_grade,
                                                                     user_org_type=other_user_institute_type,
                                                                     user_email=other_user_email_id,
                                                                     password=password)

        update_user_profile_index(
            _id=other_user_id,
            role=other_user_role,
            organisation=new_org,
            institute_type=other_user_institute_type,
            super_admin_edit=True)

        # send email notification to user if super admin change user's email.
        if other_user_email_id and other_user_email_id != previous_user_info["email"]:
            send_email_to_user(email=previous_user_info["email"],
                               name=previous_user_info["name"],
                               last_name=previous_user_info["last_name"],
                               template_path="profile_update",
                               subject="Profile Update",
                               body_data={"new_email": other_user_email_id,
                                          "previous_email": previous_user_info["email"],
                                          "new_password": original_password},
                               module="super_admin_edit_profile")

        if other_user_email_id == previous_user_info["email"] and original_password is not None:
            send_email_to_user(email=previous_user_info["email"],
                               name=previous_user_info["name"],
                               last_name=previous_user_info["last_name"],
                               template_path="profile_update",
                               subject="Profile Update",
                               body_data={"previous_email": "",
                                          "new_password": original_password,
                                          "new_email": ""},
                               module="super_admin_edit_profile")
        response = Response(json.dumps(res), mimetype='application/json', status=res['status'])
        return response
    except InvalidUsage as e:
        traceback.print_exc()
        data = {"detail": e.message,
                "message": e.message,
                "status": e.status_code}
        return Response(json.dumps(data), mimetype='application/json', status=e.status_code)
    except Exception as e:
        traceback.print_exc()
        response = {"message": "Internal server error, Please try again later.",
                    "detail": e.__str__()}
        return Response(json.dumps(response), mimetype='application/json', status=500)


@course_apis.route("/course_category", methods=["Get"])
@login
def course_list(role, organisation, permissions, login_user_other_details):
    try:
        response = Content.course_category(organisation=organisation)
        return Response(json.dumps(response), mimetype='application/json', status=200)
    except Exception as e:
        print(e)
        res = {"message": "internal server error", "status": 500}
        response = Response(json.dumps(res), mimetype='application/json', status=res['status'])
        return response


@course_apis.route("/courses/sessions/resume-time", methods=["POST"])
@login
def store_video_resume_time(role, organisation, permissions, login_user_other_details):
    try:
        data = request.get_json()
        course_id = data["course_id"]
        session_id = data["course_session_id"]
        video_time = data['video_time']
        if not type(video_time) == int or 0 > int(video_time):
            data = {"status": 400, "message": "Please enter valid time entry"}
            return Response(json.dumps(data), mimetype='application/json', status=400)

        user_id = login_user_other_details['_id']
    except KeyError:
        traceback.print_exc()
        data = {"status": 400, "message": "Please check request data"}
        return Response(json.dumps(data), mimetype='application/json', status=400)

    try:
        response, status_code = User.store_video_state(course_id=course_id,
                                                       session_id=session_id,
                                                       video_time=video_time,
                                                       user_id=user_id)
        return Response(json.dumps(response), mimetype='application/json', status=status_code)
    except Exception as e:
        traceback.print_exc()
        response_data = {"message": e.__str__()}
        response = Response(json.dumps(response_data), mimetype='application/json', status=500)
        return response


@course_apis.route("/courses/subscription", methods=["Post"])
@login
def subscribe_course(role, organisation, permissions, login_user_other_details):
    user_id = login_user_other_details['_id']
    try:
        data = request.json
        course_id = data['course_id']
        subscribe = data['subscribe']
    except KeyError:
        traceback.print_exc()
        data = {"status": 400, "message": "Please check request data."}
        return Response(json.dumps(data), mimetype='application/json', status=400)
    try:
        courses, api_status = Content.subscribe_course(user_id=user_id, course_id=course_id, subscribe=subscribe)
        response_message = {"Status": api_status, "Courses": courses}
        return Response(json.dumps(response_message), mimetype='application/json', status=api_status)
    except InvalidUsage as e:
        response = Response(json.dumps({"message": e.message}), mimetype='application/json', status=e.status_code)
        return response
    except Exception as e:
        traceback.print_exc()
        response_data = {"message": e.__str__()}
        response = Response(json.dumps(response_data), mimetype='application/json', status=500)
        return response


@course_apis.route("/upload_course_resource", methods=["Post"])
@login
def upload_course_resource(role, organisation, permissions, login_user_other_details):
    try:
        user_id = login_user_other_details['_id']
        resource_content = request.files['resource_content']

        s3_link, resource_id, api_status = Content.upload_course_resource(
            user_id=user_id,
            resource_content=resource_content,
            module_name="upload_course_resource")
        response_message = {"status": api_status, "resource_id": resource_id, "s3_location": s3_link}
        return Response(json.dumps(response_message), mimetype='application/json', status=api_status)
    except KeyError:
        traceback.print_exc()
        data = {"status": 400, "message": "please check request data"}
        return Response(json.dumps(data), mimetype='application/json', status=400)
    except Exception as e:
        traceback.print_exc()
        data = {"status": 500, "message": e.__str__()}
        return Response(json.dumps(data), mimetype='application/json', status=500)


@course_apis.route("/find-content", methods=["GET"])
@login
def find_content(role, organisation, permissions, login_user_other_details):
    """To find data from video transcriptions"""
    user_id = login_user_other_details['_id']
    try:
        search_text = request.args["search_text"]
    except KeyError as e:
        traceback.print_exc()
        data = {"detail": e.__str__(),
                "message": "Please check request data"}
        return Response(json.dumps(data), mimetype='application/json', status=400)
    try:
        response = Content.find_content_from_videos(search_text=search_text,
                                                    user_id=user_id)
        message = "Data retrieved successfully." if response else "Oops! there is nothing related to your search, " \
                                                                  "try searching something else."
        return Response(json.dumps({"message": message,
                                    "response": response}), mimetype='application/json', status=200)
    except InvalidUsage as e:
        traceback.print_exc()
        data = {"detail": e.message,
                "message": "Oops! Something went wrong, Please try again later."}
        return Response(json.dumps(data), mimetype='application/json', status=e.status_code)
    except Exception as e:
        traceback.print_exc()
        data = {"detail": "Oops! Something went wrong, Please try again later.",
                "message": e.__str__()}
        return Response(json.dumps(data), mimetype='application/json', status=500)


@course_apis.route("/course_work", methods=["Post"])
@login
def add_course_work(role, organisation, permissions, login_user_other_details):
    try:
        user_id = login_user_other_details['_id']
        data = request.json
        tags = data['tag']
        is_group = data['is_group']
        group_size = data['group_size']
        course_category_id = data['course_category_id']
        course_work_file_id = data['course_work_file_id']
        course_work_title = data['course_work_title']
        course_work_description = data['course_work_description']
        submission_requirement = data['submission_requirement']
        course_work_resources = data['course_work_resources']

        course_work_id = request.args['course_work_id']
        publish_status = data['publish']

        # tango_integration
        if submission_requirement:
            autograding = []
            for idx in range(len(submission_requirement)):
                if "autograding" in submission_requirement[idx]:
                    if submission_requirement[idx]['autograding'] == True:
                        autograding.append(idx)
                else:
                    pass
        else:
            autograding = []
        # end - tango_integration

        # to support upload resource api, need to insert resource from temp_uploaded_files collection to
        # global_resource_bank collection
        for each_resource in course_work_resources:
            resource_id = each_resource['resource_id']
            check_resource = mongo_session.check_existance_return_info(collection='global_resource_bank',
                                                                       condition={'_id': ObjectId(resource_id)},
                                                                       whole_doc=True)
            if not check_resource:
                insert_resource = mongo_session.insert_files_resource_bank(
                    collection="global_resource_bank",
                    resource_id=ObjectId(resource_id),
                    temp_collection="temp_uploaded_files")

    except KeyError:
        traceback.print_exc()
        data = {"Status": 400, "message": "Please check request data"}
        return Response(json.dumps(data), mimetype='application/json', status=400)
    try:
        if type(publish_status) != bool:
            raise InvalidUsage("Please check request data", 400)
        message, status, api_status = course_work_file.create_course_work(
            course_work_id=course_work_id,
            role=role,
            group_size=group_size,
            is_group=is_group,
            course_category_id=course_category_id,
            organisation=organisation,
            user_id=user_id,
            tags=tags,
            course_work_file_id=course_work_file_id,
            course_work_title=course_work_title,
            course_work_description=course_work_description,
            submission_requirement=submission_requirement,
            course_work_resources=course_work_resources,
            publish_status=publish_status,
            #Tango
            autograding= autograding)
        response_message = {"Status": status, "message": message}
        return Response(json.dumps(response_message), mimetype='application/json', status=api_status)

    except InvalidUsage as e:
        traceback.print_exc()
        data = {"detail": e.message,
                "message": e.message,
                "status": e.status_code}
        return Response(json.dumps(data), mimetype='application/json', status=e.status_code)

    except Exception as e:
        traceback.print_exc()
        data = {"Status": 400, "message": e.__str__()}
        return Response(json.dumps(data), mimetype='application/json', status=400)


@course_apis.route("/course_work", methods=["GET"])
@login
def view_course_work(role, organisation, permissions, login_user_other_details):
    try:
        course_work_id = request.args["course_work_id"]
        schedule_id = request.args.get("schedule_id")
        course_id = request.args.get("course_id")
        course_schedule_id = request.args.get("course_schedule_id")
    except KeyError as error:
        traceback.print_exc()
        data = {"message": "Please check request data",
                "detail": error.__str__()}
        return Response(json.dumps(data), mimetype='application/json', status=400)
    try:
        if course_schedule_id:
            course_work_info, message = course_work_file.view_course_work(
                    role=role,
                    course_work_id=course_work_id,
                    organisation=organisation,
                    schedule_id=course_schedule_id, 
                    course_id=course_id)
            response_message = {"message": message, "course_work_info": course_work_info}
        elif schedule_id:
            instance_info = cw_instance_utils.view_course_work_instance(schedule_id=schedule_id,
                                                                        course_id=course_id)
            response_message = {"message": "Information retrieved successfully.",
                                "response": instance_info}
        else:
            course_work_info, message = course_work_file.view_course_work(
                role=role,
                course_work_id=course_work_id,
                organisation=organisation)
            response_message = {"message": message, "course_work_info": course_work_info}
        return Response(json.dumps(response_message), mimetype='application/json', status=200)
    except InvalidUsage as e:
        traceback.print_exc()
        data = {"message": e.message}
        return Response(json.dumps(data), mimetype='application/json', status=e.status_code)
    except Exception as e:
        traceback.print_exc()
        data = {"detail": e.__str__(),
                "message": "Oops! Something went wrong please try again later."}
        return Response(json.dumps(data), mimetype='application/json', status=500)


@course_apis.route("/course_work", methods=["DELETE"])
@login
def delete_course_work(role, organisation, permissions, login_user_other_details):
    if role == 'student':
        error = {"message": "student user not allowed", "status": 403}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])
    try:
        user_id = login_user_other_details['_id']
        course_work_id = request.args["course_work_id"]
    except KeyError as error:
        traceback.print_exc()
        data = {"message": "Please check request data",
                "detail": error.__str__()}
        return Response(json.dumps(data), mimetype='application/json', status=400)
    try:
        response_message = course_work_file.delete_course_work(user_id, course_work_id)
        return Response(json.dumps(response_message), mimetype='application/json', status=200)
    except InvalidUsage as e:
        traceback.print_exc()
        data = {"message": e.message}
        return Response(json.dumps(data), mimetype='application/json', status=e.status_code)
    except Exception as e:
        traceback.print_exc()
        data = {"detail": e.__str__(),
                "message": "Oops! Something went wrong please try again later."}
        return Response(json.dumps(data), mimetype='application/json', status=500)


@course_apis.route("/course_work", methods=["PATCH"])
@login
def edit_course_work(role, organisation, permissions, login_user_other_details):
    try:
        user_id = login_user_other_details['_id']
        data = request.json
        tags = data['tag']
        is_group = data['is_group']
        group_size = data['group_size']
        course_category_id = data['course_category_id']
        course_work_file_id = data['course_work_file_id']
        course_work_title = data['course_work_title']
        course_work_description = data['course_work_description']
        submission_requirement = data['submission_requirement']
        course_work_resources = data['course_work_resources']
        publish_status = data["publish"]
        course_work_id = request.args['course_work_id']
        
        # tango_integration
        if submission_requirement:
            autograding = []
            for idx in range(len(submission_requirement)):
                if "autograding" in submission_requirement[idx]:
                    if submission_requirement[idx]['autograding'] == True:
                        autograding.append(idx)
                else:
                    pass
        else:
            autograding = []
        # end - tango_integration

        # to support upload resource api, need to insert resource from temp_uploaded_files collection to
        # global_resource_bank collection
        for each_resource in course_work_resources:
            resource_id = each_resource['resource_id']
            check_resource = mongo_session.check_existance_return_info(collection='global_resource_bank',
                                                                       condition={'_id': ObjectId(resource_id)},
                                                                       whole_doc=True)
            if not check_resource:
                insert_resource = mongo_session.insert_files_resource_bank(
                    collection="global_resource_bank",
                    resource_id=ObjectId(resource_id),
                    temp_collection="temp_uploaded_files")
        
    except KeyError:
        traceback.print_exc()
        data = {"Status": 400, "message": "Please check request data"}
        return Response(json.dumps(data), mimetype='application/json', status=400)
    try:
        if type(publish_status) != bool:
            raise InvalidUsage("Please check request data", 400)
        message, status, api_status = course_work_file.edit_course_work(
            course_work_id=course_work_id,
            role=role,
            group_size=group_size,
            is_group=is_group,
            course_category_id=course_category_id,
            organisation=organisation,
            user_id=user_id,
            tags=tags,
            course_work_file_id=course_work_file_id,
            course_work_title=course_work_title,
            course_work_description=course_work_description,
            submission_requirement=submission_requirement,
            course_work_resources=course_work_resources,
            publish_status=publish_status,
             #Tango
            autograding= autograding)
        response_message = {"Status": status, "message": message}
        return Response(json.dumps(response_message), mimetype='application/json', status=api_status)
    except InvalidUsage as e:
        traceback.print_exc()
        data = {"detail": e.message,
                "message": e.message,
                "status": e.status_code}
        return Response(json.dumps(data), mimetype='application/json', status=e.status_code)

    except Exception as e:
        traceback.print_exc()
        data = {"Status": 500, "message": e.__str__()}
        return Response(json.dumps(data), mimetype='application/json', status=500)


@course_apis.route("/courses", methods=["Get"])
@login
def course_view(role, organisation, permissions, login_user_other_details):
    user_id = login_user_other_details['_id']
    try:
        if request.args.get('course_id'):
            course_id = request.args.get('course_id')
            data, message, api_status = course_utils.view_course(
                course_id=course_id,
                role=role,
                user_id=user_id,
                organisation=organisation
            )
            response_data = {"message": message, "course_info": data}
        else:
            data, message = course_utils.catalogue(
                role=role,
                user_id=user_id,
                organisation=organisation,
                course_category_id=request.args.get('course_category_id'),
                subscription_status=request.args.get('subscription_status'),
                page=request.args.get('page'),
                page_name=request.args.get('page_name')
            )
            response_data = {"message": message, "courses_info": data}

        response = Response(json.dumps(response_data, default=str), mimetype='application/json', status=200)
        return response
    except InvalidUsage as e:
        error = {"message": e.message, "status": e.status_code}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])
    except Exception as e:
        traceback.print_exc()
        response_data = {"message": e.__str__(), "course_info": {}}
        response = Response(json.dumps(response_data), mimetype='application/json', status=500)
        return response


@course_apis.route("/courses/view", methods=["Get"])
@login
def single_course_view(role, organisation, permissions, login_user_other_details):
    user_id = login_user_other_details['_id']
    try:
        if request.args.get('course_id'):
            course_id = request.args.get('course_id')
            data, message, api_status = course_utils.single_view_course(
                course_id=course_id,
                role=role,
                user_id=user_id,
                organisation=organisation
            )
            response_data = {"message": message, "course_info": data}

        response = Response(json.dumps(response_data, default=str), mimetype='application/json', status=200)
        return response
    except InvalidUsage as e:
        error = {"message": e.message, "status": e.status_code}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])
    except Exception as e:
        traceback.print_exc()
        response_data = {"message": e.__str__(), "course_info": {}}
        response = Response(json.dumps(response_data), mimetype='application/json', status=500)
        return response


@course_apis.route("/courses/announcement", methods=["Get"])
@login
def view_course_announcement(role, organisation, permissions, login_user_other_details):
    user_id = login_user_other_details['_id']
    try:
        if request.args.get('course_id'):
            course_id = request.args.get('course_id')
            data, message, api_status = course_utils.view_announcement(
                course_id=course_id,
                role=role,
                user_id=user_id,
                organisation=organisation
            )
            response_data = {"message": message, "announcement_info": data}

        response = Response(json.dumps(response_data, default=str), mimetype='application/json', status=200)
        return response
    except InvalidUsage as e:
        error = {"message": e.message, "status": e.status_code}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])
    except Exception as e:
        traceback.print_exc()
        response_data = {"message": e.__str__(), "announcement_info": {}}
        response = Response(json.dumps(response_data), mimetype='application/json', status=500)
        return response


@course_apis.route("/courses/announcement", methods=["Post"])
@login
def course_announcement(role, organisation, permissions, login_user_other_details):
    """Api to add announcement in a course"""
    user_id = login_user_other_details['_id']
    try:
        data = request.get_json()
        course_id = data["course_id"]
        announcement_html = data["announcement_html"]
        title = data.get('title', "")
        resources = data.get('resources', [])
    except KeyError as error:
        traceback.print_exc()
        data = {"message": "Please check request data.",
                "detail": error.__str__()}
        return Response(json.dumps(data), mimetype='application/json', status=400)
    try:
        message = course_utils.add_announcement(
            course_id=course_id,
            role=role,
            user_id=user_id,
            announcement_html=announcement_html,
            title=title,
            resources=resources
        )
        return Response(json.dumps({"message": message}), mimetype='application/json', status=201)

    except InvalidUsage as e:
        error = {"message": e.message, "detail": e.message}
        return Response(json.dumps(error), mimetype='application/json', status=e.status_code)

    except Exception as e:
        traceback.print_exc()
        response_data = {"detail": e.__str__(),
                         "message": "Internal Server Error"}
        return Response(json.dumps(response_data), mimetype='application/json', status=500)


@course_apis.route("/courses/announcement", methods=["Patch"])
@login
def edit_announcement(role, organisation, permissions, login_user_other_details):
    """Api to update an announcement in a course"""
    try:
        data = request.get_json()
        course_id = data["course_id"]
        announcement_html = data["announcement_html"]
        index = data["index"]
        user_id = login_user_other_details['_id']
        title = data.get('title', "")
        resources = data.get('resources', [])
    except KeyError as error:
        traceback.print_exc()
        data = {"message": "Please check request data.",
                "detail": error.__str__()}
        return Response(json.dumps(data), mimetype='application/json', status=400)
    try:
        message = course_utils.edit_announcement(
            course_id=course_id,
            role=role,
            user_id=user_id,
            announcement_html=announcement_html,
            index=int(index),
            title=title,
            resources=resources
        )
        return Response(json.dumps({"message": message}), mimetype='application/json', status=200)
    except InvalidUsage as e:
        error = {"message": e.message, "detail": e.message}
        return Response(json.dumps(error), mimetype='application/json', status=e.status_code)

    except Exception as e:
        traceback.print_exc()
        response_data = {"detail": e.__str__(),
                         "message": "Internal Server Error, couldn't update the announcement."}
        return Response(json.dumps(response_data), mimetype='application/json', status=500)


@course_apis.route("/courses/announcement", methods=["Delete"])
@login
def delete_announcement(role, organisation, permissions, login_user_other_details):
    """Api to Delete an announcement in a course"""
    try:
        course_id = request.args["course_id"]
        index = request.args["index"]
        user_id = login_user_other_details['_id']
    except KeyError as error:
        traceback.print_exc()
        data = {"message": "Please check request data.",
                "detail": error.__str__()}
        return Response(json.dumps(data), mimetype='application/json', status=400)
    try:
        message = course_utils.delete_announcement(
            course_id=course_id,
            role=role,
            user_id=user_id,
            index=int(index)
        )
        return Response(json.dumps({"message": message}), mimetype='application/json', status=200)

    except InvalidUsage as e:
        error = {"message": e.message, "detail": e.message}
        return Response(json.dumps(error), mimetype='application/json', status=e.status_code)

    except Exception as e:
        traceback.print_exc()
        response_data = {"detail": e.__str__(),
                         "message": "Internal Server Error, couldn't delete the announcement."}
        return Response(json.dumps(response_data), mimetype='application/json', status=500)


@course_apis.route("/courses/subscribers", methods=["Get"])
@login
def subscribers(role, organisation, permissions, login_user_other_details):
    """Api to get all the subscribers of a particular course based on a filter(role)"""
    user_id = login_user_other_details.get("_id")
    try:
        course_id = request.args["course_id"]
        filter_role = request.args["roles"]

    except KeyError:
        traceback.print_exc()
        data = {"status": 400, "message": "Please check request data."}
        return Response(json.dumps(data), mimetype='application/json', status=400)
    try:
        data, message = course_utils.get_subscribers(
            course_id=course_id,
            role=role,
            user_id=user_id,
            filter_role=filter_role
        )
        response_data = {"users_info": data, "message": message}
        response = Response(json.dumps(response_data), mimetype='application/json', status=200)
        return response
    except InvalidUsage as e:
        traceback.print_exc()
        data = {"message": e.message,
                "status": e.status_code}
        return Response(json.dumps(data), mimetype='application/json', status=e.status_code)

    except Exception as e:
        traceback.print_exc()
        response_data = {"message": e.__str__()}
        response = Response(json.dumps(response_data), mimetype='application/json', status=500)
        return response


@course_apis.route('/courses/sessions/comments', methods=['POST'])
@login
def submit_feedback_week(role, organisation, permissions, login_user_other_details):
    user_id = login_user_other_details['_id']
    try:
        data = request.json
        session_id = data['course_session_id']
        course_id = data['course_id']
        comment = data['comment']
    except KeyError:
        traceback.print_exc()
        data = {"status": 400, "message": "Please check request data."}
        return Response(json.dumps(data), mimetype='application/json', status=400)
    try:
        profanity = Profanity_Detection.check_profanity(comment)
        if profanity:
            response_message = {"Status": "Failed",
                                "course_id": "",
                                "Message": "Oops can't add this comment"}
            return Response(json.dumps(response_message), mimetype='application/json', status=200)
        else:
            response_data = course_sessions.add_comment_course_session(comment=comment,
                                                                       user_id=user_id,
                                                                       session_id=session_id,
                                                                       )
            response_message = {"Status": "Success",
                                "Message": response_data}
        return Response(json.dumps(response_message), mimetype='application/json', status=200)
    except Exception as e:
        traceback.print_exc()
        response_data = {"message": e.__str__()}
        response = Response(json.dumps(response_data), mimetype='application/json', status=500)
        return response


@course_apis.route('/courses/sessions/comments/like_dislike', methods=['POST'])
@login
def comment_like_dislike_api(role, organisation, permissions, login_user_other_details):
    user_id = login_user_other_details['_id']
    try:
        data = request.json
        session_id = data['course_session_id']
        comment_id = data['comment_id']
        status = data['status']
        is_true = data.get('is_true', False)
    except KeyError as e:
        error = {"message": "Bad Request", "status": 400, "detail": e.__str__()}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])

    try:
        like_status, dislike_status = course_sessions.comment_like_dislike(status=status,
                                                                           user_id=user_id,
                                                                           session_id=session_id,
                                                                           comment_id=comment_id,
                                                                           is_true=is_true)
        message = "Thanks for Your valuable feedback" if like_status or dislike_status else "You can always give " \
                                                                                            "feedback later. "
        response_message = {"Status": message,
                            "Liked": like_status,
                            "Disliked": dislike_status}
        return Response(json.dumps(response_message), mimetype='application/json', status=200)
    except InvalidUsage as e:
        error = {"message": e.message, "status": e.status_code, "detail": e}
        return Response(json.dumps(error), mimetype='application/json', status=e.status_code)

    except Exception as e:
        traceback.print_exc()
        error = {"message": "Internal server error", "status": 500, "detail": e.__str__()}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])


@course_apis.route('/courses/sessions', methods=['Get'])
@login
def session_detail(role, organisation, permissions, login_user_other_details):
    user_id = login_user_other_details['_id']
    try:
        course_id = request.args["course_id"]
        session_id = request.args.get("course_session_id")
        topic_id = request.args.get("topic_id")
    except KeyError as e:
        traceback.print_exc()
        data = {"detail": e.__str__(),
                "message": "Please check request data."}
        return Response(json.dumps(data), mimetype='application/json', status=400)
    try:
        if session_id and validate_ObjectId(session_id):
            response = course_sessions.session_info(course_id=course_id,
                                                    user_id=user_id,
                                                    session_id=session_id,
                                                    role=role,
                                                    organisation=organisation
                                                    )
            topic_info = []
            if topic_id:
                topic_info = course_sessions.get_topic_session(course_id=course_id,
                                                               user_id=user_id,
                                                               topic_id=topic_id)
            response["topic_info"] = topic_info
        elif course_id and validate_ObjectId(course_id) and not session_id:
            response_data = course_sessions.get_course_sessions(user_id=user_id,
                                                                course_id=course_id,
                                                                role=role)
            response = {"message": "Sessions data retrieved successfully.",
                        "response": response_data}
        else:
            raise InvalidUsage("please check request data.", 400)
        return Response(json.dumps(response), mimetype='application/json', status=200)
    except InvalidUsage as e:
        traceback.print_exc()
        data = {"detail": e.message,
                "message": "Oops! something went wrong, Please try again later."}
        return Response(json.dumps(data), mimetype='application/json', status=e.status_code)
    except Exception as e:
        traceback.print_exc()
        data = {"detail": e.__str__(),
                "message": "Oops! something went wrong, Please try again later."}
        return Response(json.dumps(data), mimetype='application/json', status=500)


@course_apis.route('/courses/sessions-info', methods=['Get'])
@login
def session_info_detail(role, organisation, permissions, login_user_other_details):
    user_id = login_user_other_details['_id']
    role = login_user_other_details['role']
    try:
        course_id = request.args["course_id"]
        session_id = request.args.get("course_session_id")
        topic_id = request.args.get("topic_id")
    except KeyError as e:
        traceback.print_exc()
        data = {"detail": e.__str__(),
                "message": "Please check request data."}
        return Response(json.dumps(data), mimetype='application/json', status=400)
    try:
        if session_id and validate_ObjectId(session_id):
            response = course_sessions.session_info(course_id=course_id,
                                                    user_id=user_id,
                                                    session_id=session_id)   
            for note in response['content_detail']['notes']:
                note.pop('resources')  
        elif course_id and validate_ObjectId(course_id) and not session_id:
            response_data = course_sessions.get_course_sessions(user_id=user_id,
                                                                course_id=course_id,
                                                                role=role)
            response = {"message": "Sessions data retrieved successfully.",
                        "response": response_data}
        else:
            raise InvalidUsage("please check request data.", 400)
        if topic_id:
            topic_data = refactored_topics.view_course_topics_new(topic_id, user_id, role, course_id)
        else:
            topic_data = {}
        response["topics"] = topic_data
        response["announcements"] = {}
        return Response(json.dumps(response), mimetype='application/json', status=200)
    except InvalidUsage as e:
        traceback.print_exc()
        data = {"detail": e.message,
                "message": "Oops! something went wrong, Please try again later."}
        return Response(json.dumps(data), mimetype='application/json', status=e.status_code)
    except Exception as e:
        traceback.print_exc()
        data = {"detail": e.__str__(),
                "message": "Oops! something went wrong, Please try again later."}
        return Response(json.dumps(data), mimetype='application/json', status=500)


@course_apis.route("/courses", methods=["Patch"])
@login
def course_edit(role, organisation, permissions, login_user_other_details):
    """Purpose: To edit an existing course in db with provided id."""
    user_id = login_user_other_details['_id']
    try:
        data = request.get_json()
        course_id = request.headers.get('course_id')
        subject = data["subject"]
        category_id = data["course_category_id"]
        learning_objectives = data["learning_objectives"]
        banner_img = data["banner_img"]
        topics = data['topics']
        authors = data["authors"]
        instructors = data['instructors']
        editors = data["editors"]
        # teaching assistant for post exams duties
        teach_assis = data['teach_assis']
        organisations = data["organisations"]
        course_resources = data['course_resources']
        live_sessions = data['live_sessions']
        course_work = data['course_work']
        course_assessments = data['course_assessments']
        course_status = data["status"]
        course_class = data.get('course_class', None)
        requirement = data.get('requirement', "")
        what_will_you_learn = data.get('what_will_you_learn', "")
    except KeyError:
        traceback.print_exc()
        data = {"status": 400, "message": "Please check request data."}
        return Response(json.dumps(data), mimetype='application/json', status=400)

    try:
        status_message, api_status = course_utils.edit_course_detail(user_id=user_id,
                                                                     role=role,
                                                                     course_id=course_id,
                                                                     subject=subject,
                                                                     category_id=category_id,
                                                                     learning_objectives=learning_objectives,
                                                                     banner_img=banner_img,
                                                                     topics=topics,
                                                                     authors=authors,
                                                                     instructors=instructors,
                                                                     editors=editors,
                                                                     teach_assis=teach_assis,
                                                                     organisations=organisations,
                                                                     course_resources=course_resources,
                                                                     live_sessions=live_sessions,
                                                                     course_work=course_work,
                                                                     course_assessments=course_assessments,
                                                                     course_status=course_status,
                                                                     course_class_id=course_class,
                                                                     requirement= requirement,
                                                                     what_will_you_learn= what_will_you_learn)
        response_message = {"status": api_status, "message": status_message}
        response = Response(json.dumps(response_message), mimetype='application/json',
                            status=response_message['status'])
        return response

    except InvalidUsage as e:
        traceback.print_exc()
        data = {"detail": e.message,
                "message": e.message,
                "status": e.status_code}
        return Response(json.dumps(data), mimetype='application/json', status=e.status_code)

    except Exception as e:
        traceback.print_exc()
        response_data = {"detail": e.__str__(), "message": "Oops! Something went wrong, Please try again later."}
        response = Response(json.dumps(response_data), mimetype='application/json', status=500)
        return response


@course_apis.route('/courses/deactivate', methods=['PATCH'])
@login
def deactivate_course(role, organisation, permissions, login_user_other_details):
    user_id = login_user_other_details['_id']
    try:
        data = request.json
        course_id = data['course_id']
    except KeyError as e:
        traceback.print_exc()
        data = {"status": 400, "message": "Please check request data.", "detail": e.__str__()}
        return Response(json.dumps(data), mimetype='application/json', status=400)
    try:
        response_data = course_utils.course_deactivate(course_id=course_id,
                                                       user_id=user_id,
                                                       permissions=permissions)
        response_message = {"Status": response_data, "course_id": course_id}
        return Response(json.dumps(response_message), mimetype='application/json', status=200)

    except InvalidUsage as e:
        traceback.print_exc()
        data = {"detail": e.message,
                "message": e.message,
                "status": e.status_code}
        return Response(json.dumps(data), mimetype='application/json', status=e.status_code)
    except Exception as e:
        traceback.print_exc()
        data = {"status": 500, "message": "Internal Server Error", "detail": e.__str__()}
        return Response(json.dumps(data), mimetype='application/json', status=500)


@course_apis.route('/courses/sessions/assessment', methods=['Patch'])
@login
def make_assessment_live(role, organisation, permissions, login_user_other_details):
    user_id = login_user_other_details['_id']
    try:
        data = request.json
        course_id = data["course_id"]
        session_id = data["course_session_id"]
        topic_id = data["topic_id"]
        assessment_id = data["assessment_id"]
        active = data["active"]
    except KeyError as e:
        traceback.print_exc()
        data = {"status": 400, "message": "Please check request data.", "detail": e.__str__()}
        return Response(json.dumps(data), mimetype='application/json', status=400)
    try:
        response = course_sessions.activate_session_assessment(course_id=course_id,
                                                               user_id=user_id,
                                                               session_id=session_id,
                                                               topic_id=topic_id,
                                                               assessment_id=assessment_id,
                                                               role=role,
                                                               active=active)
        return Response(json.dumps(response), mimetype='application/json', status=200)
    except InvalidUsage as e:
        traceback.print_exc()
        data = {"detail": e.message,
                "message": e.message,
                "status": e.status_code}
        return Response(json.dumps(data), mimetype='application/json', status=e.status_code)
    except Exception as e:
        traceback.print_exc()
        data = {"status": 500, "message": "Internal Server Error", "detail": e.__str__()}
        return Response(json.dumps(data), mimetype='application/json', status=500)


@course_apis.route('/courses/sessions', methods=['Patch'])
@login
def activate_live_session(role, organisation, permissions, login_user_other_details):
    user_id = login_user_other_details['_id']
    try:
        data = request.json
        course_id = data["course_id"]
        session_id = data["course_session_id"]
        topic_id = data["topic_id"]
        is_live = data["is_live"]
    except KeyError as e:
        traceback.print_exc()
        data = {"status": 400, "message": "Please check request data.", "detail": e.__str__()}
        return Response(json.dumps(data), mimetype='application/json', status=400)
    try:
        response = course_sessions.activate_live_sessions(course_id=course_id,
                                                          user_id=user_id,
                                                          session_id=session_id,
                                                          topic_id=topic_id,
                                                          is_live=is_live,
                                                          role=role)
        return Response(json.dumps(response), mimetype='application/json', status=200)
    except InvalidUsage as e:
        traceback.print_exc()
        data = {"detail": e.message,
                "message": e.message,
                "status": e.status_code}
        return Response(json.dumps(data), mimetype='application/json', status=e.status_code)
    except Exception as e:
        traceback.print_exc()
        data = {"status": 500, "message": "Internal Server Error", "detail": e.__str__()}
        return Response(json.dumps(data), mimetype='application/json', status=500)


@course_apis.route('/courses/session/note', methods=['Post'])
@login
def add_notes_summary_session_lev(role, organisation, permissions, login_user_other_details):
    """To add notes and summary on any session present in the topic"""
    user_id = login_user_other_details['_id']
    try:
        data = request.json
        session_id = data["course_session_id"]
        title = data["title"]
        content = data["content"]
        note_type = data["type"]
        resources = None
        if "resources" in data:
            resources = data["resources"]

        if note_type == "note" and not title:
            message = "Please add a title to the note."
            return Response(json.dumps({"message": message}), mimetype='application/json', status=400)
    except KeyError as e:
        traceback.print_exc()
        data = {"status": 400, "message": "Please check request data.", "detail": e.__str__()}
        return Response(json.dumps(data), mimetype='application/json', status=400)
    try:
        doc_id, message = course_sessions.add_notes_summary(user_id=user_id,
                                                            session_id=session_id,
                                                            title=title,
                                                            content=content,
                                                            role=role,
                                                            note_type=note_type,
                                                            resources=resources)
        return Response(json.dumps({"message": message, "_id": doc_id}), mimetype='application/json', status=201)
    except InvalidUsage as e:
        traceback.print_exc()
        data = {"detail": e.message,
                "message": e.message,
                "status": e.status_code}
        return Response(json.dumps(data), mimetype='application/json', status=e.status_code)
    except Exception as e:
        traceback.print_exc()
        data = {"status": 500, "message": "Internal Server Error", "detail": e.__str__()}
        return Response(json.dumps(data), mimetype='application/json', status=500)


@course_apis.route('/courses/session/note', methods=['Patch'])
@login
def edit_notes_summary_session_lev(role, organisation, permissions, login_user_other_details):
    """To edit notes and summary on any session present in the topic"""
    user_id = login_user_other_details['_id']
    try:
        data = request.json
        course_id = data["course_id"]
        session_id = data["course_session_id"]
        topic_id = data["topic_id"]
        title = data["title"]
        content = data["content"]
        note_type = data["type"]
        _id = data["_id"]
        resources = None
        if "resources" in data:
            resources = data['resources']

        if note_type == "note" and not title:
            message = "Please add a title to the note."
            return Response(json.dumps({"message": message}), mimetype='application/json', status=400)
    except KeyError as e:
        traceback.print_exc()
        data = {"status": 400, "message": "Please check request data.", "detail": e.__str__()}
        return Response(json.dumps(data), mimetype='application/json', status=400)
    try:
        response = course_sessions.edit_notes_summary(course_id=course_id,
                                                      user_id=user_id,
                                                      session_id=session_id,
                                                      topic_id=topic_id,
                                                      title=title,
                                                      content=content,
                                                      role=role,
                                                      note_type=note_type,
                                                      _id=_id,
                                                      resources=resources)
        return Response(json.dumps({"message": response}), mimetype='application/json', status=200)
    except InvalidUsage as e:
        traceback.print_exc()
        data = {"detail": e.message,
                "message": e.message,
                "status": e.status_code}
        return Response(json.dumps(data), mimetype='application/json', status=e.status_code)
    except Exception as e:
        traceback.print_exc()
        data = {"status": 500, "message": "Internal Server Error", "detail": e.__str__()}
        return Response(json.dumps(data), mimetype='application/json', status=500)


@course_apis.route('/courses/session/notes', methods=['Post'])
@login
def add_courses_session_notes(role, organisation, permissions, login_user_other_details):
    """To add notes and summary on any session present in the topic"""
    user_id = login_user_other_details['_id']
    try:
        data = request.json
        session_id = data["course_session_id"]
        title = data["title"]
        content = data["content"]
        note_type = data["type"]
        course_id = data["course_id"]
        topic_id = data["topic_id"]
        timestamp = data["timestamp"]
        resources = data.get("resource_path", [])
        image_path = data.get("image_path", [])
        video_path = data.get("video_path", [])

        if note_type == "note" and not title:
            message = "Please add a title to the note."
            return Response(json.dumps({"message": message}), mimetype='application/json', status=400)
    except KeyError as e:
        traceback.print_exc()
        data = {"status": 400, "message": "Please check request data.", "detail": e.__str__()}
        return Response(json.dumps(data), mimetype='application/json', status=400)
    try:
        doc_id, message = course_session.add_session_notes_summary(user_id=user_id,
                                                                   session_id=session_id,
                                                                   title=title,
                                                                   content=content,
                                                                   course_id=course_id,
                                                                   topic_id=topic_id,
                                                                   note_type=note_type,
                                                                   timestamp=timestamp,
                                                                   image_path=image_path,
                                                                   resources=resources,
                                                                   video_path=video_path)
        return Response(json.dumps({"message": message, "_id": doc_id}), mimetype='application/json', status=201)
    except InvalidUsage as e:
        traceback.print_exc()
        data = {"detail": e.message,
                "message": e.message,
                "status": e.status_code}
        return Response(json.dumps(data), mimetype='application/json', status=e.status_code)
    except Exception as e:
        traceback.print_exc()
        data = {"status": 500, "message": "Internal Server Error", "detail": e.__str__()}
        return Response(json.dumps(data), mimetype='application/json', status=500)


@course_apis.route('/courses/session/notes', methods=['Patch'])
@login
def edit_courses_session_notes(role, organisation, permissions, login_user_other_details):
    """To edit notes and summary on any session present in the topic"""
    user_id = login_user_other_details['_id']
    try:
        data = request.json
        course_id = data["course_id"]
        session_id = data["course_session_id"]
        topic_id = data["topic_id"]
        title = data["title"]
        content = data["content"]
        note_type = data["type"]
        _id = data["_id"]
        timestamp = data["timestamp"]
        resources = data.get("resource_path", [])
        image_path = data.get("image_path", [])
        video_path = data.get("video_path", [])

        if note_type == "note" and not title:
            message = "Please add a title to the note."
            return Response(json.dumps({"message": message}), mimetype='application/json', status=400)
    except KeyError as e:
        traceback.print_exc()
        data = {"status": 400, "message": "Please check request data.", "detail": e.__str__()}
        return Response(json.dumps(data), mimetype='application/json', status=400)
    try:
        response = course_session.edit_session_notes_summary(course_id=course_id,
                                                             user_id=user_id,
                                                             session_id=session_id,
                                                             topic_id=topic_id,
                                                             title=title,
                                                             content=content,
                                                             role=role,
                                                             note_type=note_type,
                                                             _id=_id,
                                                             timestamp=timestamp,
                                                             resources=resources,
                                                             image_path=image_path,
                                                             video_path=video_path)
        return Response(json.dumps({"message": response}), mimetype='application/json', status=200)
    except InvalidUsage as e:
        traceback.print_exc()
        data = {"detail": e.message,
                "message": e.message,
                "status": e.status_code}
        return Response(json.dumps(data), mimetype='application/json', status=e.status_code)
    except Exception as e:
        traceback.print_exc()
        data = {"status": 500, "message": "Internal Server Error", "detail": e.__str__()}
        return Response(json.dumps(data), mimetype='application/json', status=500)


@course_apis.route('/courses/session/notes', methods=['DELETE'])
@login
def delete_course_session_notes(role, organisation, permissions, login_user_other_details):
    """To delete notes on any session present in the topic"""
    user_id = login_user_other_details['_id']
    try:
        session_id = request.args["course_session_id"]
        _id = request.args["_id"]  # mongo id of note
        note_type = request.args["type"]
    except KeyError as e:
        traceback.print_exc()
        data = {"status": 400, "message": "Please check request data.", "detail": e.__str__()}
        return Response(json.dumps(data), mimetype='application/json', status=400)
    try:
        message = course_session.delete_session_notes_summary(user_id=user_id,
                                                       session_id=session_id,
                                                       note_type=note_type,
                                                       _id=_id)
        return Response(json.dumps({"message": message}), mimetype='application/json', status=200)
    except InvalidUsage as e:
        traceback.print_exc()
        data = {"detail": e.message,
                "message": e.message,
                "status": e.status_code}
        return Response(json.dumps(data), mimetype='application/json', status=e.status_code)
    except Exception as e:
        traceback.print_exc()
        data = {"status": 500, "message": "Internal Server Error", "detail": e.__str__()}
        return Response(json.dumps(data), mimetype='application/json', status=500)


@course_apis.route('/courses/session/note', methods=['DELETE'])
@login
def delete_notes_summary_session_lev(role, organisation, permissions, login_user_other_details):
    """To delete notes on any session present in the topic"""
    user_id = login_user_other_details['_id']
    try:
        session_id = request.args["course_session_id"]
        _id = request.args["_id"]  # mongo id of note
        note_type = request.args["type"]
    except KeyError as e:
        traceback.print_exc()
        data = {"status": 400, "message": "Please check request data.", "detail": e.__str__()}
        return Response(json.dumps(data), mimetype='application/json', status=400)
    try:
        message = course_sessions.delete_notes_summary(user_id=user_id,
                                                       session_id=session_id,
                                                       note_type=note_type,
                                                       _id=_id)
        return Response(json.dumps({"message": message}), mimetype='application/json', status=200)
    except InvalidUsage as e:
        traceback.print_exc()
        data = {"detail": e.message,
                "message": e.message,
                "status": e.status_code}
        return Response(json.dumps(data), mimetype='application/json', status=e.status_code)
    except Exception as e:
        traceback.print_exc()
        data = {"status": 500, "message": "Internal Server Error", "detail": e.__str__()}
        return Response(json.dumps(data), mimetype='application/json', status=500)


@course_apis.route('/courses/session/notes', methods=['Get'])
@login
def get_notes(role, organisation, permissions, login_user_other_details):
    """
    This api enables the user (student, teacher and super_admin) to get the notes of
    a particular session under particular course. The user gets all the notes written
    by him for that session and teacher and super_admin get all the notes written by
    different users for that session.
    :param role: role of the current user
    :param organisation: organisation that the current user belongs to
    :param permissions: tasks that the current user is allowed to perform
    :param login_user_other_details: other details of the current user
    :return: notes for a particular session under a particular course
    """
    course_id = request.args.get('course_id')
    session_id = request.args.get('session_id')
    user_id = login_user_other_details['_id']
    try:
        condition = {"course_id": ObjectId(course_id),
                     "session_id": ObjectId(session_id),
                     "type": "note"}

        if role == 'student':
            # if the role is student, the user passes his id as well to get all
            # the notes written by him for the given session under the given course
            condition["user_id"] = ObjectId(user_id)
        response_data = course_sessions.get_notes_for_session(condition, role, organisation)
        data = {"message": "Notes fetched successfully." if response_data else "No data to show.",
                "response": response_data}
        return Response(json.dumps(data), mimetype='application/json', status=200)

    except InvalidUsage as e:
        traceback.print_exc()
        data = {"message": e.message}
        return Response(json.dumps(data), mimetype='application/json', status=e.status_code)

    except Exception as e:
        traceback.print_exc()
        data = {"message": "Oops! Something went wrong. Could not login at the moment.",
                "detail": e.__str__()}
        return Response(json.dumps(data), mimetype='application/json', status=500)


@course_apis.route('/courses/teaching-assistant/assignee', methods=['POST'])
@login
def assign_subscribers(role, organisation, permissions, login_user_other_details):
    """To assign subscribers and teams to teaching assistants(TA).
    who can access: owner of course/editors/instructors/super-admin.
    filter subscribers: if course is public all subscribers with role student else
                        subscribers from allowed organisations only.
    for teams: No filter."""
    user_id = login_user_other_details['_id']
    try:
        course_id = request.json["course_id"]
        cw_schedule_id = request.json.get("schedule_id")
        course_work_id = request.json.get("course_work_id")
        assignee_data = request.json["assignee_data"]
    except KeyError as e:
        traceback.print_exc()
        data = {"message": "Please check request data.",
                "detail": e.__str__()}
        return Response(json.dumps(data), mimetype='application/json', status=400)
    try:
        response_data = course_utils.assign_subs_teach_assis(user_id=user_id,
                                                             role=role,
                                                             course_id=course_id,
                                                             course_work_id=course_work_id,
                                                             cw_schedule_id=cw_schedule_id,
                                                             assignee_data=assignee_data)
        return Response(json.dumps({"message": "Assignee assigned to respective Teaching Assistants.",
                                    "response": response_data}), mimetype='application/json', status=201)
    except InvalidUsage as e:
        traceback.print_exc()
        data = {"message": e.message,
                "status": e.status_code}
        return Response(json.dumps(data), mimetype='application/json', status=e.status_code)
    except Exception as e:
        traceback.print_exc()
        data = {"message": "Oops! something went wrong, Please try again later.",
                "detail": e.__str__()}
        return Response(json.dumps(data), mimetype='application/json', status=500)


@course_apis.route("/courses/teaching-assistant/assignee", methods=['GET'])
@login
def allotted_subscribers(role, organisation, permissions, login_user_other_details):
    """
    To fetch assignee(subscribers/teams) assigned to teaching assistants(TA).
    who can access: owner of course/editors/instructors/super-admin.
    """
    user_id = login_user_other_details['_id']
    try:
        course_id = request.args["course_id"]
        cw_schedule_id = request.args.get("schedule_id")
        course_work_id = request.args.get("course_work_id")
    except KeyError as e:
        traceback.print_exc()
        data = {"message": "Please check request data.",
                "detail": e.__str__()}
        return Response(json.dumps(data), mimetype='application/json', status=400)
    try:
        response_data = course_utils.fetch_subs_teach_assis(user_id=user_id,
                                                            role=role,
                                                            course_id=course_id,
                                                            course_work_id=course_work_id,
                                                            cw_schedule_id=cw_schedule_id)
        message = "Data retrieved successfully for assignee to respective Teaching " \
                  "Assistants." if response_data else "Assignees have not been assigned to Teaching assistants yet."
        return Response(json.dumps({"message": message,
                                    "response": response_data}), mimetype='application/json', status=200)
    except InvalidUsage as e:
        traceback.print_exc()
        data = {"message": e.message,
                "status": e.status_code}
        return Response(json.dumps(data), mimetype='application/json', status=e.status_code)
    except Exception as e:
        traceback.print_exc()
        data = {"message": "Oops! something went wrong, Please try again later.",
                "detail": e.__str__()}
        return Response(json.dumps(data), mimetype='application/json', status=500)


@course_apis.route("/session/attendance/match", methods=["GET"])
@login
def fuzzy_match_users(role, organisation, permissions, login_user_other_details):
    """
    To Fuzzy match the students in the given .csv file to the course subscribers.
    :return: Subscribers info along with the matched user generated by fuzzy matching.
             match with highest score should be on top.
    """
    user_id = login_user_other_details["_id"]
    try:
        course_id = request.args["course_id"]
        session_id = request.args["session_id"]
        file_id = request.args.get("file_id")
        file_path = request.args.get("file_path")
    except KeyError as error:
        traceback.print_exc()
        data = {"message": "Please check request data.",
                "detail": error.__str__()}
        return Response(json.dumps(data), mimetype='application/json', status=400)
    try:
        if not (session_id and course_id):
            raise InvalidUsage("Bad Request.", 400)

        data = course_sessions.fuzzy_match_participants(course_id=course_id,
                                                        session_id=session_id,
                                                        file_id=file_id,
                                                        file_path=file_path,
                                                        user_id=user_id,
                                                        role=role)
        return Response(json.dumps(data), mimetype='application/json', status=200)
    except InvalidUsage as error:
        traceback.print_exc()
        data = {"message": error.message}
        return Response(json.dumps(data), mimetype='application/json', status=error.status_code)
    except Exception as error:
        traceback.print_exc()
        data = {"message": "Oops! something went wrong, Please try again later.",
                "detail": error.__str__()}
        return Response(json.dumps(data), mimetype='application/json', status=500)


@course_apis.route("/session/attendance", methods=["POST"])
@login
def save_session_attendance(role, organisation, permissions, login_user_other_details):
    """
    To save attendance of course subscribers(only students for now), marked by teachers.
    ** Data in request payload should include only active users that attended the lecture according to teacher.
    """
    user_id = login_user_other_details["_id"]
    try:
        data = request.get_json()
        course_id = data["course_id"]
        session_id = data["session_id"]
        participants = data["participants"]
    except KeyError as error:
        traceback.print_exc()
        data = {"message": "Please check request data.",
                "detail": error.__str__()}
        return Response(json.dumps(data), mimetype='application/json', status=400)
    try:
        if not (participants and session_id and course_id):
            raise InvalidUsage("Bad Request.", 400)

        data = course_sessions.save_attendance_by_teacher(course_id=course_id,
                                                          session_id=session_id,
                                                          participants=participants,
                                                          user_id=user_id,
                                                          role=role)
        return Response(json.dumps(data), mimetype='application/json', status=200)
    except InvalidUsage as error:
        traceback.print_exc()
        data = {"message": error.message}
        return Response(json.dumps(data), mimetype='application/json', status=error.status_code)
    except Exception as error:
        traceback.print_exc()
        data = {"message": "Oops! something went wrong, Please try again later.",
                "detail": error.__str__()}
        return Response(json.dumps(data), mimetype='application/json', status=500)


@course_apis.route("/session/attendance", methods=["GET"])
@login
def view_session_attendance(role, organisation, permissions, login_user_other_details):
    """
    To view attendance of course subscribers(only students for now), marked by teachers on the session.
    """
    user_id = login_user_other_details["_id"]
    try:
        course_id = request.args["course_id"]
        session_id = request.args["session_id"]
    except KeyError as error:
        traceback.print_exc()
        data = {"message": "Please check request data.",
                "detail": error.__str__()}
        return Response(json.dumps(data), mimetype='application/json', status=400)
    try:
        if not (session_id and course_id):
            raise InvalidUsage("Bad Request.", 400)

        data = course_sessions.get_session_attendance(course_id=course_id,
                                                      session_id=session_id,
                                                      user_id=user_id,
                                                      role=role)
        return Response(json.dumps(data), mimetype='application/json', status=200)
    except InvalidUsage as error:
        traceback.print_exc()
        data = {"message": error.message}
        return Response(json.dumps(data), mimetype='application/json', status=error.status_code)
    except Exception as error:
        traceback.print_exc()
        data = {"message": "Oops! something went wrong, Please try again later.",
                "detail": error.__str__()}
        return Response(json.dumps(data), mimetype='application/json', status=500)


@course_apis.route('/courses/topics', methods=['Get'])
@login
def course_topics_detail(role, organisation, permissions, login_user_other_details):
    user_id = login_user_other_details['_id']
    try:
        course_id = request.args["course_id"]
    except KeyError as e:
        traceback.print_exc()
        data = {"detail": e.__str__(),
                "message": "Please check request data."}
        return Response(json.dumps(data), mimetype='application/json', status=400)
    try:
        response_data = course_sessions.get_course_topics(user_id=user_id,
                                                          course_id=course_id,
                                                          role=role)
        response = {"message": "Information has been retrieved successfully.",
                    "response": response_data}
        return Response(json.dumps(response), mimetype='application/json', status=200)
    except InvalidUsage as e:
        traceback.print_exc()
        data = {"detail": e.message,
                "message": e.message}
        return Response(json.dumps(data), mimetype='application/json', status=e.status_code)
    except Exception as e:
        traceback.print_exc()
        data = {"detail": e.__str__(),
                "message": "Internal Server Error, Please try again later."}
        return Response(json.dumps(data), mimetype='application/json', status=500)


@course_apis.route('/course/recordings', methods=['Get'])
@login
def get_zoom_record_course(role, organisation, permissions, login_user_other_details):
    """To fetch the zoom recordings of the lectures conducted on a particular course"""
    user_id = login_user_other_details['_id']
    try:
        course_id = request.args["course_id"]
    except KeyError as e:
        traceback.print_exc()
        data = {"detail": e.__str__(),
                "message": "Please check request data."}
        return Response(json.dumps(data), mimetype='application/json', status=400)
    try:
        response_data = fetch_course_zoom_recordings(user_id=user_id,
                                                     course_id=course_id,
                                                     role=role)
        response = {"message": "Information has been retrieved successfully." if response_data else "No Recordings as "
                                                                                                    "of now.",
                    "response": response_data}
        return Response(json.dumps(response), mimetype='application/json', status=200)
    except InvalidUsage as e:
        traceback.print_exc()
        data = {"detail": e.message,
                "message": e.message}
        return Response(json.dumps(data), mimetype='application/json', status=e.status_code)
    except Exception as e:
        traceback.print_exc()
        data = {"detail": e.__str__(),
                "message": "Internal Server Error, Please try again later."}
        return Response(json.dumps(data), mimetype='application/json', status=500)


@course_apis.route('/course/recordings', methods=['POST'])
@login
def add_zoom_record_course(role, organisation, permissions, login_user_other_details):
    """
    To store the zoom recordings of the lectures conducted on a particular course
    as new sessions in old or new topics"""
    user_id = login_user_other_details['_id']
    try:
        data = request.get_json()
        course_id = data["course_id"]
        course_topics = data["topics"]
    except KeyError as e:
        traceback.print_exc()
        data = {"detail": e.__str__(),
                "message": "Please check request data."}
        return Response(json.dumps(data), mimetype='application/json', status=400)
    try:
        response_data = add_zoom_record_as_sessions(user_id=user_id,
                                                    course_id=course_id,
                                                    role=role,
                                                    course_topics=course_topics)
        response = {"message": "Information has been saved successfully.",
                    "response": response_data}
        return Response(json.dumps(response), mimetype='application/json', status=200)
    except InvalidUsage as e:
        traceback.print_exc()
        data = {"detail": e.message,
                "message": e.message}
        return Response(json.dumps(data), mimetype='application/json', status=e.status_code)
    except Exception as e:
        traceback.print_exc()
        data = {"detail": e.__str__(),
                "message": "Internal Server Error, Please try again later."}
        return Response(json.dumps(data), mimetype='application/json', status=500)


@course_apis.route('/courses/deactivated', methods=['GET'])
@login
def deactivated_courses(role, organisation, permissions, login_user_other_details):
    """
    To store the zoom recordings of the lectures conducted on a particular course
    as new sessions in old or new topics"""
    user_id = login_user_other_details['_id']
    page = request.args.get('page')
    try:
        response_data = course_utils.get_deactivated_courses(user_id=user_id,
                                                             role=role,
                                                             page=page)
        response = {"message": "Data retrieved successfully.",
                    "response": response_data}
        return Response(json.dumps(response), mimetype='application/json', status=200)
    except InvalidUsage as e:
        traceback.print_exc()
        data = {"detail": e.message,
                "message": e.message}
        return Response(json.dumps(data), mimetype='application/json', status=e.status_code)
    except Exception as e:
        traceback.print_exc()
        data = {"detail": e.__str__(),
                "message": "Internal Server Error, Please try again later."}
        return Response(json.dumps(data), mimetype='application/json', status=500)


@course_apis.route('/courses/activate', methods=['PATCH'])
@login
def reactivate_course(role, organisation, permissions, login_user_other_details):
    """
    To store the zoom recordings of the lectures conducted on a particular course
    as new sessions in old or new topics"""
    user_id = login_user_other_details['_id']
    data = request.get_json()
    course_id = data['course_id']
    try:
        response_data = course_utils.reactivate_course(user_id=user_id,
                                                       role=role,
                                                       course_id=course_id)
        return Response(json.dumps(response_data), mimetype='application/json', status=200)
    except InvalidUsage as e:
        traceback.print_exc()
        data = {"detail": e.message,
                "message": e.message}
        return Response(json.dumps(data), mimetype='application/json', status=e.status_code)
    except Exception as e:
        traceback.print_exc()
        data = {"detail": e.__str__(),
                "message": "Internal Server Error, Please try again later."}
        return Response(json.dumps(data), mimetype='application/json', status=500)


@course_apis.route('/get_reviews', methods=['GET'])
@login
def reviews_get(role, organisation, permissions, login_user_other_details):
    """
    To get reviews & rating data of a course"""
    user_id = login_user_other_details['_id']
    course_id = request.args['course_id']
    rating_sort = request.args.get('rating_sort',"latest")
    try:
        response_data = course_utils.get_reviews(user_id=user_id, course_id=course_id, rating_sort=rating_sort)
        return Response(json.dumps(response_data), mimetype='application/json', status=200)
    except InvalidUsage as e:
        traceback.print_exc()
        data = {"detail": e.message,
                "message": e.message}
        return Response(json.dumps(data), mimetype='application/json', status=e.status_code)
    except Exception as e:
        traceback.print_exc()
        data = {"detail": e.__str__(),
                "message": "Internal Server Error, Please try again later."}
        return Response(json.dumps(data), mimetype='application/json', status=500)


@course_apis.route('/delete_review', methods=['DELETE'])
@login
def reviews_del(role, organisation, permissions, login_user_other_details):
    """
    To get delete review and rating"""
    user_id = login_user_other_details['_id']
    course_id = request.args['course_id']
    try:
        response_data = course_utils.delete_review(user_id=user_id, course_id=course_id)
        return Response(json.dumps(response_data), mimetype='application/json', status=200)
    except InvalidUsage as e:
        traceback.print_exc()
        data = {"detail": e.message,
                "message": e.message}
        return Response(json.dumps(data), mimetype='application/json', status=e.status_code)
    except Exception as e:
        traceback.print_exc()
        data = {"detail": e.__str__(),
                "message": "Internal Server Error, Please try again later."}
        return Response(json.dumps(data), mimetype='application/json', status=500)


@course_apis.route('/course_class', methods=['GET'])
@login
def course_classes(role, organisation, permissions, login_user_other_details):
    """
    To retrieve the classes of the course.
    """
    try:
        if role == 'super_admin' or 'teacher':
            response_data = course_utils.get_course_classes()
            return Response(json.dumps(response_data), mimetype='application/json', status=200)
        else:
            raise InvalidUsage("You don't have permission to add course class", 401)
    except InvalidUsage as e:
        traceback.print_exc()
        data = {"detail": e.message,
                "message": e.message}
        return Response(json.dumps(data), mimetype='application/json', status=e.status_code)
    except Exception as e:
        traceback.print_exc()
        data = {"detail": e.__str__(),
                "message": "Internal Server Error, Please try again later."}
        return Response(json.dumps(data), mimetype='application/json', status=500)


@course_apis.route('/courses_topics', methods=['GET'])
@login
def topic_course(role, organisation, permissions, login_user_other_details):
    try:
        role = role
        user_id = login_user_other_details['_id']
        topic_id = request.args['topic_id']
        course_id = request.args['course_id']
        response_data = refactored_topics.view_course_topics_new(topic_id, user_id, role, course_id)
        return Response(json.dumps(response_data), mimetype='application/json', status=200)
    except Exception as e:
        traceback.print_exc()
        data = {"detail": e.__str__(),
                "message": "Internal Server Error, Please try again later."}
        return Response(json.dumps(data), mimetype='application/json', status=500)


@course_apis.route('/top_rated_courses', methods=['GET'])
@login
def top_rated_courses_get(role, organisation, permissions, login_user_other_details):
    """
    Retrieve top-rated courses for Edu-Collab.
    """
    try:
        response_data = {'status': True, 'message': 'Data retrieved successfully',
                         'data': course_utils.get_public_courses()}
        return Response(json.dumps(response_data), mimetype='application/json', status=200)
    except Exception as e:
        traceback.print_exc()
        data = {'data': {"detail": e.__str__()},
                "message": "Internal Server Error, Please try again later.",
                'status': False}
        return Response(json.dumps(data), mimetype='application/json', status=500)
    
    
@course_apis.route("/sorted_course_category", methods=["Get"])
@login
def sorted_course_categories(role, organisation, permissions, login_user_other_details):
    try:
        response = Content.get_categories_info(organisation=organisation, role=role)
        return Response(json.dumps(response), mimetype='application/json', status=200)
    except Exception as e:
        print(e)
        res = {"message": "internal server error", "status": 500}
        response = Response(json.dumps(res), mimetype='application/json', status=res['status'])
        return response


@course_apis.route("/courses/assessments", methods=["GET"])
@login
def course_assesments_view(role, organisation, permissions, login_user_other_details):
    user_id = login_user_other_details['_id']
    try:
        if request.args.get('course_id'):
            course_id = request.args.get('course_id')
            data, message, api_status = course_utils.view_assesments(
                course_id=course_id,
                role=role,
                user_id=user_id
            )
            response_data = {"message": message, "assesments_info": data}

        response = Response(json.dumps(response_data, default=str), mimetype='application/json', status=200)
        return response
    except InvalidUsage as e:
        error = {"message": e.message, "status": e.status_code}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])
    except Exception as e:
        traceback.print_exc()
        response_data = {"message": e.__str__(), "assesments_info": {}}
        response = Response(json.dumps(response_data), mimetype='application/json', status=500)
        return response


@course_apis.route("/courses/course_resources", methods=["GET"])
@login
def course_resources_view(role, organisation, permissions, login_user_other_details):
    user_id = login_user_other_details['_id']
    try:
        if request.args.get('course_id'):
            course_id = request.args.get('course_id')
            data, message, api_status = course_utils.view_resources(course_id=course_id)
            response_data = {"message": message, "resources_info": data}

        response = Response(json.dumps(response_data, default=str), mimetype='application/json', status=200)
        return response
    except InvalidUsage as e:
        error = {"message": e.message, "status": e.status_code}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])
    except Exception as e:
        traceback.print_exc()
        response_data = {"message": e.__str__(), "course_info": {}}
        response = Response(json.dumps(response_data), mimetype='application/json', status=500)
        return response


@course_apis.route("/courses/instructors", methods=["GET"])
@login
def course_instructors(role, organisation, permissions, login_user_other_details):
    user_id = login_user_other_details['_id']
    try:
        if request.args.get('course_id'):
            course_id = request.args.get('course_id')
            data, message, api_status = course_utils.view_instructors(
                course_id=course_id,
                role=role,
                user_id=user_id,
                organisation=organisation
            )
            response_data = {"message": message, "course_info": data}

        response = Response(json.dumps(response_data, default=str), mimetype='application/json', status=200)
        return response
    except InvalidUsage as e:
        error = {"message": e.message, "status": e.status_code}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])
    except Exception as e:
        traceback.print_exc()
        response_data = {"message": e.__str__(), "course_info": {}}
        response = Response(json.dumps(response_data), mimetype='application/json', status=500)
        return response


@course_apis.route("/courses/topics/list", methods=["GET"])
@login
def course_topics(role, organisation, permissions, login_user_other_details):
    user_id = login_user_other_details['_id']
    try:
        if request.args.get('course_id'):
            course_id = request.args.get('course_id')
            data, message, api_status = course_utils.view_topics(
                course_id=course_id,
                role=role,
                user_id=user_id
            )
            response_data = {"message": message, "topic_info": data}

        response = Response(json.dumps(response_data, default=str), mimetype='application/json', status=200)
        return response
    except InvalidUsage as e:
        error = {"message": e.message, "status": e.status_code}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])
    except Exception as e:
        traceback.print_exc()
        response_data = {"message": e.__str__(), "topic_info": {}}
        response = Response(json.dumps(response_data), mimetype='application/json', status=500)
        return response


@course_apis.route("/courses/live-sessions", methods=["GET"])
@login
def course_live_sessions(role, organisation, permissions, login_user_other_details):
    user_id = login_user_other_details['_id']
    try:
        if request.args.get('course_id'):
            course_id = request.args.get('course_id')
            data, message, api_status = course_utils.view_live_sessions(
                course_id=course_id,
                role=role,
                user_id=user_id
            )
            response_data = {"message": message, "live_sessions": data}

        response = Response(json.dumps(response_data, default=str), mimetype='application/json', status=200)
        return response
    except InvalidUsage as e:
        error = {"message": e.message, "status": e.status_code}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])
    except Exception as e:
        traceback.print_exc()
        response_data = {"message": e.__str__(), "live_sessions": {}}
        response = Response(json.dumps(response_data), mimetype='application/json', status=500)
        return response

@course_apis.route("/courses/course_work", methods=["GET"])
@login
def course_work_view(role, organisation, permissions, login_user_other_details):
    user_id = login_user_other_details['_id']
    try:
        if request.args.get('course_id'):
            course_id = request.args.get('course_id')
            user_id = login_user_other_details['_id']
            data, message, api_status = course_utils.view_coursework(course_id=course_id,
                                                                    user_id=user_id,
                                                                    role=role)
            response_data = {"message": message, "course_work_info": data}

        response = Response(json.dumps(response_data, default=str), mimetype='application/json', status=200)
        return response
    except InvalidUsage as e:
        error = {"message": e.message, "status": e.status_code}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])
    except Exception as e:
        traceback.print_exc()
        response_data = {"message": e.__str__(), "course_work_info": {}}
        response = Response(json.dumps(response_data), mimetype='application/json', status=500)
        return response


@course_apis.route("/courses/single_coursework", methods=["Get"])
@login
def single_course_work_view(role, organisation, permissions, login_user_other_details):
    try:
        course_id = request.args['course_id']
        course_work_id = request.args['course_work_id']
        user_id = login_user_other_details['_id']
        data = course_utils.view_coursework_single(course_id=course_id,
                                                   user_id=user_id,
                                                   role=role,
                                                   course_work_id=course_work_id)
        response_data = {"message": 'Successfully Retrieved', "course_work_info": data}

        response = Response(json.dumps(response_data), mimetype='application/json', status=200)
        return response
    except InvalidUsage as e:
        error = {"message": e.message, "status": e.status_code}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])
    except Exception as e:
        traceback.print_exc()
        response_data = {"message": e.__str__(), "course_work_info": {}}
        response = Response(json.dumps(response_data), mimetype='application/json', status=500)
        return response


@course_apis.route("/courses/catalouge", methods=["Get"])
@login
def course_view_new(role, organisation, permissions, login_user_other_details):
    user_id = login_user_other_details['_id']
    try:
        data, message = course_utils.catalogue_new(
            role=role,
            user_id=user_id,
            organisation=organisation,
            course_category_id=request.args.get('course_category_id'),
            subscription_status=request.args.get('subscription_status'),
            page=request.args.get('page'),
            page_name=request.args.get('page_name'),
            publish = request.args.get('publish')
        )
        response_data = {"message": message, "courses_info": data}

        response = Response(json.dumps(response_data, default=str), mimetype='application/json', status=200)
        return response
    except InvalidUsage as e:
        error = {"message": e.message, "status": e.status_code}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])
    except Exception as e:
        traceback.print_exc()
        response_data = {"message": e.__str__(), "course_info": {}}
        response = Response(json.dumps(response_data), mimetype='application/json', status=500)
        return response
