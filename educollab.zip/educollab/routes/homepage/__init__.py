from flask import Blueprint
homepage_api = Blueprint('homepage', __name__)

from routes.homepage.main import get_homepage