from email import message
from re import U
from routes.homepage import homepage_api
from flask import request, Response, json
from model.User import login
import traceback
from model.homepage import utils
from routes.exception import InvalidUsage
from db_wrapper.fetch_functions import Fetch
from bson import ObjectId
fetch = Fetch()


@homepage_api.route("/homepage", methods=['GET'])
@login
def get_homepage(role, organisation, permissions, login_user_other_details):
    """
    this api gives the list of all passion projects
    """
    try:
        if role != 'student':
            raise InvalidUsage('Only students can access this API for now.', status_code=401)
        user_id = login_user_other_details['_id']
        res_data, status = utils.main_pipeline(user_id=str(user_id), organisation=str(organisation))
        res_data = {'status': True, 'data': res_data, 'message':'Successful'}
        return Response(json.dumps(res_data), mimetype='application/json', status=status)
    except InvalidUsage as e:
        data = {"status": False,
                "message": 'Internal Server Error',
                "data": e.message}
        return Response(json.dumps(data), mimetype='application/json', status=e.status_code)
    except Exception as e:
        error = {"message": "Internal Server Error", "status": False, 'data': str(e)}
        return Response(json.dumps(error), mimetype='application/json', status=400)


@homepage_api.route("/get_recommended_courses", methods=['GET'])
@login
def get_recommended_courses(role, organisation, permissions, login_user_other_details):
    """
    this api gives the list of all recommended courses
    """
    try:
        if role != 'student':
            raise InvalidUsage('Only students can access this API for now.', status_code=401)
        user_id = login_user_other_details['_id']
        res_data, status = utils.get_all_recommended_courses(user_id=str(user_id), organisation=str(organisation))
        res_data = {'status': True, 'data': res_data, 'message': 'Successful'}
        return Response(json.dumps(res_data), mimetype='application/json', status=status)
    except InvalidUsage as e:
        data = {"status": False,
                "message": 'Internal Server Error',
                "data": e.message}
        return Response(json.dumps(data), mimetype='application/json', status=e.status_code)
    except Exception as e:
        error = {"message": "Internal Server Error", "status": False, 'data': str(e)}
        return Response(json.dumps(error), mimetype='application/json', status=400)


@homepage_api.route("/get_top_courses", methods=['GET'])
@login
def get_top_courses(role, organisation, permissions, login_user_other_details):
    """
    this api gives the list of all top courses
    """
    try:
        if role != 'student':
            raise InvalidUsage('Only students can access this API for now.', status_code=401)
        user_id = login_user_other_details['_id']
        res_data, status = utils.get_all_top_courses(user_id=str(user_id), organisation=str(organisation))
        res_data = {'status': True, 'data': res_data, 'message': 'Successful'}
        return Response(json.dumps(res_data), mimetype='application/json', status=status)
    except InvalidUsage as e:
        data = {"status": False,
                "message": 'Internal Server Error',
                "data": e.message}
        return Response(json.dumps(data), mimetype='application/json', status=e.status_code)
    except Exception as e:
        error = {"message": "Internal Server Error", "status": False, 'data': str(e)}
        return Response(json.dumps(error), mimetype='application/json', status=400)


@homepage_api.route("/discover_our_courses", methods=['GET'])
def discover_courses_api():
    """
    this api gives the list of all top courses
    """
    try:
        res_data, status = utils.discover_courses()
        res_data = {'status': True, 'data': res_data, 'message': 'Successful'}
        return Response(json.dumps(res_data), mimetype='application/json', status=status)
    except InvalidUsage as e:
        data = {"status": False,
                "message": 'Internal Server Error',
                "data": e.message}
        return Response(json.dumps(data), mimetype='application/json', status=e.status_code)
    except Exception as e:
        error = {"message": "Internal Server Error", "status": False, 'data': str(e)}
        return Response(json.dumps(error), mimetype='application/json', status=400)
