import traceback

from flask import request, Response, json, Blueprint, jsonify
import config
from model.User import login
from config import es, ES_USER_PROFILE_INDEX
from routes.exception import InvalidUsage
from utils.elasticsearch.user import search_user
from utils.elasticsearch.user import index_profile_data, update_user_profile_index
import model.User as User
from model.user.public_profile import public_profile
import model.user.public_profile as Profile

user_apis = Blueprint("user", __name__)


@user_apis.route("/users", methods=["GET"])
@login
def users(role, organisation, permissions, login_user_other_details):
    """
        API to search users from database
    """
    try:
        search_on = "0"
        query = request.args['query']
        module = request.args.get('module')

        filters = request.args.to_dict(flat=False)
        filters.pop('query', None)
        filters.pop('module', None)

        if role.lower() == "student":
            if "role" not in filters.keys():
                filters["role"] = ["student"]
            else:
                if filters["role"][0] != "student" or len(filters["role"]) > 1:
                    data = {"status": 403,
                            "message": "Insufficent permission for student to search users apart from other students"}
                    return Response(json.dumps(data), mimetype='application/json', status=403)

        if role.lower() == "teacher" and module != "course":
            if "organisation_name" not in filters.keys():
                filters["organisation_name"] = [organisation]
            else:
                if filters["organisation_name"][0] != organisation or len(filters["organisation_name"]) > 1:
                    data = {"status": 403,
                            "message": "Insufficent permission for teacher to search users outside {}".format(
                                organisation)}
                    return Response(json.dumps(data), mimetype='application/json', status=403)

        if "search_on" in filters.keys():
            """
                As user search is on name and username parameter 
                Hence no other value is allowed for search_on key
            """
            search_on = filters["search_on"][0]
            if search_on not in ["name", "username"]:
                data = {"status": 400, "message": "Invalid value for search_on key"}
                return Response(json.dumps(data), mimetype='application/json', status=400)
            filters.pop('search_on', None)
    except KeyError:
        traceback.print_exc()
        data = {"status": 400, "message": "Missing mandatory keys in payload"}
        return Response(json.dumps(data), mimetype='application/json', status=400)

    try:
        res = search_user(data=query,
                          filter_dict=filters,
                          search_on=search_on)
        return json.dumps(res)

    except Exception as e:
        traceback.print_exc()
        data = {"detail": e.__str__(),
                "message": "Could not retrieve results"}
        return Response(json.dumps(data), mimetype='application/json', status=500)


@user_apis.route('/user_levels', methods=['GET'])
@login
def user_type(role, organisation, permissions, login_user_other_details):
    try:
        response_data = User.fetch_user_type()
        if response_data:
            return Response(json.dumps(response_data), mimetype='application/json', status=200)
        else:
            data = {"status": 400, "message": "Not authorized user"}
            return Response(json.dumps(data), mimetype='application/json', status=400)
    except Exception as e:
        print('exception logged', e)
        data = {"status": 400, "message": "COULD NOT connect"}
        return Response(json.dumps(data), mimetype='application/json', status=400)


@user_apis.route('/change_password', methods=['POST'])
@login
def chnage_password_api(role, organisation, permissions, login_user_other_details):
    try:
        data = request.get_json()
        old_password = data['old_password']
        new_password = data['new_password']
        response_data, status_code = User.reset_password(email_address=login_user_other_details["email"],
                                                         new_password=new_password, confirm_password=new_password,
                                                         old_password=old_password,
                                                         saved_old_password=login_user_other_details['Password'])
        response_message = {"message": response_data, "status": status_code}
        return Response(json.dumps(response_message), mimetype='application/json', status=status_code)
    except Exception as e:
        print('exception logged', e)
        data = {"status": 400, "message": "COULD NOT connect"}
        return Response(json.dumps(data), mimetype='application/json', status=400)


@user_apis.route('/profile', methods=['GET'])
@login
def user_profile_api(role, organisation, permissions, login_user_other_details):
    try:
        user_id = login_user_other_details['_id']
        response_data = User.User_Profile(user_id=user_id, application_type="webapp")
        if response_data:
            return Response(json.dumps(response_data), mimetype='application/json', status=200)
        else:
            data = {"status": 400, "message": "Not authorized user"}
            return Response(json.dumps(data), mimetype='application/json', status=400)
    except Exception as e:
        print('exception logged', e)
        data = {"status": 400, "message": "COULD NOT connect"}
        return Response(json.dumps(data), mimetype='application/json', status=400)


@user_apis.route('/profile', methods=['PATCH'])
@login
def edit_profile_api(role, organisation, permissions, login_user_other_details):
    """
    This api is use to edit user profile
    :param role:
    :param organisation:
    :param permissions:
    :param login_user_other_details:
    :return:
    """
    try:
        user_id = login_user_other_details['_id']
        update_field = request.json
        first_name = update_field['first_name']
        last_name = update_field['last_name']
        mobile = update_field['mobile']
        profile_pic = update_field['avatar_url']
        username = update_field['username']
        email = update_field['email']
        institute = update_field['institute']
        about = update_field['about']
        facebook = update_field['facebook']
        linkedin = update_field['linkedin']
        user_type = update_field['user_type']

    except KeyError:
        error = {"status": "Key Error"}
        return Response(json.dumps(error), mimetype='application/json', status=400)
    try:
        status, response_data = User.update_user_profile(user_id=user_id, name=first_name, last_name=last_name,
                                                         mobile=mobile, profile_pic=profile_pic, username=username,
                                                         about=about, facebook=facebook, linkedin=linkedin,
                                                         user_type=user_type,
                                                         application_type="webapp")

        update_user_profile_index(_id=user_id, first_name=first_name, last_name=last_name,
                                  username=username, avatar=profile_pic)
        return Response(json.dumps(response_data), mimetype='application/json', status=200)
    except InvalidUsage as e:
        data = {"status": e.status_code, "message": e.message}
        return Response(json.dumps(data), mimetype='application/json', status=e.status_code)
    except Exception as e:
        traceback.print_exc()
        data = {"status": e.status_code, "message": e.message}
        return Response(json.dumps(data), mimetype='application/json', status=500)


@user_apis.route('/public_profile', methods=['GET'])
@login
def public_profile_api(role, organisation, permissions, login_user_other_details):
    try:
        current_user_id = login_user_other_details['_id']
        if request.args.get('user_id'):
            user_id = request.args.get('user_id')
            response_data = public_profile(user_id=user_id, application_type='webapp')
            # room = chat_db.get_common_room(user_id, current_user_id)
            # if room:
            #     room = room[0]['_id']
            #     response_data['room_id'] = room
        else:
            response_data = public_profile(user_id=current_user_id, application_type='webapp')

        if response_data:
            # if room is empty and user id of other user is given then display send request button
            # if a room is present Chat button will show which will take the user to the chat room
            # if user id is not given room will be empty string
            return Response(json.dumps(response_data), mimetype='application/json', status=200)
        else:
            data = {"status": 400, "message": "Not authorized user"}
            return Response(json.dumps(data), mimetype='application/json', status=400)
    except Exception as e:
        print('exception logged', e)
        data = {"status": 400, "message": "COULD NOT connect"}
        return Response(json.dumps(data), mimetype='application/json', status=400)


@user_apis.route('/user_profile', methods=['PATCH'])
@login
def edit_user_profile(role, organisation, permissions, login_user_other_details):
    """
    This api is use to edit user profile
    """
    page_name = request.args.get('page')
    user_id = login_user_other_details['_id']
    role = login_user_other_details['role']

    # Personal Detail Page
    if page_name == 'personal':
        try:
            update_field = request.json
            name = update_field['name']
            email = update_field['email']
            mobile = update_field['mobile']
            username = update_field['username']
            institute = update_field['institute']
            about = update_field['about']
            user_type = login_user_other_details['role']
            facebook = update_field.get('facebook', "")
            linkedin = update_field.get('linkedin', "")
            instagram = update_field.get('instagram', "")
            twitter = update_field.get('twitter', "")
            fields_of_interest = update_field.get("fields_of_interest", "")
            profile_pic = update_field['avatar_url']

        except KeyError:
            error = {"status": "Key Error"}
            return Response(json.dumps(error), mimetype='application/json', status=400)

        try:
            status, response_data = Profile.update_user_profile(user_id=user_id, name=name, mobile=mobile,
                                                                profile_pic=profile_pic, username=username,
                                                                about=about, facebook=facebook, linkedin=linkedin,
                                                                instagram=instagram, twitter=twitter,
                                                                user_type=user_type,
                                                                fields_of_interest=fields_of_interest,
                                                                application_type="webapp")

            return Response(json.dumps(response_data), mimetype='application/json', status=200)
        except InvalidUsage as e:
            data = {"status": e.status_code, "message": e.message}
            return Response(json.dumps(data), mimetype='application/json', status=e.status_code)
        except Exception as e:
            traceback.print_exc()
            data = {"status": e.status_code, "message": e.message}
            return Response(json.dumps(data), mimetype='application/json', status=500)

    # Education Page
    elif page_name == 'education':
        try:
            update_field = request.json
            education_details = update_field.get('education','')
        except KeyError:
            error = {"status": "Key Error"}
            return Response(json.dumps(error), mimetype='application/json', status=400)

        try:
            # check if education details are empty
            # if not education_details:
            #     raise InvalidUsage("Please enter your education details", 400)

            # check if education marks are < 0
            for edu in education_details:
                if str(edu['marks']) < "0":
                    raise InvalidUsage("Invalid details", 400)

            else:
                status, response_data = Profile.update_user_education(user_id=user_id,
                                                                      education_details=education_details)
            return Response(json.dumps(response_data), mimetype='application/json', status=200)

        except InvalidUsage as e:
            data = {"status": e.status_code, "message": e.message}
            return Response(json.dumps(data), mimetype='application/json', status=e.status_code)

    # Professional Page
    elif page_name == 'professional':
        try:
            update_field = request.json
            exp = update_field.get('experience','')

        except KeyError:
            error = {"status": "Key Error"}
            return Response(json.dumps(error), mimetype='application/json', status=400)

        try:
            if exp:
                for experience in exp:
                    # is currently working (true) and end date not given
                    if experience['curretly_working'] == True and len(experience['end_date']) == 0:
                        status, response_data = Profile.update_user_experience(user_id=user_id, experience=exp)

                    # is not currently working (false) and end date is given
                    elif experience['curretly_working'] == False and len(experience['end_date']) > 0:
                        status, response_data = Profile.update_user_experience(user_id=user_id, experience=exp)

                    else:
                        raise InvalidUsage("Invalid details", 400)

                return Response(json.dumps(response_data), mimetype='application/json', status=200)

        except InvalidUsage as e:
            traceback.print_exc()
            data = {"message": e.message, "status": e.status_code}
            return Response(json.dumps(data), mimetype='application/json', status=e.status_code)

    # Account Setting Page
    elif page_name == 'account_settings': 
        try:
            data = request.get_json()
            old_password = data['old_password']
            new_password = data['new_password']
            response_data, status_code = Profile.update_password(email_address=login_user_other_details["email"],
                                                            new_password=new_password, confirm_password=new_password,
                                                            old_password=old_password,
                                                            saved_old_password=login_user_other_details['Password'])
            response_message = {"message": response_data, "status": status_code}
            return Response(json.dumps(response_message), mimetype='application/json', status=status_code)
        except Exception as e:
            print('exception logged', e)
            data = {"status": 400, "message": "COULD NOT connect"}
            return Response(json.dumps(data), mimetype='application/json', status=400)

    # Resume Page
    elif page_name == 'resume': 
        try:
            data = request.json
            resource_id = data['resource_id']
            path = data['path']
            
        except KeyError as e:
            traceback.print_exc()
            data = {"status": 400, "message": "Please check request data.", "detail": e.__str__()}
            return Response(json.dumps(data), mimetype='application/json', status=400)
        
        try:
            message = Profile.submit_resume(user_id=user_id, resource_id=resource_id, path=path)
            response_message = {"message": message}
            return Response(json.dumps(response_message), mimetype='application/json', status=200)

        except InvalidUsage as e:
            traceback.print_exc()
            data = {"detail": e.message,
                    "message": e.message,
                    "status": e.status_code}
            return Response(json.dumps(data), mimetype='application/json', status=e.status_code)
    
    # Profile Settings page
    elif page_name == 'profile_settings': 
        try:
            data = request.json
            show_profile = data['show_profile']
            show_username = data['show_username']
            show_organization = data['show_organization']
            show_social_media = data['show_social_media']
            hrs_study_today = data['hrs_study_today']
            show_email = data['show_email']
            show_phone = data['show_phone']
            show_courses = data['show_courses']

            
        except KeyError as e:
            traceback.print_exc()
            data = {"status": 400, "message": "Please check request data.", "detail": e.__str__()}
            return Response(json.dumps(data), mimetype='application/json', status=400)
        
        try:
            message = Profile.profile_settings(user_id=user_id, show_profile=show_profile, show_username=show_username,
                                                show_organization=show_organization, show_social_media=show_social_media, 
                                                hrs_study_today=hrs_study_today,show_email=show_email, show_phone=show_phone, 
                                                show_courses=show_courses)
            response_message = {"message": message}
            return Response(json.dumps(response_message), mimetype='application/json', status=200)

        except InvalidUsage as e:
            traceback.print_exc()
            data = {"detail": e.message,
                    "message": e.message,
                    "status": e.status_code}
            return Response(json.dumps(data), mimetype='application/json', status=e.status_code)


@user_apis.route('/public_profile/new', methods=['GET'])
@login
def public_profile_api_new(role, organisation, permissions, login_user_other_details):
    try:
        current_user_id = login_user_other_details['_id']
        if request.args.get('user_id'):
            user_id = request.args.get('user_id')
            response_data = Profile.public_profile_new(user_id=user_id, application_type='webapp', check=False)
            # room = chat_db.get_common_room(user_id, current_user_id)
            # if room:
            #     room = room[0]['_id']
            #     response_data['room_id'] = room
        else:
            response_data = Profile.public_profile_new(user_id=current_user_id, application_type='webapp', check = True)

        if response_data:
            # if room is empty and user id of other user is given then display send request button
            # if a room is present Chat button will show which will take the user to the chat room
            # if user id is not given room will be empty string
            return Response(json.dumps(response_data), mimetype='application/json', status=200)
        else:
            data = {"status": 400, "message": "Not authorized user"}
            return Response(json.dumps(data), mimetype='application/json', status=400)
    except Exception as e:
        print('exception logged', e)
        data = {"status": 400, "message": "COULD NOT connect"}
        return Response(json.dumps(data), mimetype='application/json', status=400)
