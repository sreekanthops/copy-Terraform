from flask import Blueprint
report_apis = Blueprint('report', __name__)

from routes.report import courses, teach_assistant

