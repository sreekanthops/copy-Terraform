from routes.exception import InvalidUsage
from routes.report import report_apis
from flask import request, Response, json
from model.User import login
import traceback
from model.report import teach_assistant as utils


@report_apis.route('/courses/teaching-assistant/report', methods=["GET"])
@login
def get_teaching_assistant_report(role, organisation, permissions, login_user_other_details):
    """To know the progress of teaching assistant on the basis of course works and assessments"""
    user_id = login_user_other_details['_id']
    try:
        course_id = request.args["course_id"]
    except KeyError as e:
        traceback.print_exc()
        data = {"message": "Please check request data.",
                "detail": e.__str__()}
        return Response(json.dumps(data), mimetype='application/json', status=400)
    try:
        response_data = utils.get_teaching_assistant_progress_report(user_id=user_id,
                                                                     course_id=course_id,
                                                                     role=role)
        response = {"message": "Report generated successfully.",
                    "response": response_data}
        return Response(json.dumps(response), mimetype='application/json', status=200)
    except InvalidUsage as e:
        traceback.print_exc()
        return Response(json.dumps({"message": e.message}), mimetype='application/json', status=e.status_code)
    except Exception as e:
        traceback.print_exc()
        data = {"message": "Oops! Something went wrong please try again later.",
                "detail": e.__str__()}
        return Response(json.dumps(data), mimetype='application/json', status=500)
