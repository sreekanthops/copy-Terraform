from io import BytesIO

import pandas as pd

from routes.exception import InvalidUsage
from routes.report import report_apis
from flask import request, Response, json, send_file
from model.User import login
import traceback
from model.report import courses as course_utils
from werkzeug.wsgi import FileWrapper

@report_apis.route('/courses/report', methods=["POST"])
@login
def generate_report(role, organisation, permissions, login_user_other_details):
    """To get details about Notes, Attendance, Course Work, Assessments of some particular course.
    """
    user_id = login_user_other_details['_id']
    try:
        data = request.json
        course_id = data["course_id"]
        # at most fifteen sessions can be selected
        sessions = data.get("session")
        # provide notes details for selected sessions if required
        notes = data.get("notes")
        # course work can be at topic level or course level no link to sessions
        coursework = data.get("coursework")
        # provide assessment data for selected sessions
        assessment = data.get("assessment")
        # provide attendance data for selected sessions
        attendance = data.get("attendance")
        # provide topic if need to search by topic, offset is compulsory in that case.
        topic_filter = data.get("topic")
        # offset for topic sessions
        session_offset = data.get("offset")
    except KeyError as e:
        traceback.print_exc()
        data = {"message": "Please check request data.",
                "detail": e.__str__()}
        return Response(json.dumps(data), mimetype='application/json', status=400)
    try:
        response_data = course_utils.course_report(user_id=user_id,
                                                   course_id=course_id,
                                                   role=role,
                                                   sessions=sessions,
                                                   notes=notes,
                                                   coursework=coursework,
                                                   assessment=assessment,
                                                   attendance=attendance,
                                                   topic_filter=topic_filter,
                                                   session_offset=session_offset,
                                                   max_sessions=15)
        response = {"message": "Report generated successfully.",
                    "response": response_data}
        return Response(json.dumps(response), mimetype='application/json', status=200)
    except InvalidUsage as e:
        traceback.print_exc()
        return Response(json.dumps({"message": e.message}), mimetype='application/json', status=e.status_code)
    except Exception as e:
        traceback.print_exc()
        data = {"message": "Oops! Something went wrong please try again later.",
                "detail": e.__str__()}
        return Response(json.dumps(data), mimetype='application/json', status=500)


@report_apis.route('/courses/report/export', methods=['POST'])
@login
def generate_excel_for_report(role, organisation, permissions, login_user_other_details):
    """
    This api generates excel sheet for the student monitoring report
    :return: csv of the report generated
    """
    user_id = login_user_other_details['_id']
    try:
        data = request.get_json()
        course_id = data['course_id']
        # course_work contains information about course level and topic level course_work
        course_work = data['course_work']
        # assessment contains information about course, topic and session level assessments
        assessment = data['assessment']
        # notes have session ids
        notes = data['notes']
        # attendance have session ids
        attendance = data['attendance']

    except KeyError as e:
        traceback.print_exc()
        data = {"message": "Please check request data.",
                "detail": e.__str__()}
        return Response(json.dumps(data), mimetype='application/json', status=400)

    try:
        report = course_utils.generate_data_for_excel(course_id=course_id,
                                                      course_work=course_work,
                                                      assessments=assessment,
                                                      notes= notes,
                                                      attendance=attendance,
                                                      role=role,
                                                      user_id=user_id)

        output = BytesIO()
        report.to_excel(output, startrow=0, merge_cells=True, sheet_name="Sheet_1", engine='openpyxl')
        output.seek(0)
        file_wrapper = FileWrapper(output)
        headers = {
            'Content-Disposition': 'attachment; filename="{}"'.format('student_monitoring.xlsx')
        }
        return Response(file_wrapper,
                        mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                        direct_passthrough=True,
                        headers=headers)

    except InvalidUsage as e:
        traceback.print_exc()
        return Response(json.dumps({"message": e.message}), mimetype='application/json', status=e.status_code)
    except Exception as e:
        traceback.print_exc()
        data = {"message": "Oops! Something went wrong please try again later.",
                "detail": e.__str__()}
        return Response(json.dumps(data), mimetype='application/json', status=500)
