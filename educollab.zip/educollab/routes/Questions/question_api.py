from bson import ObjectId

from model.Questions import Similar_questions
from model.Questions.new_recommender_system import rs_check, recommender_system
from routes.Questions import my_question_api
import pandas as pd
from flask import request, Response, json
import model.Questions.Content as Content
import model.User as User
from model.User import login
import traceback
from db_wrapper.tasks import Mongo
from model.tracking.questions import user_ques_history
from routes.exception import InvalidUsage
import services.Recommendation_engine as recommendation_engine
import ast
import model.course_session as course_session
import model.Question as Question
import services.common.translation as translation
import services.profanity_check as Profanity_Detection
from services.storage.s3_services import s3_storage

s3_function = s3_storage()

mongo_session = Mongo()


@my_question_api.route("/user_questions", methods=["GET"])
@login
def fetch_answers(role, organisation, permissions, login_user_other_details):
    """1. To fetch details and answers of a particular question, if question id is provided.
       2. To fetch questions on a particular session if course id and session id is provided.
       3. To fetch user specific questions, if user id is given."""
    user_id = login_user_other_details['_id']
    question_id = request.args.get('id')
    session_id = request.args.get('course_session_id')
    course_id = request.args.get('course_id')
    user_specific = request.args.get('user_specific')
    sort_by = request.args.get('sort_by')
    categories = request.args.get('categories')
    if categories:
        cat_filter = categories.split(",")
    else:
        cat_filter = []
    try:
        if question_id:
            # add question to user tracking
            user_ques_history(user_id, question_id)
            response_data = Content.answer_to_questions(question_id=question_id)
            message = "Data has been retrieved successfully."
        else:
            response_data = Content.get_questions_info(session_id=session_id,
                                                       course_id=course_id,
                                                       user_specific=user_specific,
                                                       user_id=user_id,
                                                       cat_filter=cat_filter,
                                                       sort_by=sort_by)
            message = "Questions has been retrieved successfully." if response_data else "No questions to show, start " \
                                                                                         "collaborating. "
        data = {"message": message,
                "response": response_data}
        return Response(json.dumps(data), mimetype='application/json', status=200)
    except InvalidUsage as e:
        traceback.print_exc()
        error = {"message": e.message, "detail": e.message}
        return Response(json.dumps(error), mimetype='application/json', status=e.status_code)
    except Exception as e:
        traceback.print_exc()
        response_data = {"detail": e.__str__(),
                         "message": "Oops! something went wrong, please try again later."}
        response = Response(json.dumps(response_data), mimetype='application/json', status=500)
        return response


@my_question_api.route("/my_recommend_questions", methods=["POST"])
@login
def recommend_questions(role, organisation, permissions, login_user_other_details):
    user_id = login_user_other_details['_id']
    try:
        data = request.get_json()
        count = int(data["count"])
        sort_by = data.get('sort_by')
        categories = data.get('categories')
        if categories:
            cat_filter = categories.split(",")
        else:
            cat_filter = []
    except KeyError:
        traceback.print_exc()
        data = {"status": 400, "message": "Please check request data."}
        return Response(json.dumps(data), mimetype='application/json', status=400)
    try:
        try_rs = rs_check(user_id)
        if try_rs:
            try:

                user_questions = mongo_session.get_all_data_for_particular_condition_fields(collection="user_profile",
                                                                                            condition={"_id": ObjectId(
                                                                                                user_id)},
                                                                                            )["message"][0]

                if user_questions["questions"]:
                    user_questions_id = [str(user_question["_id"]) for user_question in user_questions["questions"]]

                answers = recommender_system(user_id=user_id, cat_filter=cat_filter)

                if user_questions_id:
                    for ind, ans in enumerate(answers):
                        ans_id = ans["id"]
                        if ans_id in user_questions_id:
                            answers.pop(ind)

            except:
                answered_questions = recommendation_engine.fetch_answered_questions(user_id)
                answers = Similar_questions.botone(user_id, count, answered_questions, cat_filter)

            chat_unread = mongo_session.check_existance(collection="messages",
                                                        condition={"receivers": User.User_Profile(user_id=user_id,
                                                                                                  application_type='webapp')[
                                                            'username'],
                                                                   "is_read": False,
                                                                   "$and": [{"is_group": {"$exists": True}},
                                                                            {"is_group": False}]})
            chat_unread_group = mongo_session.check_existance(collection='messages',
                                                              condition={
                                                                  "receiver_status":
                                                                      {"$elemMatch": {"$and": [
                                                                          {"_id": ObjectId(user_id)},
                                                                          {"status": False}
                                                                      ]}
                                                                      }})
            if not chat_unread and not chat_unread_group:
                unread = False
            else:
                unread = True
            # response_message = {"Status": "200", "answers": answers, "new_message": unread}
            # return Response(json.dumps(response_message), mimetype='application/json', status=200)

        else:
            answered_questions = recommendation_engine.fetch_answered_questions(user_id)
            answers = Similar_questions.botone(user_id, count, answered_questions, cat_filter)
            chat_unread = mongo_session.check_existance(collection="messages",
                                                        condition={"receivers": User.User_Profile(user_id=user_id,
                                                                                                  application_type='webapp')[
                                                            'username'],
                                                                   "is_read": False,
                                                                   "$and": [{"is_group": {"$exists": True}},
                                                                            {"is_group": False}]})
            chat_unread_group = mongo_session.check_existance(collection='messages',
                                                              condition={
                                                                  "receiver_status":
                                                                      {"$elemMatch": {"$and": [
                                                                          {"_id": ObjectId(user_id)},
                                                                          {"status": False}
                                                                      ]}
                                                                      }})
            if not chat_unread and not chat_unread_group:
                unread = False
            else:
                unread = True
        for ques in answers:
            if str(ques["user_id"]) == str(user_id):
                question_user_type = "my_question"
            elif ques["user_id"] == 'celery_service':
                question_user_type = "session_question"
            else:
                question_user_type = "others_question"
            del ques["user_id"]
            ques["question_type"] = question_user_type
        # sort filtering
        if sort_by:
            if sort_by == "recent":
                answers = answers
            else:
                answers = sorted(answers, key=lambda k: k['count'], reverse=True)
        response_message = {"Status": "200", "answers": answers, "new_message": unread}
        return Response(json.dumps(response_message), mimetype='application/json', status=200)

    except Exception as e:
        traceback.print_exc()
        response_data = {"message": e.__str__()}
        response = Response(json.dumps(response_data), mimetype='application/json', status=500)
        return response


@my_question_api.route("/user_answers", methods=["GET"])
@login
def answer_data(role, organisation, permissions, login_user_other_details):
    """To find the details of an answer."""
    user_id = login_user_other_details['_id']
    try:
        answer_id = request.args['answer_id']
    except KeyError as e:
        error = {"message": "Bad Request", "status": 400, "detail": e.__str__()}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])
    try:
        response_data = Content.fetch_answer_details(answer_id=answer_id, user_id=user_id)
        data = {"message": "Answer meta data has been retrieved successfully",
                "response": response_data}
        return Response(json.dumps(data), mimetype='application/json', status=200)
    except InvalidUsage as e:
        traceback.print_exc()
        error = {"message": e.message, "detail": e.message}
        return Response(json.dumps(error), mimetype='application/json', status=e.status_code)
    except Exception as e:
        traceback.print_exc()
        data = {"detail": e.__str__(), "message": "Oops! something went wrong, Please try again later."}
        return Response(json.dumps(data), mimetype='application/json', status=500)


@my_question_api.route("/question_bank", methods=["GET"])
@login
def question_bank_api(role, organisation, permissions, login_user_other_details):
    """1. To fetch details and answers of a particular question, if question id is provided.
       2. To fetch questions on a particular session if course id a nd session id is provided.
       3. To fetch user specific questions, if user id is given."""
    page = request.args.get('page')
    is_extracted = request.args.get('is_extracted')
    sort_by = request.args.get('sort_by')
    categories = request.args.get('categories')
    total_question = request.args.get('total_question', 50)
    if categories:
        cat_filter = categories.split(",")
    else:
        cat_filter = []
    user_id = login_user_other_details['_id']
    try:
        response_data = Content.get_other_question(user_id=str(user_id), page=int(page), is_extracted=is_extracted,
                                                   sort_by=sort_by, cat_filter=cat_filter,
                                                   total_question=int(total_question))
        message = "Questions has been retrieved successfully." if response_data else "No questions to show, start " \
                                                                                     "collaborating. "
        if not response_data:
            response_data = {"total_pages": 0, "data": [], "current_page": 0}
        data = {"message": message,
                "response": response_data}
        return Response(json.dumps(data), mimetype='application/json', status=200)
    except InvalidUsage as e:
        traceback.print_exc()
        error = {"message": e.message, "detail": e.message}
        return Response(json.dumps(error), mimetype='application/json', status=e.status_code)
    except Exception as e:
        traceback.print_exc()
        response_data = {"detail": e.__str__(),
                         "message": "Oops! something went wrong, please try again later."}
        response = Response(json.dumps(response_data), mimetype='application/json', status=500)
        return response


@my_question_api.route('/ask_questions', methods=['POST'])
@login
def ask_question_api(role, organisation, permissions, login_user_other_details):
    user_id = login_user_other_details['_id']
    try:
        data = request.get_json()
        coordinates = data.get("coordinates")
        if coordinates:
            coordinates = ast.literal_eval(data["coordinates"])

        asked_question = data['question']
        coins = float(data['coins'])
        language = data['language']
        category_id = data['category_id']
        tags = data['tags']
        question_image = data.get('question_image', [])
        question_video = data.get('video_path', [])
        question_doc = data.get('doc_path', [])
        answer_id = data['answer_id']
        video_time = data['video_time']
        course_id = data['course_id']
        session_id = data['course_session_id']
        if not asked_question and coins and language and category_id:
            print("inside not condition")
            raise Exception("Please check request data.")
    except KeyError:
        traceback.print_exc()
        print("key error", traceback.print_exc())
        data = {"status": 400, "message": "Please check request data."}
        print("here exception")
        return Response(json.dumps(data), mimetype='application/json', status=400)

    if not coins >= 1:
        response_message = {"Status": "Failed",
                            "question_id": "",
                            "message": "Your coin balance is insufficient, kindly check. To earn more coins answer some questions under the recommended questions tab"}
        return Response(json.dumps(response_message), mimetype='application/json', status=402)
    try:
        check_reward_status = User.check_coins(coins_for_question=coins, user_id=user_id)
        if not (type(check_reward_status) == bool and check_reward_status):
            response_message = {"Status": "Failed",
                                "question_id": "",
                                "message": "Insufficient balance to give reward"}
            return Response(json.dumps(response_message), mimetype='application/json', status=402)
        if language != "en":
            translated_question, converted_language = translation.question_translation(asked_question)
        else:
            translated_question = asked_question

        profanity = Profanity_Detection.check_profanity(translated_question)
        if type(profanity) == bool and profanity:
            response_message = {"Status": "Failed",
                                "question_id": "",
                                "message": "Oops can't add this question."}
            return Response(json.dumps(response_message), mimetype='application/json', status=422)

        # ask question on answers
        if answer_id and video_time:
            print("answers")
            answer_info = mongo_session.answer_info_ask_question(collection="answer_bank",
                                                                 condition={"_id": ObjectId(answer_id)})
            if not answer_info['message'] == answer_id:
                data = {"Status": "Failed",
                        "question_id": "",
                        "message": answer_info['msg']}
                return Response(json.dumps(data), mimetype='application/json', status=409)
            question_data, available_coins, s3_link, video_s3_link, message, notification_status = Content.ask_question(
                question=asked_question,
                user_id=user_id,
                language=language,
                translated_question=translated_question,
                coins=coins,
                category_id=category_id,
                question_image=question_image,
                question_video=question_video,
                tags=tags,
                question_doc=question_doc,
                coordinates=coordinates)
            store_status = Question.store_answer_info(answer_id, video_time, str(question_data))
            response_message = {"Status": "Success",
                                "question_id": str(question_data),
                                "message": "Question Added Successfully",
                                "avail_coin": available_coins,
                                "question_image_path": s3_link,
                                "video_path": video_s3_link,
                                "notification_status": notification_status}

        elif course_id and session_id and int(video_time) >= 0:
            question_data, available_coins, s3_link, video_s3_link, message, store_status, session_video_link, \
            session_file_id = Content.ask_question_session(
                question=asked_question,
                user_id=user_id,
                language=language,
                translated_question=translated_question,
                coins=coins,
                category_id=category_id,
                question_image=question_image,
                question_video=question_video,
                course_id=course_id,
                session_id=session_id,
                video_time=video_time,
                tags=tags,
                question_doc=question_doc,
                coordinates=coordinates)
            response_message = {"Status": "Success",
                                "question_id": str(question_data),
                                "message": "Question Added Successfully",
                                "avail_coin": available_coins,
                                "question_image_path": s3_link,
                                "video_path": video_s3_link,
                                "session_video_link": session_video_link,
                                "session_file_id": session_file_id, }
        elif not (answer_id or video_time and course_id and session_id):
            question_data, available_coins, s3_link, video_s3_link, message, notification_status = Content.ask_question(
                question=asked_question,
                user_id=user_id,
                language=language,
                translated_question=translated_question,
                coins=coins,
                category_id=category_id,
                question_image=question_image,
                question_video=question_video,
                tags=tags,
                question_doc=question_doc,
                coordinates=coordinates)
            store_status = 200
            response_message = {"Status": "Success",
                                "question_id": str(question_data),
                                "message": "Question Added Successfully",
                                "avail_coin": available_coins,
                                "question_image_path": s3_link,
                                "video_path": video_s3_link,
                                "notification_status": notification_status}
        else:
            raise Exception("cannot process your request, please check your request data.")
        if not (question_data and store_status == 200):
            raise Exception("Some Internal error occurred Please try again later.")
        return Response(json.dumps(response_message), mimetype='application/json', status=200)
    except Exception as e:
        traceback.print_exc()
        response_message = {"Status": "Failed",
                            "question_id": "",
                            "message": e.__str__()}
        response = Response(json.dumps(response_message), mimetype='application/json', status=500)
        return response


@my_question_api.route('/edit_answer', methods=['PATCH'])
@login
def edit_answer(role, organisation, permissions, login_user_other_details):
    """This to edit the answers given by users on someone else's question.
       video: contains video_path and thumbnails in form of s3_keys.
    """
    # Note : user can not answer his/her own question.
    user_id = login_user_other_details['_id']
    try:
        data = request.get_json()
        answer_id = data['answer_id']
        question_id = data['question_id']
        speech_text = data['speech_text']
        answer_html = data['answer_html']
        # video_info = data['video']
        answer_image = data.get('answer_image', [])
        answer_video = data.get('answer_video', [])
        answer_doc = data.get('answer_doc', [])
    except KeyError as err:
        traceback.print_exc()
        data = {"message": "Please check all the request data.",
                "detail": err.__str__()}
        return Response(json.dumps(data), mimetype='application/json', status=400)
    try:
        status_message, api_status = Content.edit_answer(question_id=question_id,
                                                         answer_id=answer_id,
                                                         user_id=user_id,
                                                         answer_html=answer_html,
                                                         speech_text=speech_text,
                                                         answer_image=answer_image,
                                                         answer_video=answer_video,
                                                         answer_doc=answer_doc
                                                         )
        response_message = {"status": api_status, "message": status_message}
        return Response(json.dumps(response_message), mimetype='application/json', status=response_message['status'])

    except InvalidUsage as e:
        traceback.print_exc()
        error = {"message": e.message, "detail": e.message}
        return Response(json.dumps(error), mimetype='application/json', status=e.status_code)
    except Exception as e:
        traceback.print_exc()
        data = {"detail": e.__str__(), "message": "Oops! something went wrong, Please try again later."}
        return Response(json.dumps(data), mimetype='application/json', status=500)


@my_question_api.route('/edit_questions', methods=['PATCH'])
@login
def edit_question_api(role, organisation, permissions, login_user_other_details):
    """This to edit the question.
    """
    user_id = login_user_other_details['_id']
    try:
        data = request.get_json()
        question_id = data['question_id']
        asked_question = data['question']
        coins = float(data['coins'])
        language = data['language']
        category_id = data['category_id']
        tags = data['tags']
        question_image = data.get('question_image', [])
        question_video = data.get('video_path', [])
        question_doc = data.get('doc_path', [])
        if not asked_question and coins and language and category_id:
            print("inside not condition")
            raise Exception("Please check request data.")
    except KeyError:
        traceback.print_exc()
        print("key error", traceback.print_exc())
        data = {"status": 400, "message": "Please check request data."}
        print("here exception")
        return Response(json.dumps(data), mimetype='application/json', status=400)

    if not coins >= 1:
        response_message = {"Status": "Failed",
                            "question_id": "",
                            "message": "Your coin balance is insufficient, kindly check. To earn more coins answer some questions under the recommended questions tab"}
        return Response(json.dumps(response_message), mimetype='application/json', status=402)

    question_data = mongo_session.check_existance_return_info(collection="question_bank",
                                                              condition={"_id": ObjectId(question_id)},
                                                              whole_doc=True)
    if not question_data:
        raise InvalidUsage("Please look for a valid question.", 400)
    if role == 'student' and str(question_data['user_id']) != str(user_id):
        raise InvalidUsage("You cannot edit other user's question.", 403)
    try:
        reward = int(float(question_data['reward']) - coins)
        if reward > 0:
            check_reward_status = User.check_coins(coins_for_question=reward, user_id=user_id)
            if not (type(check_reward_status) == bool and check_reward_status):
                response_message = {"Status": "Failed",
                                    "question_id": "",
                                    "message": "Insufficient balance to give reward"}
                return Response(json.dumps(response_message), mimetype='application/json', status=402)
        if language != "en":
            translated_question, converted_language = translation.question_translation(asked_question)
        else:
            translated_question = asked_question

        profanity = Profanity_Detection.check_profanity(translated_question)
        if type(profanity) == bool and profanity:
            response_message = {"Status": "Failed",
                                "question_id": "",
                                "message": "Oops can't edit this question."}
            return Response(json.dumps(response_message), mimetype='application/json', status=422)
        status_message, api_status = Content.edit_question(
            question_id=question_id,
            question=asked_question,
            user_id=user_id,
            language=language,
            translated_question=translated_question,
            coins=coins,
            reward=reward,
            category_id=category_id,
            question_image=question_image,
            question_video=question_video,
            tags=tags,
            question_doc=question_doc)
        response_message = {"status": api_status, "message": status_message}
        return Response(json.dumps(response_message), mimetype='application/json', status=response_message['status'])

    except InvalidUsage as e:
        traceback.print_exc()
        error = {"message": e.message, "detail": e.message}
        return Response(json.dumps(error), mimetype='application/json', status=e.status_code)
    except Exception as e:
        traceback.print_exc()
        data = {"detail": e.__str__(), "message": "Oops! something went wrong, Please try again later."}
        return Response(json.dumps(data), mimetype='application/json', status=500)
