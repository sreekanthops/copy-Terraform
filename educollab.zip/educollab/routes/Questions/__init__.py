from flask import Blueprint

my_question_api = Blueprint('my_question_api', __name__)
from routes.Questions.question_api import *
