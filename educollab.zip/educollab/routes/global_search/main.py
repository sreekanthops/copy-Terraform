from routes.global_search import global_search_api
from flask import request, Response, json
from model.global_search import content_search
from model.User import login, encryption_function
import mongo_connection
from bson import ObjectId
import config
import traceback
from routes.exception import InvalidUsage


@global_search_api.route("/global_search", methods=["GET"])
@login
def find_content(role, organisation, permissions, login_user_other_details):
    """To find the courses by searching by title and description of the course"""
    user_id = login_user_other_details['_id']
    try:
        search_text = request.args["search_text"]
        content_type = request.args["content_type"]
    except KeyError as e:
        traceback.print_exc()
        data = {"detail": e.__str__(),
                "message": "Please check request data"}
        return Response(json.dumps(data), mimetype='application/json', status=400)
    try:
        response = []
        if content_type == "course":
            response = content_search.find_course(search_text=search_text,
                                                  content_type=content_type,
                                                  user_id=user_id,
                                                  login_user_other_details=login_user_other_details)
        if content_type == "session":
            response = content_search.find_session(search_text=search_text,
                                                   content_type=content_type,
                                                   user_id=user_id,
                                                   login_user_other_details=login_user_other_details)
        if content_type == "question":
            response = content_search.find_question(search_text=search_text,
                                                    content_type=content_type,
                                                    user_id=user_id,
                                                    login_user_other_details=login_user_other_details)
        if content_type == "mosaic":
            response = content_search.find_mosaic(search_text=search_text,
                                                  content_type=content_type,
                                                  user_id=user_id,
                                                  login_user_other_details=login_user_other_details)
        if content_type == "usersandmessage":
            response = content_search.find_users_and_message(search_text=search_text,
                                                             content_type=content_type,
                                                             user_id=user_id,
                                                             login_user_other_details=login_user_other_details)

        message = "Data retrieved successfully." if response else "Oops! there is nothing related to your search, " \
                                                                  "try searching something else."
        return Response(json.dumps({"message": message,
                                    "response": response}), mimetype='application/json', status=200)
    except InvalidUsage as e:
        traceback.print_exc()
        data = {"detail": e.message,
                "message": "Oops! Something went wrong, Please try again later."}
        return Response(json.dumps(data), mimetype='application/json', status=e.status_code)
    except Exception as e:
        traceback.print_exc()
        data = {"detail": "Oops! Something went wrong, Please try again later.",
                "message": e.__str__()}
        return Response(json.dumps(data), mimetype='application/json', status=500)
