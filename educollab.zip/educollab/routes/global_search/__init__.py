from flask import Blueprint

global_search_api = Blueprint('global_search', __name__)
from routes.global_search.main import *