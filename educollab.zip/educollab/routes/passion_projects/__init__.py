from flask import Blueprint
passion_project_api = Blueprint('passion_projects', __name__)

from routes.passion_projects.main import projects_list,add_project,edit_project,edit_team,create_team,team_list