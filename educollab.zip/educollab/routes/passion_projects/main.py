from routes.passion_projects import passion_project_api
from flask import request, Response, json
from model.User import login
import traceback
from model.passion_projects import utils
from routes.exception import InvalidUsage
from model.course import create_group_chat
from db_wrapper.fetch_functions import Fetch
from bson import ObjectId
from model import User
fetch = Fetch()


@passion_project_api.route("/passion_projects", methods=['GET'])
@login
def projects_list(role, organisation, permissions, login_user_other_details):
    """
    this api gives the list of all passion projects
    """
    try:
        user_id = login_user_other_details['_id']
        res_data, status = utils.get_project_names(user_id,organisation,role)
        return Response(json.dumps(res_data), mimetype='application/json', status=status)
    except Exception as e:
        traceback.print_exc()
        error = {"message": "internal server error", "status": 500}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])


@passion_project_api.route("/passion_projects/new", methods=['GET'])
@login
def projects_list_new(role, organisation, permissions, login_user_other_details):
    """
    this api gives the list of all passion projects
    """
    try:
        user_id = login_user_other_details['_id']
        project_id = request.args.get('project_id')
        if project_id:
            res_data, status = utils.view_project(user_id=user_id, organisation=organisation, role=role,
                                                  project_id=project_id)
        else:
            page_name = request.args.get('page_name', "published")
            res_data, status = utils.project_catalogue(
                                                        user_id,
                                                        organisation,
                                                        role,
                                                        page_name=page_name
                                                    )
        return Response(json.dumps(res_data), mimetype='application/json', status=status)
    except Exception as e:
        traceback.print_exc()
        error = {"message": "internal server error", "status": 500}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])


@passion_project_api.route("/passion_projects", methods=['POST'])
@login
def add_project(role, organisation, permissions, login_user_other_details):
    """
    this api insert new project in db
    """
    if "passion_project" not in permissions:
        error = {"message": "Permission Denied", "status": 403}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])

    user_id = login_user_other_details['_id']
    req_data = request.get_json()

    key_data_with_default_mapping_dict = {"project_title": "",
                                          "project_description": "",
                                          "project_tags": [],
                                          "project_image": "",
                                          "project_mentors": [{"id": user_id}],
                                          "project_resources": []
                                          }

    missing_keys_set = set(key_data_with_default_mapping_dict.keys()) - set(req_data.keys())
    if len(missing_keys_set) > 0:
        traceback.print_exc()
        error = {"message": "bad request({0} key missing)".format(" ,".join(missing_keys_set)), "status": 400}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])
    else:
        try:
            for key in key_data_with_default_mapping_dict.keys():
                api_key_data = req_data[key]
                if type(api_key_data) == type(key_data_with_default_mapping_dict[key]):
                    key_data_with_default_mapping_dict[key] = api_key_data
            project_mentors = [doc["id"] for doc in key_data_with_default_mapping_dict["project_mentors"]]
            user_id = login_user_other_details['_id']
            project_mentors.append(user_id)

            if len(key_data_with_default_mapping_dict["project_title"]) < 4:
                error = {"message": "Minimum length of project name should be 4", "status": 400}
                return Response(json.dumps(error), mimetype='application/json', status=error['status'])

        except KeyError:
            traceback.print_exc()
            error = {"message": "bad request({0} key missing)".format(key), "status": 400}
            return Response(json.dumps(error), mimetype='application/json', status=error['status'])

    try:
        project_mentors = utils.validate_project_mentors(project_mentors)
        key_data_with_default_mapping_dict["project_mentors"] = project_mentors
        res_data = utils.insert_project(user_id=user_id,
                                        key_data_with_default_mapping_dict=key_data_with_default_mapping_dict)
        return Response(json.dumps(res_data), mimetype='application/json', status=201)
    except InvalidUsage as e:
        error = {"message": e.message, "status": e.status_code}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])
    except Exception as e:
        traceback.print_exc()
        error = {"message": "Internal server error", "status": 500, "detail": e.__str__()}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])


@passion_project_api.route("/passion_projects", methods=['PATCH'])
@login
def edit_project(role, organisation, permissions, login_user_other_details):
    """
    this api will edit existing project in db
    """
    if "passion_project" not in permissions:
        error = {"message": "Permission Denied", "status": 403}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])
    
    try:
        req_data = request.get_json()
        id = req_data['project_id']
        title = req_data['project_title']
        image = req_data['project_image']
        description = req_data['project_description']
        tags = req_data['project_tags']
        mentors = req_data['project_mentors']
        resources = req_data['project_resources']
    except KeyError as e:
        traceback.print_exc()
        error = {"message": "bad request", "status": 400, "detail": e.__str__()}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])
    try:
        user_id = login_user_other_details['_id']
        res_data = utils.update_project(project_id=id,role=role,
                                        user_id=user_id,
                                        title=title,
                                        image_url=image,
                                        description=description,
                                        tags=tags,
                                        mentors=mentors,
                                        resources=resources)
        return Response(json.dumps(res_data), mimetype='application/json', status=200)
    except InvalidUsage as e:
        error = {"message": e.message, "status": e.status_code, "detail": e.message}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])

    except Exception as e:
        traceback.print_exc()
        error = {"message": "internal server error", "status": 500, "detail": e.__str__()}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])


@passion_project_api.route("/passion_projects", methods=['DELETE'])
@login
def delete_project(role, organisation, permissions, login_user_other_details):
    project_id = request.args.get('project_id')
    user_id = login_user_other_details['_id']
    if role != 'super_admin':
        raise InvalidUsage('You are not authorized to delete the project')
    try:
        res_data = utils.delete_project(project_id=project_id,
                                        user_id=user_id)
        data = {"message": "Successfully deleted the passion project"}
        return Response(json.dumps(data), mimetype='application/json', status=200)
    except InvalidUsage as e:
        error = {"message": e.message, "detail": e.message}
        return Response(json.dumps(error), mimetype='application/json', status=e.status_code)
    except Exception as e:
        traceback.print_exc()
        error = {"message": "internal server error", "status": 500, "detail": e.__str__()}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])


@passion_project_api.route("/passion_projects/team", methods=['GET'])
@login
def team_list(role, organisation, permissions, login_user_other_details):
    """
    This api give list of all the teams present
    """
    user_id = login_user_other_details['_id']
    project_id = request.args.get("project_id")
    team_id = request.args.get("team_id")
    try:
        if project_id:
            res_data = utils.get_teams(project_id=project_id, team_id=team_id,
                                       user_info_id=user_id)
        else:
            res_data = utils.get_teams(user_id=user_id, team_id=team_id, user_info_id=user_id)
        return Response(json.dumps(res_data), mimetype='application/json', status=200)
    except InvalidUsage as e:
        error = {"message": e.message, "status": e.status_code}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])

    except Exception as e:
        traceback.print_exc()
        error = {"message": "internal server error. Unable to fetch teams",
                 "status": 500,
                 "detail": e.__str__()}
        return Response(json.dumps(error), mimetype='application/json', status=500)


@passion_project_api.route("/passion_projects/team", methods=['POST'])
@login
def create_team(role, organisation, permissions, login_user_other_details):
    """
    This api create a new team
    """
    if role != "student":
        error = {"message": "only student is allowed to create team", "status": 403}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])
    try:
        req_data = request.get_json()
        team_name = req_data['team_name']
        team_logo = req_data['team_logo']
        team_members = req_data['team_members']
        project_id = req_data['project_id']
        original_team = req_data.get('duplicates_to')
    except KeyError as e:
        traceback.print_exc()
        error = {"message": "bad request", "status": 400, "detail": e.__str__()}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])
    try:
        user_id = login_user_other_details['_id']
        res_data = utils.insert_team(user_id=user_id,
                                     team_logo_key=team_logo,
                                     team_name=team_name,
                                     team_members=team_members,
                                     project_id=project_id,
                                     original_team=original_team)
        return Response(json.dumps(res_data), mimetype='application/json', status=201)

    except InvalidUsage as e:
        error = {"message": e.message, "status": e.status_code}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])

    except Exception as e:
        traceback.print_exc()
        error = {"message": "internal server error. Unable to add team", "detail": e.__str__(), "status": 500}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])


@passion_project_api.route("/passion_projects/team", methods=['PATCH'])
@login
def edit_team(role, organisation, permissions, login_user_other_details):
    """
    This api edit an existing team.
    """
    if role != "student":
        error = {"message": "only student is allowed to edit team", "status": 403}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])
    try:
        req_data = request.get_json()
        team_id = req_data['team_id']
        team_name = req_data['team_name']
        team_logo = req_data['team_logo']
        team_members = req_data['team_members']
        project_id = req_data['project_id']
    except KeyError:
        traceback.print_exc()
        error = {"message": "bad request", "status": 400}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])
    try:
        user_id = login_user_other_details['_id']
        res_data = utils.update_team(user_id=user_id, team_logo_url=team_logo, team_name=team_name,
                                     team_members=team_members, team_id=team_id, project_id=project_id)
        return Response(json.dumps(res_data), mimetype='application/json', status=200)

    except InvalidUsage as e:
        error = {"message": e.message, "status": e.status_code}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])

    except Exception as e:
        traceback.print_exc()
        error = {"message": "Internal server error, Please try again later.", "status": 500, "detail": e.__str__()}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])


@passion_project_api.route("/passion_projects/report", methods=['GET'])
@login
def project_reports(role, organisation, permissions, login_user_other_details):
    """
    this api gives the reports of  passion projects
    """
    user_id = login_user_other_details['_id']
    project_id = request.args.get("project_id")
    team_id = request.args.get("team_id")
    report_id = request.args.get('report_id')
    user_id = login_user_other_details['_id']
    try:
        res_data = utils.get_project_report(user_id=user_id, project_id=project_id, team_id=team_id, report_id=report_id)
        return Response(json.dumps(res_data), mimetype='application/json', status=200)

    except Exception as e:
        traceback.print_exc()
        error = {"message": "internal server error", "status": 500}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])


@passion_project_api.route("/passion_projects/report", methods=['POST'])
@login
def add_project_report(role, organisation, permissions, login_user_other_details):
    """
    this api add the report of a particular passion project
    """
    if role != "student":
        error = {"message": "only student is allowed to create report", "status": 403}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])

    try:
        req_data = request.get_json()
        project_id = req_data['project_id']
        team_id = req_data['team_id']
        title = req_data['title']
        content = req_data['content']
        tags = req_data['tags']
        code_links = req_data['code_links']
        resource_links = req_data['resource_links']
        webinar_links = req_data['webinar_links']

    except KeyError:
        traceback.print_exc()
        error = {"message": "bad request", "status": 400}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])
    try:
        user_id = login_user_other_details['_id']
        res_data = utils.insert_project_report(project_id=project_id, team_id=team_id, title=title,
                                               content=content, tags=tags, code_links=code_links,
                                               resource_links=resource_links, webinar_links=webinar_links,
                                               user_id=user_id)
        return Response(json.dumps(res_data), mimetype='application/json', status=201)

    except InvalidUsage as e:
        error = {"message": e.message, "status": e.status_code}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])

    except Exception as e:
        traceback.print_exc()
        error = {"message": "internal server error", "status": 500}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])


@passion_project_api.route("/passion_projects/report", methods=['PATCH'])
@login
def edit_project_report(role, organisation, permissions, login_user_other_details):
    """
    this api update the report of a particular passion project
    """
    if role != "student":
        error = {"message": "only student is allowed to update report", "status": 403}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])

    try:
        req_data = request.get_json()
        report_id = req_data['_id']
        project_id = req_data['project_id']
        team_id = req_data['team_id']
        title = req_data['title']
        content = req_data['content']
        tags = req_data['tags']
        code_links = req_data['code_links']
        resource_links = req_data['resource_links']
        webinar_links = req_data['webinar_links']
    except KeyError:
        traceback.print_exc()
        error = {"message": "bad request", "status": 400}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])
    try:
        user_id = login_user_other_details['_id']
        res_data = utils.update_project_report(project_id=project_id, team_id=team_id, title=title,
                                               content=content, tags=tags, code_links=code_links,
                                               resource_links=resource_links, webinar_links=webinar_links,
                                               user_id=user_id, report_id=report_id)
        return Response(json.dumps(res_data), mimetype='application/json', status=200)

    except InvalidUsage as e:
        error = {"message": e.message, "status": e.status_code}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])

    except Exception as e:
        traceback.print_exc()
        error = {"message": "internal server error", "status": 500}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])


@passion_project_api.route("/init_mentor_chat", methods=['POST'])
@login
def passion_project_chat_init(role, organisation, permissions, login_user_other_details):
    """
    this api will create a chat room for the user and passion project mentors
    """
    try:
        user_id = login_user_other_details['_id']
        data = request.get_json()
        group_name = data['group_name']
        admins = data['admins']
        group_description = data['group_description']
        subheading = data['subheading']
        resource_bank_resource_id = ""

        passion_project_id = data['passion_project_id']
        s3_key_info = fetch.access_specific_fields(collection="passion_projects",
                                                condition={"_id":ObjectId(passion_project_id)},
                                                return_keys=["project_image"])[0]["project_image"]
        check = fetch.check_existance_return_info(collection="chat_rooms", condition={"passion_project_id":ObjectId(passion_project_id),"created_by":ObjectId(user_id), "mentor_chat":True})

        if check:
            chat_info = utils.chat_room_data(condition={"_id":ObjectId(check)}, user_id=user_id)                                                                             
            return Response(json.dumps({"chat_room":chat_info}), mimetype='application/json', status=200)            
        else:
            res_data = create_group_chat(members=[user_id], 
                                        group_name='{} - {}'.format(User.User_Profile(user_id)[0]['username'], group_name),
                                        admins=admins,
                                        created_by=user_id,
                                        group_description=group_description,
                                        subheading=subheading,
                                        resource_bank_resource_id=resource_bank_resource_id,
                                        s3_key_info=s3_key_info,
                                        passion_project_id=passion_project_id)
            chat_info = utils.chat_room_data({"_id":ObjectId(res_data["_id"])}, user_id)
            return Response(json.dumps({"chat_room":chat_info}), mimetype='application/json', status=200)

    except Exception as e:
        traceback.print_exc()
        error = {"message": "internal server error", "status": 500}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])


@passion_project_api.route("/check_mentors_chat", methods=['GET'])
@login
def mentor_chat_check(role, organisation, permissions, login_user_other_details):
    """
    this api will check mentors chat
    """
    try:
        user_id = login_user_other_details['_id']
        data = request.get_json()
        passion_project_id = data['passion_project_id']
        res_data = fetch.check_existance_return_info(collection="chat_rooms", condition={"passion_project_id":ObjectId(passion_project_id),
                                                                                        "created_by":ObjectId(user_id), "mentor_chat":True})
        if res_data:
            return Response(json.dumps({"room_status":True, "room_id":str(res_data)}), mimetype='application/json', status=200)
        else:
            return Response(json.dumps({"room_status":False, "room_id":""}), mimetype='application/json', status=204)
    except Exception as e:
        traceback.print_exc()
        error = {"message": "internal server error", "status": 500}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])


@passion_project_api.route("/passion_project_proposal", methods=['GET'])
@login
def proposal_passion_project(role, organisation, permissions, login_user_other_details):
    """
    this api will get passion project proposal chats
    """
    try:
        user_id = login_user_other_details['_id']
        passion_project_id = request.args.get('passion_project_id')
        if role == "teacher" or role == "mentor" or role == "super_admin":
            res_data = fetch.access_specific_fields(collection="chat_rooms", condition={"passion_project_id":ObjectId(passion_project_id),
                                                                                        "mentor_chat":True,
                                                                                        "admins.admin_id":{"$in":[ObjectId(user_id)]}})
            out_data = []
            if res_data:
                for data in res_data:
                    out_data.append(utils.chat_room_data(condition={"_id":ObjectId(data['_id'])}, user_id=user_id))
                return Response(json.dumps({"rooms_data": out_data}), mimetype='application/json', status=200)
            else:
                return Response(json.dumps({"rooms_data":None}), mimetype='application/json', status=204)
        else:
            return Response(json.dumps({"rooms_data":None}), mimetype='application/json', status=204)
    except Exception as e:
        traceback.print_exc()
        error = {"message": "internal server error", "status": 500}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])  


@passion_project_api.route("/passion_projects/new", methods=['POST'])
@login
def add_passion_project(role, organisation, permissions, login_user_other_details):
    """
    this api insert new project in db
    """
    if "passion_project" not in permissions:
        error = {"message": "Permission Denied", "status": 403}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])

    try:
        user_id = login_user_other_details['_id']
        req_data = request.get_json()
        project_title = req_data['project_title']
        project_image  = req_data['project_image']
        project_overview = req_data['project_overview']
        project_tags  = req_data['project_tags']
        project_mentors  = req_data['project_mentors']
        project_resources  = req_data['project_resources']
        project_goals = req_data['project_goals']
        project_details = req_data['project_details']
        publish = bool(req_data['publish'])
        
    except KeyError:
            error = {"status": "Key Error"}
            return Response(json.dumps(error), mimetype='application/json', status=400) 

    try:
        project_mentors = [doc["id"] for doc in project_mentors]
        project_mentors.append(user_id)

        if len(project_title) < 4:
            error = {"message": "Minimum length of project name should be 4", "status": 400}
            return Response(json.dumps(error), mimetype='application/json', status=error['status'])

    except KeyError as key:
        traceback.print_exc()
        error = {"message": "bad request({0} key missing)".format(key), "status": 400}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])

    try:
        project_mentors = utils.validate_project_mentors(project_mentors)
        res_data = utils.insert_passion_project(user_id=user_id, project_title=project_title, project_image=project_image, project_overview=project_overview,
                                        project_tags=project_tags, project_mentors=project_mentors, project_resources=project_resources, 
                                        project_goals = project_goals, project_details=project_details, publish=publish)
                                        
        return Response(json.dumps(res_data), mimetype='application/json', status=201)
    except InvalidUsage as e:
        error = {"message": e.message, "status": e.status_code}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])
    except Exception as e:
        traceback.print_exc()
        error = {"message": "Internal server error", "status": 500, "detail": e.__str__()}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])


@passion_project_api.route("/discover_our_project", methods=['GET'])
@login
def discover_project_api(role, organisation, permissions, login_user_other_details):
    """
    this api gives the list of all top project
    """
    try:
        res_data, status = utils.discover_project()
        res_data = {'status': True, 'data': res_data, 'message': 'Successful'}
        return Response(json.dumps(res_data), mimetype='application/json', status=status)
    except InvalidUsage as e:
        data = {"status": False,
                "message": e.message,
                "data": str(e)}
        return Response(json.dumps(data), mimetype='application/json', status=e.status_code)
    except Exception as e:
        error = {"message": "Internal Server Error", "status": False, 'data': str(e)}
        return Response(json.dumps(error), mimetype='application/json', status=500)


