from flask import Blueprint

coursework_api = Blueprint('coursework', __name__)
from routes.course_work import submissions, remarks
