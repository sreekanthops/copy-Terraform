from routes.course_work import coursework_api
from model.User import login
from flask import request, Response, json
import traceback
from model.course_work_wrapper import remarks
from routes.exception import InvalidUsage
from utils.misc import is_empty


@coursework_api.route("/course-work/submission/remarks", methods=["Post"])
@login
def give_remarks_on_coursework_submissions(role, organisation, permissions, login_user_other_details):
    """
        This api gives the list of all submitted assessment of a user with status for the current month.
    """
    checker_id = login_user_other_details['_id']
    try:
        req_data = request.get_json()
        schedule_id = req_data['schedule_id']
        team_name = req_data['team_name']
        course_work_id = req_data['course_work_id']
        course_id = req_data['course_id']
        remark = req_data['feedback']
        user_id = req_data['user_id']
        submission_name = req_data['submission_name']
        submission_index = req_data['submission_index']
        grade = req_data['grade']
        peer_review = req_data.get('peer_review')
        self_review = req_data.get('self_review')
        if peer_review or self_review:
            grade = "0"
        if (is_empty(grade) and is_empty(remark)) or (not is_empty(grade) and not is_empty(remark)):
            error = {"message": "Bad Request", "detail": "Please enter either a remark or grade.", "status": 400}
            return Response(json.dumps(error), mimetype='application/json', status=error['status'])

        if not is_empty(grade):
            grade = str(int(grade))

    except (ValueError, KeyError) as e:
        traceback.print_exc()
        error = {"message": "Bad Request", "detail": e.__str__(), "status": 400}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])
    try:
        res_data = remarks.add_remark(checker_id=checker_id,
                                      schedule_id=schedule_id,
                                      team_name=team_name,
                                      course_work_id=course_work_id,
                                      course_id=course_id,
                                      remark=remark,
                                      user_id=user_id,
                                      submission_name=submission_name,
                                      submission_index=submission_index,
                                      grade=grade,
                                      role=role,
                                      peer_review_feedback=req_data['peer_review'] if peer_review else None,
                                      self_review_feedback=req_data['self_review'] if self_review else None
                                     )
        response = {"message": res_data}
        return Response(json.dumps(response), mimetype='application/json', status=201)
    except InvalidUsage as e:
        error = {"message": e.message,
                 "detail": "Could not add remark. Please try again later. Contact support if the problem persists.",
                 "status": e.status_code}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])
    except Exception as e:
        traceback.print_exc()
        error = {"message": "Internal server error", "detail": e.__str__(), "status": 500}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])
