from model.course_work_wrapper.course_work_submissions import submissions_file
from model.course_work_wrapper.submissions import get_zip_file
from routes.course_work import coursework_api
from model.User import login
from flask import request, Response, json
from flask_cors import cross_origin
import traceback
from model.course_work_wrapper import submissions
from routes.exception import InvalidUsage
from utils.misc import send_confirmation_email


@coursework_api.route("/course-work/submissions", methods=["Post"])
@login
def submit_course_work_submission(role, organisation, permissions, login_user_other_details):
    user_id = login_user_other_details['_id']
    try:
        data = request.json
        course_work_id = data['course_work_id']
        course_instance_id = data['schedule_id']
        course_id = data['course_id']
        file_id = data['file_id']
        report_name = data['report_name']
        report_index = data['report_index']
        team_name = data['team_name']

        check = data.get('autograding_id')
        if check:
            autograding_id = data['autograding_id']
        else:
            autograding_id = ''

    except KeyError as e:
        traceback.print_exc()
        data = {"status": 400, "message": "Please check request data.", "detail": e.__str__()}
        return Response(json.dumps(data), mimetype='application/json', status=400)
    try:
        response_url, message = submissions.submit_report(
            user_id=user_id,
            course_work_id=course_work_id,
            course_id=course_id,
            course_instance_id=course_instance_id,
            file_id=file_id,
            report_name=report_name,
            report_index=report_index,
            team_name=team_name,
            autograding_id = autograding_id)
        send_email = send_confirmation_email(login_user_other_details=login_user_other_details,
                                             report_name=report_name, template_path="report_submission",
                                             subject="Report Submission")
        send_email = submissions.send_email_to_ta(course_id=course_id, user_id=user_id, course_work_id=course_work_id, course_instance_id=course_instance_id)
        if send_email:
            response_message = {"message": "Report successfully submitted.", "response": response_url}
            return Response(json.dumps(response_message), mimetype='application/json', status=200)
        response_message = {"message": message, "response": response_url}
        return Response(json.dumps(response_message), mimetype='application/json', status=200)
    except InvalidUsage as e:
        traceback.print_exc()
        data = {"detail": e.message,
                "message": e.message,
                "status": e.status_code}
        return Response(json.dumps(data), mimetype='application/json', status=e.status_code)
    except Exception as e:
        traceback.print_exc()
        data = {"detail": e.__str__(), "message": "Internal server error, Please try again later."}
        return Response(json.dumps(data), mimetype='application/json', status=500)


@coursework_api.route("/course-work/submissions", methods=["Delete"])
@login
def delete_course_work_submission(role, organisation, permissions, login_user_other_details):
    user_id = login_user_other_details['_id']
    try:
        data = request.json
        course_work_id = data['course_work_id']
        course_instance_id = data['schedule_id']
        course_id = data['course_id']
        file_detail = data['file_info']
        report_name = data['report_name']
        report_index = data['report_index']
        team_name = data['team_name']
        message = submissions.delete_report(
            user_id=user_id,
            course_work_id=course_work_id,
            course_id=course_id,
            course_instance_id=course_instance_id,
            file_detail=file_detail,
            report_name=report_name,
            report_index=report_index,
            team_name=team_name)
        response_message = {"message": message}
        return Response(json.dumps(response_message), mimetype='application/json', status=200)
    except InvalidUsage as e:
        traceback.print_exc()
        data = {"detail": e.message,
                "message": e.message,
                "status": e.status_code}
        return Response(json.dumps(data), mimetype='application/json', status=e.status_code)
    except Exception as e:
        traceback.print_exc()
        data = {"detail": e.__str__(), "message": "Internal server error, Please try again later."}
        return Response(json.dumps(data), mimetype='application/json', status=500)


@coursework_api.route("/course-work/submissions/new", methods=["Get"])
@login
def course_work_submissions_view_new(role, organisation, permissions, login_user_other_details):
    """Api to fetch all the submission related to a particular course work instance."""
    user_id = login_user_other_details['_id']
    try:
        course_work_id = request.args['course_work_id']
        course_instance_id = request.args['schedule_id']
        course_id = request.args['course_id']
        team_name = request.args['team_name']
        peer_review = request.args['peer_review']
        self_review = request.args['self_review']
        try:
            grade_view = request.args['grade_view']
        except:
            grade_view = 'false'
        try:
            expand_view = request.args['expand_view']
        except:
            expand_view = 'false'
        response_data, submission_publish = submissions.get_submissions_new(user_id=user_id,
                                                                            role=role,
                                                                            course_id=course_id,
                                                                            course_instance_id=course_instance_id,
                                                                            course_work_id=course_work_id,
                                                                            team_name=team_name,
                                                                            peer_review=peer_review,
                                                                            self_review=self_review,
                                                                            grade_view=grade_view,
                                                                            expand_view=expand_view)

        message = "There are no submissions." if not response_data else "Data retrieved successfully."
        response = {"response": response_data, "message": message, "submission_publish": submission_publish}
        return Response(json.dumps(response), mimetype='application/json', status=200)
    except InvalidUsage as e:
        traceback.print_exc()
        data = {"detail": e.message,
                "message": e.message,
                "status": e.status_code}
        return Response(json.dumps(data), mimetype='application/json', status=500)
    except Exception as e:
        traceback.print_exc()
        data = {"detail": e.__str__(), "message": "Internal server error, Please try again later."}
        return Response(json.dumps(data), mimetype='application/json', status=500)


@coursework_api.route("/course-work/submissions", methods=["Get"])
@login
def course_work_submissions_view(role, organisation, permissions, login_user_other_details):
    """Api to fetch all the submission related to a particular course work instance."""
    user_id = login_user_other_details['_id']
    try:
        course_work_id = request.args['course_work_id']
        course_instance_id = request.args['schedule_id']
        course_id = request.args['course_id']
        team_name = request.args['team_name']
        peer_review = request.args['peer_review']
        self_review = request.args['self_review']
        try:
            grade_view = request.args['grade_view']
        except:
            grade_view = 'false'
        try:
            expand_view = request.args['expand_view']
        except:
            expand_view = 'false'
        response_data, submission_publish = submissions.get_submissions(user_id=user_id,
                                                                        role=role,
                                                                        course_id=course_id,
                                                                        course_instance_id=course_instance_id,
                                                                        course_work_id=course_work_id,
                                                                        team_name=team_name,
                                                                        peer_review=peer_review,
                                                                        self_review=self_review,
                                                                        grade_view=grade_view,
                                                                        expand_view=expand_view)

        message = "There are no submissions." if not response_data else "Data retrieved successfully."
        response = {"response": response_data, "message": message, "submission_publish": submission_publish}
        return Response(json.dumps(response), mimetype='application/json', status=200)
    except InvalidUsage as e:
        traceback.print_exc()
        data = {"detail": e.message,
                "message": e.message,
                "status": e.status_code}
        return Response(json.dumps(data), mimetype='application/json', status=500)
    except Exception as e:
        traceback.print_exc()
        data = {"detail": e.__str__(), "message": "Internal server error, Please try again later."}
        return Response(json.dumps(data), mimetype='application/json', status=500)


@coursework_api.route("/course-work/submissions/files", methods=["Delete"])
@login
def delete_course_work_submission_file(role, organisation, permissions, login_user_other_details):
    user_id = login_user_other_details['_id']
    try:
        course_work_id = request.args['course_work_id']
        course_instance_id = request.args['schedule_id']
        course_id = request.args['course_id']
        file_id = request.args['file_id']
        report_name = request.args['report_name']
        report_index = request.args['report_index']
        team_name = request.args['team_name']
        message = submissions_file.delete_submission_file(
            user_id=user_id,
            course_work_id=course_work_id,
            course_id=course_id,
            course_instance_id=course_instance_id,
            file_id=file_id,
            report_name=report_name,
            report_index=report_index,
            team_name=team_name)
        response_message = {"message": message}
        return Response(json.dumps(response_message), mimetype='application/json', status=200)
    except InvalidUsage as e:
        traceback.print_exc()
        data = {"detail": e.message,
                "message": e.message,
                "status": e.status_code}
        return Response(json.dumps(data), mimetype='application/json', status=e.status_code)
    except Exception as e:
        traceback.print_exc()
        data = {"detail": e.__str__(), "message": "Internal server error, Please try again later."}
        return Response(json.dumps(data), mimetype='application/json', status=500)


@coursework_api.route("/course-work/submission/publish", methods=["POST"])
@cross_origin()
@login
def publish_course_work_submission(role, organisation, permissions, login_user_other_details):
    user_id = login_user_other_details['_id']
    try:
        data = request.json
        course_work_id = data['course_work_id']
        course_instance_id = data['schedule_id']
        course_id = data['course_id']
    except KeyError as e:
        traceback.print_exc()
        data = {"status": 400, "message": "Please check request data.", "detail": e.__str__()}
        return Response(json.dumps(data), mimetype='application/json', status=400)
    try:
        response_data = submissions.submission_publish(user_id=user_id,
                                                       role=role,
                                                       course_id=course_id,
                                                       course_instance_id=course_instance_id,
                                                       course_work_id=course_work_id)
        return Response(json.dumps(response_data), mimetype='application/json', status=200)
    except InvalidUsage as e:
        traceback.print_exc()
        data = {"detail": e.message,
                "message": e.message,
                "status": e.status_code}
        return Response(json.dumps(data), mimetype='application/json', status=e.status_code)
    except Exception as e:
        traceback.print_exc()
        data = {"detail": e.__str__(), "message": "Internal server error, Please try again later."}
        return Response(json.dumps(data), mimetype='application/json', status=500)


@coursework_api.route('/course-work/submission/zip', methods=['POST'])
@login
def get_submission_zip(role, organisation, permissions, login_user_other_details):
    current_user = login_user_other_details['_id']
    try:
        data = request.get_json()
        course_work_id = data['course_work_id']
        course_instance_id = data['schedule_id']
        user_id = data['user_id']
        if data.get('team_name'):
            team_name = data['team_name']
        else:
            team_name = ""
        if data.get('generate_mobile_link'):
            gen_mobile_link = data['generate_mobile_link']
        else:
            gen_mobile_link = False
        response = get_zip_file(course_work_id=course_work_id,
                                course_instance_id=course_instance_id,
                                user_id=user_id,
                                team_name=team_name,
                                gen_mobile_link= gen_mobile_link)
        if gen_mobile_link:
            return Response(json.dumps(response), mimetype='application/json', status=200)
        else:
            return Response(response, mimetype='application/zip', direct_passthrough=True,
                            headers={'Content-Disposition': 'attachment;filename=zones.zip'}, status=200)
    except InvalidUsage as e:
        traceback.print_exc()
        data = {"detail": e.message,
                "message": e.message,
                "status": e.status_code}
        return Response(json.dumps(data), mimetype='application/json', status=e.status_code)
    except Exception as e:
        traceback.print_exc()
        data = {"detail": e.__str__(), "message": "Internal server error, Please try again later."}
        return Response(json.dumps(data), mimetype='application/json', status=500)
