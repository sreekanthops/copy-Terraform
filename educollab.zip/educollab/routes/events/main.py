from routes.events import events_api
from model.User import login
from flask import request, Response, json
import traceback
from routes.exception import InvalidUsage
from utils.misc import is_empty
from model.events import utils


@events_api.route("/events", methods=["GET"])
@login
def retrieve_events(role, organisation, permissions, login_user_other_details):
    """
    This api gives the list of all system generated events.
    Events: course work submissions, calendered assessments, live sessions on courses.
    """
    user_id = login_user_other_details['_id']
    try:
        from_date = request.args['from_date']
        to_date = request.args['to_date']
    except (ValueError, KeyError) as e:
        traceback.print_exc()
        error = {"message": "Bad Request", "detail": e.__str__(), "status": 400}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])
    try:
        if is_empty(from_date) and is_empty(to_date):
            raise InvalidUsage("Bad Request", 400)
        systems_events = utils.system_events(user_id=user_id,
                                            from_date=from_date,
                                            to_date=to_date)
        course_ids, systems_events = utils.get_event_details(systems_events=systems_events, role = role, organisation=organisation,user_id=user_id)
        response = {"system_events": systems_events}
        return Response(json.dumps(response), mimetype='application/json', status=200)
    except InvalidUsage as e:
        error = {"message": "Please try again later. Contact support if the problem persists.",
                 "detail": e.message,
                 "status": e.status_code}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])
    except Exception as e:
        traceback.print_exc()
        error = {"message": "Internal server error", "detail": e.__str__(), "status": 500}
        return Response(json.dumps(error), mimetype='application/json', status=error['status'])
