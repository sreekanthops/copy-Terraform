import flask
from flask import request, Response, json, Blueprint, jsonify
from model.User import login
from model.chat import chat
from routes.exception import InvalidUsage
import traceback


chat_apis = Blueprint("chat_api", __name__)


@chat_apis.route('/chat/notification/mute', methods=['Patch'])
@login
def mute_chat_notification_api(role, organisation, permissions, login_user_other_details):
    """
        Api used to mute or unmute chat notification
    """
    user_id = login_user_other_details['_id']
    try:
        mute = request.args['mute']
        if mute == "true":
            mute = True
        elif mute == "false":
            mute = False
    except KeyError as e:
        traceback.print_exc()
        data = {"status": 400, "message": "Please check request data.", "detail": e.__str__()}
        return Response(json.dumps(data), mimetype='application/json', status=400)
    try:
        response = chat.mute_chat_notification(mute=mute, user_id=user_id)
        return Response(json.dumps(response), mimetype='application/json', status=200)
    except InvalidUsage as e:
        traceback.print_exc()
        data = {"detail": e.message,
                "message": e.message,
                "status": e.status_code}
        return Response(json.dumps(data), mimetype='application/json', status=e.status_code)
    except Exception as e:
        traceback.print_exc()
        data = {"status": 500, "message": "Internal Server Error", "detail": e.__str__()}
        return Response(json.dumps(data), mimetype='application/json', status=500)


@chat_apis.route('/chat/user/block', methods=['Patch'])
@login
def block_user_api(role, organisation, permissions, login_user_other_details):
    """
        Api used to block or unblock user
    """
    user_id = login_user_other_details['_id']
    try:
        block = request.args['block']
        target_user_id =  request.args['user_id']
        if block == "true":
            block = True
        elif block == "false":
            block = False
    except KeyError as e:
        traceback.print_exc()
        data = {"status": 400, "message": "Please check request data.", "detail": e.__str__()}
        return Response(json.dumps(data), mimetype='application/json', status=400)
    try:
        response = chat.block_user(block=block, user_id=user_id, target_user_id=target_user_id, )
        return Response(json.dumps(response), mimetype='application/json', status=200)
    except InvalidUsage as e:
        traceback.print_exc()
        data = {"detail": e.message,
                "message": e.message,
                "status": e.status_code}
        return Response(json.dumps(data), mimetype='application/json', status=e.status_code)
    except Exception as e:
        traceback.print_exc()
        data = {"status": 500, "message": "Internal Server Error", "detail": e.__str__()}
        return Response(json.dumps(data), mimetype='application/json', status=500)


@chat_apis.route('/chat/user/report', methods=['Patch'])
@login
def report_user_api(role, organisation, permissions, login_user_other_details):
    """
        Api used to report user
    """
    user_id = login_user_other_details['_id']
    try:
        target_user_id =  request.args['user_id']
        message = request.args['report_reason']
    except KeyError as e:
        traceback.print_exc()
        data = {"status": 400, "message": "Please check request data.", "detail": e.__str__()}
        return Response(json.dumps(data), mimetype='application/json', status=400)
    try:
        response = chat.report_user(user_id=user_id,
                                    target_user_id=target_user_id,
                                    reported_by_username=login_user_other_details['username'],
                                    reported_by_email=login_user_other_details['email'],
                                    message=message)
        return Response(json.dumps(response), mimetype='application/json', status=200)
    except InvalidUsage as e:
        traceback.print_exc()
        data = {"detail": e.message,
                "message": e.message,
                "status": e.status_code}
        return Response(json.dumps(data), mimetype='application/json', status=e.status_code)
    except Exception as e:
        traceback.print_exc()
        data = {"status": 500, "message": "Internal Server Error", "detail": e.__str__()}
        return Response(json.dumps(data), mimetype='application/json', status=500)
