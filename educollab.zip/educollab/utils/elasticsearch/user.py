import json
import traceback

from config import DEFAULT_AVATAR, ES_USER_PROFILE_INDEX, es


def index_profile_data(id, first_name, last_name, organisation_name, username, institute_type, role,
                       avatar=DEFAULT_AVATAR):
    """
    This function will take input from mongo document and ingest to Elastic search
    Following user data points will be ingested to Elastic search
    :param id:
    :param first_name:
    :param last_name:
    :param organisation_name:
    :param username:
    :param institute_type:
    :param role:
    :param avatar:
    :return:
    """
    try:
        body = {}
        body['id'] = id
        body['name'] = str(first_name) + " " + str(last_name)
        body['name_suggest'] = body['name'].split()
        body['name_suggest'].append(str(username))
        body['username'] = str(username)
        body['username_suggest'] = str(username)
        body['role_name_suggest'] = body['name_suggest']
        body['institute_name_suggest'] = body['name_suggest']
        body['institute_type_name_suggest'] = body['name_suggest']
        body['role'] = str(role)
        body['organisation_name'] = str(organisation_name)
        body['institute_type'] = str(institute_type)
        body['avatar'] = str(avatar)

        res = es.index(index=ES_USER_PROFILE_INDEX, body=body, id=id)
        return json.dumps(res), 200
    except Exception as e:
        print('exception logged', e)
        return str(e), 500


def check_filter(filters, result):
    for each_filter in filters:
        if result[each_filter] not in filters[each_filter]:
            return False
    return True


def search_user(data, filter_dict, search_on):
    """
    Get user results based on input query
    :param data:
    :param filter:
    :param value:
    :return:
    """
    baseQuery = {
        "suggest": {
            "user-suggest": {
                "prefix": None,
                "completion": {
                    "field": "name_suggest",
                    "size": 100

                }
            }
        }
    }
    baseQuery["suggest"]["user-suggest"]["prefix"] = "{}*".format(data)

    count_keys = len(filter_dict)
    if count_keys == 1:
        value = filter_dict[list(filter_dict.keys())[0]]
        single_filter = list(filter_dict.keys())[0]
        filter_combinations = {"role": "role_name_suggest", "institute_type": "institute_type_name_suggest",
                               "organisation_name": "institute_name_suggest"}
        baseQuery["suggest"]["user-suggest"]["completion"]["field"] = "{}".format(filter_combinations[single_filter])
        baseQuery["suggest"]["user-suggest"]["completion"]["contexts"] = {single_filter: value}
    response = es.search(index=ES_USER_PROFILE_INDEX, size=0, body=baseQuery)
    res = []
    for i in range(len(response["suggest"]["user-suggest"][0]["options"])):
        if count_keys > 1:
            if not check_filter(filters=filter_dict,
                                result=response["suggest"]["user-suggest"][0]["options"][i]["_source"]):
                continue
        if search_on != "0":
            if search_on == "username":
                if not str(response["suggest"]["user-suggest"][0]["options"][i]["_source"][search_on]).startswith(data):
                    continue
            else:
                if (str(response["suggest"]["user-suggest"][0]["options"][i]["_source"][search_on]).find(data) == -1):
                    continue

        response_dict = {
            "id": response["suggest"]["user-suggest"][0]["options"][i]["_source"]["id"],
            "name": response["suggest"]["user-suggest"][0]["options"][i]["_source"]["name"],
            "username": response["suggest"]["user-suggest"][0]["options"][i]["_source"]["username"],
            "role": response["suggest"]["user-suggest"][0]["options"][i]["_source"]["role"],
            "organisation_name": response["suggest"]["user-suggest"][0]["options"][i]["_source"]["organisation_name"],
            "institute_type": response["suggest"]["user-suggest"][0]["options"][i]["_source"]["institute_type"],
            "avatar": response["suggest"]["user-suggest"][0]["options"][i]["_source"]["avatar"]
        }

        res.append(response_dict)

    return res


def update_user_profile_index(_id, first_name=None, last_name=None, username=None, role=None, organisation=None,
                              institute_type=None, avatar=DEFAULT_AVATAR, super_admin_edit=False):
    """
    :param _id:
    :param first_name:
    :param last_name:
    :param username:
    :param role:
    :param organisation:
    :param institute_type:
    :param avatar:
    :param super_admin_edit:
    :return:
    """
    body = dict()
    body['id'] = _id

    if not super_admin_edit:
        body['name'] = str(first_name) + " " + str(last_name)
        body['name_suggest'] = body['name'].split()
        body['name_suggest'].append(str(username))
        body['username'] = str(username)
        body['username_suggest'] = str(username)
        body['role_name_suggest'] = body['name_suggest']
        body['institute_name_suggest'] = body['name_suggest']
        body['institute_type_name_suggest'] = body['name_suggest']
        body['avatar'] = str(avatar)
    else:
        body['role'] = str(role)
        if organisation:
            body['organisation_name'] = str(organisation)
        body['institute_type'] = str(institute_type)
    try:
        res = es.update(index=ES_USER_PROFILE_INDEX, body={"doc": body}, id=_id)
        if res['_shards']['failed']:
            raise Exception("Error in updating elasticsearch")
    except Exception as e:
        print(e)
