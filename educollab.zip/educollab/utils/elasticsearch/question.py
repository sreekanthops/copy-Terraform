from bson import ObjectId

from db_wrapper.tasks import Mongo
from config import es
from bs4 import BeautifulSoup
from model.general import get_img_in_question
import traceback
from config import ES_QUESTION_INDEX
from db_wrapper.fetch_functions import Fetch
fetch = Fetch()
mongo_session = Mongo()


def index_question(question_dict):
    """
    This function will take input from mongo document and ingest to Elastic search
    1. question data is being ingested to Elastic search.
    2. question and tags are stored in a tokenize format so that document
        can be searched using both question or tags.
    """
    try:
        tags_collection = mongo_session.get_all_data("question_tags")['message']
        tags_dict = dict(map(lambda x: (x['_id'], x['tag']), tags_collection))
        tags_collection_global = mongo_session.get_all_data("global_tags")['message']
        tags_dict_global = dict(map(lambda x: (str(x['_id']), x['tag']), tags_collection_global))
        id = str(question_dict['_id'])
        body = {
            'question': question_dict['question'],
            'filtered_question': question_dict['filtered_question'],
            'org': question_dict['organisation'],
            'duration': question_dict['duration'],
            'complexity': str(question_dict['complexity']),
            'questype': str(question_dict['questype']),
            'user_id': str(question_dict['user_id']),
            'course_id': str(question_dict['course_id']),
            'in_import_table': question_dict['in_import_table'],
            'in_assessment': question_dict['in_assessment'],
            'tags': [],
            'marks': question_dict.get('marks',1)
        }
        question_tag = question_dict['filtered_question']
        for t in question_dict['tags']:
            if str(t) in tags_dict.keys():
                body['tags'].append(str(t))
                question_tag += (" " + tags_dict[str(t)])
            elif str(t) in tags_dict_global.keys():
                body['tags'].append(str(t))
                question_tag += (" " + tags_dict_global[str(t)])
        tokenize_question = []
        question_tag_arr = question_tag.split(" ")
        for i in reversed(question_tag_arr):
            if not tokenize_question:
                tokenize_question.append(i)
            else:
                ele = i + " " + tokenize_question[-1]
                tokenize_question.append(ele)
        tokenize_question = tokenize_question[::-1]

        body['question_tag'] = tokenize_question

        if "meta_data" in question_dict.keys():
            body['meta_data'] = question_dict['meta_data']
        if "sub_qus" in question_dict.keys():
            body['sub_qus'] = question_dict['sub_qus']

        res = es.index(index=ES_QUESTION_INDEX, body=body, id=id)
        if res['result'] == 'created' or res['result'] == 'updated':
            return True
        else:
            return False

    except Exception as e:
        traceback.print_exc()
        return False


def search_question(question_tag, organisation):
    """
    Search question documents within a particular organisation
    for a particular question or tag input given
    """
    tags_collection = mongo_session.get_all_data("question_tags")['message']
    tags_dict = dict(map(lambda x: (str(x['_id']), x['tag']), tags_collection))

    tags_collection_global = mongo_session.get_all_data("global_tags")['message']
    tags_dict_global = dict(map(lambda x: (str(x['_id']), x['tag']), tags_collection_global))

    type_collection = mongo_session.get_all_data("question_type")['message']
    type_dict = dict(map(lambda x: (str(x['_id']), x['name']), type_collection))

    complexity_collection = mongo_session.get_all_data("question_complexity")['message']
    complexity_dict = dict(map(lambda x: (str(x['_id']), x['name']), complexity_collection))

    b = {
        "suggest": {
            "suggest_questions": {
                "prefix": question_tag,
                "completion": {
                    "field": "question_tag",
                    "fuzzy": {
                        "fuzziness": 1
                    },
                    "contexts": {
                        "org": [organisation]
                    },
                    "size": 500
                }
            }
        }
    }
    res = es.search(index=ES_QUESTION_INDEX, body=b)

    options = res['suggest']['suggest_questions'][0]['options']

    res_data = []
    for doc in options:
        try:
            if fetch.check_existance_return_info(collection="add_questions", condition={"_id": ObjectId(doc['_id'])}) or \
                    fetch.check_existance_return_info(collection="question_bank", condition={"_id": ObjectId(doc['_id'])}):
                # fetching image urls present in question text
                specific_data_add_ques = mongo_session.access_specific_fields(collection='add_questions',
                                                    condition={"_id": ObjectId(doc['_id'])})
                image_urls_question = get_img_in_question(doc['_source']['question'])
                if image_urls_question:
                    bs_question = BeautifulSoup(doc['_source']['question'])
                    for img, url in zip(bs_question.findAll('img'), image_urls_question):
                        img['src'] = url
                        print(url)
                    doc['_source']['question'] = str(bs_question)

                if type_dict[str(doc['_source']['questype'])] == "Comprehension":
                    # fetching image urls present in sub_question
                    for ques in doc['_source']['sub_qus']:
                        image_urls_sub_qus = get_img_in_question(ques['question'])
                        if image_urls_sub_qus:
                            bs_sub_question = BeautifulSoup(ques['question'])
                            for img, url in zip(bs_sub_question.findAll('img'), image_urls_sub_qus):
                                img['src'] = url
                            ques['question'] = str(bs_sub_question)

                        for data in ques['meta_data']:
                            image_urls_option = get_img_in_question(data['option'])
                            if image_urls_option:
                                bs_option = BeautifulSoup(data['option'])
                                for img, url in zip(bs_option.findAll('img'), image_urls_option):
                                    img['src'] = url
                                data['option'] = str(bs_option)
                else:
                    # fetching image urls present in meta_data
                    for data in doc['_source']['meta_data']:
                        if type_dict[str(doc['_source']['questype'])] == "Text":
                            if isinstance(data['answer'], bool):
                                data['answer'] = str(data['answer'])
                            image_urls_option = get_img_in_question(data['answer'])
                            if image_urls_option:
                                bs_option = BeautifulSoup(data['answer'])
                                for img, url in zip(bs_option.findAll('img'), image_urls_option):
                                    img['src'] = url
                                data['answer'] = str(bs_option)
                        else:
                            if data.get('option'):
                                image_urls_option = get_img_in_question(data['option'])
                                if image_urls_option:
                                    bs_option = BeautifulSoup(data['option'])
                                    for img, url in zip(bs_option.findAll('img'), image_urls_option):
                                        img['src'] = url
                                    data['option'] = str(bs_option)
                question_obj = {
                    '_id': doc['_id'],
                    'question': doc['_source']['question'],
                    'filtered_question': doc['_source']['filtered_question'],
                    'org': doc['_source']['org'],
                    'duration': doc['_source']['duration'],
                    'user_id': doc['_source']['user_id'],
                    'course_id': doc['_source']['course_id'],
                    'in_assessment': doc['_source']['in_assessment'],
                    'in_import_table': doc['_source']['in_import_table'],
                    'tags': [],
                    'marks': specific_data_add_ques[0].get('marks',1)
                }
                if type_dict[str(doc['_source']['questype'])] == "Comprehension":
                    question_obj['sub_qus'] = doc['_source']['sub_qus']
                else:
                    question_obj['meta_data'] = doc['_source']['meta_data']
                for t in doc['_source']['tags']:
                        tag_obj = {
                            '_id': str(t),
                            'tag': tags_dict[str(t)] if tags_dict.get(str(t)) else tags_dict_global[str(t)]
                        }
                        question_obj['tags'].append(tag_obj)

                type_obj = {
                    '_id': str(doc['_source']['questype']),
                    'type': type_dict[str(doc['_source']['questype'])]
                }
                question_obj['questype'] = type_obj
                complexity_obj = {
                    '_id': str(doc['_source']['complexity']),
                    'complexity': complexity_dict[str(doc['_source']['complexity'])]
                }
                question_obj['complexity'] = complexity_obj
                res_data.append(question_obj)
        except:
            pass
    return res_data






