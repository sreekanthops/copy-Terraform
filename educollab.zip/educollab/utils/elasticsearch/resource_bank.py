import traceback

import bson
from bson import ObjectId

from config import es, ES_RESOURCE_BANK_INDEX
from db_wrapper.connection import mongo_session
from db_wrapper.tasks import Mongo
from model.User import User_Profile
from services.storage.s3_services import s3_storage

s3_function = s3_storage()

fetch_session = Mongo()


def search_resources(data, user_id, role, filetype=None):

    if filetype:
        body = {
            "query": {
                "regexp": {
                    "created_by": None
                }
            },
            "suggest": {
                "resource-suggest": {
                    "prefix": None,
                    "completion": {
                        "field": "title_tag_context",
                        "size": 100,
                        "contexts": {
                            "file_type": filetype
                        }
                    }
                }
            }
        }
    else:
        body = {
            "query": {
                "regexp": {
                    "created_by": None
                }
            },
            "suggest": {
                "resource-suggest": {
                    "prefix": None,
                    "completion": {
                        "field": "title_tag",
                        "size": 100
                    }
                }
            }
        }

    body["suggest"]["resource-suggest"]["prefix"] = "{}*".format(data)
    body["query"]["regexp"]["created_by"] = "{}.*".format(data)
    tags_collection = fetch_session.get_all_data("question_tags")['message']
    tags_collection_global = fetch_session.get_all_data("global_tags")['message']
    tags_collection.extend(tags_collection_global)
    tags_dict = dict(map(lambda x: (str(x['_id']), x['tag']), tags_collection))
    response = es.search(index=ES_RESOURCE_BANK_INDEX, body=body)
    all_options = response["suggest"]["resource-suggest"][0]["options"]
    all_options.extend(response['hits']['hits'])
    res = []
    for i in range(len(all_options)):
        s3_url, status_code = s3_function.generate_presigned_url_from_s3(all_options[i]['_source']['s3_path'])
        edit_rights = False
        delete_rights = False
        if all_options[i]['_source']['created_by'] == user_id or role == 'super_admin':
            edit_rights = True
            delete_rights = True

        if bson.objectid.ObjectId.is_valid(all_options[i]['_source']['created_by']):
            created_by = User_Profile(all_options[i]['_source']['created_by'])[0]['username']
        else:
            created_by = all_options[i]['_source']['created_by']

        response_body = {
            "id": all_options[i]['_source']['id'],
            "title": all_options[i]['_source']['title'],
            "description": all_options[i]['_source']['description'],
            "tags": [],
            "url": s3_url,
            "created_by": created_by,
            "created_at": all_options[i]['_source']['created_at'],
            "edit_rights": edit_rights,
            "delete_rights": delete_rights,
            "type": all_options[i]['_source']['file_type']
        }
        for t in all_options[i]['_source']['tags']:
                tag_obj = {
                    '_id': str(t),
                    'tag': tags_dict[str(t)]
                }
                response_body['tags'].append(tag_obj)
        res.append(response_body)
        check_resource = fetch_session.access_specific_fields(
            collection='resource_bank_instance',
            condition={'resource_id': ObjectId(response_body['id']),
                       'used_at': {'$ne': ""}})
        response_body['history'] = []
        check_url = fetch_session.check_existance_return_info(collection='global_resource_bank',
                                                              condition={'_id': ObjectId(response_body['id'])},
                                                              return_keys=['s3_key'])
        if check_url:
            response_body['url'], status = s3_function.generate_presigned_url_from_s3(check_url['s3_key'])
        if check_resource:
            for use in check_resource:
                used_at = use['used_at']
                if used_at.get('session_id'):
                    find_topic = fetch_session.check_existance_return_info(collection='course_topics',
                                                                           condition={
                                                                               'sessions._id': ObjectId(
                                                                                   used_at['session_id'])
                                                                           },
                                                                           return_keys=['_id', 'title'])
                    find_course = ""
                    user = ""
                    if find_topic:
                        find_course = fetch_session.check_existance_return_info(collection='courses_bank',
                                                                                condition={
                                                                                    'topics._id': ObjectId(
                                                                                        find_topic['_id'])
                                                                                },
                                                                                return_keys=['_id', 'subject'])
                        user = User_Profile(str(use['updated_by']))[0]['username'] if find_course else ""
                    response_body['history'].append({
                        'session_title': use['title'],
                        'topic_title': find_topic['title'] if find_topic else "",
                        'course_title': find_course['subject'] if find_course else "",
                        'created_by': user if user else "",
                        'level_type': 'session_level',
                        'course_work': ''})
                if used_at.get('course_id'):
                    find_course = fetch_session.check_existance_return_info(collection='courses_bank',
                                                                            condition={
                                                                                '_id': ObjectId(
                                                                                    used_at['course_id'])
                                                                            },
                                                                            return_keys=['_id', 'subject'])
                    user = User_Profile(str(use['updated_by']))[0]['username'] if find_course else ""
                    response_body['history'].append({
                        'session_title': "",
                        'topic_title': "",
                        'course_title': find_course['subject'] if find_course else "",
                        'created_by': user if user else "",
                        'level_type': 'course_level',
                        'course_work': ''})
                if used_at.get('topic_id'):
                    find_topic_title = fetch_session.check_existance_return_info(collection='course_topics',
                                                                                 condition={
                                                                                     '_id': ObjectId(
                                                                                         used_at['topic_id'])
                                                                                 },
                                                                                 return_keys=['title'])
                    find_course = fetch_session.check_existance_return_info(collection='courses_bank',
                                                                            condition={
                                                                                'topics._id': ObjectId(
                                                                                    used_at['topic_id'])
                                                                            },
                                                                            return_keys=['_id', 'subject'])
                    user = User_Profile(str(use['updated_by']))[0]['username'] if find_course else ""
                    response_body['history'].append({
                        'session_title': "",
                        'topic_title': find_topic_title['title'],
                        'course_title': find_course['subject'] if find_course else "",
                        'created_by': user if user else "",
                        'level_type': 'topic_level',
                        'course_work': ''})
                if used_at.get('course_work_id'):
                    find_topic = fetch_session.check_existance_return_info(collection='course_topics',
                                                                           condition={
                                                                               'course_work._id': ObjectId(
                                                                                   used_at['course_work_id'])
                                                                           },
                                                                           return_keys=['_id', 'title'])
                    find_course = fetch_session.check_existance_return_info(collection='courses_bank',
                                                                            condition={
                                                                                'course_work._id': ObjectId(
                                                                                    used_at['course_work_id'])
                                                                            },
                                                                            return_keys=['_id', 'subject'
                                                                                         ])
                    course_work_subject = fetch_session.access_specific_fields(collection="course_work_bank",
                                                                               condition={'_id': ObjectId(
                                                                                   used_at['course_work_id'])},
                                                                               return_keys=['courseWorkTitle'])[0][
                        'courseWorkTitle']
                    user = User_Profile(str(use['updated_by']))[0]['username'] if find_course else ""
                    if find_topic:
                        find_course_t = fetch_session.check_existance_return_info(collection='courses_bank',
                                                                                  condition={
                                                                                      'topics._id': ObjectId(
                                                                                          find_topic['_id'])
                                                                                  },
                                                                                  return_keys=['_id',
                                                                                               'subject'])
                        user = User_Profile(str(use['updated_by']))[0]['username'] if find_course else ""
                        response_body['history'].append({
                            'session_title': "",
                            'topic_title': find_topic['title'] if find_topic else "",
                            'course_title': find_course_t[
                                'subject'] if find_course_t else "",
                            'created_by': user if user else "",
                            'level_type': 'topic_level',
                            'course_work': course_work_subject
                        })
                    if find_course:
                        response_body['history'].append({
                            'session_title': "",
                            'topic_title': "",
                            'course_title': find_course['subject'] if find_course else "",
                            'created_by': user if user else "",
                            'level_type': 'course_level',
                            'course_work': course_work_subject})
                    if not find_topic and not find_course:
                        response_body['history'].append({
                            'session_title': "",
                            'topic_title': "",
                            'course_title': '',
                            'created_by': user if user else "",
                            'level_type': '',
                            'course_work': course_work_subject})
                if used_at.get('passion_project_id'):
                    find_pp = fetch_session.check_existance_return_info(collection='passion_projects',
                                                                        condition={
                                                                            '_id': ObjectId(
                                                                                used_at['passion_project_id'])
                                                                        },
                                                                        return_keys=['project_title'])
                    user = ""
                    if find_pp:
                        user = User_Profile(str(use['updated_by']))[0]['username'] if find_pp else ""
                    response_body['history'].append({
                        'session_title': "",
                        'topic_title': "",
                        'course_title': "",
                        'created_by': user if user else "",
                        'level_type': 'passion_project_level',
                        'course_work': '',
                        'passion_project_title': find_pp['project_title'] if find_pp else ""
                    })

        elif check_resource is None:
            course_bank_find = fetch_session.check_existance_return_info(
                collection='course_resource_bank',
                condition={
                    "_id": ObjectId(response_body['id'])
                },
                whole_doc=True)
            if course_bank_find:
                response_body['url'], status = s3_function.generate_presigned_url_from_s3(course_bank_find['s3_key'])
            passion_project_find = fetch_session.check_existance_return_info(collection='resources',
                                                                             condition={
                                                                                 "_id": ObjectId(
                                                                                     response_body['id'])
                                                                             },
                                                                             whole_doc=True)
            if passion_project_find:
                response_body['url'], status = s3_function.generate_presigned_url_from_s3(passion_project_find['s3_key'])
            if course_bank_find:
                # check for sessions
                session_resources = fetch_session.check_existance_return_info(collection='course_sessions',
                                                                              condition={
                                                                                  'resources._id': ObjectId(
                                                                                      response_body['id'])
                                                                              },
                                                                              return_keys=['_id', 'title'])
                topic_resources = fetch_session.check_existance_return_info(collection='course_topics',
                                                                            condition={
                                                                                'resources._id': ObjectId(
                                                                                    response_body['id'])
                                                                            },
                                                                            return_keys=['_id', 'title'])
                course_resources = fetch_session.check_existance_return_info(collection='courses_bank',
                                                                             condition={
                                                                                 'resources._id': ObjectId(
                                                                                     response_body['id'])
                                                                             },
                                                                             return_keys=['_id', 'subject',
                                                                                          'created_by'])
                if session_resources:
                    find_topic = fetch_session.check_existance_return_info(collection='course_topics',
                                                                           condition={
                                                                               'sessions._id': ObjectId(
                                                                                   session_resources['_id'])
                                                                           },
                                                                           return_keys=['_id', 'title'])
                    find_course = ""
                    user = ""
                    if find_topic:
                        find_course = fetch_session.check_existance_return_info(collection='courses_bank',
                                                                                condition={
                                                                                    'topics._id': ObjectId(
                                                                                        find_topic['_id'])
                                                                                },
                                                                                return_keys=['_id', 'subject',
                                                                                             'created_by'])
                        user = User_Profile(str(find_course['created_by']))[0]['username'] if find_course else ""
                    response_body['history'].append({'session_title': str(session_resources['title']),
                                                     'course_title': str(
                                                         find_course['subject']) if find_course else "",
                                                     'topic_title': str(find_topic['title']) if find_topic else "",
                                                     'created_by': user if user else "",
                                                     'level_type': 'session_level',
                                                     'course_work': ''
                                                     })

                if topic_resources:
                    find_course = fetch_session.check_existance_return_info(collection='courses_bank',
                                                                            condition={
                                                                                'topics._id': ObjectId(
                                                                                    topic_resources['_id'])
                                                                            },
                                                                            return_keys=['_id', 'subject',
                                                                                         'created_by'])
                    user = User_Profile(str(find_course['created_by']))[0]['username'] if find_course else ""
                    response_body['history'].append({
                        'topic_title': str(topic_resources['title']),
                        'course_title': str(
                            find_course['subject']) if find_course else "",
                        'session_title': "",
                        'created_by': user if user else "",
                        'level_type': 'topic_level',
                        'course_work': ''
                    })
                if course_resources:
                    user = User_Profile(str(course_resources['created_by']))[0]['username'] if course_resources else ""
                    response_body['history'].append({'course_title': str(course_resources['subject']),
                                           'topic_title': "",
                                           "session_title": "",
                                           'created_by': user if user else "",
                                           'level_type': 'course_level',
                                           'course_work': ''})
            if passion_project_find:
                pp = fetch_session.check_existance_return_info(collection='passion_projects',
                                                               condition={"project_resources":
                                                                              {"$in": [
                                                                                  ObjectId(passion_project_find)]}},
                                                               return_keys=['project_title', 'created_by'])
                if pp:
                    user = User_Profile(str(pp['created_by']))[0]['username'] if pp else ""
                response_body['history'].append({
                    'session_title': "",
                    'topic_title': "",
                    'course_title': "",
                    'created_by': user if user else "",
                    'level_type': 'passion_project_level',
                    'course_work': '',
                    'passion_project_title': pp['project_title'] if pp else ""
                })

            if passion_project_find or course_bank_find:
                pass
    return res


def insert_resource_elastic(resource):
    try:
        tags_collection = fetch_session.get_all_data("global_tags")['message']
        tags_collection_q = fetch_session.get_all_data("question_tags")['message']
        tags_collection.extend(tags_collection_q)
        tags_dict = dict(map(lambda x: (x['_id'], x['tag']), tags_collection))
        body = {'id': resource['_id'].__str__(), 'title': resource['title'], 'description': resource['description'],
                'tags': [], 'mongo_collection': resource['mongo_collection'],
                'module_name': resource['module_name'], 'created_by': str(resource['created_by']),
                'created_at': str(resource['created_at']), 'file_type': resource['file_type'],
                's3_path': resource['url']}
        title_tag = body['title']
        description_tag = body['description']

        new_arr = []
        if resource['tags']:
            for t in resource['tags']:
                if str(t) in tags_dict.keys():
                    body['tags'].append(str(t))
                    title_tag += (" " + tags_dict[str(t)])

        title_tag_arr = title_tag.split(" ")
        for i in reversed(title_tag_arr):
            if not new_arr:
                new_arr.append(i)
            else:
                ele = i + " " + new_arr[-1]
                new_arr.append(ele)
        new_arr = new_arr[::-1]
        body['title_tag'] = new_arr
        body['title_tag_context'] = new_arr

        new_arr = []
        if resource['tags']:
            for t in resource['tags']:
                if str(t) in tags_dict.keys():
                    description_tag += (" " + tags_dict[str(t)])
        description_tag_arr = description_tag.split(" ")
        for i in reversed(description_tag_arr):
            if not new_arr:
                new_arr.append(i)
            else:
                ele = i + " " + new_arr[-1]
                new_arr.append(ele)
        new_arr = new_arr[::-1]

        body['description_tag'] = new_arr
        body['description_tag_context'] = new_arr
        print('body', body)
        res = es.index(index=ES_RESOURCE_BANK_INDEX, body=body, id=body['id'])
        print('es_res', res)

    except Exception as e:
        traceback.print_exc()


def update_resource_elastic(resource, id):
    try:
        tags_collection = fetch_session.get_all_data("global_tags")['message']
        tags_dict = dict(map(lambda x: (x['_id'], x['tag']), tags_collection))
        body = {}
        if resource['title'] is not None:
            body['title'] = resource['title']
        if resource['tags'] is not None:
            body['tags'] = []
        if resource['title'] is not None:
            body['description'] = resource['description']
        body['id'] = id
        title_tag = body['title']
        description_tag = body['description']

        new_arr = []
        if resource['tags']:
            for t in resource['tags']:
                if str(t) in tags_dict.keys():
                    body['tags'].append(str(t))
                    title_tag += (" " + tags_dict[str(t)])

        title_tag_arr = title_tag.split(" ")
        for i in reversed(title_tag_arr):
            if not new_arr:
                new_arr.append(i)
            else:
                ele = i + " " + new_arr[-1]
                new_arr.append(ele)
        new_arr = new_arr[::-1]

        body['title_tag'] = new_arr
        body['title_tag_context'] = new_arr

        new_arr = []
        description_tag_arr = description_tag.split(" ")
        for i in reversed(description_tag_arr):
            if not new_arr:
                new_arr.append(i)
            else:
                ele = i + " " + new_arr[-1]
                new_arr.append(ele)
        new_arr = new_arr[::-1]

        body['description_tag'] = new_arr
        body['description_tag_context'] = new_arr
        res = es.update(index=ES_RESOURCE_BANK_INDEX, body={"doc": body}, id=id)

    except Exception as e:
        traceback.print_exc()
