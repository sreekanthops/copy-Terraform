from datetime import datetime
from bs4 import BeautifulSoup
from config import img_down_mob_path
from routes.exception import InvalidUsage
from services.storage.s3_services import s3_storage
from moviepy.editor import *
from PIL import Image

s3_function = s3_storage()
import bson
from config import email_Address, email_password, DEFAULT_AVATAR
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import ssl
from flask import render_template


def convert_dict_standard_dt(date_time_dict, key="Timestamp", format='%d %b %Y, %I:%M %p',
                             sort_key="Timestamp_standard"):
    """
    converts input date time in given format to standard date time format
    :param date_time_dict:
    :param key:
    :param format:
    :return:
    """
    date_time_dict[sort_key] = datetime.strptime(date_time_dict[key], format)
    return date_time_dict


def mongo_columns_mapping_to_request_response_keys(mongo_data_res: "dict", column_request_response_key_mapping):
    processed_data_res = []
    if mongo_data_res["status"] == 200:
        for doc in mongo_data_res["message"]:
            single_doc = {}
            for column_from_db, request_response_key in column_request_response_key_mapping.items():
                if doc.get(column_from_db) != None:
                    single_doc[request_response_key] = doc.get(column_from_db)
                else:
                    single_doc[request_response_key] = None
            processed_data_res.append(single_doc)

        mongo_data_res["message"] = processed_data_res
        return mongo_data_res
    else:
        return mongo_data_res


def validate_ObjectId(string):
    return bson.objectid.ObjectId.is_valid(string)


def renew_s3_links(html_string, is_links=False):
    """ This function will refresh the file links in the html string
    is_links specify whether the original html string contains the previous s3 links or not."""
    bs_string = BeautifulSoup(html_string)
    if is_links:
        for img in bs_string.findAll('img'):
            s3_url = img['src'].split('?')[0]
            key = s3_url.split('/')[-2] + '/' + s3_url.split('/')[-1]
            # check if the key is in s3 bucket if not don't refresh the source
            if not s3_function._key_existing_size__list(key):
                continue
            s3_link, s3_status = s3_function.generate_presigned_url_from_s3(key)
            if s3_status != 200:
                raise Exception("Error occurred while communicating with s3.")
            img['src'] = s3_link
    else:
        for img in bs_string.findAll('img'):
            # check if the key is in s3 bucket if not don't refresh the source
            if not s3_function._key_existing_size__list(img['src']):
                continue
            s3_link, s3_status = s3_function.generate_presigned_url_from_s3(img['src'])
            if s3_status != 200:
                raise Exception("Error occurred while communicating with s3.")
            img['src'] = s3_link
    return str(bs_string)


def is_empty(val):
    if not val or val.isspace() or val == "null":
        return True
    return False


def replace_s3_links_with_keys(html_string, module=None):
    bs_string = BeautifulSoup(html_string)
    image_tags = bs_string.findAll("img")

    for img in bs_string.findAll('img'):
        if module == "offline-assess":
            filename = img['src'].split('?')[0].split('/')[-1]
            key = "".join([img_down_mob_path, filename])
        elif module == "course-work":
            s3_url = img['src'].split('?')[0]
            key = s3_url.split('/')[-2] + '/' + s3_url.split('/')[-1]
            if not s3_function._key_existing_size__list(key):
                continue
        else:
            s3_url = img['src'].split('?')[0]
            key = s3_url.split('/')[-2] + '/' + s3_url.split('/')[-1]
            if not s3_function._key_existing_size__list(key):
                raise InvalidUsage("There was problem processing your file, Please upload again.", 400)
        img['src'] = key
    return str(bs_string)


def create_thumbnail_for_video(s3_link, s3_key, height=None, width=None):
    """This function is used to create thumbnail from the first frame of the video, video is already uploaded in s3"""
    clip = VideoFileClip(s3_link)
    frame = clip.get_frame(0)
    video_thumbnail = Image.fromarray(frame)
    if height and width:
        thumbnail_image = video_thumbnail.resize((height, width))
        image_file = os.path.join(os.getcwd(), s3_key[14:-4] + ".png")
        thumbnail_image.save(image_file, "PNG")
        return image_file
    else:
        image_file = os.path.join(os.getcwd(), s3_key[14:-4] + ".png")
        video_thumbnail.save(image_file, "PNG")
        return image_file


def extract_s3_keys_from_html_str(html_str):
    """TO extract s3 keys that are used in the html content.
    :param html_str: content for different modules.
    :type html_str: str (html).
    :returns : list containing s3 keys."""
    s3_keys_list = []
    bs_string = BeautifulSoup(html_str)
    for img in bs_string.findAll('img'):
        s3_key = img['src']
        if not s3_function._key_existing_size__list(s3_key):
            continue
        s3_keys_list.append(s3_key)
    return s3_keys_list


def send_confirmation_email(login_user_other_details, report_name, template_path, subject):
    """Send a confirmation email that the report is submitted."""
    password = email_password
    sender_email = email_Address
    receiver_email = login_user_other_details["email"]
    msg = MIMEMultipart('alternative')
    msg['Subject'] = subject
    msg['From'] = sender_email
    msg['To'] = receiver_email
    name = login_user_other_details['name'] + " " + login_user_other_details['last_name']
    confirmation_message = render_template(template_path + ".txt",
                                           name=name,
                                           report_name=report_name
                                           )
    email_text = MIMEText(confirmation_message, 'plain')
    msg.attach(email_text)
    text = msg.as_string()
    # context = ssl.create_default_context()
    # with smtplib.SMTP_SSL("smtp.gmail.com", 465, context=context) as server:
    #     server.login(sender_email, password)
    #     server.sendmail(sender_email, receiver_email, text)
    smtp = smtplib.SMTP(host="172.31.6.215", port=25)
    smtp.sendmail(sender_email, receiver_email, text)
    smtp.close()
    return True


def get_profile_pic(s3_key=None):
    """TO generate profile pic of a user from s3 key if present otherwise
    return default profile pic"""
    s3_key = s3_key if s3_key else DEFAULT_AVATAR

    # s3 key is present in bucket or not
    if not s3_function._key_existing_size__list(s3_key):
        s3_key = DEFAULT_AVATAR
    s3_link, s3_status = s3_function.generate_presigned_url_from_s3(s3_key)
    return s3_link


def send_email_to_user(email, name, last_name, template_path, subject, body_data, module):
    """General function to send emails for various features to user.
    :param email: receiver email
    :type email: str
    :param name: name of the receiver
    :type name: str
    :param last_name: last name of the receiver
    :type last_name: str
    :param template_path: path in the project where the template of the email is stored
    :type template_path: str(path)
    :param body_data: data which is needed to send the email
    :type body_data: dict
    :param subject: subject of the email
    :type subject: str
    :param module: different body params according to the module name
    :type module: str
    """
    password = email_password
    sender_email = email_Address
    receiver_email = email
    name = name + " " + last_name

    msg = MIMEMultipart('alternative')
    msg['Subject'] = subject
    msg['From'] = sender_email
    msg['To'] = receiver_email

    if module == "super_admin_edit_profile":
        new_password = ""
        if body_data.get('new_password'):
            new_password = body_data['new_password']
        text = render_template(template_path + ".txt",
                               name=name,
                               previous_email=body_data["previous_email"],
                               new_email=body_data["new_email"],
                               new_password=new_password
                               )
        html_doc = render_template(template_path + ".html",
                                   name=name,
                                   previous_email=body_data["previous_email"],
                                   new_email=body_data["new_email"],
                                   new_password=new_password
                                   )
    else:
        return False

    part1 = MIMEText(text, 'plain')
    part2 = MIMEText(html_doc, 'html')
    msg.attach(part1)
    msg.attach(part2)

    text = msg.as_string()
    # context = ssl.create_default_context()
    # with smtplib.SMTP_SSL("smtp.gmail.com", 465, context=context) as server:
    #     server.login(sender_email, password)
    #     server.sendmail(sender_email, receiver_email, text)
    smtp = smtplib.SMTP(host="172.31.6.215", port=25)
    smtp.sendmail(sender_email, receiver_email, text)
    smtp.close()
    return True
