from datetime import datetime, timedelta
import pytz
from config import DEFAULT_DT_FORMAT
from dateutil.tz import gettz


def utc_datetime_now():
    return datetime.now().astimezone(pytz.utc)


def str_to_utc_datetime_obj(time_string, date_format, zone="Asia/Kolkata"):
    """method to convert a valid datetime string to utc datetime object.
       :param time_string:The time string which needs to be modified.
       :param date_format: The format in which time_string is written.
       :param zone: Specify the time_string current time zone
       :type time_string: str
       :type date_format: str
       :type zone: str
       :return: Returns a utc datetime object
       :rtype: datetime.datetime
    """
    local = pytz.timezone(zone)  # 'Asia/Kolkata'
    naive = datetime.strptime(time_string, date_format)
    local_dt = local.localize(naive, is_dst=None)
    utc_datetime = local_dt.astimezone(pytz.utc)
    return utc_datetime


def utc_dtime_obj_to_zone_str(utc_dt_obj, date_format=DEFAULT_DT_FORMAT, zone="Asia/Kolkata"):
    """method to convert a valid datetime string to utc datetime object.
           :param utc_dt_obj:The ISO time object which needs to be modified.
           :param date_format: The format in which time_string is to return.
           :param zone: Specify the time_string current time zone
           :type utc_dt_obj: ISO datetime
           :type date_format: str
           :type zone: str
           :return: Returns a time string according to given zone
           :rtype: str
        """
    local_tz = pytz.timezone(zone)
    local_dt = utc_dt_obj.replace(tzinfo=pytz.utc).astimezone(local_tz)
    return local_dt.strftime(date_format)


def convert_utc_to_ist(utc_dt_obj, zone="Asia/Kolkata"):
    ist = gettz(zone)
    date = utc_dt_obj
    date = date.astimezone(ist)
    return date