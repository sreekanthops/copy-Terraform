# -*- coding: utf-8 -*-


"""
This file will be used to make connection to the database
"""

from pymongo import MongoClient
from config import mongo_database,mongo_ip_address,mongo_port,mongousername,mongopassword
# from config import mongo_database,mongo_ip_address,mongo_port

# client = MongoClient(mongo_ip_address,mongo_port)
client=MongoClient('mongodb://%s:%s@%s:%s' % (mongousername, mongopassword,mongo_ip_address,mongo_port))
connection=client[mongo_database]