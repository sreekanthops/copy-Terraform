import json

import config
from config import download_path

from model import Question as q, User
from model.zoom import Zoom
from mongo_connection import connection
import datetime
from bson import ObjectId
from werkzeug.utils import secure_filename
import os
from db_wrapper.tasks import Mongo
from routes.exception import InvalidUsage

mongo_session = Mongo()
from services.storage.s3_services import s3_storage


s3_function = s3_storage()
import regex as re
import time
from config import es, ES_VIDEO_TRANSCRIBE
from model import Notification
from datetime import timedelta
import numpy as np
import traceback
from operator import itemgetter
from utils.misc import convert_dict_standard_dt, is_empty, renew_s3_links
from utils.time_conversions import utc_dtime_obj_to_zone_str, utc_datetime_now
import traceback
import sys


class Content(object):
    def __init__(self, content_id):
        self.content_id = content_id
        self.load_content()

    def load(self, pathname):
        self.my_questions = []
        with open(pathname, "r") as fp:
            for line in fp:
                self.my_questions.append(q.Question(line))

    def load_content(self):
        with open(config.CONTENT_BANK_PATH, "r") as fp:
            for line in fp:
                bits = line.split(",")
                if bits[0] == self.content_id:
                    self.author = bits[1]
                    self.language = bits[2]
                    self.comments = self.load_comments(bits[3])
                    self.ratings = self.load_ratings(bits[4])

    def add_comment(self, comment):
        self.comments.append(comment)

    def add_rating(self, rating):
        self.ratings.append(rating)

    def get_comment(self):
        return self.comments

    def get_rating(self):
        return self.ratings

    def load_comments(self, comments):
        return comments.split(";")

    def load_ratings(self, ratings):
        return ratings.split(";")


def fetch_answers(user_id, cat_filter, ans_filter):
    """To return all answers given by a user
    :param user_id: id of the user whose answers we are looking for.
    :type user_id: str (object of mongo db).
    :returns: answers list.
    :param ans_filter: video/text filter for my answers questions
    :param cat_filter: category wise filter for my answers questions"""
    answers = []
    if ans_filter:
        if ans_filter == 'video':
            vid_filter = {"user_id": ObjectId(user_id), 'video': {'$ne': {}}}
        else:
            vid_filter = {"user_id": ObjectId(user_id), 'video': {'$eq': {}}}
        answers_info = mongo_session.access_specific_fields(collection="answer_bank",
                                                            condition=vid_filter,
                                                            sort_condition=("$natural", -1)
                                                            )
    else:
        answers_info = mongo_session.access_specific_fields(collection="answer_bank",
                                                            condition={"user_id": ObjectId(user_id)},
                                                            sort_condition=("$natural", -1)
                                                            )

    if not answers_info:
        return answers
    # category wise filter
    if cat_filter:
        question_list = []
        for data in answers_info:
            if str(data["question_id"]) not in question_list:
                if data["course_category"] in cat_filter:
                    answer = fetch_answers_data(data=data)
                    answers.append(answer)
                    question_list.append(str(data["question_id"]))
                else:
                    continue
    else:
        question_list = []
        for data in answers_info:
            if str(data["question_id"]) not in question_list:
                answer = fetch_answers_data(data=data)
                answers.append(answer)
                question_list.append(str(data["question_id"]))
    return answers


def fetch_answers_data(data):
    answer = {"_id": str(data["_id"]),
              "question_id": str(data["question_id"]),
              "user_id": str(data["user_id"]),
              "course_category": data["course_category"],
              "created_at": utc_dtime_obj_to_zone_str(data["created_at"])}
    # convert utc to ist time zone
    if data.get('video_question'):
        for video_ques in data['video_question']:
            video_ques['question_id'] = str(video_ques['question_id'])
        answer['video_question'] = data['video_question']

    aggregate_rating = float(sum(rating['Rating'] for rating in data['Rating'])) / len(data["Rating"]) if data[
        "Rating"] else 0
    answer['Rating'] = int(round(aggregate_rating, 2))

    # process answer html
    answer['answer_html'] = renew_s3_links(data['answer_html']) if data['answer_html'] else ""

    # process video data if present
    answer['video'] = data.get('video', "")
    if answer['video']:
        answer['video']['video_path'], status = s3_function.generate_presigned_url_from_s3(
            answer['video']['video_path'])
        if answer['video'].get('thumbnail'):
            answer['video']['thumbnail'], status = s3_function.generate_presigned_url_from_s3(
                answer['video']['thumbnail'])
    # process feedback on answers
    answer['Feedback'] = data['Feedback']
    for feedback in answer['Feedback']:
        feedback["_id"] = str(feedback.get('_id', ''))
        user_info = mongo_session.check_existance_return_info(collection="user_profile",
                                                              condition={"_id": ObjectId(feedback['user_id'])},
                                                              columns={"_id": 1, "username": 1},
                                                              return_keys=["_id", "username"]
                                                              )
        feedback['username'] = user_info["username"]
        feedback['Timestamp'] = utc_dtime_obj_to_zone_str(feedback['Timestamp'])
    question_data = mongo_session.check_existance_return_info(collection="question_bank",
                                                                   condition={
                                                                       "_id": ObjectId(answer["question_id"])},
                                                                   columns={"questions": 1, "tags": 1},
                                                                   return_keys=["questions", "tags"])
    answer['question'] = question_data["questions"]
    answer['tags'] = question_data['tags'] if question_data.get('tags') else []
    return answer


def answer_to_questions(question_id):
    """To return all the details and answer content for particular question"""
    question_data = mongo_session.check_existance_return_info(collection="question_bank",
                                                              condition={"_id": ObjectId(question_id)},
                                                              whole_doc=True)
    if not question_data:
        raise InvalidUsage("Please look for a valid question.", 400)
    question_image_path = ""
    question_video_path = ""

    answer_data = mongo_session.access_specific_fields(collection="answer_bank",
                                                       condition={"question_id": ObjectId(question_id)})
    answers = []
    if answer_data:
        for data in answer_data:
            answer = {"_id": str(data["_id"]),
                      "course_category": data["course_category"],
                      "user_id": str(data["user_id"]),
                      "created_at": utc_dtime_obj_to_zone_str(data["created_at"])}
            aggregate_rating = float(sum(rating['Rating'] for rating in data['Rating'])) / len(data["Rating"]) if data[
                "Rating"] else 0
            answer["Rating"] = int(round(aggregate_rating, 2))

            for feedback in data['Feedback']:
                user_info = mongo_session.check_existance_return_info(collection="user_profile",
                                                                      condition={"_id": ObjectId(feedback['user_id'])},
                                                                      columns={"username": 1},
                                                                      return_keys=["username"])
                if user_info:
                    feedback['username'] = user_info['username']
                feedback['Timestamp'] = utc_dtime_obj_to_zone_str(feedback['Timestamp'])
            answer['Feedback'] = data['Feedback']

            if data.get("video_question"):
                for ques in data["video_question"]:
                    ques["question_id"] = str(ques["question_id"])
                answer["video_question"] = data["video_question"]

            answer["approval_status"] = "approved" if data["approval_status"] == 1 else ""

            # process answer html
            answer['answer_html'] = renew_s3_links(data['answer_html']) if data['answer_html'] else ""

            # process video data if present
            answer['video'] = data.get('video', "")
            if answer['video']:
                answer['video']['video_path'], status = s3_function.generate_presigned_url_from_s3(
                    answer['video']['video_path'])
                if answer['video'].get('thumbnail'):
                    answer['video']['thumbnail'], status = s3_function.generate_presigned_url_from_s3(
                        answer['video']['thumbnail'])

            answers.append(answer)

    # process question files
    if question_data.get("question_video_path") and question_data["question_video_path"]:
        question_video_path, status = s3_function.generate_presigned_url_from_s3(question_data["question_video_path"])
    if question_data.get("question_image_path") and question_data["question_image_path"]:
        question_image_path, status = s3_function.generate_presigned_url_from_s3(question_data["question_image_path"])

    # process category taxonomy
    course_category = mongo_session.check_existance_return_info(collection="Course_Category",
                                                                condition={"_id": question_data['course_category_id']},
                                                                whole_doc=True)
    course_category_taxonomy = category_taxonomy_by_category_id(course_category)

    # process answer on which the question was asked.
    answer_id = ""
    answer_video_time = ""
    answer_info_on_ques_asked = mongo_session.access_specific_fields(collection="answer_bank",
                                                                     condition={"video_question.question_id": ObjectId(
                                                                         question_id)})
    if answer_info_on_ques_asked:
        for question_detail in answer_info_on_ques_asked:
            answer_id = str(question_detail['_id'])
            for doc in question_detail['video_question']:
                if str(doc['question_id']) == question_id:
                    answer_video_time = doc['video_time']
    video_time = ""
    course_id = ""
    session_id = ""
    vtt = ""
    transcriptions = {'transcripts': [], 'items': []}
    if question_data.get("course_id"):
        video_time = question_data["video_time"]
        course_id = str(question_data["course_id"])
        session_id = str(question_data["course_session_id"])
        if course_id and session_id:
            course_session_data = mongo_session.get_all_data_for_particular_condition_fields(
                collection="course_sessions",
                condition={"_id": ObjectId(session_id)})
            if course_session_data['message'][0]:
                video_s3_key = course_session_data['message'][0]['url']
                transcriptions = mongo_session.access_specific_fields(collection="video_transcriptions",
                                                                      condition={"s3_key": video_s3_key})
                # adding transcriptions to the searched questions linked to videos
                if transcriptions:
                    if transcriptions[0].get('vtt'):
                        vtt = transcriptions[0]['vtt'].split('/')[3:]
                        key = '{}/{}'.format(vtt[0], vtt[1])
                        vtt = s3_function.generate_presigned_url_from_s3(s3_key=key)[0]
                    else:
                        vtt = ""
                else:
                    vtt = ""
                if transcriptions:
                    transcriptions = transcriptions[0]['transcription']['results']
                    if transcriptions['items']:
                        for t in transcriptions['items']:
                            t['text'] = t['alternatives'][0]['content']
                            t.pop('alternatives')
                    else:
                        transcriptions = {'transcripts': [], 'items': []}
                else:
                    transcriptions = {'transcripts': [], 'items': []}

    return {'answers': answers,
            'answer_id': answer_id,
            'answer_video_time': answer_video_time,
            'question': question_data["questions"],
            'course_category_taxonomy': course_category_taxonomy,
            'question_status': "closed" if question_data['status'] else "open",
            'video_time': video_time,
            'course_id': course_id,
            'course_session_id': session_id,
            'user_id': question_data['user_id'],
            'course_category_id': str(question_data['course_category_id']),
            'reward': question_data['reward'],
            'question_image_path': question_image_path,
            'question_video_path': question_video_path,
            'course_category': course_category["name"],
            "vtt": vtt,
            "transcriptions": transcriptions}


def convert_time_into_humanreadable_form(time_in_Seconds):
    """convert timestamp into format like 1 day ago"""
    seconds = time_in_Seconds  # For example
    days = divmod(seconds, 86400)
    hours = divmod(days[1], 3600)
    minutes = divmod(hours[1], 60)
    if days[0] == 0 and hours == 0 and minutes[0] == 0:
        time_format = "%i seconds" % (minutes[1])
    elif days[0] == 0 and hours[0] == 0:
        time_format = "%i minutes,%i seconds ago" % (minutes[0], minutes[1])
    elif days[0] == 0:
        time_format = " %i hours,%i minutes,%i seconds ago" % (hours[0], minutes[0], minutes[1])
    else:
        time_format = "%i days, %i hours" % (days[0], hours[0])
    return time_format


def fetch_answer_details(answer_id, user_id, comment_filter):
    """function to return answer metadata
    :param answer_id: id of the answer to fetch it's metadata.
    :type answer_id: str
    :param user_id: user who is accessing the answer metadata
    :type user_id: str
    param comment_filter: comment filter for top comments
    :type comment_filter: str"""
    answer_info = mongo_session.check_existance_return_info(collection="answer_bank",
                                                            condition={"_id": ObjectId(answer_id)},
                                                            whole_doc=True)
    if not answer_info:
        raise InvalidUsage("Please check request data.", 400)
    # calculate aggregate rating of answer
    aggregate_rating = float(sum(rating['Rating'] for rating in answer_info['Rating'])) / len(answer_info["Rating"]) if \
        answer_info[
            "Rating"] else 0

    # process feedbacks given on answer
    for feedback in answer_info['Feedback']:
        feedback["_id"] = str(feedback.get('_id', ''))
        # process whether user liked the comment or not
        if feedback.get("Liked"):
            feedback['like_count'] = len(feedback["Liked"])
            feedback["Liked"] = any(user["user_id"] == user_id for user in feedback["Liked"])
        else:
            feedback['like_count'] = 0
            feedback["Liked"] = False
        if feedback.get("Disliked"):
            feedback['dislike_count'] = len(feedback["Disliked"])
            feedback["Disliked"] = any(user["user_id"] == user_id for user in feedback["Disliked"])
        else:
            feedback['dislike_count'] = 0
            feedback["Disliked"] = False
        user_info = mongo_session.check_existance_return_info(collection="user_profile",
                                                              condition={"_id": ObjectId(feedback['user_id'])},
                                                              columns={"username": 1, "name": 1, "last_name": 1, "profile_pic": 1},
                                                              return_keys=["username", "name", "last_name", "profile_pic"])
        if user_info:
            feedback['username'] = user_info['username']
            feedback["name"] = user_info["name"].capitalize() + " " + user_info["last_name"].capitalize()
            s3_url, status_code = s3_function.generate_presigned_url_from_s3(user_info['profile_pic'])
            feedback['profile_pic'] = s3_url
            feedback['Timestamp'] = utc_dtime_obj_to_zone_str(feedback['Timestamp'])
            feedback["user_id"] = str(feedback["user_id"])

    if str(comment_filter).lower() == "top":
        answer_info["Feedback"] = sorted(answer_info["Feedback"], key=lambda k: (k['Timestamp']), reverse=True)
        answer_info["Feedback"] = sorted(answer_info["Feedback"], key=lambda k: (k['like_count']), reverse=True)
    elif str(comment_filter).lower() == "newest":
        answer_info["Feedback"] = answer_info["Feedback"][::-1]
    else:
        answer_info["Feedback"] = answer_info["Feedback"]

    answer_data = {"_id": str(answer_info["_id"]),
                   "user_id": str(answer_info["user_id"]),
                   "course_category": answer_info["course_category"],
                   "question_id": str(answer_info["question_id"]),
                   "speech_text": str(answer_info["speech_text"]),
                   "created_at": utc_dtime_obj_to_zone_str(answer_info["created_at"]),
                   "approval_status": "approved" if answer_info["approval_status"] == 1 else "",
                   "Rating": int(round(aggregate_rating, 2)),
                   "Feedback": answer_info["Feedback"],
                   "answer_html": renew_s3_links(answer_info['answer_html']) if answer_info['answer_html'] else ""
                   }
    # process if answer is on video question
    if answer_info.get("video_question"):
        for ques in answer_info["video_question"]:
            ques["question_id"] = str(ques["question_id"])
            answer_data["video_question"] = answer_info["video_question"]
    answer_image_path = []
    answer_video_path = []
    answer_doc_path = []
    answer_image_key = []
    answer_video_key = []
    answer_doc_key = []
    # process video data if present
    answer_data["video"] = answer_info.get('video', "")
    if answer_data['video']:
        answer_data['video']['video_path'], status = s3_function.generate_presigned_url_from_s3(
            answer_data['video']['video_path'])
        answer_video_path.append(answer_data['video']['video_path'])
        if answer_data['video'].get('thumbnail'):
            answer_data['video']['thumbnail'], status = s3_function.generate_presigned_url_from_s3(
                answer_data['video']['thumbnail'])
    # process answer files
    if answer_info.get("answer_video") and answer_info["answer_video"]:
        for a_video in answer_info["answer_video"]:
            ans_video, status = s3_function.generate_presigned_url_from_s3(a_video)
            answer_video_path.append(ans_video)
            answer_video_key.append(a_video)
    if answer_info.get("answer_image") and answer_info["answer_image"]:
        for a_image in answer_info["answer_image"]:
            ans_image, status = s3_function.generate_presigned_url_from_s3(a_image)
            answer_image_path.append(ans_image)
            answer_image_key.append(a_image)
    if answer_info.get("answer_doc") and answer_info["answer_doc"]:
        for a_files in answer_info["answer_doc"]:
            ans_doc, status = s3_function.generate_presigned_url_from_s3(a_files)
            answer_doc_path.append(ans_doc)
            answer_doc_key.append(a_files)

    # process whether user liked the answer or not
    answer_data["answer_image"] = answer_image_path
    answer_data["answer_video"] = answer_video_path
    answer_data["answer_doc"] = answer_doc_path
    answer_data["answer_image_key"] = answer_image_key
    answer_data["answer_video_key"] = answer_video_key
    answer_data["answer_doc_key"] = answer_doc_key
    answer_data["Liked"] = any(user["user_id"] == user_id for user in answer_info["Liked"])
    answer_data["Disliked"] = any(user["user_id"] == user_id for user in answer_info["Disliked"])
    answer_data['like_count'] = len(answer_info["Liked"])
    answer_data['dislike_count'] = len(answer_info["Disliked"])

    # fetch category taxonomy
    course_category = mongo_session.check_existance_return_info(collection="Course_Category",
                                                                condition={"name": answer_info['course_category']},
                                                                whole_doc=True)
    answer_data['course_category_taxonomy'] = category_taxonomy_by_category_id(course_category)

    # process question info
    question_info = mongo_session.check_existance_return_info(collection="question_bank",
                                                              condition={"_id": answer_info["question_id"]},
                                                              columns={"questions": 1, "status": 1},
                                                              return_keys=["questions", "status"])

    answer_data["question"] = question_info["questions"]
    answer_data["question_status"] = "closed" if question_info["status"] else "open"
    return answer_data


def slash_separated_Tree_form(list_containing_category_dicts):
    categories_tree = []

    def process_parent_until_null(base_category, list_containing_category_dicts):
        for item in list_containing_category_dicts:
            if item['_id'] == base_category['parent_id']:
                return item, item['name']

    for category in list_containing_category_dicts:
        current_category = {}
        current_category['_id'] = category['_id']
        if category['parent_id'] == "None":
            current_category['Course_Category'] = category['name']
        else:
            generated_string = category['name']
            while category['parent_id'] != "None":
                returned_category, course_string = process_parent_until_null(category, list_containing_category_dicts)
                generated_string = course_string + " / " + generated_string
                category = returned_category
            current_category['Course_Category'] = generated_string
        categories_tree.append(current_category)
    return categories_tree


def category_taxonomy_by_category_id(category):
    generated_string = category['name']
    while category['parent_id']:
        category = mongo_session.get_all_data_for_particular_condition_fields("Course_Category",
                                                                              {"_id": ObjectId(category['parent_id'])})[
            'message'][0]
        generated_string = category['name'] + " / " + generated_string
    return generated_string


def course_category(organisation=None):
    """return the course list"""
    try:
        required_column_name = {"_id": 1, "name": 1, "parent_id": 1}
        cursor = mongo_session.get_all_data_for_particular_fields_course_category_api(collection='Course_Category',
                                                                                      columns=required_column_name)
        category_list = slash_separated_Tree_form(cursor['message'])
        category_list = sorted(category_list, key=lambda i: i['Course_Category'])
        if organisation is not None:
            # checking that course category is aligned to how many courses
            organisation_data = mongo_session.get_data_for_particular_columns_with_condition(collection='organisations',
                                                                                             condition={"name": organisation},
                                                                                             columns={"_id": 1})
            org_id = organisation_data['message'][0]["_id"]
            for doc in category_list:
                column_name = {"_id": 1, "status": 1}
                course_count = mongo_session.get_data_for_particular_columns_with_condition(collection='courses_bank',
                                                                                            condition={"course_category_id": ObjectId(doc['_id']),
                                                                                                       "status": "publish",
                                                                                                       "active": True,
                                                                                                       "organisations._id": {"$in": [ObjectId(org_id)]}},
                                                                                            columns=column_name)
                doc["course_count"] = len(course_count["message"])

    except Exception as e:
        print(e)
        category_list = None
    return category_list


def course_recommendation(course_subject):
    """This function return the list of recommended course and popular topics"""
    course_category_collection = connection.Course_Category
    course_collection = connection.courses_bank
    new_course_list = []
    status = course_category_collection.find({"Course_Category": course_subject}).count() > 0
    try:
        if status == True:
            cursor = course_category_collection.find({"Course_Category": course_subject}, {"Recommeded_Courses": 1})
            for courses in cursor:
                course_dict = courses["Recommeded_Courses"]
                course_list = course_dict['course']
                for items in course_list:
                    entity = {}
                    course_cursor = course_collection.find({"_id": items['Course_id']},
                                                           {"subject": 1, "Course_Category": 1, "Rating": 1,
                                                            "About_Course": 1, "status": 1})
                    for data in course_cursor:
                        status_course = data['status']
                    if status_course == "False":
                        pass
                    else:
                        rating_aggregate_cursor = course_collection.aggregate([{"$match": {"_id": items['Course_id']}},
                                                                               {"$project": {"av_rating": {
                                                                                   "$avg": "$Rating.Rating"}}}])
                        for entry in rating_aggregate_cursor:
                            aggregate_rating = entry["av_rating"]
                            if aggregate_rating != None:
                                aggregate_rating = float(round(aggregate_rating, 2))
                            else:
                                aggregate_rating = 0.0
                        entity['About_Course'] = data['About_Course']
                        entity['Course'] = data['subject']
                        entity['Course_Category'] = data['Course_Category']
                        entity['Course_id'] = str(data['_id'])
                        entity['Rating'] = aggregate_rating
                        new_course_list.append(entity)

                topic_list = course_dict["Popular_topic"]
                response = {"Course_suugestion": new_course_list, "Popular_topic": topic_list}
        else:
            cursor = course_category_collection.find()
            topic_list = []
            for courses in cursor:
                if courses['Course_Category'] == "Others":
                    pass
                else:
                    course_dict = courses["Recommeded_Courses"]
                    course_list = course_dict['course']
                    topic_list.append(course_dict["Popular_topic"])

                    for items in course_list:
                        entity = {}
                        course_cursor = course_collection.find({"_id": items['Course_id']},
                                                               {"subject": 1, "Course_Category": 1, "Rating": 1,
                                                                "About_Course": 1, "status": 1})
                        for data in course_cursor:
                            status_course = data['status']
                        if status_course == "False":
                            pass
                        else:
                            rating_aggregate_cursor = course_collection.aggregate(
                                [{"$match": {"_id": items['Course_id']}},
                                 {"$project": {"av_rating": {"$avg": "$Rating.Rating"}}}])
                            for entry in rating_aggregate_cursor:
                                aggregate_rating = entry["av_rating"]
                                if aggregate_rating != None:
                                    aggregate_rating = float(round(aggregate_rating, 2))
                                else:
                                    aggregate_rating = 0.0
                            entity['About_Course'] = data['About_Course']
                            entity['Course'] = data['subject']
                            entity['Course_Category'] = data['Course_Category']
                            entity['Course_id'] = str(data['_id'])
                            entity['Rating'] = aggregate_rating
                            new_course_list.append(entity)

            response = {"Course_suugestion": new_course_list, "Popular_topic": topic_list}
    except Exception as e:
        print(e)
        response = None

    return response


def upload_course_work_and_instance(course_work, course_id):
    try:
        course_work_instance_array = []
        for each_course_work in course_work:
            submission_array_work = []
            for submission in each_course_work['submissionRequirement']:
                submission_array_work.append({"submissionReport": submission['submissionReport']})
            course_bank_dict = {"courseWorkTitle": each_course_work['courseWorkTitle'],
                                "courseURL": each_course_work['courseURL'],
                                "course_work_file_id": each_course_work['course_work_file_id'],
                                "type": each_course_work['type'], "course_id": [{"_id": ObjectId(course_id)}],
                                "submissionRequirement": submission_array_work}
            course_work_inserted = mongo_session.insert_documnet(collection='course_work_bank',
                                                                 doc_to_insert=course_bank_dict)

            course_work_start_date = webapp_time_to_string(each_course_work['courseWorkStartdate'],
                                                           each_course_work['courseworkstartTime'])
            course_work_end_date = webapp_time_to_string(each_course_work['courseworkEndDate'],
                                                         each_course_work['courseworkEndTime'])
            if each_course_work['PresenationDate'] == None:
                presentation_date = None
            else:
                presentation_date = webapp_time_to_string(each_course_work['PresenationDate'],
                                                          each_course_work['PresenationTime'])
            submission_array_instance = []
            for submission in each_course_work['submissionRequirement']:
                submission_array_instance.append({"submissionDate": webapp_time_to_string(submission['submissionDate'],
                                                                                          submission[
                                                                                              'submissionTime'])})

            course_work_instance_dict = {"course_work_id": ObjectId(course_work_inserted['_id'].inserted_id),
                                         "course_id": [{"_id": ObjectId(course_id)}],
                                         "courseWorkStartdate": course_work_start_date,
                                         "courseworkEndDate": course_work_end_date,
                                         "OnlinePresentation": each_course_work['OnlinePresentation'],
                                         "PresenationDate": presentation_date,
                                         "submissionRequirement": submission_array_instance}
            course_work_instance_array.append(course_work_instance_dict)
        mongo_session.insert_multiple_documents(collection='course_work_instances',
                                                doc_to_insert=course_work_instance_array)
        return True
    except Exception as e:
        print('exception ', e)
        return False


def webapp_time_to_string(date_object, time_value):
    year = date_object['year']
    month = date_object['month']
    day = date_object['day']
    timestamp_string = str(year) + ":" + str(month) + ":" + str(day) + "T" + time_value
    return timestamp_string


def schedule_assessment(assessment_data, assessment_type):
    assessment_collection = mongo_session.get_all_data_for_particular_condition_fields("assessment",
                                                                                       {"_id": ObjectId(
                                                                                           assessment_data['_id'])})[
        'message'][0]
    assessment_name = assessment_collection['assessment_name']

    total_time = int(assessment_collection['total_time'])
    if assessment_type == "course":
        start_time_str = webapp_time_to_string(assessment_data['date'], assessment_data['time'])

        start_time_obj = datetime.datetime.strptime(start_time_str, "%Y:%m:%dT%H:%M")

        end_time = start_time_obj + timedelta(minutes=total_time)
        end_time_str = end_time.strftime("%Y:%m:%dT%H:%M")

        schedule_assessment_collection = connection.schedule_assessment
        doc = {
            "assessment_id": ObjectId(assessment_data['_id']),
            "assessment_name": assessment_name,
            "start_time": start_time_str,
            "end_time": end_time_str,
            "total_time": total_time
        }

    cursor = schedule_assessment_collection.insert_one(doc)
    schedule_id = cursor.inserted_id
    return schedule_id


def course_upload_into_db(category_id, subject, course_detail, content, Instructors, institute, created_by,
                          course_resources, live_sess_links, course_work, assessment):
    """this module add the course detail into db"""
    try:
        delete_record_list = []
        if type(course_resources) != list:
            return {"message": "invalid type of course resources", "status": 400}
        week_list = []
        content_list = []
        for num in range(0, len(content)):
            arg = "Week_%s" % (num + 1)
            week_list.append(arg)

        week_index = 1
        for week_record in content:
            for video_index in range(0, len(week_record['des_arr'])):
                for week_inside_resource in week_record['des_arr'][video_index]['resource']:
                    if week_inside_resource['type'] == 'file':
                        resource_id = week_inside_resource['resourceName']
                        delete_record_list.append(ObjectId(resource_id))
                        resource_bank_resource_id = \
                            mongo_session.insert_files_resource_bank(collection="course_resource_bank",
                                                                     resource_id=ObjectId(resource_id),
                                                                     temp_collection="temp_uploaded_files")['message']
                        week_inside_resource['_id'] = resource_bank_resource_id
                        s3_key_info = mongo_session.fetch_s3_key_temp_uploaded_files(collection="temp_uploaded_files",
                                                                                     condition={
                                                                                         "_id": ObjectId(resource_id)},
                                                                                     columns={"s3_key": 1})
                        if s3_key_info['status'] == 200:
                            week_inside_resource['resourceName'] = s3_key_info['message']
                        else:
                            return {"message": "error in upload_course api", "status": 400}
            for week_resource in week_record['weekly_Resourse']:
                if week_resource['type'] == 'file':
                    resource_id = week_resource['weeklyResourse']
                    delete_record_list.append(ObjectId(resource_id))
                    resource_bank_resource_id = \
                        mongo_session.insert_files_resource_bank(collection="course_resource_bank",
                                                                 resource_id=ObjectId(resource_id),
                                                                 temp_collection="temp_uploaded_files")['message']
                    week_resource['_id'] = resource_bank_resource_id
                    s3_key_info = mongo_session.fetch_s3_key_temp_uploaded_files(collection="temp_uploaded_files",
                                                                                 condition={
                                                                                     "_id": ObjectId(resource_id)},
                                                                                 columns={"s3_key": 1})
                    if s3_key_info['status'] == 200:
                        week_resource['weeklyResourse'] = s3_key_info['message']
                    else:
                        return {"message": "error in upload_course api", "status": 400}
            content_list.append({week_list[week_index - 1]: week_record['des_arr'],
                                 'weekly_description': week_record['weekly_description'],
                                 'weekly_Resourse': week_record['weekly_Resourse']})
            week_index = week_index + 1

        for each_resource in course_resources:
            if each_resource['type'] == 'file':
                resource_id = each_resource['course_resourcesName']
                delete_record_list.append(ObjectId(resource_id))
                resource_bank_resource_id = mongo_session.insert_files_resource_bank(collection="course_resource_bank",
                                                                                     resource_id=ObjectId(resource_id),
                                                                                     temp_collection="temp_uploaded_files")[
                    'message']
                each_resource['_id'] = resource_bank_resource_id
                s3_key_info = mongo_session.fetch_s3_key_temp_uploaded_files(collection="temp_uploaded_files",
                                                                             condition={
                                                                                 "_id": ObjectId(resource_id)},
                                                                             columns={"s3_key": 1})
                if s3_key_info['status'] == 200:
                    each_resource['course_resourcesName'] = s3_key_info['message']
                else:
                    return {"message": "error in upload_course api", "status": 400}
        if len(course_work) > 0 and type(course_work) == list:
            for each_resource in course_work:
                if each_resource['type'] == 'file':
                    resource_id = each_resource['course_work_file_id']
                    delete_record_list.append(ObjectId(resource_id))
                    resource_bank_resource_id = \
                        mongo_session.insert_files_resource_bank(collection="course_resource_bank",
                                                                 resource_id=ObjectId(resource_id),
                                                                 temp_collection="temp_uploaded_files")[
                            'message']
                    each_resource['course_work_file_id'] = resource_bank_resource_id
                    s3_key_info = mongo_session.fetch_s3_key_temp_uploaded_files(collection="temp_uploaded_files",
                                                                                 condition={
                                                                                     "_id": ObjectId(resource_id)},
                                                                                 columns={"s3_key": 1})
                    if s3_key_info['status'] == 200:
                        each_resource['courseURL'] = s3_key_info['message']
                    else:
                        return {"message": "error in upload_course api", "status": 400}

        condition = {"_id": ObjectId(category_id)}
        columns = {"_id": 1, "name": 1}
        category_id_data = mongo_session.get_data_for_particular_columns_with_condition(collection='Course_Category',
                                                                                        condition=condition,
                                                                                        columns=columns)

        if category_id_data['status'] == 400:
            return {"message": "error while fetching course_category_id from db", "status": 400}
        elif len(category_id_data['message']) == 0:
            return {"message": "category not present", "status": 400}
        else:
            category = category_id_data['message'][0]['name']

        doc_to_insert = {"Course_Category": category, "subject": subject, "About_Course": course_detail,
                         "Content": content_list, "course_resources": course_resources,
                         "Instructors": Instructors, "status": "True", "show_to": institute,
                         'created_by': ObjectId(created_by), "overall_rating": 0.0,
                         'course_category_id': ObjectId(category_id),
                         "live_sess_links": live_sess_links}

        document_inserted = mongo_session.insert_documnet(collection='courses_bank', doc_to_insert=doc_to_insert)
        record_removed_temp = mongo_session.delete_record_temp_uploaded_files(collection="temp_uploaded_files",
                                                                              id_list=delete_record_list)
        if document_inserted["status"] == 400 or record_removed_temp["status"] == 400:
            return {"message": "error while adding document in courses_bank collection", "status": 400}
        elif document_inserted["status"] == 200 or record_removed_temp["status"] == 200:
            course_id = document_inserted['_id'].inserted_id
            if len(course_work) > 0 and type(course_work) == list:
                upload_status = upload_course_work_and_instance(course_work, course_id)
                # for each_course_work in course_work:
                #     each_course_work['module_name'] = "course_work"
                #     each_course_work['course_id'] = [{"_id": ObjectId(document_inserted['_id'].inserted_id)}]
                # mongo_session.insert_multiple_documents(collection='course_work_bank', doc_to_insert=course_work)
                if upload_status:
                    pass
                else:
                    return {"message": "error occurred while adding course_work", "status": 400}

            if len(assessment) > 0 and type(assessment) == list:
                for each_assessment in assessment:
                    print('course_id returned', document_inserted['_id'].inserted_id)
                    schedule_assessment_response = schedule_assessment(assessment_data=each_assessment, assessment_type="course")
                    if schedule_assessment_response == True:
                        pass
                    else:
                        return {"message": "error occurred while adding assessment", "status": 400}
            return {"message": "course seccessfully added", "status": 200}

    except Exception as e:
        print(e)
        return {"message": "error in upload_course api", "status": 400}


def subscribe_course(user_id, course_id, subscribe):
    """to subscribe the course for authorized user
    :param user_id: user subscribing the course.
    :param course_id: course to which user is subscribing.
    :param subscribe: subscription status
    :type user_id: str(mongo id)
    :type course_id: str(mongo id)
    :type subscribe: boolean"""
    course_collection = connection.courses_bank
    user_collection = connection.user_profile

    if mongo_session.check_existance_return_info(collection="courses_bank",
                                                 condition={"_id": ObjectId(course_id),
                                                            "teach_assis._id": {"$in": [ObjectId(user_id)]}}):
        raise InvalidUsage("Teaching assistant is not allowed to subscribe the same course", 400)
    room_id = mongo_session.check_existance_return_info(collection="chat_rooms",
                                                        condition={"course_id": ObjectId(course_id)})
    room_info = mongo_session.check_existance_return_info(collection='chat_rooms',
                                                          condition={"_id": ObjectId(room_id)},
                                                          whole_doc=True)

    user_info = User.User_Profile(user_id, application_type='webapp')
    email = user_info['Email']
    first_name = user_info['username']
    if not room_id:
        raise InvalidUsage('No room found')
    if type(subscribe) == bool and subscribe:
        if mongo_session.check_existance_return_info(collection="courses_bank", condition=
        {'_id': ObjectId(course_id), "subscribers.user_id": ObjectId(user_id)}):
            raise InvalidUsage("Already subscribed")
        course_query = {"_id": ObjectId(course_id)}
        course_update = {"user_id": ObjectId(user_id)}
        update_status = mongo_session.update_course_subscription(collection="courses_bank", condition=course_query,
                                                                 push_pull_inc_info={
                                                                     "$push": {"subscribers": course_update}})

        user_query = {"_id": ObjectId(user_id)}
        course_detail = {"course_id": ObjectId(course_id)}
        course_data = mongo_session.check_existance_return_info(collection="courses_bank",
                                                                condition={"_id": ObjectId(course_id)},
                                                                return_keys=['live_sessions'])
        for session in course_data['live_sessions']:
            if session.get("meeting_details") and session["meeting_details"]:
                # refresh the start_url
                # create zoom object to perform various zoom operations
                zoom_app = Zoom(jwt_api_key=session["zoom_account"]["api_key"],
                                jwt_secret_key=session["zoom_account"]["secret_key"],
                                zoom_email=session["zoom_account"]["email"])
                zoom_jwt_token = zoom_app.generate_jwt_token()
                try:
                    meeting_detail_response = zoom_app.register_participants(
                        jwt_token=zoom_jwt_token,
                        meetingID=session["meeting_details"]["meeting_id"],
                        email=email,
                        username=first_name)
                    meeting_detail_response = json.loads(meeting_detail_response.content)
                    session['subscriber_url'] = {user_id: {'url': meeting_detail_response['join_url'],
                                                           'registrant_id': meeting_detail_response['registrant_id']}}
                except:
                    continue
        print(course_data['live_sessions'])
        r = mongo_session.update_db_data(collection='courses_bank',
                                         condition=course_query,
                                         update_info={"$set": {"live_sessions": course_data['live_sessions']}})

        updating_user_profile = mongo_session.update_course_subscription(collection="user_profile",
                                                                         condition=user_query,
                                                                         push_pull_inc_info={"$push":
                                                                             {
                                                                                 "subscribed_courses": course_detail}})
        previous_subscription_info = mongo_session.get_previous_subscription_status(
            collection="user_profile",
            condition={
                "_id": ObjectId(user_id),
                "courses_once_subscribed._id": ObjectId(course_id)},
            columns={"_id": 1})

        previous_subscription_status = previous_subscription_info['message']

        if not room_info['room_members']:
            room_info['room_members'] = {}
        room_info['room_members'][user_id] = {"created_by": ObjectId(user_id),
                                              "created_at": utc_datetime_now(),
                                              "status": "active"}
        update_info = {"$set": {"room_members": room_info['room_members']}}
        response = mongo_session.update_db_data(collection='chat_rooms',
                                                condition={'_id': ObjectId(room_id)},
                                                update_info=update_info)

        if not previous_subscription_status:
            earned_coins = config.coins_given_on_course_subscription
            push_pull_inc_info = {"$inc": {"coin": earned_coins},
                                  "$push": {"courses_once_subscribed": course_query}}
            update_user_profile = mongo_session.update_coins_and_previous_subscription_info(
                collection="user_profile", condition=user_query, push_pull_inc_info=push_pull_inc_info)
        total_coin = \
            mongo_session.get_user_coin(collection="user_profile", condition=user_query, columns={"coin": 1})[
                'message']
        api_status = 200
        courses = {"Status": "Subscribed Course Successfully", "Subscription_Status": True, "coin": total_coin}

    elif type(subscribe) == bool and not subscribe:
        course_query = {"_id": ObjectId(course_id)}
        course_update = {"user_id": ObjectId(user_id)}
        course_collection.update_one(course_query, {"$pull": {"subscribers": course_update}})
        user_query = {"_id": ObjectId(user_id)}
        course_detail = {"course_id": ObjectId(course_id)}
        user_collection.update(user_query, {"$pull": {"subscribed_courses": course_detail}})
        cursor = user_collection.find(user_query)
        for data in cursor:
            total_coin = float(round(data["coin"], 2))
        if user_id in room_info['room_members']:
            del room_info['room_members'][user_id]

        update_info = {"$set": {"room_members": room_info['room_members']}}
        response = mongo_session.update_db_data(collection='chat_rooms',
                                                condition={'_id': ObjectId(room_id)},
                                                update_info=update_info)
        api_status = 200
        courses = {"Status": "UnSubscribed Course Successfully", "Subscription_Status": False, "coin": total_coin}
    else:
        api_status = 400
        courses = {"Status": "something went wrong", "Subscription_Status": None, "coin": None}
    return courses, api_status


def subscribed_course_details(user_id):
    """returns the subscribed courses for particular user"""
    collection = connection.courses_bank
    subscribed_courses = []
    try:
        course_cursor = collection.find({"Subscribed_Users.User_id": user_id}, {"Subscribed_Users": 0})

        for courses in course_cursor:
            course_id = courses["_id"]
            status_course = courses['status']
            if status_course == "False":
                continue
            else:
                pass
            #
            # rating_aggregate_cursor = collection.aggregate([{"$match": {"_id": ObjectId(course_id)}}, {"$project": {"av_rating": {"$avg": "$Rating.Rating"}}}])
            # for data in rating_aggregate_cursor:
            #     aggregate_rating = data["av_rating"]
            #     if aggregate_rating != None:
            #         aggregate_rating = float(round(aggregate_rating, 2))
            #     else:
            #         aggregate_rating = 0.0

            for course_resource in courses['course_resources']:
                if course_resource['type'] == 'file':
                    course_resource['_id'] = str(course_resource['_id'])
                    s3_link, status = s3_function.generate_presigned_url_from_s3(
                        course_resource['course_resourcesName'])
                    if s3_link and status == 200:
                        course_resource['course_resourcesName'] = s3_link
                    else:
                        course_resource['course_resourcesName'] = ""
            index = 1
            for week_record in courses['Content']:
                week_index = 'Week_' + str(index)
                index = index + 1
                for video_index in range(0, len(week_record[week_index])):
                    for week_inside_resource in week_record[week_index][video_index]['resource']:
                        if week_inside_resource['type'] == 'file':
                            week_inside_resource['_id'] = str(week_inside_resource['_id'])
                            s3_link, status = s3_function.generate_presigned_url_from_s3(
                                week_inside_resource['resourceName'])
                            if s3_link and status == 200:
                                week_inside_resource['resourceName'] = s3_link
                            else:
                                week_inside_resource['resourceName'] = ""
                for week_resource in week_record['weekly_Resourse']:
                    if week_resource['type'] == 'file':
                        week_resource['_id'] = str(week_resource['_id'])
                        s3_link, status = s3_function.generate_presigned_url_from_s3(
                            week_resource['weeklyResourse'])
                        if s3_link and status == 200:
                            week_resource['weeklyResourse'] = s3_link
                        else:
                            week_resource['weeklyResourse'] = ""

            courses["_id"] = str(courses["_id"])
            courses['Rating'] = courses.pop('overall_rating')
            if 'created_by' in list(courses.keys()):
                courses['created_by'] = str(courses['created_by'])
            if 'course_category_id' in list(courses.keys()):
                courses['course_category_id'] = str(courses['course_category_id'])

            subscribed_courses.append(courses)


    except Exception as e:
        print(e)
        subscribed_courses = ""
    return subscribed_courses


def add_feedback_subscribed_course(feedback, user_id, course_id):
    """to update feedback in course bank collection and user collection"""
    user_collection = connection.user_profile
    courses_collection = connection.courses_bank
    try:
        feedback_update = {"User_id": user_id, "Feedback": feedback, "Timestamp": datetime.datetime.today()}
        up_feedback = courses_collection.update({"_id": ObjectId(course_id), "Subscribed_Users.User_id": (user_id)},
                                                {"$push": {"Feedback": feedback_update}})
        print(up_feedback)
        if up_feedback['n'] != 1:
            data = None
            return data
        user_query = {"_id": ObjectId(user_id), "Subscribed_Courses.course_id": course_id}
        feedback_update = {"Feedback": feedback, "Week_id": None}
        user_collection.update(user_query, {"$push": {"Subscribed_Courses_Feedback": feedback_update}})
        data = course_id
    except Exception as e:
        print(e)
        data = None
    return data


def video_question(user_id, course_id, week, week_index, asked_question, question_id, video_time):
    """added the video question in video question collection"""
    user_collection = connection.video_questions
    status = user_collection.find({"Course_id": ObjectId(course_id), "Week": week, "video_index": week_index,
                                   "user_id": ObjectId(user_id)}).count() > 0
    try:
        if status == True:
            find_query = {"Course_id": ObjectId(course_id), "Week": week, "video_index": week_index,
                          "user_id": ObjectId(user_id)}
            update_query = {"question_id": ObjectId(question_id), "video_time": video_time}
            user_collection.update(find_query, {"$push": {"question_detail": update_query}})
            user_collection.update_one(find_query, {"$set": {"resume_video": video_time}})
        else:
            update_query = {"question_id": ObjectId(question_id), "video_time": video_time}
            user_collection.insert({"Course_id": ObjectId(course_id), "Week": week, "video_index": week_index,
                                    "user_id": ObjectId(user_id), "question_detail": [update_query],
                                    "resume_video": video_time})
        response = "Added question"

        return response

    except:
        response = None
        return response


def video_answer_question(user_id, course_id, week, week_index, asked_question, question_id, video_time, answer_id):
    """added the video question in video question collection"""
    user_collection = connection.video_answer_questions
    status = user_collection.find(
        {"Course_id": course_id, "Week": week, "video_index": week_index, "answer_id": answer_id}).count() > 0
    try:
        if status == True:
            find_query = {"Course_id": course_id, "Week": week, "video_index": week_index, "answer_id": answer_id}
            update_query = {"question": asked_question, "question_id": question_id, "video_time": video_time,
                            "user_id": user_id}
            user_collection.update(find_query, {"$push": {"question_detail": update_query}})
            resume_time = video_time - 10
            if resume_time < 0:
                resume_time = 0
            # user_collection.update_one(find_query,{"$set":{"resume_video":resume_time}})
        else:
            update_query = {"question": asked_question, "question_id": question_id, "video_time": video_time,
                            "user_id": user_id}
            user_collection.insert(
                {"Course_id": course_id, "Week": week, "video_index": week_index, "answer_id": answer_id,
                 "question_detail": [update_query]})
        response = "Added question"

        return response

    except:
        response = None
        return response


def report(user_id, type, description, report, report_type):
    """to add bug report in collection"""
    report_collection = connection.bug_report
    try:
        if report:
            filename = secure_filename(report.filename)
            report.save(os.path.join(filename))
            upload_file_name = type + "_" + filename
            config.s3_connection.upload_file(filename, config.bucket, upload_file_name)
            response = config.s3_connection.generate_presigned_url('get_object',
                                                                   Params={'Bucket': config.bucket,
                                                                           'Key': upload_file_name}, ExpiresIn=604800)
            os.remove(filename)
        else:
            upload_file_name = None
            response = None

        report_collection.insert(
            {"user_id": user_id, "type": type, "description": description, "attached_file": upload_file_name,
             "report_type": report_type, "status": False})

        response_message = {"status": "Reported successfully",
                            "message": "Thank You .Will try to resolve this as soon as possible", "link":
                                response}
        return response_message
    except:
        response_message = {"status": "Operation Failed",
                            "message": "Something went wrong", "link":
                                None}
        return response_message


def get_bugs(user_id, role):
    """
        Get a list of all the bug reported and only superadmin has the permission
        to view reported bugs
    """
    response = []
    if role != "super_admin":
        raise InvalidUsage("You cannot view reported bug list", 400)

    report_collection = connection.bug_report
    try:
        all_data = report_collection.find()
        for data in all_data:
            bugs_dict = {}
            bugs_dict["_id"] = str(data["_id"])
            bugs_dict['type'] = data["type"]
            bugs_dict['description'] = data["description"]
            bugs_dict['report_type'] = data["report_type"]
            bugs_dict['status'] = data["status"] if 'status' in data else False
            s3_link, s3_status = s3_function.generate_presigned_url_from_s3(data['attached_file'])
            if s3_status != 200:
                raise Exception("Error occurred while communicating with s3")
            bugs_dict["report"] = s3_link
            response.append(bugs_dict)

        response_message = {"message": "Data retrieved successfully",
                            "response": response
                            }
        return response_message
    except:
        response_message = {"status": "Operation Failed",
                            "message": "Something went wrong"
                            }
        return response_message


def report_bug_status_update(role, bug_id):
    """to update bug report status"""
    if role != "super_admin":
        raise InvalidUsage("You cannot update reported bug status", 400)
    report_collection = connection.bug_report
    try:
        filters = {'_id': ObjectId(bug_id)}
        new_value = {"$set": {'status': True}}
        report_collection.update_one(filters, new_value)

        response_message = {"message": "Updated successfully"}
        return response_message
    except:
        response_message = {"status": "Operation Failed",
                            "message": "Something went wrong"}
        return response_message


def change_course_universal(course_id, permissions):
    if not "make_course_universal" in permissions:
        raise InvalidUsage("Permission Denied", 403)
    course_data = mongo_session.check_existance_return_info(collection="courses_bank",
                                                            condition={"_id": ObjectId(course_id)},
                                                            columns={"is_public": 1},
                                                            return_keys=["is_public"])
    if not course_data:
        raise InvalidUsage(message="Course is Invalid.", status_code=400)

    if course_data["is_public"]:
        raise InvalidUsage(message="Course is already public.", status_code=400)

    update_course = mongo_session.update_db_data(collection="courses_bank",
                                                 condition={"_id": ObjectId(course_id)},
                                                 update_info={"$set": {"is_public": True}})
    if not update_course["nModified"]:
        raise InvalidUsage("Internal Server Error.", 500)

    return {"status": 200, "message": "Course is now available to all Edu-Collab users."}


def edit_course_universal(course_id, permissions, toggle):
    update_course =[]
    if not "make_course_universal" in permissions:
        raise InvalidUsage("Permission Denied", 403)
    course_data = mongo_session.check_existance_return_info(collection="courses_bank",
                                                            condition={"_id": ObjectId(course_id)},
                                                            columns={"is_public": 1},
                                                            return_keys=["is_public"])
    if not course_data:
        raise InvalidUsage(message="Course is Invalid.", status_code=400)

    if not course_data["is_public"] and toggle:
        print("#")
        update_course = mongo_session.update_db_data(collection="courses_bank",
                                                 condition={"_id": ObjectId(course_id)},
                                                 update_info={"$set": {"is_public": True}})
        message = "Course is now available to all Edu-Collab users."
    if course_data["is_public"] and not toggle:
        update_course = mongo_session.update_db_data(collection="courses_bank",
                                                 condition={"_id": ObjectId(course_id)},
                                                 update_info={"$set": {"is_public": False}})
        message = "Course is no longer public"
    if course_data["is_public"] and toggle:
        raise InvalidUsage(message="Course is already public.", status_code=400)
    if not course_data["is_public"] and  not toggle:
        raise InvalidUsage(message="Course is not public already.", status_code=400)
    if not update_course["nModified"]:
        raise InvalidUsage("Internal Server Error.", 500)

    return {"status": 200, "message": message}


def edit_user_profile(user_id, user_role, user_org, user_grade, user_org_type, user_email, password):
    """This is to make changes in user profile.
    :param user_id: id of the user whose profile is getting changed.
    :param user_role: new role slug to assign.
    :param user_org: new org slug to assign.
    :param user_grade: new grade for the user.
    :param user_org_type: new type of the org for user.
    :param user_email: new email id of the user
    :type user_id: str
    :type user_role: str slug
    :type user_org: str slug
    :type user_grade: str
    :type user_org_type: str slug
    :type user_email: str
    """
    condition = {"_id": ObjectId(user_id)}
    set_columns = {}
    new_org = ""
    previous_user_info = mongo_session.check_existance_return_info(collection="user_profile",
                                                                   condition={"_id": ObjectId(user_id)},
                                                                   columns={"_id": 1,
                                                                            "name": 1,
                                                                            "last_name": 1,
                                                                            "email": 1},
                                                                   return_keys=["_id", "name",
                                                                                "last_name", "email"])
    if not previous_user_info:
        raise InvalidUsage("Bad Request", 400)

    if not is_empty(user_role):
        find_role = mongo_session.check_existance_return_info(collection="roles",
                                                              condition={"name": user_role})
        if not find_role:
            raise InvalidUsage("Please select appropriate role to change.", 400)
        set_columns['role'] = user_role
    if not is_empty(user_org):
        find_org = mongo_session.check_existance_return_info(collection="organisations",
                                                             condition={"slug": user_org},
                                                             columns={"name": 1, "_id": 1},
                                                             return_keys=["name", "_id"])
        if not find_org:
            raise InvalidUsage("Please select appropriate organisation to change.", 400)
        set_columns['organisation'] = find_org["name"]
        set_columns['organisation_id'] = find_org["_id"]
        new_org = find_org["name"]
    if not is_empty(user_org_type):
        find_org_type = mongo_session.check_existance_return_info(collection="organisations_type",
                                                                  condition={"slug": user_org_type})

        if not find_org_type:
            raise InvalidUsage("Please select appropriate organisation type to change.", 400)
        set_columns['institute_type'] = user_org_type
    if not is_empty(user_grade):
        set_columns['grade'] = int(user_grade)

    if not is_empty(user_email):
        email_address_validation = re.match(r"^[A-Za-z0-9\.\+_-]+@[A-Za-z0-9\._-]+\.[a-zA-Z]*$", user_email)
        find_email = mongo_session.check_existance_return_info(collection="user_profile",
                                                               condition={"email": user_email,
                                                                          "_id": {"$ne": ObjectId(user_id)}})
        if find_email:
            raise InvalidUsage("Email %s already exist. Try with different email." % user_email, 409)
        if not email_address_validation:
            raise InvalidUsage("Enter a valid Email Address.", 409)
        set_columns['email'] = user_email
    if not is_empty(password):
        set_columns['Password'] = password
    user_profile_update = mongo_session.update_multiple_fields(collection='user_profile',
                                                               condition=condition,
                                                               set_columns=set_columns)
    if user_profile_update['status'] != 200:
        raise InvalidUsage("Something went wrong, Please try again later.", 400)
    if user_profile_update['document_updated'] == 1:
        return {"message": "user profile updated", "status": 200}, previous_user_info, new_org
    else:
        raise InvalidUsage("Something is wrong, Try editing again.", 400)


def upload_course_resource(user_id, resource_content, module_name):
    try:
        supported_content = config.supported_video_content_type + config.supported_image_content_type + \
                            config.other_supported_content_type
        resource_content_ext_validation = q.get_extension_validation(resource_content, supported_content)

        if resource_content_ext_validation[0]:
            unique_key = str(int(time.time())) + '-' + str(user_id)
            resource_content_type = config.supported_content_type_with_extension[resource_content_ext_validation[1]]
            resourec_content_s3_info = s3_function.upload_data_to_s3_private(resource_content, unique_key=unique_key,
                                                                             folder_name="course-resource-videos/",
                                                                             file_extension=
                                                                             resource_content_ext_validation[1],
                                                                             Content_Type=resource_content_type)
            if resourec_content_s3_info['status'] == 200:
                resource_content_s3_key = resourec_content_s3_info['s3_key']
                time_field = int(time.time())
                doc_to_insert = {"s3_key": resource_content_s3_key, "uploaded_at": time_field,
                                 "user_id": ObjectId(user_id), "module_name": module_name,
                                 "expires_at": time_field + config.course_resource_expiry_in_sec}
                insert_resource_into_db = \
                    mongo_session.insert_doc_upload_resource(collection="temp_uploaded_files", record=doc_to_insert)[
                        'resource_id']
                resource_id = str(insert_resource_into_db)

                s3_link, status = s3_function.generate_presigned_url_from_s3(resource_content_s3_key)
                if not s3_link and status != 200:
                    return "", "", 500
                return s3_link, resource_id, 200
            else:
                resource_id = ""
                return "", resource_id, 500

    except Exception as e:
        traceback.print_exc()
        resource_id = ""
        s3_link = ""
        return s3_link, resource_id, 500


def find_content_from_videos(search_text, user_id):
    """searching the content in transcriptions of videos generated beforehand."""
    courses_collection = connection.courses_bank
    topic_collection = connection.course_topics
    data = {"course_session_id": "",
            "title": "",
            "description": "",
            "resume_time": "",
            "s3_link": "",
            "video_link": "",
            "course_id": "",
            "course": "",
            "rating": "",
            "course_category_id": "",
            "course_category": "",
            "file_id": "",
            "banner_img": ""}
    response = []
    body = {
        "suggest": {
            "resource-suggest": {
                "prefix": None,
                "completion": {
                    "field": "title",
                    "size": 100
                }
            }
        }
    }
    body["suggest"]["resource-suggest"]["prefix"] = "{}*".format(search_text)
    elastic_response = es.search(index=ES_VIDEO_TRANSCRIBE,
                                 body=body)
    all_options = elastic_response["suggest"]["resource-suggest"][0]["options"]
    all_options.extend(elastic_response['hits']['hits'])

    for video_item in all_options:
        resume_time = video_item['_source']['timestamp']
        video_url = video_item['_source']['video_url']
        video_s3_key = video_url.split('/')[-2] + '/' + video_url.split('/')[-1]
        presigned_s3_link, s3_status = s3_function.generate_presigned_url_from_s3(video_s3_key)
        if s3_status != 200:
            continue
        fetch_data_course_content = mongo_session.get_all_data_for_particular_condition_fields(
            collection="global_resource_bank",
            condition={"s3_key": video_s3_key})

        sessionss = []
        if fetch_data_course_content['message'] and fetch_data_course_content['status']:
            resource_id = fetch_data_course_content['message'][0]['_id']
            resource_info = mongo_session.access_specific_fields(collection='resource_bank_instance',
                                                                 condition={'resource_id': resource_id})

            if resource_info:
                if len(resource_info) > 1:
                    for i in resource_info:
                        if i['used_at'].get('session_id'):
                            course_session_id = i['used_at']['session_id']
                            sessionss.append(ObjectId(course_session_id))

        if not fetch_data_course_content['message'] and fetch_data_course_content["status"]:
            if 'recorded-sessions' in video_s3_key:
                fetch_data_course_content = mongo_session.get_all_data_for_particular_condition_fields(
                    collection="course_sessions",
                    condition={"url": video_s3_key})
                if fetch_data_course_content['message']:
                    course_session_id = fetch_data_course_content['message'][0]['_id']
                    sessionss.append(ObjectId(course_session_id))
            else:
                fetch_data_course_content = mongo_session.get_all_data_for_particular_condition_fields(
                    collection="course_sessions",
                    condition={"url": video_s3_key})
                if fetch_data_course_content['message']:
                    for session in range(len(fetch_data_course_content['message'])):
                        course_session_id = fetch_data_course_content['message'][session]['_id']
                        sessionss.append(ObjectId(course_session_id))
                else:
                    continue

        # if not required_data['subject']:
        #     # data["resume_time"] = resume_time
        #     # data["s3_link"] = presigned_s3_link
        #     # response.append(data)
        #     continue
        # topic_index = int(required_data["week"].split("_")[-1]) - 1
        # session_index = int(required_data["week_index"])
        # course_session_id = ""
        # for course_data in courses_collection.find({"_id": required_data["course_id"]}, {"topics": 1}):
        #     topic_id = course_data["topics"][topic_index]["_id"]
        #     for topic in topic_collection.find({"_id": topic_id}, {"sessions": 1}):
        #         course_session_id = topic["sessions"][session_index]["_id"]
        # if not course_session_id:
        #     continue
        session_query = mongo_session.get_all_data_for_particular_condition_fields(
            collection="course_sessions",
            condition={"_id": {"$in": sessionss}})
        if session_query['status'] == 200 and session_query['message']:
            for i in range(len(session_query['message'])):
                session_data = session_query['message'][i]
                topic_query = mongo_session.get_data_for_particular_columns_with_condition(
                    collection="course_topics",
                    condition={"sessions._id": ObjectId(session_data["_id"])},
                    columns={"_id": 1})
                if topic_query["status"] != 200 or not topic_query['message']:
                    continue
                course_query = mongo_session.get_data_for_particular_columns_with_condition(
                    collection="courses_bank",
                    condition={"topics._id": ObjectId(topic_query["message"][0]["_id"])},
                    columns={"_id": 1,
                             "course_category": 1,
                             "course_category_id": 1,
                             "subject": 1,
                             "overall_rating": 1,
                             "banner_img": 1
                             })
                if course_query["status"] != 200 or not course_query['message']:
                    continue
                course_data = course_query["message"][0]
                course_category = mongo_session.get_all_data_for_particular_condition_fields(
                    collection="Course_Category",
                    condition={"_id": course_data["course_category_id"]})["message"][0]

                taxonomy = category_taxonomy_by_category_id(course_category)
                s3_link, s3_status = s3_function.generate_presigned_url_from_s3(course_data['banner_img'])
                if s3_status != 200:
                    continue
                data = {"course_session_id": str(session_data["_id"]),
                        "title": session_data["title"],
                        "description": session_data["description"],
                        "resume_time": resume_time,
                        "s3_link": presigned_s3_link,
                        "video_link": session_data['url'],
                        "course_id": str(course_data["_id"]),
                        "course": course_data['subject'],
                        "rating": course_data['overall_rating'],
                        "course_category_id": str(course_data["course_category_id"]),
                        "course_category": taxonomy,
                        "file_id": str(session_data["file_id"]),
                        "banner_img": s3_link}
                response.append(data)
    return response


def get_questions_info(user_id, session_id=None, course_id=None, user_specific=None):
    """
    This function get all questions for
    1. a given session for filter session_id and course_id
    2. all questions asked by user
    :param user_id: questions asked by specific user.
    :type user_id: str
    :param session_id: if question is on some course session
    :type session_id: str
    :param course_id: session belongs to which course.
    :type course_id: str
    :param user_specific: whether to find the user specific questions or not.
    :type user_specific: str(true/false)
    """
    if course_id and session_id:
        condition = {"course_id": ObjectId(course_id), "course_session_id": ObjectId(session_id)}
    elif user_specific == "true" or type(user_specific) == bool and user_specific:
        condition = {"user_id": user_id}
    else:
        raise InvalidUsage("Please check request data.", 400)
    question_data = mongo_session.access_specific_fields(collection="question_bank",
                                                         condition=condition)
    if not question_data:
        return []
    questions_list = []
    for question in question_data:
        question_image_path = ""
        question_user_type = ""
        if question.get("question_image_path") and question["question_image_path"]:
            question_image_path, status = s3_function.generate_presigned_url_from_s3(question['question_image_path'])

        if question["user_id"] == user_id:
            question_user_type = "my_question"
        elif question["user_id"] == 'celery_service':
            question_user_type = "session_question"
        else:
            question_user_type = "others_question"
        question_obj = {
            'qus_title': question['questions'],
            'question_time': question['Timestamp'],
            '_id': str(question['_id']),
            'course_category_id': str(question["course_category_id"]),
            'course_session_id': str(question["course_session_id"]) if question.get("course_session_id") else "",
            'course_id': str(question["course_id"]) if question.get("course_id") else "",
            'coins': question["reward"],
            'video_time': int(question["video_time"]) if question.get("video_time") else 0,
            'question_image_path': question_image_path,
            'answers_count': len(question["answers"]) if question["answers"] else 0,
            'course_category': question["Course_Category"],
            "question_type": question_user_type
        }
        questions_list.append(question_obj)
    return questions_list


# function to return sorted dictionary of categories
def get_categories_info(organisation, role):
    required_column_name = {"_id": 1, "name": 1, "parent_id": 1}
    cursor = mongo_session.get_all_data_for_particular_fields_course_category_api(collection='Course_Category',
                                                                                      columns=required_column_name)['message']
    organisation_data = mongo_session.get_data_for_particular_columns_with_condition(collection='organisations',
                                                                                         condition={"name": organisation},
                                                                                         columns={"_id": 1})
    org_id = organisation_data['message'][0]["_id"]
    data = []
    for cat in cursor:
        if cat['parent_id'] == 'None':
            column_name = {"_id": 1, "status": 1}
            course_count = mongo_session.get_data_for_particular_columns_with_condition(collection='courses_bank',
                                                                                        condition={"course_category_id": ObjectId(str(cat['_id'])),
                                                                                                   "status": "publish",
                                                                                                   "active": True,
                                                                                                   "organisations": {"$elemMatch": {'_id': ObjectId(str(org_id))}}},
                                                                                        columns=column_name)
            course_count_public = mongo_session.get_data_for_particular_columns_with_condition(collection='courses_bank',
                                                                                        condition={"course_category_id": ObjectId(str(cat['_id'])),
                                                                                                   "status": "publish",
                                                                                                   "active": True,
                                                                                                   "is_public":True},
                                                                                        columns=column_name)
            if course_count_public['message']:
                course_count = len(set([str(x['_id']) for x in course_count["message"]] + [str(x['_id']) for x in course_count_public["message"]]))
            else:
                course_count = len(set([str(x['_id']) for x in course_count["message"]]))
            if course_count >= 0:
                cat_obj = {
                    'cat_id': str(cat['_id']),
                    'parentName': cat['name'],
                    'subChild': [],
                    'course_count': course_count
                }
            data.append(cat_obj)
    data = sorted(data, key=lambda b: b['parentName'].lower()) 
    for cat_level_1 in data:
        for cat_1 in cursor:
            # if parent['cat_id'] == "5e9033a3c57f6d8564adaa8e":
            # print(cat_level_1)
            if str(cat_level_1['cat_id']) == cat_1['parent_id']:
                column_name = {"_id": 1, "status": 1}
                course_count = mongo_session.get_data_for_particular_columns_with_condition(collection='courses_bank',
                                                                                            condition={"course_category_id": ObjectId(str(cat_1['_id'])),
                                                                                                    "status": "publish",
                                                                                                    "active": True,
                                                                                                    "organisations": {"$elemMatch": {'_id': ObjectId(str(org_id))}}},
                                                                                            columns=column_name)
                course_count_public = mongo_session.get_data_for_particular_columns_with_condition(collection='courses_bank',
                                                                                        condition={"course_category_id": ObjectId(str(cat_1['_id'])),
                                                                                                   "status": "publish",
                                                                                                   "active": True,
                                                                                                   "is_public":True},
                                                                                        columns=column_name)
                if course_count_public['message']:
                    course_count = len(set([str(x['_id']) for x in course_count["message"]] + [str(x['_id']) for x in course_count_public["message"]]))
                else:
                    course_count = len(set([str(x['_id']) for x in course_count["message"]]))
                if course_count >= 0:
                    cat_level_1['subChild'].append({
                        'cat_id': str(cat_1['_id']),
                        'subChildName': cat_1['name'],
                        'grandChild': [],
                        'course_count': course_count
                    })
            cat_level_1['subChild'] = sorted(cat_level_1['subChild'], key=lambda z: z['subChildName'].lower())
    for cat_level_2 in data:
        if cat_level_2['subChild']:
            for cat_2 in cat_level_2['subChild']:
                for cat_3 in cursor:
                    if str(cat_2['cat_id']) == cat_3['parent_id']:
                        column_name = {"_id": 1, "status": 1}
                        course_count = mongo_session.get_data_for_particular_columns_with_condition(collection='courses_bank',
                                                                                                    condition={"course_category_id": ObjectId(str(cat_3['_id'])),
                                                                                                            "status": "publish",
                                                                                                            "active": True,
                                                                                                            "organisations": {"$elemMatch": {'_id': ObjectId(str(org_id))}}},
                                                                                                    columns=column_name)
                        course_count_public = mongo_session.get_data_for_particular_columns_with_condition(collection='courses_bank',
                                                                                        condition={"course_category_id": ObjectId(str(cat_3['_id'])),
                                                                                                    "status": "publish",
                                                                                                    "active": True,
                                                                                                    "is_public":True},
                                                                                        columns=column_name)
                        if course_count_public['message']:
                            course_count = len(set([str(x['_id']) for x in course_count["message"]] + [str(x['_id']) for x in course_count_public["message"]]))
                        else:
                            course_count = len(set([str(x['_id']) for x in course_count["message"]]))                      
                        if course_count >= 0:
                            cat_2['grandChild'].append({
                                'cat_id': str(cat_3['_id']),
                                'grandChildName': cat_3['name'],
                                'course_count': course_count})
                cat_2['grandChild'] = sorted(cat_2['grandChild'], key=lambda z: z['grandChildName'].lower())
    
    # rendering new list for student role
    # all checks added to check if course_count is greater than zero in category for all parent, child and grandChild
    # print(data)
    cat_data = []
    if role == "student":
        for parent in data:
            if len(parent["subChild"]) == 0:
                if parent['course_count'] > 0:
                    parent_data = {
                        'cat_id': str(parent['cat_id']),
                        'parentName': parent['parentName'],
                        'subChild': [],
                        'course_count': parent['course_count']
                    }
                    if not parent_data.get("cat_id") in [cat['cat_id'] for cat in cat_data]:
                        cat_data.append(parent_data)
                # else:
                #     continue
            else:
                # if parent['cat_id'] == "5e9033a3c57f6d8564adaa8e":
                    # print(parent["parentName"])
                parent_data = {
                        'cat_id': str(parent['cat_id']),
                        'parentName': parent['parentName'],
                        'subChild': [],
                        'course_count': parent['course_count']
                    }
                for child in parent["subChild"]:
                    if len(child["grandChild"]) == 0:
                        # print("1", print(child))
                        if child["course_count"] > 0:
                            # print("3")
                            parent_data['subChild'].append({
                                'cat_id': str(child['cat_id']),
                                'subChildName': child['subChildName'],
                                'grandChild': [],
                                'course_count': child['course_count']
                            })
                        # else:
                        #     continue
                        # print(parent_data.get("cat_id") in [cat['cat_id'] for cat in cat_data])
                        if not parent_data.get("cat_id") in [cat['cat_id'] for cat in cat_data]:
                            cat_data.append(parent_data)
                    else:
                        # print("2")
                        child_data = {
                            'cat_id': str(child['cat_id']),
                            'subChildName': child['subChildName'],
                            'grandChild': [],
                            'course_count': child['course_count']
                        }
                        for grandChild in child["grandChild"]:
                            if grandChild["course_count"] > 0:
                                child_data['grandChild'].append({
                                    'cat_id': str(grandChild['cat_id']),
                                    'grandChildName': grandChild['grandChildName'],
                                    'course_count': grandChild['course_count']
                                })
                                if not child_data.get("cat_id") in [pat['cat_id'] for pat in parent_data['subChild']]:
                                    parent_data['subChild'].append(child_data)
                                if not parent_data.get("cat_id") in [cat['cat_id'] for cat in cat_data]:
                                    cat_data.append(parent_data)
                            # else:
                            #     continue
        return cat_data
    else:
        return data
