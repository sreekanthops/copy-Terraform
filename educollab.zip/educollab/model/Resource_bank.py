import json
import math
import os
import re
import time

from bson import ObjectId
import config
from model.User import User_Profile
from mongo_connection import connection
from db_wrapper.tasks import Mongo
from utils.elasticsearch.resource_bank import insert_resource_elastic, update_resource_elastic
from utils.misc import is_empty
from utils.time_conversions import utc_datetime_now, str_to_utc_datetime_obj, convert_utc_to_ist

mongo_session = Mongo()
import traceback
from services.storage.s3_services import s3_storage
import json
import requests

s3_function = s3_storage()
from bs4 import BeautifulSoup
from routes.exception import InvalidUsage
from new_celery import celery_app


def insert_tags(tags):
    try:
        tag_records = []
        for t in tags:
            tag_obj = {}
            tag_obj['tag'] = t
            tag_records.append(tag_obj)

        tag_collection = connection.global_tags
        cursor = tag_collection.insert_many(tag_records)
        ids = cursor.inserted_ids
        return ids
    except Exception as e:
        traceback.print_exc()
        return "error in inserting"


def edit_resource_bank(user_id, role, resource_id, tags, description, title, instance_id):
    """This is to make changes in resource bank.
    :param user_id: id of the resource which is getting changed.
    :param title: adding title to the resource.
    :param description: adding description to the resource.
    :type user_id: str
    :type tags : str
    :type role: str
    :type resource_id: str
    """
    condition = {"_id": ObjectId(resource_id)}
    set_columns = {}
    previous_user_info = mongo_session.check_existance_return_info(collection="user_profile",
                                                                   condition={"_id": ObjectId(user_id)},
                                                                   columns={"_id": 1,
                                                                            "name": 1,
                                                                            "last_name": 1,
                                                                            "email": 1},
                                                                   return_keys=["_id", "name",
                                                                                "last_name", "email"])
    global_bank = mongo_session.check_existance_return_info(collection='global_resource_bank',
                                                            condition={
                                                                "_id": ObjectId(resource_id)
                                                            })
    if role != "super_admin" and role != "teacher":
        raise InvalidUsage("You are not authorized to edit resources", 400)

    if not is_empty(description):
        set_columns['description'] = str(description)

    if tags:
        tags_collection = mongo_session.get_all_data("global_tags")['message']
        tags_dict = dict(map(lambda x: (x['tag'], x['_id']), tags_collection))
        new_tags = []
        tag_ids = []
        for t in tags:
            if t['_id'] == t['tag']:
                if t['tag'] in tags_dict.keys():
                    tag_ids.append(ObjectId(tags_dict[t['tag']]))
                else:
                    new_tags.append(t['tag'])
            else:
                tag_ids.append(ObjectId(t['_id']))

        if new_tags:
            tag_ids.extend(insert_tags(new_tags))

        set_columns['tags'] = tag_ids
    if global_bank is None:
        course_bank_find = mongo_session.check_existance_return_info(collection='course_resource_bank',
                                                                     condition={
                                                                         "_id": ObjectId(resource_id)
                                                                     },
                                                                     whole_doc=True)
        passion_project_find = mongo_session.check_existance_return_info(collection='resources',
                                                                         condition={
                                                                             "_id": ObjectId(resource_id)
                                                                         },
                                                                         whole_doc=True)
        if course_bank_find:
            session_id = topic_id = cw_id = course_id = ""
            some = mongo_session.transfer_docs_another_collection(from_collection='course_resource_bank',
                                                                  to_collection='global_resource_bank',
                                                                  condition={"_id": ObjectId(resource_id)})
            # check whether belongs to session/course/topic/coursework resource
            course_resource = mongo_session.check_existance_return_info(collection="courses_bank",
                                                                        condition={
                                                                            "resources._id": ObjectId(resource_id)
                                                                        },
                                                                        whole_doc=True)
            topic_resource = mongo_session.check_existance_return_info(collection="course_topics",
                                                                       condition={
                                                                           "resources._id": ObjectId(resource_id)
                                                                       },
                                                                       whole_doc=True)
            session_resource = mongo_session.check_existance_return_info(collection="course_sessions",
                                                                         condition={"$or": [
                                                                             {"resources._id": ObjectId(resource_id)},
                                                                             {"file_id": ObjectId(resource_id)}
                                                                         ]},
                                                                         whole_doc=True)
            cw_resource = mongo_session.check_existance_return_info(collection="course_work_bank",
                                                                    condition={
                                                                        "course_work_resources.resource_id": ObjectId(
                                                                            resource_id)
                                                                    },
                                                                    whole_doc=True)
            doc_to_insert = {
                "resource_id": ObjectId(resource_id),
                "tags": set_columns['tags'],
                "description": description,
                "title": title,
                "module": course_bank_find['module_name'],
                "used_at": "",
                "updated_at": utc_datetime_now(),
                "updated_by": ObjectId(user_id),
            }
            resp_id = mongo_session.insert_documnet(collection="resource_bank_instance",
                                                    doc_to_insert=doc_to_insert)

            def update_resources(collection, condition, type_resources):
                resources = [str(resource['_id']) for resource in type_resources['resources']]
                if resource_id in resources:
                    ind = resources.index(resource_id)
                    type_resources['resources'][ind]['instance_id'] = resp_id['_id'].inserted_id
                    update_info = {"$set": {"resources": type_resources['resources']}}
                    mongo_session.update_db_data(collection=collection,
                                                 condition=condition,
                                                 update_info=update_info)

            if course_resource:
                update_resources(collection="courses_bank",
                                 condition={'_id': course_resource['_id']},
                                 type_resources=course_resource)

            if topic_resource:
                update_resources(collection="course_topics",
                                 condition={'_id': topic_resource['_id']},
                                 type_resources=topic_resource)

            if session_resource:
                update_resources(collection="course_sessions",
                                 condition={'_id': session_resource['_id']},
                                 type_resources=session_resource)

            if cw_resource:
                resources = [str(resource['resource_id']) for resource in cw_resource['course_work_resources']]
                if resource_id in resources:
                    ind = resources.index(resource_id)
                    cw_resource['course_work_resources'][ind]['instance_id'] = resp_id['_id'].inserted_id
                    update_info = {"$set": {"resources": cw_resource['course_work_resources']}}
                    mongo_session.update_db_data(collection="course_work_bank",
                                                 condition={"_id": cw_resource['_id']},
                                                 update_info=update_info)
            # add this doc to instance collection
            # add the instance id to course/topic/session/pp/coursework resources
        if passion_project_find:
            some = mongo_session.transfer_docs_another_collection(from_collection='resources',
                                                                  to_collection='global_resource_bank',
                                                                  condition={"_id": ObjectId(resource_id)})
            doc_to_insert = {
                "resource_id": ObjectId(resource_id),
                "tags": set_columns['tags'],
                "description": description,
                "title": title,
                "module": passion_project_find['module_name'] if passion_project_find[
                    'module_name'] else "passion_project",
                "used_at": "",
                "updated_at": utc_datetime_now(),
                "updated_by": ObjectId(user_id),
            }
            resp_id = mongo_session.insert_documnet(collection="resource_bank_instance",
                                                    doc_to_insert=doc_to_insert)
        body = {}
        if title is not None:
            body['title'] = title
        if set_columns['tags'] is not None:
            body['tags'] = set_columns['tags']
        if description is not None:
            body['description'] = description
        update_resource_elastic(body, resource_id)
    if global_bank:
        # check the instance id and the resource id
        # update the doc related to instance id
        # make changes in all resources api

        if description is not None:
            set_columns['description'] = description

        if title is not None:
            set_columns['title'] = title

        condition = {"_id": ObjectId(instance_id)}
        resource_check = mongo_session.check_existance_return_info(collection='resource_bank_instance',
                                                                   condition=condition,
                                                                   whole_doc=True)
        res_check = mongo_session.check_existance_return_info(collection='global_resource_bank',
                                                              condition={"_id": resource_check['resource_id']},
                                                              whole_doc=True)
        # if str(resource_check['updated_by']) != user_id and role != 'super_admin' and \
        #         str(res_check['user_id']) != user_id:
        #     raise InvalidUsage("You are not authorised to change the title", 400)
        if resource_check:
            resource_update = mongo_session.update_multiple_fields(collection='resource_bank_instance',
                                                                   condition=condition,
                                                                   set_columns=set_columns)
            update_resource_elastic(set_columns, resource_id)
    return {"message": "Updated successfully"}


def delete_resource_bank(user_id, role, resource_id, instance_id):
    """This is to make changes in resource bank.
    :param user_id: id of the resource which is getting changed.
    :type user_id: str
    :param resource_id: id of the resource which has to be deleted
    type resource_id: str
    """
    condition = {"_id": ObjectId(resource_id)}
    set_columns = {}
    previous_user_info = mongo_session.check_existance_return_info(collection="user_profile",
                                                                   condition={"_id": ObjectId(user_id)},
                                                                   columns={"_id": 1,
                                                                            "name": 1,
                                                                            "last_name": 1,
                                                                            "email": 1},
                                                                   return_keys=["_id", "name",
                                                                                "last_name", "email"])
    if not previous_user_info:
        raise InvalidUsage("Bad Request", 400)

    if not is_empty(role):
        find_role = mongo_session.check_existance_return_info(collection="roles",
                                                              condition={"name": role})
        if not find_role:
            raise InvalidUsage("Please select appropriate role to change.", 400)

        creator = ""
        main_creator = ""
        course_resource_bank = mongo_session.check_existance_return_info(collection="course_resource_bank",
                                                                         condition={
                                                                             "_id": ObjectId(resource_id)
                                                                         },
                                                                         whole_doc=True)
        if course_resource_bank:
            creator = str(course_resource_bank['user_id'])
        if instance_id is not None:
            resource_bank_instance = mongo_session.check_existance_return_info(collection="resource_bank_instance",
                                                                               condition={
                                                                                   "_id": ObjectId(instance_id),
                                                                                   "resource_id": ObjectId(resource_id)
                                                                               },
                                                                               whole_doc=True)
            global_resource_bank = mongo_session.check_existance_return_info(collection="global_resource_bank",
                                                                             condition={
                                                                                 "_id": ObjectId(resource_id),
                                                                             },
                                                                             whole_doc=True)
            if global_resource_bank:
                main_creator = str(global_resource_bank['user_id'])
            creator = str(resource_bank_instance['updated_by'])
        if role == "super_admin" or main_creator == user_id or creator == user_id:
            if instance_id is None:
                course_resource = mongo_session.check_existance_return_info(collection="courses_bank",
                                                                            condition={
                                                                                "resources._id": ObjectId(resource_id)
                                                                            },
                                                                            whole_doc=True)
                topic_resource = mongo_session.check_existance_return_info(collection="course_topics",
                                                                           condition={
                                                                               "resources._id": ObjectId(resource_id)
                                                                           },
                                                                           whole_doc=True)
                session_resource = mongo_session.check_existance_return_info(collection="course_sessions",
                                                                             condition={"$or": [
                                                                                 {"resources._id": ObjectId(
                                                                                     resource_id)},
                                                                                 {"file_id": ObjectId(resource_id)}
                                                                             ]},
                                                                             whole_doc=True)
                cw_resource = mongo_session.check_existance_return_info(collection="course_work_bank",
                                                                        condition={
                                                                            "course_work_resources.resource_id": ObjectId(
                                                                                resource_id)
                                                                        },
                                                                        whole_doc=True)

                if course_resource:
                    for res in course_resource['resources']:
                        if res['_id'] == resource_id:
                            course_resource['resources'].remove(res)
                    update_condition = {"$set": {"resources": course_resource['resources']}}
                    mongo_session.update_db_data(collection='courses_bank',
                                                 condition={"_id": ObjectId(course_resource['_id'])},
                                                 update_info=update_condition)

                if topic_resource:
                    for res in topic_resource:
                        if res['_id'] == resource_id:
                            topic_resource.remove(res)
                    update_condition = {"$set": {"resources": topic_resource['resources']}}
                    mongo_session.update_db_data(collection='course_topics',
                                                 condition={"_id": ObjectId(topic_resource['_id'])},
                                                 update_info=update_condition)

                if session_resource:
                    for res in session_resource:
                        if res['_id'] == resource_id:
                            session_resource.remove(res)
                    update_condition = {"$set": {"resources": session_resource['resources']}}
                    mongo_session.update_db_data(collection='course_sessions',
                                                 condition={"_id": ObjectId(session_resource['_id'])},
                                                 update_info=update_condition)

                if cw_resource:
                    for res in cw_resource:
                        if res['resource_id'] == resource_id:
                            cw_resource.remove(res)
                    update_condition = {"$set": {"resources": cw_resource['resources']}}
                    mongo_session.update_db_data(collection='course_work_bank',
                                                 condition={"_id": ObjectId(cw_resource['_id'])},
                                                 update_info=update_condition)
            else:
                update_condition = {"$set": {"deactivate": True}}
                resource_bank_instance = mongo_session.update_db_data(collection="resource_bank_instance",
                                                                      condition={
                                                                          "_id": ObjectId(instance_id),
                                                                          "resource_id": ObjectId(
                                                                              resource_id)
                                                                      },
                                                                      update_info=update_condition)

                course_level = mongo_session.check_existance_return_info(collection='courses_bank',
                                                                         condition={"resources":
                                                                             {"$elemMatch": {"$and": [
                                                                                 {"_id": ObjectId(resource_id)},
                                                                                 {"schedule_id": ObjectId(instance_id)}
                                                                             ]}}},
                                                                         whole_doc=True)
                topic_level = mongo_session.check_existance_return_info(collection='course_topics',
                                                                        condition={"resources":
                                                                            {"$elemMatch": {"$and": [
                                                                                {"_id": ObjectId(resource_id)},
                                                                                {"schedule_id": ObjectId(instance_id)}
                                                                            ]}}},
                                                                        whole_doc=True)
                session_level = mongo_session.check_existance_return_info(collection='course_sessions',
                                                                          condition={"resources":
                                                                              {"$elemMatch": {"$and": [
                                                                                  {"_id": ObjectId(resource_id)},
                                                                                  {"schedule_id": ObjectId(instance_id)}
                                                                              ]}}},
                                                                          whole_doc=True)
                cw_level = mongo_session.check_existance_return_info(collection='course_work_bank',
                                                                     condition={"resources":
                                                                         {"$elemMatch": {"$and": [
                                                                             {"resource_id": ObjectId(resource_id)},
                                                                             {"schedule_id": ObjectId(instance_id)}
                                                                         ]}}},
                                                                     whole_doc=True)

                if course_level:
                    for res in course_level['resources']:
                        if res['_id'] == resource_id:
                            course_level['resources'].remove(res)
                    update_condition = {"$set": {"resources": course_level['resources']}}
                    mongo_session.update_db_data(collection='courses_bank',
                                                 condition={"_id": ObjectId(course_level['_id'])},
                                                 update_info=update_condition)

                if topic_level:
                    for res in topic_level:
                        if res['_id'] == resource_id:
                            topic_level.remove(res)
                    update_condition = {"$set": {"resources": topic_level['resources']}}
                    mongo_session.update_db_data(collection='course_topics',
                                                 condition={"_id": ObjectId(topic_level['_id'])},
                                                 update_info=update_condition)

                if session_level:
                    for res in session_level:
                        if res['_id'] == resource_id:
                            session_level.remove(res)
                    update_condition = {"$set": {"resources": session_level['resources']}}
                    mongo_session.update_db_data(collection='course_sessions',
                                                 condition={"_id": ObjectId(session_level['_id'])},
                                                 update_info=update_condition)

                if cw_level:
                    for res in cw_level:
                        if res['resource_id'] == resource_id:
                            cw_level.remove(res)
                    update_condition = {"$set": {"resources": cw_level['resources']}}
                    mongo_session.update_db_data(collection='course_work_bank',
                                                 condition={"_id": ObjectId(cw_level['_id'])},
                                                 update_info=update_condition)

            return {"message": "resource deleted", "status": 200}
        else:
            raise InvalidUsage("You are not authorised to delete this resource.", 400)
    else:
        raise InvalidUsage("Please  appropriate role to change.", 400)


def get_all_resources(file_type, page, user_id, role):
    all_resources = []
    if file_type == 'video':
        search_text = ""
        for extension in config.supported_video_content_type:
            search_text = search_text + "|"
        search_text = search_text.strip("|")

    elif file_type == 'image':
        search_text = ""
        for extension in config.supported_image_content_type:
            search_text = search_text + "|"
        search_text = search_text.strip("|")

    elif file_type == 'audio':
        audio_types = ['.mp3', '.wav']
        search_text = ""
        for extension in audio_types:
            search_text = search_text + "|"
        search_text = search_text.strip("|")

    elif file_type == 'file':
        search_text = ""
        for extension in config.other_supported_content_type:
            if extension != '.ipynb' or extension != '.py':
                search_text = search_text + extension + "|"
        search_text = search_text.strip("|")

    elif file_type == 'python':
        search_text = ""
        python_extensions = ['.py', '.ipynb']
        for extension in python_extensions:
            search_text = search_text + extension.strip('.') + "|"
        search_text = search_text.strip("|")

    else:
        search_text = ""

    def retrieve_resources(course_resource_data, field=None, where=None):
        resp_resources = []
        if course_resource_data:
            resources_id = []
            for record in course_resource_data['message']:
                for resource in record['resources']:
                    if resource['_id'] != "":
                        resources_id.append(resource['_id'])
                    if resource.get('instance_id'):
                        resource['instance_id'] = str(resource['instance_id'])
                    if resource.get('schedule_id'):
                        resource['schedule_id'] = str(resource['schedule_id'])

            course_resource_bank = mongo_session.access_specific_fields(collection='course_resource_bank',
                                                                        condition={"_id": {"$in": resources_id}})
            if course_resource_bank:
                cr_dict = {}
                user_dict = {}
                created_by_list = [resc['user_id'] for resc in course_resource_bank]

                user_info = mongo_session.access_specific_fields(collection='user_profile',
                                                                 condition={"_id": {"$in": created_by_list}},
                                                                 return_keys=['username', "_id"])
                for info in user_info:
                    user_dict[str(info['_id'])] = info['username']

                for resc in course_resource_bank:
                    if str(resc['user_id']) in user_dict:
                        resc['user_oid'] = str(resc['user_id'])
                        resc['user_id'] = user_dict[str(resc['user_id'])]
                        cr_dict[str(resc['_id'])] = resc

                for resources in course_resource_data['message']:
                    for res in resources['resources']:
                        res['history'] = []
                        if str(res['_id']) in cr_dict:
                            res['_id'] = str(res['_id'])
                            if res.get('instance_id'):
                                res['instance_id'] = str(res['instance_id'])
                            if res.get('schedule_id'):
                                res['schedule_id'] = str(res['schedule_id'])
                            now = time.strftime('%Y-%m-%d %H:%M',
                                                time.localtime(int(cr_dict[str(res['_id'])]['uploaded_at'])))
                            if res['title'] == "":
                                res['title'] = resources[field]

                            if where == 'topic':
                                find_course = mongo_session.check_existance_return_info(collection='courses_bank',
                                                                                        condition={
                                                                                            'topics._id': ObjectId(
                                                                                                resources['_id'])
                                                                                        },
                                                                                        return_keys=['_id', 'subject',
                                                                                                     'created_by'])
                                user = User_Profile(str(find_course['created_by']))[0]['username'] if find_course else ""
                                res['history'].append({
                                                       'topic_title': str(resources[field]),
                                                       'course_title': str(
                                                           find_course['subject']) if find_course else "",
                                                        'session_title': "",
                                                       'created_by': user if user else "",
                                                       'level_type': 'topic_level',
                                                       'course_work': ''
                                                       })

                            if where == 'session':
                                find_topic = mongo_session.check_existance_return_info(collection='course_topics',
                                                                                       condition={
                                                                                           'sessions._id': ObjectId(
                                                                                               resources['_id'])
                                                                                       },
                                                                                       return_keys=['_id', 'title'])
                                if find_topic:
                                    find_course = mongo_session.check_existance_return_info(collection='courses_bank',
                                                                                            condition={
                                                                                                'topics._id': ObjectId(
                                                                                                    find_topic['_id'])
                                                                                            },
                                                                                            return_keys=['_id', 'subject',
                                                                                                         'created_by'])
                                    user = User_Profile(str(find_course['created_by']))[0]['username'] if find_course else ""
                                res['history'].append({'session_title': str(resources[field]),
                                                       'course_title': str(
                                                           find_course['subject']) if find_course else "",
                                                       'topic_title': str(find_topic['title']) if find_topic else "",
                                                       'created_by': user if user else "",
                                                       'level_type': 'session_level',
                                                       'course_work': ''
                                                       })

                            if where == 'course':
                                user = User_Profile(str(resources['created_by']))[0]['username'] if resources else ""
                                res['history'].append({'course_title': str(resources[field]),
                                                       'topic_title': "",
                                                       "session_title": "",
                                                       'created_by': user if user else "",
                                                       'level_type': 'course_level',
                                                       'course_work': ''})

                            find_global = mongo_session.check_existance_return_info(collection='global_resource_bank',
                                                                                    condition={
                                                                                        "_id": ObjectId(res['_id'])})
                            res['time'] = str_to_utc_datetime_obj(now, '%Y-%m-%d %H:%M')
                            res['time'] = convert_utc_to_ist(res['time']).replace(tzinfo=None).isoformat(' ')
                            created_by = str(cr_dict[str(res['_id'])]['user_oid'])
                            res['created_by'] = str(cr_dict[str(res['_id'])]['user_id'])
                            res['description'] = ""
                            res['tags'] = []
                            res['url'], status = s3_function.generate_presigned_url_from_s3(res['url'])
                        else:
                            created_by = ""
                            res['created_by'] = ""
                            res['time'] = ""
                            res['description'] = ""
                            res['tags'] = []
                        edit_rights = False
                        delete_rights = False
                        if str(res['created_by']) == user_id or role == "super_admin":
                            edit_rights = True
                            delete_rights = True
                        res['edit_rights'] = edit_rights
                        res['delete_rights'] = delete_rights
                        resp_resources.append(res)
                    del resources['_id']
        return resp_resources

    # retrieve course resources from courses_bank
    course_resource_info = mongo_session.get_all_data_for_particular_fields(collection='courses_bank',
                                                                            columns={'resources': 1,
                                                                                     'subject': 1,
                                                                                     '_id': 1,
                                                                                     'created_by': 1})
    course_resources = retrieve_resources(course_resource_info, field='subject', where='course')

    # retrieve resources from course_topics
    course_topic_info = mongo_session.get_all_data_for_particular_fields(collection='course_topics',
                                                                         columns={'resources': 1,
                                                                                  'title': 1,
                                                                                  '_id': 1})
    topic_resources = retrieve_resources(course_topic_info, field='title', where='topic')
    # retrieve resources from course_sessions
    course_sessions_info = mongo_session.get_all_data_for_particular_fields(collection='course_sessions',
                                                                            columns={'resources': 1,
                                                                                     'title': 1,
                                                                                     'description': 1,
                                                                                     'url': 1,
                                                                                     '_id': 1})
    all_videos = []
    for session_videos in course_sessions_info['message']:
        session_videos['url'], status = s3_function.generate_presigned_url_from_s3(session_videos['url'])
        session_videos['_id'] = str(session_videos['_id'])
        find_topic = mongo_session.check_existance_return_info(collection='course_topics',
                                                               condition={'sessions._id': ObjectId(session_videos['_id'])
                                                                          },
                                                               return_keys=['_id', 'title'])
        find_course = ""
        if find_topic:
            find_course = mongo_session.check_existance_return_info(collection='courses_bank',
                                                                    condition={'topics.id': ObjectId(find_topic['_id'])},
                                                                    return_keys=['_id', 'subject', 'created_by'])

        session_videos['created_by'] = ""
        session_videos['time'] = ""
        session_videos['tags'] = []
        data = {}
        data['url'] = session_videos['url']
        data['_id'] = str(session_videos['_id'])
        data['history'] = []
        data['history'].append({
                                'session_title': session_videos['title'],
                                'topic_title': find_topic['title'] if find_topic else "",
                                'course_title': find_course['subject'] if find_course else "",
                                'created_by': "",
                                'level_type': 'session_level',
                                'course_work': ''})
        data['created_by'] = ""
        data['time'] = ""
        data['tags'] = []
        data['title'] = session_videos['title']
        data['description'] = session_videos['description']
        all_videos.append(data)
    session_resources = retrieve_resources(course_sessions_info, field='title', where='session')
    # retrieve resources from course_works
    course_work_resources = mongo_session.get_all_data_for_particular_fields(collection='course_work_bank',
                                                                             columns={'course_work_resources': 1,
                                                                                      'courseWorkTitle': 1,
                                                                                      '_id': 1})

    all_resources = []
    if course_work_resources:
        resources_id = []
        for record in course_work_resources['message']:
            for resource in record['course_work_resources']:
                if resource['resource_id'] != "":
                    resources_id.append(ObjectId(resource['resource_id']))

        course_resource_bank = mongo_session.access_specific_fields(collection='course_resource_bank',
                                                                    condition={"_id": {"$in": resources_id}})
        if course_resource_bank:
            cr_dict = {}
            user_dict = {}
            created_by_list = [resc['user_id'] for resc in course_resource_bank]

            user_info = mongo_session.access_specific_fields(collection='user_profile',
                                                             condition={"_id": {"$in": created_by_list}},
                                                             return_keys=['username', "_id"])
            for info in user_info:
                user_dict[str(info['_id'])] = info['username']

            for resc in course_resource_bank:
                if str(resc['user_id']) in user_dict:
                    resc['user_oid'] = str(resc['user_id'])
                    resc['user_id'] = user_dict[str(resc['user_id'])]
                    cr_dict[str(resc['_id'])] = resc

            for resources in course_work_resources['message']:
                all_instances = mongo_session.access_specific_fields(collection='course_work_instances',
                                                                     condition={
                                                                         'course_work_id': ObjectId(resources['_id'])
                                                                     },
                                                                     return_keys=['_id'])
                if all_instances:
                    cw_insts = [ObjectId(cw['_id']) for cw in all_instances]
                    course_find = mongo_session.access_specific_fields(collection='courses_bank',
                                                                       condition={
                                                                           'course_work.schedule_id': {'$in': cw_insts},
                                                                           'course_work._id': ObjectId(
                                                                               resources['_id'])},
                                                                       return_keys=['_id', 'subject', 'created_by'])

                    if course_find:
                        for c in range(len(course_find)):
                            course_find[c]['_id'] = str(course_find[c]['_id'])
                            course_find[c]['created_by'] = User_Profile(str(course_find[c]['created_by']))[0]['username']
                            course_find[c]['level_type'] = 'course_level'
                            course_find[c]['session_title'] = ""
                            course_find[c]['topic_title'] = ""
                    topic_find = mongo_session.access_specific_fields(collection='course_topics',
                                                                      condition={
                                                                          'course_work.schedule_id': {'$in': cw_insts},
                                                                          'course_work._id': ObjectId(
                                                                              resources['_id'])},
                                                                      return_keys=['_id', 'title'])
                    if topic_find:
                        topic_ids = [ObjectId(t_id['_id']) for t_id in topic_find]
                        course_topic_find = mongo_session.access_specific_fields(collection='courses_bank',
                                                                                 condition={
                                                                                     'topics._id': {"$in": topic_ids}},
                                                                                 return_keys=['_id', 'subject',
                                                                                              'topics', 'created_by'])
                        if course_topic_find:
                            for d in range(len(course_topic_find)):
                                course_topic_find[d]['topics'] = [str(t['_id']) for t in course_topic_find[d]['topics']]
                                course_topic_find[d]['created_by'] = User_Profile(str(course_topic_find[d]['created_by']))[0]['username']

                        for c in range(len(topic_find)):
                            topic_find[c]['_id'] = str(topic_find[c]['_id'])
                            topic_find[c]['level_type'] = 'topic_level'
                            topic_find[c]['session_title'] = ""
                            flag = False
                            if course_topic_find:
                                for d in course_topic_find:
                                    if topic_find[c]['_id'] in d['topics']:
                                        flag = True
                                        topic_find[c]['course_title'] = d['subject']
                                        topic_find[c]['created_by'] = d['created_by']
                            if not flag:
                                topic_find[c]['course_title'] = ""
                                topic_find[c]['created_by'] = d['created_by']
                for res in resources['course_work_resources']:
                    if str(res['resource_id']) in cr_dict:
                        res['resource_id'] = str(res['resource_id'])
                        if res.get('instance_id'):
                            res['instance_id'] = str(res['instance_id'])
                        if res.get('schedule_id'):
                            res['schedule_id'] = str(res['schedule_id'])
                        now = time.strftime('%Y-%m-%d %H:%M',
                                            time.localtime(int(cr_dict[str(res['resource_id'])]['uploaded_at'])))
                        res['time'] = str_to_utc_datetime_obj(now, '%Y-%m-%d %H:%M')
                        res['time'] = convert_utc_to_ist(res['time']).replace(tzinfo=None).isoformat(' ')
                        if res['resource_title'] == "":
                            res['resource_title'] = resources['courseWorkTitle']
                        if all_instances:
                            if course_find:
                                res['history'] = course_find
                            if topic_find:
                                res['history'] = topic_find
                        created_by = str(cr_dict[str(res['resource_id'])]['user_oid'])
                        res['created_by'] = str(cr_dict[str(res['resource_id'])]['user_id'])
                        res['url'], status = s3_function.generate_presigned_url_from_s3(res['resource_url'])
                    else:
                        created_by = ""
                        res['created_by'] = ""
                        res['url'], status = s3_function.generate_presigned_url_from_s3(res['resource_url'])
                        res['time'] = ""
                    edit_rights = False
                    delete_rights = False
                    if str(res['created_by']) == user_id or role == "super_admin":
                        edit_rights = True
                        delete_rights = True
                    res['edit_rights'] = edit_rights
                    res['delete_rights'] = delete_rights
                    res['description'] = ""
                    res['tags'] = []
                    res['_id'] = str(res['resource_id'])
                    del res['resource_url']
                    del res['resource_id']
                    res['title'] = res['resource_title']
                    res['type'] = res['resource_type']
                    del res['resource_title']
                    del res['resource_type']
                    all_resources.append(res)

        # extract resources from global bank
    global_resource_bank = mongo_session.get_all_data(collection='global_resource_bank')
    if global_resource_bank['message']:
        cr_dict = {}
        user_dict = {}
        created_by_list = [resc['user_id'] for resc in global_resource_bank['message']]
        resources_id = [ObjectId(resc['_id']) for resc in global_resource_bank['message']]
        urls = [resc['s3_key'] for resc in global_resource_bank['message']]
        url_dict = {}
        for res, url in zip(resources_id, urls):
            url_dict[str(res)] = url

        user_info = mongo_session.access_specific_fields(collection='user_profile',
                                                         condition={"_id": {"$in": created_by_list}},
                                                         return_keys=['username', "_id"])
        for info in user_info:
            user_dict[str(info['_id'])] = info['username']

        for resc in global_resource_bank['message']:
            if str(resc['user_id']) in user_dict:
                resc['user_oid'] = str(resc['user_id'])
                resc['user_id'] = user_dict[str(resc['user_id'])]
                cr_dict[str(resc['_id'])] = resc

        fetch_meta = mongo_session.access_specific_fields(collection='resource_bank_instance',
                                                          condition={'resource_id': {"$in": resources_id},
                                                                     'used_at': "",
                                                                     'deactivate': {"$exists": False}})
        if fetch_meta:
            for data in fetch_meta:
                creator_list = []
                creator = mongo_session.check_existance_return_info(collection='global_resource_bank',
                                                                    condition={"_id": data['resource_id']},
                                                                    return_keys=['user_id'])
                all_uses = mongo_session.access_specific_fields(collection='resource_bank_instance',
                                                                condition={'resource_id': data['resource_id'],
                                                                           'used_at': {'$ne': ""}})
                data['history'] = []
                if all_uses:
                    for use in all_uses:
                        used_at = use['used_at']
                        if used_at.get('passion_project_id'):
                            find_pp = mongo_session.check_existance_return_info(collection='passion_projects',
                                                                                condition={
                                                                                    '_id': ObjectId(
                                                                                        used_at['passion_project_id'])
                                                                                },
                                                                                return_keys=['project_title'])
                            user = ""
                            if find_pp:
                                user = User_Profile(str(use['updated_by']))[0]['username'] if find_pp else ""
                            data['history'].append({
                                'session_title': "",
                                'topic_title': "",
                                'course_title': "",
                                'created_by': user if user else "",
                                'level_type': 'passion_project_level',
                                'course_work': '',
                                'passion_project_title': find_pp['project_title'] if find_pp else ""
                            })
                        if used_at.get('session_id'):
                            find_topic = mongo_session.check_existance_return_info(collection='course_topics',
                                                                                   condition={
                                                                                       'sessions._id': ObjectId(
                                                                                           used_at['session_id'])
                                                                                   },
                                                                                   return_keys=['_id', 'title'])
                            find_course = ""
                            user = ""
                            if find_topic:
                                find_course = mongo_session.check_existance_return_info(collection='courses_bank',
                                                                                        condition={
                                                                                            'topics._id': ObjectId(
                                                                                                find_topic['_id'])
                                                                                        },
                                                                                        return_keys=['_id', 'subject'])
                                user = User_Profile(str(use['updated_by']))[0]['username'] if find_course else ""
                            data['history'].append({
                                                    'session_title': use['title'],
                                                    'topic_title': find_topic['title'] if find_topic else "",
                                                    'course_title': find_course['subject'] if find_course else "",
                                                    'created_by': user if user else "",
                                                    'level_type': 'session_level',
                                                    'course_work': ''})
                        if used_at.get('course_id'):
                            find_course = mongo_session.check_existance_return_info(collection='courses_bank',
                                                                                    condition={
                                                                                        '_id': ObjectId(
                                                                                            used_at['course_id'])
                                                                                    },
                                                                                    return_keys=['_id', 'subject'])
                            user = User_Profile(str(use['updated_by']))[0]['username'] if find_course else ""
                            data['history'].append({
                                                    'session_title': "",
                                                    'topic_title': "",
                                                    'course_title': find_course['subject'] if find_course else "",
                                                    'created_by': user if user else "",
                                                    'level_type': 'course_level',
                                                    'course_work': ''})
                        if used_at.get('topic_id'):
                            find_topic_title = mongo_session.check_existance_return_info(collection='course_topics',
                                                                                         condition={
                                                                                             '_id': ObjectId(
                                                                                                 used_at['topic_id'])
                                                                                         },
                                                                                         return_keys=['title'])
                            find_course = mongo_session.check_existance_return_info(collection='courses_bank',
                                                                                    condition={
                                                                                        'topics._id': ObjectId(
                                                                                            used_at['topic_id'])
                                                                                    },
                                                                                    return_keys=['_id', 'subject'])
                            user = User_Profile(str(use['updated_by']))[0]['username'] if find_course else ""
                            data['history'].append({
                                                    'session_title': "",
                                                    'topic_title': find_topic_title['title'],
                                                    'course_title': find_course['subject'] if find_course else "",
                                                    'created_by': user if user else "",
                                                    'level_type': 'topic_level',
                                                    'course_work': ''})
                        if used_at.get('course_work_id'):
                            find_topic = mongo_session.check_existance_return_info(collection='course_topics',
                                                                                   condition={
                                                                                       'course_work._id': ObjectId(
                                                                                           used_at['course_work_id'])
                                                                                   },
                                                                                   return_keys=['_id', 'title'])
                            find_course = mongo_session.check_existance_return_info(collection='courses_bank',
                                                                                    condition={
                                                                                        'course_work._id': ObjectId(
                                                                                            used_at['course_work_id'])
                                                                                    },
                                                                                    return_keys=['_id', 'subject'
                                                                                                 ])
                            course_work_subject = mongo_session.access_specific_fields(collection="course_work_bank",
                                                                                       condition={'_id':ObjectId(used_at['course_work_id'])},
                                                                                       return_keys=['courseWorkTitle'])[0]['courseWorkTitle']
                            user = User_Profile(str(use['updated_by']))[0]['username'] if find_course else ""
                            if find_topic:
                                find_course_t = mongo_session.check_existance_return_info(collection='courses_bank',
                                                                                          condition={
                                                                                              'topics._id': ObjectId(
                                                                                                  find_topic['_id'])
                                                                                          },
                                                                                          return_keys=['_id',
                                                                                                       'subject'])
                                user = User_Profile(str(use['updated_by']))[0]['username'] if find_course else ""
                                data['history'].append({
                                                        'session_title': "",
                                                        'topic_title': find_topic['title'] if find_topic else "",
                                                        'course_title': find_course_t[
                                                            'subject'] if find_course_t else "",
                                                        'created_by': user if user else "",
                                                        'level_type': 'topic_level',
                                                        'course_work': course_work_subject
                                                        })
                            if find_course:
                                data['history'].append({
                                                        'session_title': "",
                                                        'topic_title': "",
                                                        'course_title': find_course['subject'] if find_course else "",
                                                        'created_by': user if user else "",
                                                        'level_type': 'course_level',
                                                        'course_work': course_work_subject})
                            if not find_topic and not find_course:
                                data['history'].append({
                                                        'session_title': "",
                                                        'topic_title': "",
                                                        'course_title': '',
                                                        'created_by': user if user else "",
                                                        'level_type': '',
                                                        'course_work': course_work_subject})
                creator_list.append(str(creator['user_id']))
                if str(data['resource_id']) in url_dict:
                    data['url'], status = s3_function.generate_presigned_url_from_s3(url_dict[str(data['resource_id'])])
                else:
                    data['url'] = ""
                data['_id'] = str(data['_id'])
                data['instance_id'] = str(data['_id'])
                data['_id'] = str(data['resource_id'])
                creator_list.append(str(data['updated_by']))
                edit_rights = False
                delete_rights = False
                for user in creator_list:
                    if str(user) == user_id or role == "super_admin":
                        edit_rights = True
                        delete_rights = True

                data['created_by'] = User_Profile(data['updated_by'], application_type='webapp')['username']
                data['time'] = data['updated_at']
                data['time'] = convert_utc_to_ist(data['time']).replace(tzinfo=None).isoformat(' ')
                all_tags = []
                for tag in data['tags']:
                    tags_names = mongo_session.check_existance_return_info(collection='global_tags',
                                                                           condition={'_id': ObjectId(tag)},
                                                                           return_keys=['tag', '_id'])
                    tags_names_ques = mongo_session.check_existance_return_info(collection='question_tags',
                                                                                condition={'_id': ObjectId(tag)},
                                                                                return_keys=['tag', '_id'])
                    if tags_names and not tags_names_ques:
                        d = {"tag": tags_names['tag'], "_id": str(tags_names['_id'])}
                        all_tags.append(d)
                    if tags_names_ques and not tags_names:
                        d = {"tag": tags_names_ques['tag'], "_id": str(tags_names_ques['_id'])}
                        all_tags.append(d)
                data['tags'] = all_tags
                data['edit_rights'] = edit_rights
                data['delete_rights'] = delete_rights
                del data['used_at']
                del data['updated_at']
                del data['updated_by']
                del data['resource_id']
                del data['module']
            all_resources.extend(fetch_meta)

    all_resources.extend(all_videos)
    all_resources.extend(course_resources)
    all_resources.extend(topic_resources)
    all_resources.extend(session_resources)

    type_resources = []
    if file_type == 'video':
        for item in all_resources:
            item['_id'] = str(item['_id'])
            if item.get('instance_id'):
                item['instance_id'] = str(item['instance_id'])
            if item.get('schedule_id'):
                item['schedule_id'] = str(item['schedule_id'])
            if re.findall('\.mp4', item['url']):
                item['type'] = "video"
                type_resources.append(item)
    if file_type == 'image':
        for item in all_resources:
            if item.get('instance_id'):
                item['instance_id'] = str(item['instance_id'])
            if item.get('schedule_id'):
                item['schedule_id'] = str(item['schedule_id'])
            item['_id'] = str(item['_id'])
            if re.findall('\.png|\.jpg|\.jpeg', item['url']):
                item['type'] = "image"
                type_resources.append(item)

    if file_type == 'audio':
        for item in all_resources:
            if item.get('instance_id'):
                item['instance_id'] = str(item['instance_id'])
            if item.get('schedule_id'):
                item['schedule_id'] = str(item['schedule_id'])
            item['_id'] = str(item['_id'])
            if re.findall(search_text, item['url']):
                item['type'] = "audio"
                type_resources.append(item)

    if file_type == 'file':
        for item in all_resources:
            if item.get('instance_id'):
                item['instance_id'] = str(item['instance_id'])
            if item.get('schedule_id'):
                item['schedule_id'] = str(item['schedule_id'])
            item['_id'] = str(item['_id'])
            if re.findall('\.pdf|\.zip|\.doc|\.docx|\.ppt|\.pptx|\.txt|\.xml|\.rar|\.csv|\.mp3|\.xlsx', item['url']):
                item['type'] = "file"
                type_resources.append(item)

    if file_type == 'python':
        for item in all_resources:
            if item.get('instance_id'):
                item['instance_id'] = str(item['instance_id'])
            if item.get('schedule_id'):
                item['schedule_id'] = str(item['schedule_id'])
            item['_id'] = str(item['_id'])
            if re.findall('\.py|\.ipynb', item['url']):
                item['type'] = "python"
                type_resources.append(item)

    if file_type == "":
        for item in all_resources:
            item['_id'] = str(item['_id'])
            if item.get('instance_id'):
                item['instance_id'] = str(item['instance_id'])
            if item.get('schedule_id'):
                item['schedule_id'] = str(item['schedule_id'])
            if re.findall('\.py|\.ipynb', item['url']):
                item['type'] = "python"
                item['_id'] = str(item['_id'])

            elif re.findall('\.pdf|\.zip|\.doc|\.docx|\.ppt|\.pptx|\.txt|\.xml|\.rar|\.csv|\.mp3|\.xlsx', item['url']):
                item['type'] = "file"
                item['_id'] = str(item['_id'])

            elif re.findall('\.mp3|\.wav', item['url']):
                item['type'] = "audio"
                item['_id'] = str(item['_id'])

            elif re.findall('\.png|\.jpg|\.jpeg', item['url']):
                item['type'] = "image"
                item['_id'] = str(item['_id'])

            elif re.findall('\.mp4', item['url']):
                item['type'] = "video"
                item['_id'] = str(item['_id'])
        type_resources = all_resources

    type_resources = sorted(type_resources, key=lambda k: k['time'], reverse=True)
    total_pages = math.ceil(len(type_resources) / 12)
    type_resources = type_resources[(page - 1) * 12: page * 12]
    return type_resources, total_pages


def add_resources(role, user_id, title, tags, description, resource_id):
    if title is None:
        title = ""

    if description is None:
        description = ""

    tags_collection = mongo_session.get_all_data("global_tags")['message']
    tags_dict = dict(map(lambda x: (x['tag'], x['_id']), tags_collection))
    new_tags = []
    tag_ids = []
    for t in tags:
        if t['_id'] == t['tag']:
            if t['tag'] in tags_dict.keys():
                tag_ids.append(ObjectId(tags_dict[t['tag']]))
            else:
                new_tags.append(t['tag'])
        else:
            tag_ids.append(ObjectId(t['_id']))

    if new_tags:
        tag_ids.extend(insert_tags(new_tags))

    resource_bank_resource_id = mongo_session.insert_files_resource_bank(
        collection="global_resource_bank",
        resource_id=ObjectId(resource_id),
        temp_collection="temp_uploaded_files")['message']
    s3_key_info = mongo_session.fetch_s3_key_temp_uploaded_files(
        collection="temp_uploaded_files",
        condition={
            "_id": ObjectId(resource_id)},
        columns={"s3_key": 1})
    doc_to_insert = {
        "resource_id": ObjectId(resource_id),
        "tags": tag_ids,
        "description": description,
        "title": title,
        "module": "global_resource",
        "used_at": "",
        "updated_at": utc_datetime_now(),
        "updated_by": ObjectId(user_id),
    }
    resp_id = mongo_session.insert_documnet(collection="resource_bank_instance",
                                            doc_to_insert=doc_to_insert)
    url = s3_key_info['message']

    item_type = ""
    if re.findall('\.mp4', url):
        item_type = "video"
        celery_args = [url]
        rec_status = celery_app.send_task("video_transcription_job", args=celery_args)
    if re.findall('\.png|\.jpg|\.jpeg', url):
        item_type = "image"
    if re.findall('\.pdf|\.zip|\.doc|\.docx|\.ppt|\.pptx|\.txt|\.xml|\.rar|\.csv|\.mp3|\.xlsx', url):
        item_type = "file"
    if re.findall('\.py|\.ipynb', url):
        item_type = "python"

    resource = {
        "_id": resource_id,
        "title": title,
        "description": description,
        "tags": tag_ids,
        "mongo_collection": "global_resource_bank",
        "module_name": "global_resources",
        "created_by": user_id,
        "created_at": utc_datetime_now(),
        "url": "",
        "file_type": item_type
    }
    insert_resource_elastic(resource)

    fetch_data = mongo_session.check_existance_return_info(collection='resource_bank_instance',
                                                           condition={'_id': ObjectId(resp_id['_id'].inserted_id)},
                                                           whole_doc=True)

    fetch_data['_id'] = str(fetch_data['_id'])
    fetch_data['url'], status = s3_function.generate_presigned_url_from_s3(s3_key_info['message'])
    fetch_data['resource_id'] = str(fetch_data['resource_id'])
    fetch_data['updated_by'] = str(fetch_data['updated_by'])
    for i in range(len(fetch_data['tags'])):
        fetch_data['tags'][i] = str(fetch_data['tags'][i])
    updated_by = mongo_session.check_existance_return_info(collection='user_profile',
                                                           condition={'_id': ObjectId(fetch_data['updated_by'])},
                                                           return_keys=['username'])
    fetch_data['updated_by'] = updated_by['username']
    return fetch_data
