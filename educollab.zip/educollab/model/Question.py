# -*- coding: utf-8 -*-


"""
    Question related interaction with Mongo
"""
import copy
import urllib
from urllib import request

import chardet
import cv2
import numpy as np
import pandas
import pytesseract
from pymongo import message
# import pytesseract

import config
from services import Embedding as e
from mongo_connection import connection
from datetime import datetime
from pytz import timezone
from bson import ObjectId
from googletrans import Translator
import pickle
from werkzeug.utils import secure_filename
import os
from config import download_path, supported_video_content_type, supported_image_content_type, \
    other_supported_content_type, question_complexity_score, es, ES_QUESTION_INDEX
import services.profanity_check as Profanity_Detection
import services.common.translation as translation
from services.storage.s3_services import s3_storage

s3_function = s3_storage()
from db_wrapper.tasks import Mongo

mongo_session = Mongo()
import services.Similar_questions as Similar_questions
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
import pytz
import time
import html2text
import re
import magic as file_checker
import xmltodict
import filetype
# import magic
from io import BytesIO
import traceback
from model import Notification
from bs4 import BeautifulSoup
from utils.misc import convert_dict_standard_dt, replace_s3_links_with_keys, renew_s3_links, \
    extract_s3_keys_from_html_str, validate_ObjectId
from model.general import get_img_in_question
from utils.elasticsearch.question import index_question
from routes.exception import InvalidUsage
from config import EMPTY_STRING
from utils.misc import create_thumbnail_for_video, is_empty
from PIL import Image
from utils.time_conversions import utc_datetime_now


class Question(object):
    def __init__(self, text):
        bits = text.split(",")
        self.question_id = bits[0]
        if len(bits) == 1:
            bits = self.load_question().split(",")
        self.question = bits[1]
        if len(bits[2]) > 0:
            self.question_embedding = bits[2]
        else:
            self.question_embedding = e.Embedding().get_embedding(self.question)
        self.content_list = bits[3].split(";")

    def load_question(self):
        with open(config.QUESTION_BANK_PATH, "r") as fp:
            for line in fp:
                if line.split(',')[0] == self.question_id:
                    return line

    def add_content(self, content):
        self.content_list.append(content)


def question_profanity_check(question):
    ques_model = open(download_path + '/model.pkl', 'rb')
    clf = pickle.load(ques_model)
    pred = clf.predict(question)
    if pred == 'Toxic':
        return True
    else:
        return False


def convert_utc_ist(format, time_obj):
    utc = time_obj.astimezone(timezone('UTC'))
    ist = utc.astimezone(timezone('Asia/Kolkata'))

    string_time = ist.strftime(format)
    return datetime.strptime(string_time, format)


def ask_question(question, user_id, language, translated_question, coins, category_id, question_image, question_video,
                 coordinates=None):
    """to ask question and add in database"""
    timestamp = indian_standard_time()
    question_image_s3_link = ""
    question_video_s3_link = ""
    question_image_s3_path = None
    question_video_s3_path = None
    available_coin = ""
    message = ""
    notification_status = ""
    try:
        if question_image:
            question_image_ext_validation = get_extension_validation(question_image, supported_image_content_type)
            if question_image_ext_validation[0]:
                unique_key = str(int(time.time())) + '-' + str(user_id)
                question_image_content_type = config.supported_content_type_with_extension[
                    question_image_ext_validation[1]]
                question_image_s3_info = s3_function.upload_data_to_s3_private(question_image, unique_key=unique_key,
                                                                               folder_name="question-images/",
                                                                               file_extension=
                                                                               question_image_ext_validation[1],
                                                                               Content_Type=question_image_content_type)
                if question_image_s3_info['status'] == 200:
                    question_image_s3_link = question_image_s3_info['s3_link']
                    question_image_s3_path = question_image_s3_info['s3_key']

                else:
                    return None, None, None, "error while uploading data to s3"
        if question_video:
            question_video_ext_validation = get_extension_validation(question_video, supported_video_content_type)
            if question_video_ext_validation[0]:
                unique_key = str(int(time.time())) + '-' + str(user_id)
                question_video_content_type = config.supported_content_type_with_extension[
                    question_video_ext_validation[1]]
                question_video_s3_info = s3_function.upload_data_to_s3_private(question_video, unique_key=unique_key,
                                                                               folder_name="question-videos/",
                                                                               file_extension=
                                                                               question_video_ext_validation[1],
                                                                               Content_Type=question_video_content_type)
                if question_video_s3_info['status'] == 200:
                    question_video_s3_link = question_video_s3_info['s3_link']
                    question_video_s3_path = question_video_s3_info['s3_key']
                else:
                    return None, None, None, "error while uploading data to s3"
        category_name = \
        mongo_session.get_all_data_for_particular_condition_fields("Course_Category", {"_id": ObjectId(category_id)})[
            'message'][0]['name']
        insert_doc = {"user_id": user_id,
                      "questions": question,
                      "question_image_path": question_image_s3_path,
                      "question_video_path": question_video_s3_path,
                      "course_category_id": ObjectId(category_id),
                      "Course_Category": category_name,
                      "Timestamp": timestamp,
                      "status": False,
                      "answers": [],
                      "reward": coins,
                      "language": language,
                      "translated_question": translated_question,
                      "es_flag": False}
        if coordinates:
            insert_doc["coordinates"] = coordinates
        question_cursor_info = mongo_session.insert_data_ask_question(collection="question_bank", record=insert_doc)
        question_cursor = question_cursor_info['message']
        if question_cursor_info['status'] == 200:
            message = "question added"
            user_data_updation = mongo_session.update_user_data_ask_question(collection="user_profile",
                                                                             condition={"_id": ObjectId(user_id)},
                                                                             push_info={
                                                                                 "questions": {"_id": question_cursor}},
                                                                             increment_info={"coin": -coins})

        user_cursor = user_data_updation['message']
        for data in user_cursor:
            available_coin = float(round(data['coin'], 2))
        data = str(question_cursor)
        user_ids = [ObjectId(user_id)]
        device_tokens = mongo_session.get_device_tokens(collection="user_profile",
                                                    condition={"_id": {"$in": user_ids},
                                                               "user_device_tokens": {"$exists": True}},
                                                    columns={"user_device_tokens": 1, "_id": 0})
        message_title = "Coins Deducted"
        message_body = "Your coins are deducted for asking a question."
        data_message = {
                "module_name": "Coinsrewarded"
            }
        if device_tokens['status'] == 200:
            firebase_response = Notification.notify_multiple_users(user_id_list=user_ids,
                                                                       device_tokens=device_tokens['message'],
                                                                       message_title=message_title,
                                                                       data_message=data_message,
                                                                       message_body=message_body)
        #print("firebase_response", firebase_response)
        if firebase_response['status'] == 200:
            notification_status = firebase_response['notification_status']
    except Exception as e:
        print(e)
        data = None
        available_coin = None
        message = e
    return data, available_coin, question_image_s3_link, question_video_s3_link, message, notification_status


def indian_standard_time():
    format = "%d %b %Y, %I:%M %p"
    # Current time in UTC
    now_utc = datetime.now(timezone('UTC'))
    # print(now_utc.strftime(format))
    # Convert to Asia/Kolkata time zone
    now_asia = now_utc.astimezone(timezone('Asia/Kolkata'))
    # print(now_asia.strftime(format))
    return now_asia.strftime(format)


def convert_utc_format(time_object, format):
    time_format = time_object.strftime(format)
    return time_format


# def convert_filestorage_to_byte(file):
#     msg_part_io_byte = BytesIO()
#     msg_part_io_byte.write(file.read())
#     content_type = magic.from_buffer(msg_part_io_byte.getvalue(), mime=True)
#     return content_type

def get_extension_validation(file, supported_content):
    name, ext = os.path.splitext(secure_filename(file.filename))
    if ext.lower() in supported_content:
        validation_status = True
    else:
        validation_status = False
    return [validation_status, ext.lower()]

def get_extension_validation_urls(file, supported_content):
    name, ext = '.'.join(file.split('.')[0:-1]), file.split('.')[-1]
    ext = "." + ext
    if ext.lower() in supported_content:
        validation_status = True
    else:
        validation_status = False
    return [validation_status, ext.lower()]

def answer_verification(question_id, answer_id, user_id, status):
    """To approve  to best answer given to the user's question and return the reward.
    :param question_id: question whose answers are getting approved.
    :type question_id: str
    :param answer_id: answer which need approval
    :type answer_id: str
    :param user_id: user who asked question
    :type user_id: str
    :param status: whether to approve the answer or not
    :type status: str ("approved")"""
    answer_collection = connection.answer_bank
    notification_status = ""
    if not validate_ObjectId(answer_id):
        raise InvalidUsage("Bad Request.", 400)
    # fetch question info
    question_data = mongo_session.check_existance_return_info(collection="question_bank",
                                                              condition={"_id": ObjectId(question_id)},
                                                              columns={"reward": 1, "user_id": 1},
                                                              return_keys=["reward", "user_id"])                                                         
    if not question_data:
        raise InvalidUsage("Bad Request.", 400)

    # reward for answering the question
    reward = float(round(question_data['reward'], 2))
    # validate: user asking the question and verifying answer is same.
    if user_id != question_data['user_id']:
        raise InvalidUsage("You are not authorised user to perform this operation.", 401)

    # update answer approval status
    for answer in  answer_collection.find({"_id": ObjectId(answer_id)},{"approval_status": 1}):
        if answer['approval_status'] == 1:
            message = "Answer is already approved"
            answer_status = "Already Approved"
            return answer_status, message, None, None, None
    approval_status = 1 if status.lower() == "approved" else 0
    user_id_answer = mongo_session.update_coin_record_into_db(collection="answer_bank",
                                                              condition={"_id": ObjectId(answer_id)},
                                                              update_info={"$set": {"approval_status": approval_status}})['user_info']
    user_coins_data = mongo_session.get_user_coin(collection="user_profile",
                                                     condition={"_id": ObjectId(user_id_answer)},
                                                     columns={"coin" : 1 ,"user_id": 1})
    message = "Hope this answer has served it's purpose"                                                
    update_coins = user_coins_data['message']
    available_coin = update_coins + reward
    user_coin_updation = mongo_session.update_record_into_db(collection="user_profile",
                                        condition={"_id": ObjectId(user_id_answer)},
                                        update_info={"$set": {"coin": available_coin}})
    user_ids = [ObjectId(user_id)]
    user_answer_id = [ObjectId(user_id_answer)]
    device_tokens = mongo_session.get_device_tokens(collection="user_profile",
                                                    condition={"_id": {"$in": user_answer_id},
                                                               "user_device_tokens": {"$exists": True}},
                                                    columns={"user_device_tokens": 1, "_id": 0})
    message_title = "Congratulations"
    message_body = "You have been rewarded coins for the questions you answered"
    data_message = {
                "module_name": "Coinsrewarded"
            }
    if device_tokens['status'] == 200:
        firebase_response = Notification.notify_multiple_users(user_id_list=user_answer_id,
                                                                       device_tokens=device_tokens['message'],
                                                                       message_title=message_title,
                                                                       data_message=data_message,
                                                                       message_body=message_body)
        if firebase_response['status'] == 200:
            notification_status = firebase_response['notification_status']
    return status, message, reward, available_coin, notification_status


def add_answer_feedback(feedback, user_id, answer_id):
    """to update feedback in answer collection and user collection
    :param feedback: feedback given by the user.
    :type feedback: str
    :param user_id: user adding the feedback.
    :type user_id: str
    :param answer_id: answer on which feedback has been given.
    :type answer_id: str
    """
    answer_data = mongo_session.check_existance_return_info(collection="answer_bank",
                                                            condition={"_id": ObjectId(answer_id)},
                                                            whole_doc=True)
    if not answer_data:
        raise InvalidUsage("Please check request data.", 400)

    feedback_update = {"user_id": user_id,
                       "_id": ObjectId(),
                       "Feedback": feedback,
                       "Timestamp": utc_datetime_now()}
    # add feedback in answers
    mongo_session.update_record_into_db(collection="answer_bank",
                                        condition={"_id": ObjectId(answer_id)},
                                        update_info={"$push": {"Feedback": feedback_update}})
    # add feedback information in user profile
    feedback_update = {"answer_id": answer_id,
                       "Feedback": feedback,
                       "Timestamp": utc_datetime_now()}
    mongo_session.update_record_into_db(collection="user_profile",
                                        condition={"_id": ObjectId(user_id)},
                                        update_info={"$push": {"Feedback": feedback_update}})
    question_id = answer_data['question_id']
    return question_id


def add_question_feedback(feedback, user_id, question_id, role):
    """to update feedback in answer collection and user collection
    :param feedback: feedback given by the user.
    :type feedback: str
    :param user_id: user adding the feedback.
    :type user_id: str
    """
    question_data = mongo_session.check_existance_return_info(collection="question_bank",
                                                            condition={"_id": ObjectId(question_id)},
                                                            whole_doc=True)
    if role == "teacher":
        if not question_data:
            raise InvalidUsage("Please check request data.", 400)

        feedback_update = {"user_id": user_id,
                        "Feedback": feedback,
                        "Timestamp": utc_datetime_now()}
        # add feedback in questions
        mongo_session.update_record_into_db(collection="question_bank",
                                            condition={"_id": ObjectId(question_id)},
                                            update_info={"$push": {"Feedback": feedback_update}})
        # add feedback information in user profile
        feedback_update = {"question_id": question_id,
                        "Question_Feedback": feedback,
                        "Timestamp": utc_datetime_now()}
        mongo_session.update_record_into_db(collection="user_profile",
                                            condition={"_id": ObjectId(user_id)},
                                            update_info={"$push": {"Feedback": feedback_update}})
        question_id = question_data['_id']
        return question_id
    else:
        return None


def add_rating(rating, user_id, answer_id, course_id, review=None):
    """to update rating in answer collection and user collection"""
    user_collection = connection.user_profile
    answer_collection = connection.answer_bank
    course_collection = connection.courses_bank
    if answer_id:
        answer_query = {"_id": ObjectId(answer_id)}
        user_query = {"_id": ObjectId(user_id)}
        rating_update = {"user_id": user_id, "Rating": rating}

        if answer_collection.find({'_id': ObjectId(answer_id), 'Rating.user_id': user_id}, {'Rating.$': 1}).count() > 0:
            answer_collection.update({'_id': ObjectId(answer_id), 'Rating.user_id': user_id},
                                     {"$set": {"Rating.$.Rating": rating}})
            rating_update = {"answer_id": answer_id, "Rating": rating}
            if user_collection.find({"_id": ObjectId(user_id), "Answer Rating.answer_id": answer_id},
                                    {'Rating.$': 1}).count() > 0:
                user_collection_cursor = user_collection.update(
                    {"_id": ObjectId(user_id), "Answer Rating.answer_id": answer_id},
                    {"$set": {"Answer Rating.$.Rating": rating}})
            else:
                user_collection_cursor = user_collection.update(user_query, {"$push": {"Answer Rating": rating_update}})
        else:
            answer_collection.update_one(answer_query, {"$push": {"Rating": rating_update}})
            rating_update = {"answer_id": answer_id, "Rating": rating}
            user_collection_cursor = user_collection.update(user_query, {"$push": {"Answer Rating": rating_update}})
        rating_aggregate_cursor = answer_collection.aggregate(
            [{"$match": {"_id": ObjectId(answer_id)}}, {"$project": {"av_rating": {"$avg": "$Rating.Rating"}}}])
        for data in rating_aggregate_cursor:
            aggregate_rating = data["av_rating"]
            if aggregate_rating:
                aggregate_rating = float(round(aggregate_rating, 2))
            else:
                aggregate_rating = 0.0
        answer_data_cursor = answer_collection.find({"_id": ObjectId(answer_id)})
        for data in answer_data_cursor:
            question_id = data['question_id']
        data = question_id
        rating_type = 'answer'

    elif course_id:
        user_query = {"_id": ObjectId(user_id)}
        course_query = {"_id": ObjectId(course_id)}
        if review:
            rating_update = {"user_id": user_id, "Rating": rating, 'review': review}
        else:
            rating_update = {"user_id": user_id, "Rating": rating, 'review': ""}
        if course_collection.find({'_id': ObjectId(course_id), 'Rating.user_id': user_id}, {'Rating.$': 1}).count() > 0:

            course_collection.update({'_id': ObjectId(course_id)},
                                     {'$pull': {'Rating': {'user_id': user_id}}})
            course_collection.update({'_id': ObjectId(course_id)},
                                     {'$push': {"Rating": rating_update}})
            if review:
                rating_update = {"user_id": user_id, "Rating": rating, 'review': review}
            else:
                rating_update = {"user_id": user_id, "Rating": rating, 'review': ""}
            if user_collection.find({"_id": ObjectId(user_id), "Course Rating.course_id": course_id},
                                    {"Course Rating.$.": 1}):
                user_collection_cursor = user_collection.update(
                    {"_id": ObjectId(user_id), "Course Rating.course_id": course_id},
                    {"$set": {"Course Rating.$.Rating": rating}})
            else:
                user_collection_cursor = user_collection.update(user_query, {"$push": {"Course Rating": rating_update}})
        else:
            course_collection.update_one(course_query, {"$push": {"Rating": rating_update}})
            if review:
                rating_update = {"user_id": user_id, "Rating": rating, 'review': review}
            else:
                rating_update = {"user_id": user_id, "Rating": rating, 'review': ""}
            user_collection_cursor = user_collection.update(user_query, {"$push": {"Course Rating": rating_update}})
        rating_aggregate_cursor = course_collection.aggregate(
            [{"$match": {"_id": ObjectId(course_id)}}, {"$project": {"av_rating": {"$avg": "$Rating.Rating"}}}])
        for data in rating_aggregate_cursor:
            aggregate_rating = data["av_rating"]
            if aggregate_rating:
                aggregate_rating = float(round(aggregate_rating, 2))
                upd = course_collection.update({"_id": ObjectId(course_id)},
                                               {"$set": {"overall_rating": aggregate_rating}})
            else:
                aggregate_rating = 0.0
                upd = course_collection.update({"_id": ObjectId(course_id)},
                                               {"$set": {"overall_rating": aggregate_rating}})
        user_query = {"_id": ObjectId(user_id)}
        if upd['n'] != 1:
            return "error in updating course rating"
        course_data_cursor = course_collection.find({"_id": ObjectId(course_id)})
        for data in course_data_cursor:
            course_id = data['_id']
        data = course_id
        rating_type = 'course'
    return data, rating_type, aggregate_rating, rating


def like_dislike_status(status, user_id, answer_id):
    """to update like dislike status in answer collection and user collection"""
    user_collection = connection.user_profile
    answer_collection = connection.answer_bank
    answer_query = {"_id": ObjectId(answer_id)}

    if status.lower() == "liked":
        liked_update = {"user_id": user_id}
        if answer_collection.find({"_id": ObjectId(answer_id), "Liked.user_id": user_id},
                                  {"Liked.$": 1}).count():
            answer_collection.update({"_id": ObjectId(answer_id)},
                                     {"$pull": {"Liked": {"user_id": user_id},
                                                "Disliked": {"user_id": user_id}}})
            user_collection.update({"_id": ObjectId(user_id)},
                                   {"$pull": {"Liked": {"answer_id": answer_id},
                                              "Disliked": {"answer_id": answer_id}}})
            like_status = False
            dislike_status = False
        else:
            answer_collection.update_one(answer_query, {"$push": {"Liked": liked_update},
                                                        "$pull": {"Disliked": {"user_id": user_id}}})
            user_query = {"_id": ObjectId(user_id)}
            liked_detail = {"answer_id": answer_id}
            user_collection.update(user_query, {"$push": {"Liked": liked_detail},
                                                "$pull": {"Disliked": {"answer_id": answer_id}}})
            like_status = True
            dislike_status = False
    elif status.lower() == "disliked":
        disliked_update = {"user_id": user_id}

        if answer_collection.find({"_id": ObjectId(answer_id), "Disliked.user_id": user_id},
                                  {"Disliked.$": 1}).count():
            answer_collection.update({"_id": ObjectId(answer_id)},
                                     {"$pull": {"Liked": {"user_id": user_id},
                                                "Disliked": {"user_id": user_id}}})
            user_collection.update({"_id": ObjectId(user_id)},
                                   {"$pull": {"Liked": {"answer_id": answer_id},
                                              "Disliked": {"answer_id": answer_id}}})
            like_status = False
            dislike_status = False
        else:
            answer_collection.update_one(answer_query, {"$push": {"Disliked": disliked_update},
                                                        "$pull": {"Liked": {"user_id": user_id}}})
            user_query = {"_id": ObjectId(user_id)}
            disliked_detail = {"answer_id": answer_id}
            user_collection.update(user_query, {"$push": {"Disliked": disliked_detail},
                                                "$pull": {"Liked": {"answer_id": answer_id}}})

            like_status = False
            dislike_status = True
    else:
        raise InvalidUsage("Bad Request", 400)
    answer_data_cursor = answer_collection.find({"_id": ObjectId(answer_id)})
    data = answer_data_cursor[0]['question_id']
    return data, like_status, dislike_status


def answer_comment_like_dislike(status, user_id, comment_id, answer_id, is_true):
    """to update like dislike status of comment/Feedback in answer collection """
    answer_collection = connection.answer_bank
    answer_query = {"_id": ObjectId(str(answer_id)), "Feedback._id": ObjectId(str(comment_id))}
    like_query = {"Feedback.$.Liked": {"user_id": str(user_id)}}
    dislike_query = {"Feedback.$.Disliked": {"user_id": str(user_id)}}

    if status.lower() == "liked":
        if is_true:
            answer_collection.update_one(answer_query,
                                         {"$pull": like_query})
            answer_collection.update_one(answer_query,
                                         {"$pull": dislike_query})
            like_status = False
            dislike_status = False
        else:
            answer_collection.update_one(answer_query,
                                         {"$push": like_query})
            answer_collection.update_one(answer_query,
                                         {"$pull": dislike_query})
            like_status = True
            dislike_status = False
    elif status.lower() == "disliked":
        if is_true:
            answer_collection.update_one(answer_query,
                                         {"$pull": like_query})
            answer_collection.update_one(answer_query,
                                         {"$pull": dislike_query})

            like_status = False
            dislike_status = False
        else:
            answer_collection.update_one(answer_query,
                                         {"$pull": like_query})
            answer_collection.update_one(answer_query,
                                         {"$push": dislike_query})

            like_status = False
            dislike_status = True
    else:
        raise InvalidUsage("Bad Request", 400)
    answer_data_cursor = answer_collection.find({"_id": ObjectId(answer_id)})
    data = answer_data_cursor[0]['question_id']
    return data, like_status, dislike_status


def create_test(user_id, question_list, answer_id, answer_list):
    "creating test for an answer based on the question list that we have"
    test_collection = connection.test
    user_collection = connection.user_profile
    try:
        test_id = test_collection.insert(
            {"user_id": user_id, "Questions": question_list, "Answers": answer_list, "answer_id": answer_id,
             "user_submissions": []})
        user_query = {"_id": ObjectId(user_id)}
        test_update = {"test_id": test_id}
        user_cursor = user_collection.update_one(user_query, {"$push": {"tests_created": test_update}})
    except Exception as e:
        print(e)
        test_id = None
    return test_id


def test_submission(answer, user_id, test_id):
    "creating test for an answer based on the question list that we have"
    test_collection = connection.test
    user_collection = connection.user_profile
    try:

        test_query = {"_id": ObjectId(test_id)}
        test_update = {"user_id": user_id, "answer": answer}
        test_cursor = test_collection.update_one(test_query, {"$push": {"user_submissions": test_update}})
        user_query = {"_id": ObjectId(user_id)}
        user_update = {"test_id": test_id, "answer": answer, "Score": None}
        test_cursor = user_collection.update_one(user_query, {"$push": {"test_submissions": user_update}})
    except Exception as e:
        print(e)
        test_id = None
    return test_id


def similar_questions(user_id=None, question_id=None):
    """finding questions similar to what has been asked"""
    questions_found = ["This is still work in progress"]
    return questions_found


def my_questions(user_id):
    """function to return all the questions asked by the user"""
    question_collection = connection.question_bank
    video_question_collection = connection.video_questions
    try:
        questions = []
        question_cursor = question_collection.find({"user_id": user_id})
        for question in question_cursor:
            question["_id"] = str(question["_id"])
            question["course_category_id"] = str(question["course_category_id"])
            if question_collection.find({"_id": ObjectId(question["_id"]),
                                         "question_video_path": {"$exists": True, "$ne": None}}).count() > 0:
                question['question_video_path'] = config.s3_connection.generate_presigned_url('get_object',
                                                                                              Params={
                                                                                                  'Bucket': config.bucket,
                                                                                                  'Key': question[
                                                                                                      'question_video_path']},
                                                                                              ExpiresIn=604800)
            if question_collection.find(
                    {"_id": ObjectId(question["_id"]),
                     "question_image_path": {"$exists": True, "$ne": None}}).count() > 0:
                question['question_image_path'] = config.s3_connection.generate_presigned_url('get_object',
                                                                                              Params={
                                                                                                  'Bucket': config.bucket,
                                                                                                  'Key': question[
                                                                                                      'question_image_path']},
                                                                                              ExpiresIn=604800)
            question['video_time'] = 0
            question['Course_id'] = ""
            question['Week'] = ""
            question['video_index'] = ""
            cursor = video_question_collection.find(
                {"user_id": user_id, "question_detail.question_id": question["_id"]},
                {"question_detail.$": 1, "Course_id": 1, "Week": 1, "video_index": 1})
            for data in cursor:
                question_detail = data['question_detail']
                print(question_detail)
                question['video_time'] = question_detail[0]['video_time']
                question['Course_id'] = data['Course_id']
                question['Week'] = data['Week']
                question['video_index'] = int(data['video_index'])
            for ans in question["answers"]:
                ans["_id"] = str(ans['_id'])

            questions.append(question)
            questions.reverse()
        questions = map(convert_dict_standard_dt, questions)
        questions = sorted(
            questions,
            key=lambda x: x["Timestamp_standard"], reverse=True
        )
        return questions
    except Exception as e:
        print(e)
        questions = None
        return questions


def question_translation(question):
    """to translate question"""
    translator = Translator()
    translation = translator.translate(question)
    translated_question = translation.text
    language = "english"
    return translated_question, language


def question_deactive(question_id, question_status, passed_user_id):
    question_collection = connection.question_bank
    user_collection = connection.user_profile
    answer_collection = connection.answer_bank
    user_answer_list = []
    user_cursor = list(
        question_collection.find({"_id": ObjectId(question_id)}, {"user_id": 1, "reward": 1, "answers": 1}))
    coin_reward = float(user_cursor[0]['reward'])
    question_asked_by = user_cursor[0]['user_id']
    user_id = user_cursor[0]['user_id']
    answers = user_cursor[0]['answers']
    answer_rating_status = False
    no_of_users = 0
    rating_sum = 0  # taking 3 as 1, 4 as 2, 5 as 3
    rating_status = False  # it is to check check whether any answer has rating above or equal to 3 if it doesn't then the question cannot close
    if user_id == passed_user_id:
        for question in  question_collection.find({"_id": ObjectId(question_id)},{"status": 1}):
            if question['status'] == True:
                cursor = list(user_collection.find({"_id": ObjectId(user_id)}, {"coin": 1}))
                avaialbale_coin = float(round(cursor[0]['coin'], 2))
                message = "Question is already closed"
                question_status = "Already Closed"
                return question_status, avaialbale_coin, message
        if answers:
            cursor = list(user_collection.find({"_id": ObjectId(user_id)}, {"coin": 1}))
            avaialbale_coin = float(round(cursor[0]['coin'], 2))
            if question_status == "closed":
                for data in answers:
                    answer_cursor = list(
                        answer_collection.find({"_id": data["_id"]}, {"approval_status": 1, "user_id": 1}))
                    if not answer_cursor:
                        continue
                    if answer_cursor[0]['approval_status'] == 1:
                        no_of_users = no_of_users + 1

                    if answer_collection.find(
                            {"_id": data['_id'], "approval_status": 1, "Rating.user_id": user_id}).count() > 0:
                        rating_cursor = list(answer_collection.find(
                            {"_id": data['_id'], "approval_status": 1, "Rating.user_id": user_id},
                            {"Rating.Rating": 1, "_id": 0}))[0]
                        answer_rating_status = True
                        rating_by_inquisitive = rating_cursor['Rating'][0]['Rating']
                        if rating_by_inquisitive in range(3, 6):
                            rating_sum = rating_sum + (rating_by_inquisitive - 2)
                        user = {"user_id": answer_cursor[0]['user_id'], "answer_id": answer_cursor[0]['_id'],
                                "rating_by_inquisitive": rating_by_inquisitive}
                        user_answer_list.append(user)

                if no_of_users == 0:
                    question_status = "open"
                    message = " Approve the answers first to close the question"
                    return question_status, avaialbale_coin, message
                if answer_rating_status:
                    for user in user_answer_list:
                        if user['rating_by_inquisitive'] in range(3, 6):
                            rating_status = True
                            reward_coins = float(coin_reward / rating_sum) * (user['rating_by_inquisitive'] - 2)
                            user_collection.update({"_id": ObjectId(user['user_id'])},
                                                   {"$inc": {"coin": float(round(reward_coins, 2))}})
                    if rating_status:
                        question_collection.update({"_id": ObjectId(question_id)}, {"$set": {"status": True}})
                        cursor = list(user_collection.find({"_id": ObjectId(user_id)}, {"coin": 1}))
                        avaialbale_coin = float(round(cursor[0]['coin'], 2))

                        users_id_dict = list(
                            answer_collection.find({"question_id": question_id}, {"user_id": 1, "_id": 0}))
                        user_id_list = list(set([ObjectId(dict['user_id']) for dict in users_id_dict]))
                        #print('user_id_list', user_id_list)
                        device_tokens = mongo_session.get_device_tokens(collection="user_profile",
                                                                        condition={"_id": {"$in": user_id_list},
                                                                                   "user_device_tokens": {
                                                                                       "$exists": True}},
                                                                        columns={"user_device_tokens": 1, "_id": 0})
                        #print('device_tokens', device_tokens, question_asked_by)
                        data_message = {"question_id": question_id, "click_action": "FLUTTER_NOTIFICATION_CLICK",
                                        "module_name": "QuestionClosed"}
                        message_title = "Question Closed"
                        message_body = "A question you had submitted an answer to has been closed!"
                        if device_tokens['status'] == 200:
                            firebase_response = Notification.notify_multiple_users(user_id_list=user_id_list,
                                                                                   device_tokens=device_tokens[
                                                                                       'message'],
                                                                                   data_message=data_message,
                                                                                   message_title=message_title,
                                                                                   message_body=message_body)
                            if firebase_response['status'] == 200:
                                notification_status = firebase_response['notification_status']
                        message = 'Question closed successfully.'
                    else:
                        question_status = "open"
                        message = "Question cannot be closed as no user has rating above 3"
                        return question_status, avaialbale_coin, message

                else:
                    question_status = "open"
                    message = "Please rate the approved answers"
                    return question_status, avaialbale_coin, message


            elif question_status == "open":
                question_collection.update({"_id": ObjectId(question_id)}, {"$set": {"status": False}})
                message = 'Question opened successfully.'
            else:
                question_status = "open"
                message = 'Question can not be closed'
        else:
            question_status = "open"
            message = "Answers are not present for this questions"
            return question_status, None, message
    else:
        message = "you don't have permission to close this question"
        return None, None, message
    return question_status, avaialbale_coin, message


def question_deactivate(question_id, question_status, passed_user_id):
    question_collection = connection.question_bank
    user_collection = connection.user_profile
    answer_collection = connection.answer_bank
    user_answer_list = []
    user_cursor = list(
        question_collection.find({"_id": ObjectId(question_id)}, {"user_id": 1, "reward": 1, "answers": 1}))
    coin_reward = float(user_cursor[0]['reward'])
    question_asked_by = user_cursor[0]['user_id']
    user_id = user_cursor[0]['user_id']
    answers = user_cursor[0]['answers']
    answer_rating_status = False
    no_of_users = 0
    rating_sum = 0  # taking 3 as 1, 4 as 2, 5 as 3
    rating_status = False  # it is to check check whether any answer has rating above or equal to 3 if it doesn't then the question cannot close
    if user_id == passed_user_id:
        for question in question_collection.find({"_id": ObjectId(question_id)},{"status": 1}):
            if question['status']:
                cursor = list(user_collection.find({"_id": ObjectId(user_id)}, {"coin": 1}))
                available_coin = float(round(cursor[0]['coin'], 2))
                message = "Question is already closed"
                question_status = "Already Closed"
                return question_status, available_coin, message
        if answers:
            cursor = list(user_collection.find({"_id": ObjectId(user_id)}, {"coin": 1}))
            available_coin = float(round(cursor[0]['coin'], 2))
            if question_status == "closed":
                # for data in answers:
                #     answer_cursor = list(
                #         answer_collection.find({"_id": data["_id"]}, {"approval_status": 1, "user_id": 1}))
                #     if not answer_cursor:
                #         continue
                #     if answer_cursor[0]['approval_status'] == 1:
                #         no_of_users = no_of_users + 1
                #
                #     if answer_collection.find(
                #             {"_id": data['_id'], "approval_status": 1, "Rating.user_id": user_id}).count() > 0:
                #         rating_cursor = list(answer_collection.find(
                #             {"_id": data['_id'], "approval_status": 1, "Rating.user_id": user_id},
                #             {"Rating.Rating": 1, "_id": 0}))[0]
                #         answer_rating_status = True
                #         rating_by_inquisitive = rating_cursor['Rating'][0]['Rating']
                #         if rating_by_inquisitive in range(3, 6):
                #             rating_sum = rating_sum + (rating_by_inquisitive - 2)
                #         user = {"user_id": answer_cursor[0]['user_id'], "answer_id": answer_cursor[0]['_id'],
                #                 "rating_by_inquisitive": rating_by_inquisitive}
                #         user_answer_list.append(user)
                #
                # if no_of_users == 0:
                #     question_status = "open"
                #     message = " Approve the answers first to close the question"
                #     return question_status, available_coin, message
                # if answer_rating_status:
                #     for user in user_answer_list:
                #         if user['rating_by_inquisitive'] in range(3, 6):
                #             rating_status = True
                #             reward_coins = float(coin_reward / rating_sum) * (user['rating_by_inquisitive'] - 2)
                #             user_collection.update({"_id": ObjectId(user['user_id'])},
                #                                    {"$inc": {"coin": float(round(reward_coins, 2))}})
                #     if rating_status:
                question_collection.update({"_id": ObjectId(question_id)}, {"$set": {"status": True}})
                cursor = list(user_collection.find({"_id": ObjectId(user_id)}, {"coin": 1}))
                available_coin = float(round(cursor[0]['coin'], 2))

                users_id_dict = list(
                    answer_collection.find({"question_id": question_id}, {"user_id": 1, "_id": 0}))
                user_id_list = list(set([ObjectId(d['user_id']) for d in users_id_dict]))
                #print('user_id_list', user_id_list)
                device_tokens = mongo_session.get_device_tokens(collection="user_profile",
                                                                condition={"_id": {"$in": user_id_list},
                                                                           "user_device_tokens": {
                                                                               "$exists": True}},
                                                                columns={"user_device_tokens": 1, "_id": 0})
                #print('device_tokens', device_tokens, question_asked_by)
                data_message = {"question_id": question_id, "click_action": "FLUTTER_NOTIFICATION_CLICK",
                                "module_name": "QuestionClosed"}
                message_title = "Question Closed"
                message_body = "A question you had submitted an answer to has been closed!"
                if device_tokens['status'] == 200:
                    firebase_response = Notification.notify_multiple_users(user_id_list=user_id_list,
                                                                           device_tokens=device_tokens[
                                                                               'message'],
                                                                           data_message=data_message,
                                                                           message_title=message_title,
                                                                           message_body=message_body)
                    if firebase_response['status'] == 200:
                        notification_status = firebase_response['notification_status']
                message = 'Question closed successfully.'
                    # else:
                    #     question_status = "open"
                    #     message = "Question cannot be closed as no user has rating above 3"
                    #     return question_status, available_coin, message

                # else:
                #     question_status = "open"
                #     message = "Please rate the approved answers"
                #     return question_status, available_coin, message

            elif question_status == "open":
                question_collection.update({"_id": ObjectId(question_id)}, {"$set": {"status": False}})
                message = 'Question opened successfully.'
            else:
                question_status = "open"
                message = 'Question can not be closed'
        else:
            question_status = "open"
            message = "Answers are not present for this questions"
            return question_status, None, message
    else:
        message = "you don't have permission to close this question"
        return None, None, message
    return question_status, available_coin, message


def update_question(new_question, user_id, language, category_id, question_id, question_image, delete_image_status,
                    question_video, delete_video_status, coordinates, role):
    """to update question asked by the user only if it hasn't been answered."""
    question_collection = connection.question_bank
    question_detail = {}
    try:
        for data in question_collection.find({"_id": ObjectId(question_id)}, {'answers': 1}):
            if data['answers']:
                message = "cannot edit this question because it already answered by someone"
            else:
                question_user_id = list(question_collection.find({"_id": ObjectId(question_id)}, {'user_id': 1}))[0][
                    'user_id']
                if (question_user_id == user_id) or role == 'teacher':
                    if new_question and category_id and language:
                        if language != "en":
                            translated_question, converted_language = translation.question_translation(new_question)
                        else:
                            translated_question = new_question
                        profanity = Profanity_Detection.check_profanity(translated_question)
                        if profanity == True:
                            message = "Oops can't update this question, use appropriate language"
                            return question_detail, message
                        else:
                            question_collection.update({"_id": ObjectId(question_id)}, {
                                "$set": {"questions": new_question, "translated_question": translated_question}})

                        category_name = mongo_session.get_all_data_for_particular_condition_fields("Course_Category", {
                            "_id": ObjectId(category_id)})['message'][0]['name']
                        question_collection.update({"_id": ObjectId(question_id)}, {
                            "$set": {"Course_Category": category_name, "course_category_id": ObjectId(category_id)}})

                        if coordinates:
                            question_collection.update({"_id": ObjectId(question_id)}, {
                                "$set": {"coordinates": coordinates}})

                        if delete_image_status == "true":
                            if question_image:
                                
                                question_image_ext_validation = get_extension_validation(question_image,
                                                                                         supported_image_content_type)
                                if question_image_ext_validation[0]:
                                    unique_key = str(int(time.time())) + '-' + str(user_id)
                                    question_image_content_type = config.supported_content_type_with_extension[
                                        question_image_ext_validation[1]]
                                    question_image_s3_info = s3_function.upload_data_to_s3_private(question_image,
                                                                                                   unique_key=unique_key,
                                                                                                   folder_name="question-images/",
                                                                                                   file_extension=
                                                                                                   question_image_ext_validation[
                                                                                                       1],
                                                                                                   Content_Type=question_image_content_type)
                                    if question_image_s3_info['status'] == 200:
                                        image_s3_link = question_image_s3_info['s3_link']
                                        image_s3_path = question_image_s3_info['s3_key']
                                    else:
                                        return question_detail, "error while uploading data to s3"

                                if question_collection.find({"_id": ObjectId(question_id),
                                                             "question_image_path": {"$exists": True,
                                                                                     "$ne": None}}).count() > 0:
                                    image_name = [doc['question_image_path'] for doc in
                                                  question_collection.find({"_id": ObjectId(question_id)},
                                                                           {"question_image_path": 1})]
                                    if s3_function.delete_s3_data(image_name[0]):
                                        question_collection.update({"_id": ObjectId(question_id)},
                                                                   {"$set": {"question_image_path": image_s3_path}})
                                    else:
                                        return question_detail, " error while deleting from s3"
                                else:
                                    question_collection.update({"_id": ObjectId(question_id)},
                                                               {"$set": {"question_image_path": image_s3_path}})

                            if not question_image:
                                
                                if question_collection.find({"_id": ObjectId(question_id),
                                                             "question_image_path": {"$exists": True,
                                                                                     "$ne": None}}).count() > 0:
                                    image_name = [doc['question_image_path'] for doc in
                                                  question_collection.find({"_id": ObjectId(question_id)},
                                                                           {"question_image_path": 1})]
                                    if s3_function.delete_s3_data(image_name[0]):
                                        question_collection.update({"_id": ObjectId(question_id)},
                                                                   {"$set": {"question_image_path": None}})
                                    else:
                                        return question_detail, " error while deleting from s3"
                                else:
                                    return question_detail, "Invalid operation to update question"
                        if delete_image_status == "false" and question_image:
                            
                            return question_detail, "Invalid operation to update question"

                        if delete_video_status == "true":
                            if question_video:
                                
                                question_video_ext_validation = get_extension_validation(question_video,
                                                                                         supported_video_content_type)
                                if question_video_ext_validation[0]:
                                    unique_key = str(int(time.time())) + '-' + str(user_id)
                                    question_video_content_type = config.supported_content_type_with_extension[
                                        question_video_ext_validation[1]]
                                    question_video_s3_info = s3_function.upload_data_to_s3_private(question_video,
                                                                                                   unique_key=unique_key,
                                                                                                   folder_name="question-videos/",
                                                                                                   file_extension=
                                                                                                   question_video_ext_validation[
                                                                                                       1],
                                                                                                   Content_Type=question_video_content_type)
                                    if question_video_s3_info['status'] == 200:
                                        question_video_s3_link = question_video_s3_info['s3_link']
                                        question_video_s3_path = question_video_s3_info['s3_key']
                                    else:
                                        return question_detail, "error while uploading data to s3"

                                if question_collection.find({"_id": ObjectId(question_id),
                                                             "question_video_path": {"$exists": True,
                                                                                     "$ne": None}}).count() > 0:
                                    video_name = [doc['question_video_path'] for doc in
                                                  question_collection.find({"_id": ObjectId(question_id)},
                                                                           {"question_video_path": 1})]
                                    if s3_function.delete_s3_data(video_name[0]):
                                        question_collection.update({"_id": ObjectId(question_id)}, {
                                            "$set": {"question_video_path": question_video_s3_path}})
                                    else:
                                        return question_detail, " error while deleting from s3"
                                else:
                                    question_collection.update({"_id": ObjectId(question_id)},
                                                               {"$set": {
                                                                   "question_video_path": question_video_s3_path}})

                            if not question_video:
                                
                                if question_collection.find({"_id": ObjectId(question_id),
                                                             "question_video_path": {"$exists": True,
                                                                                     "$ne": None}}).count() > 0:
                                    video_name = [doc['question_video_path'] for doc in
                                                  question_collection.find({"_id": ObjectId(question_id)},
                                                                           {"question_video_path": 1})]
                                    if s3_function.delete_s3_data(video_name[0]):
                                        question_collection.update({"_id": ObjectId(question_id)},
                                                                   {"$set": {"question_video_path": None}})
                                    else:
                                        return question_detail, " error while deleting from s3"
                                else:
                                    return question_detail, "Invalid operation to update question"
                        if delete_video_status == "false" and question_video:
                            
                            return question_detail, "Invalid operation to update question"

                        message = "Question Updated Successfully"
                        question_cursor = question_collection.find({"_id": ObjectId(question_id)},
                                                                   {'reward': 1, 'questions': 1, 'user_id': 1, '_id': 1,
                                                                    'Course_Category': 1, 'Timestamp': 1})
                        for data in question_cursor:
                            question_detail = data
                    else:
                        message = "Please add information to update the question"
                else:
                    message = "you cannot edit other user's question"
            return question_detail, message

    except Exception as e:
        print(e)
        question_detail = {}
        message = "cannot update question details"
        return question_detail, message


def search_question_string_matching(role, institute_type, organisation, grade, search_text, user_id,
                                    sort_by_coins=False, filter_dict={}):
    """return the questions after string matching with the questions in database after filtering same school
    and grade lower and of same level"""
    if role == "student":
        if institute_type == "school":
            user_condition = {"grade": {"$lt": int(grade) + 1}, "institute_type": institute_type}
        elif institute_type == "univeristy" or "collage" or "university" or "college":
            user_condition = {"$or": [{"grade": {"$lt": int(grade) + 1},
                                       "institute_type": institute_type}, {"institute_type": "school"}]}
    elif role == "teacher" or role == "super_admin" or role == "school_admin":
        user_condition = {}
    else:
        return {"status": "failed", "questions": []}, 400
    user_columns = {"_id": 1}
    valid_users_from_db = mongo_session.get_data_for_particular_columns_with_condition(
        'user_profile',
        user_condition,
        user_columns)
    user_list = [user["_id"] for user in valid_users_from_db['message'] if user['_id'] != user_id]
    questions = []
    questions_from_question_bank = mongo_session.get_all_data_search_question_string_matching(
        'question_bank')
    # body = {
    #     "query": {
    #         "bool": {
    #             "must": [
    #                 {
    #                     "match": {
    #                         "questions": search_text
    #                     }
    #                 }
    #             ]
    #         }
    #     }
    # }
    # if len(filter_dict.keys()) != 0:
    #     body["query"]["bool"]["must"].append({"match":filter_dict})
    #
    # elastic_Search_response = config.es.search(index=config.ES_USER_QUESTION_BANK_INDEX, body=body)
    # questions_from_question_bank = elastic_Search_response['hits']['hits']
    # for question in questions_from_question_bank:
    #     if question["_source"]['user_id'] in user_list:
    #         if role == "student":
    #             if len(question["_source"]["answers"]) > 0:
    #                 question["_score"] += question["_score"] * 2
    #             if question["_source"]["status"] ==  False:
    #                 question["_score"] += question["_score"] * 3
    #         else:
    #             if len(question["_source"]["answers"]) > 0:
    #                 question["_score"] += question["_score"] / 2
    #             if question["_source"]["status"] ==  False:
    #                 question["_score"] += question["_score"] / 3
    #         questions.append(question["_source"])
    #
    # if sort_by_coins == True:
    #     if len(questions) > 20:
    #         questions = questions[:20]
    #         questions = sorted(questions, key = lambda i: i['reward'],reverse=True)
    #     else:
    #         questions = sorted(questions, key=lambda i: i['reward'], reverse=True)
    search_text = search_text.lower()
    for question in questions_from_question_bank["message"]:
        stop_words = set(stopwords.words("english"))
        similarity_status = False
        for word in word_tokenize(search_text):
            if word not in stop_words and word.lower() in word_tokenize(question['questions'].lower()):
                similarity_status = True
        if question['user_id'] in user_list and similarity_status:
            if question.get("course_id"):
                question["course_id"] = str(question["course_id"])
                question["course_session_id"] = str(question["course_session_id"])
            questions.append(question)
    similar_questions = Similar_questions.find_similarity_search_question_string_matching(search_text, questions)
    similar_questions = similar_questions[0:20]
    question_data = {"status": "success", "questions": similar_questions}
    api_status = 200
    return question_data, api_status


def store_answer_info(answer_id, video_time, question_id):
    """to translate question"""
    status = mongo_session.store_question_araay_to_answer_ask_question(
        collection="answer_bank",
        condition={"_id": ObjectId(answer_id)},
        question_id=question_id,
        video_time=video_time)['status']
    return status


def fetch_question_tags():
    tags_dict = mongo_session.get_all_data(collection='question_tags')
    tags_dict_global = mongo_session.get_all_data(collection='global_tags')
    if tags_dict_global:
        tags_dict['message'].extend(tags_dict_global['message'])
    status = tags_dict['status']
    ids = []
    for tag_id in tags_dict['message']:
        if tag_id['_id'] in ids:
            tags_dict['message'].remove(tag_id)
            continue
        else:
            ids.append(tag_id['_id'])
    return status, tags_dict


def search_tags(search_text):
    tags_dict = mongo_session.get_all_data(collection='question_tags')
    tags_dict_global = mongo_session.get_all_data(collection='global_tags')
    if tags_dict_global:
        tags_dict['message'].extend(tags_dict_global['message'])
    status = tags_dict['status']
    tags = []
    for tag in tags_dict['message']:
        if search_text.lower() in tag["tag"].lower():
           tags.append({
            "_id": str(tag["_id"]),
            "tag": tag["tag"]
           })
    return status, tags


def get_question_content(tag):
    converter = html2text.HTML2Text()
    converter.ignore_links = True
    content = converter.handle(tag)
    content = re.sub("\n", "", content)
    content = re.sub("\*{2}", "", content)

    return content


def check_html_string(text):
    return bool(BeautifulSoup(text, "html.parser").find())


def insert_tags(tags):
    try:
        tag_records = []
        for t in tags:
            tag_obj = {}
            tag_obj['tag'] = t
            tag_records.append(tag_obj)

        tag_collection = connection.question_tags
        cursor = tag_collection.insert_many(tag_records)
        ids = cursor.inserted_ids
        return ids
    except Exception as e:
        traceback.print_exc()
        return "error in inserting"


def insert_question(user_id, course_id, question, tags, complexity, meta_data, ques_type, duration, sub_qus, marks):
    """
    In this a new question is added to db
    1. Question type is checked.
    2. For comprehension a sub_qus is added in schema and for other types meta_data is inserted.
    3. Question with images are also handled.
    4. Same options for questions are not allowed.
    """
    try:
        ques_type_value = mongo_session.get_all_data_for_particular_condition_fields(collection="question_type",
                                                                                     condition={
                                                                                         "_id": ObjectId(ques_type)}
                                                                                     )['message'][0]['value']
    except Exception as e:
        res_data = {"message": "Invalid question type"}
        api_status = 400
        return res_data, api_status

    try:
        if not sub_qus and not meta_data:
            raise ValueError("Invalid Data")

    except ValueError as e:
        return {"message": e.args[0]}, 400

    try:
        if ques_type_value == 'text':
            if not meta_data[0]['answer']:
                message = "Modal answer is required."
                api_status = 400
                ques_data = {'message': message, 'id': ''}
                return ques_data, api_status

        org_name_res = mongo_session.get_data_for_particular_columns_with_condition("user_profile",
                                                                                    {"_id": ObjectId(user_id)},
                                                                                    ["organisation"])
        org_name = org_name_res['message'][0]['organisation']
        tags_collection = mongo_session.get_all_data("question_tags")['message']
        tags_dict = dict(map(lambda x: (x['tag'], x['_id']), tags_collection))
        new_tags = []
        tag_ids = []
        for t in tags:
            if t['_id'] == t['tag']:
                if t['tag'] in tags_dict.keys():
                    tag_ids.append(ObjectId(tags_dict[t['tag']]))
                else:
                    new_tags.append(t['tag'])
            else:
                tag_ids.append(ObjectId(t['_id']))

        if new_tags:
            tag_ids.extend(insert_tags(new_tags))

        # fetching s3_key of image present in question text
        question = replace_s3_links_with_keys(question)
        if ques_type_value == "comprehension":
            # fetching s3_key of image present in sub questions
            for ques in sub_qus:
                images_key_sub_question = get_s3_key_in_question(ques['question'])
                if images_key_sub_question:
                    bs_sub_question = BeautifulSoup(ques['question'])
                    for img, key in zip(bs_sub_question.findAll('img'), images_key_sub_question):
                        img['src'] = key
                    ques['question'] = str(bs_sub_question)
                # to restrict that same options for a question are not allowed
                unique_options = []
                # fetching s3_key of image present in sub questions option
                for data in ques['meta_data']:
                    images_key_sub_question_option = get_s3_key_in_question(data['option'])
                    if images_key_sub_question_option:
                        bs_option = BeautifulSoup(data['option'])
                        for img, key in zip(bs_option.findAll('img'), images_key_sub_question_option):
                            img['src'] = key
                        data['option'] = str(bs_option)
                    bs_data = BeautifulSoup(data['option'])
                    if bs_data.text != "":
                        bs_data = bs_data.text.replace("\n", "").replace(" ", "")
                        if bs_data in unique_options:
                            return {'message': "Options with same value cannot be added.", 'id': ''}, 400
                    else:
                        bs_data = data['option']
                        if bs_data in unique_options:
                            return {'message': "Options with same value cannot be added.", 'id': ''}, 400
                    unique_options.append(bs_data)
        else:
            # to restrict that same options for a question are not allowed
            unique_options = []
            for data in meta_data:
                if ques_type_value == "text":
                    # fetching s3_key of image present in answer
                    data['answer'] = replace_s3_links_with_keys(data['answer'])
                else:
                    # fetching s3_key of image present in option
                    data['option'] = replace_s3_links_with_keys(data['option'])

                    # checking the duplicity of options
                    bs_data = BeautifulSoup(data['option'])
                    if bs_data.text != "":
                        bs_data = bs_data.text.replace("\n", "").replace(" ", "")
                        if bs_data in unique_options:
                            return {'message': "Options with same value cannot be added.", 'id': ''}, 400
                    else:
                        bs_data = data['option']
                        if bs_data in unique_options:
                            return {'message': "Options with same value cannot be added.", 'id': ''}, 400
                    unique_options.append(bs_data)

        filtered_text = filtered_html_tags(question)
        ques_text = ""
        if filtered_text == "":
            images_key_question = get_s3_key_in_question(question)
            if images_key_question:
                ques_data = BeautifulSoup(question)
                for img, key in zip(ques_data.findAll('img'), images_key_question):
                    img['src'] = key
                    url, status = s3_function.generate_presigned_url_from_s3(key)
                    resp = urllib.request.urlopen(url)
                    image = np.asarray(bytearray(resp.read()), dtype="uint8")
                    image = cv2.imdecode(image, cv2.IMREAD_COLOR)
                    # image = cv
                    text = pytesseract.image_to_string(image)
                    ques_text += text
                filtered_text = ques_text

        document = {
            'user_id': ObjectId(user_id),
            'organisation': org_name,
            'course_id': ObjectId(course_id),
            'question': question,
            "filtered_question": filtered_text,
            'tags': tag_ids,
            'complexity': ObjectId(complexity),
            'questype': ObjectId(ques_type),
            'duration': duration,
            'marks': marks,
            "in_assessment": False,
            "in_import_table": False
        }

        if ques_type_value == "comprehension":
            document['sub_qus'] = sub_qus
        else:
            document['meta_data'] = meta_data

        add_question_collection = connection.add_questions
        cursor = add_question_collection.insert_one(document)
        id = str(cursor.inserted_id)
        document['_id'] = id

        if index_question(document):
            message = "Question added successfully"
            api_status = 201
        else:
            message = "failed to insert in elastic"
            api_status = 500
        ques_data = {'message': message, 'id': id}

    except Exception as e:
        traceback.print_exc()
        message = "unable to add question"
        api_status = 500
        ques_data = {'message': message, 'id': ''}

    return ques_data, api_status


def get_questions(user_id):
    """
    this is used to get all the data of questions in the db
    """
    try:
        id_cond = {"_id": ObjectId(user_id)}
        institute_name_res = mongo_session.get_data_for_particular_columns_with_condition("user_profile",
                                                                                          id_cond, ['organisation'])
        institute_name = institute_name_res['message'][0]['organisation']

        tags_collection = mongo_session.get_all_data("question_tags")['message']
        tags_dict = dict(map(lambda x: (str(x['_id']), x['tag']), tags_collection))

        type_collection = mongo_session.get_all_data("question_type")['message']
        type_dict = dict(map(lambda x: (str(x['_id']), x['name']), type_collection))

        complexity_collection = mongo_session.get_all_data("question_complexity")['message']
        complexity_dict = dict(map(lambda x: (str(x['_id']), x['name']), complexity_collection))

        org_cond = {'organisation': institute_name}
        resp_data = mongo_session.get_all_data_for_particular_condition_fields("add_questions", org_cond)['message']

        for doc in resp_data:
            # fetching image urls present in question text
            image_urls_question = get_img_in_question(doc['question'])
            if image_urls_question:
                bs_question = BeautifulSoup(doc['question'])
                for img, url in zip(bs_question.findAll('img'), image_urls_question):
                    img['src'] = url
                doc['question'] = str(bs_question)

            if type_dict[str(doc['questype'])] == "Comprehension":
                # fetching image urls present in sub_question
                for ques in doc['sub_qus']:
                    image_urls_sub_qus = get_img_in_question(ques['question'])
                    if image_urls_sub_qus:
                        bs_sub_question = BeautifulSoup(ques['question'])
                        for img, url in zip(bs_sub_question.findAll('img'), image_urls_sub_qus):
                            img['src'] = url
                        ques['question'] = str(bs_sub_question)

                    for data in ques['meta_data']:
                        image_urls_option = get_img_in_question(data['option'])
                        if image_urls_option:
                            bs_option = BeautifulSoup(data['option'])
                            for img, url in zip(bs_option.findAll('img'), image_urls_option):
                                img['src'] = url
                            data['option'] = str(bs_option)
            else:
                # fetching image urls present in meta_data
                for data in doc['meta_data']:
                    image_urls_option = get_img_in_question(data['option'])
                    if image_urls_option:
                        bs_option = BeautifulSoup(data['option'])
                        for img, url in zip(bs_option.findAll('img'), image_urls_option):
                            img['src'] = url
                        data['option'] = str(bs_option)

            tag = []
            for t in doc['tags']:
                if str(t) in tags_dict.keys():
                    custom_obj = {
                        '_id': str(t),
                        'tag': tags_dict[str(t)]
                    }
                    tag.append(custom_obj)
            doc['tags'] = tag

            type_custom_obj = {
                '_id': str(doc['questype']),
                'type': type_dict[str(doc['questype'])]
            }
            complexity_custom_obj = {
                '_id': str(doc['complexity']),
                'complexity': complexity_dict[str(doc['complexity'])]
            }
            doc['complexity'] = complexity_custom_obj
            doc['questype'] = type_custom_obj
            doc['course_id'] = str(doc['course_id'])
            doc['user_id'] = str(doc['user_id'])

        question_data = {'status': 'success', 'data': resp_data}
        api_status = 200

    except Exception as e:
        traceback.print_exc()
        question_data = {"status": "failed", "data": []}
        api_status = 400

    return question_data, api_status


def fetch_question_complexities():
    mongo_res = mongo_session.get_all_data(collection='question_complexity')
    complexity_dict = {}
    complexity_dict['complexity'] = mongo_res['message']
    status = mongo_res['status']
    return (status, complexity_dict)


def fetch_question_type():
    mongo_res = mongo_session.get_all_data(collection='question_type')
    type_dict = {}
    type_dict['ques_type'] = mongo_res['message']
    status = mongo_res['status']
    return (status, type_dict)


def upload_files_questionbank(user_id, file_path):
    try:
        supported_files_content_type = supported_image_content_type + supported_video_content_type + other_supported_content_type
        print(file_path)
        file_ext_validation = get_extension_validation(file_path, supported_files_content_type)
        print(file_ext_validation)
        if file_ext_validation[0]:
            unique_key = str(int(time.time())) + '-' + str(user_id)
            file_content_type = config.supported_content_type_with_extension[file_ext_validation[1]]


            file_s3_info = s3_function.upload_data_to_s3_private(file_path, unique_key=unique_key,
                                                                 folder_name="question_bank_files/",
                                                                 file_extension=file_ext_validation[1],
                                                                 Content_Type=file_content_type)
            file_s3_links = file_s3_info['s3_link']
            file_s3_path = file_s3_info['s3_key']
            # print("4-->", file_s3_info)
            # file_s3_links = file_s3_info['s3_link']
            # file_s3_path = file_s3_info['s3_key']
            # print("2-->",file_s3_path, file_s3_links )


            documnet = {
                "user_id": user_id,
                "s3_key": file_s3_path,
                "file_type": file_content_type,
                "uploaded_at": int(time.time()),
                "module_name": ""
            }
            add_question_files_collection = connection.global_resource_bank
            cursor = add_question_files_collection.insert_one(documnet)
            file_id = str(cursor.inserted_id)
            inst_doc = {
                "resource_id": ObjectId(file_id),
                "tags": [],
                "description": "",
                "title": "",
                "module": "",
                "used_at": "",
                "updated_at": utc_datetime_now(),
                "updated_by": ObjectId(user_id),
            }
            add_instance_collection = connection.resource_bank_instance
            cursor_in = add_instance_collection.insert_one(inst_doc)

        else:
            api_status = 400
            uploaded_data = {"message": "file path not supported"}
            return uploaded_data, api_status

        print("file uploaded", file_s3_info)
        api_status = 200
        uploaded_data = {"message": "files uploaded", "location": file_s3_links, "file_id": file_id,
                         "file_type": file_content_type, "file_path": file_s3_path}

    except Exception as e:
        print(e)
        uploaded_data = {"message": "uploaded failed"}
        api_status = 400

    return uploaded_data, api_status


def update_question_db(user_id, course_id, question, tags, complexity, meta_data, ques_type, duration, question_id,
                       import_ques, sub_qus, marks):
    """
    it is used update question in db
    1. It is checked whether question is imported or not
    2. If yes then it is inserted in db otherwise following question is updated
    """
    try:
        org_name_res = mongo_session.get_data_for_particular_columns_with_condition("user_profile",
                                                                                    {"_id": ObjectId(user_id)},
                                                                                    ["organisation"])
        org_name = org_name_res['message'][0]['organisation']
        ques_type_collection = mongo_session.get_all_data("question_type")['message']
        ques_type_dict = dict(map(lambda x: (x['_id'], x['value']), ques_type_collection))
        tags_collection = mongo_session.get_all_data("question_tags")['message']
        tags_dict = dict(map(lambda x: (x['tag'], x['_id']), tags_collection))
        new_tags = []
        tag_ids = []
        for t in tags:
            if t['_id'] == t['tag']:
                if t['tag'] in tags_dict.keys():
                    tag_ids.append(ObjectId(tags_dict[t['tag']]))
                else:
                    new_tags.append(t['tag'])
            else:
                tag_ids.append(ObjectId(t['_id']))
        if new_tags:
            tag_ids.extend(insert_tags(new_tags))

        if not import_ques:
            # fetching s3_key of image present in question text
            question = replace_s3_links_with_keys(question)
            if ques_type_dict[ques_type] == "comprehension":
                # fetching s3_key of image present in sub questions
                for ques in sub_qus:
                    images_key_sub_question = get_s3_key_in_question(ques['question'])
                    if images_key_sub_question:
                        bs_sub_question = BeautifulSoup(ques['question'])
                        for img, url in zip(bs_sub_question.findAll('img'), images_key_sub_question):
                            img['src'] = url
                        ques['question'] = str(bs_sub_question)
                    # fetching s3_key of image present in sub questions option
                    for data in ques['meta_data']:
                        images_key_sub_question_option = get_s3_key_in_question(data['option'])
                        if images_key_sub_question_option:
                            bs_option = BeautifulSoup(data['option'])
                            for img, url in zip(bs_option.findAll('img'), images_key_sub_question_option):
                                img['src'] = url
                            data['option'] = str(bs_option)
            else:
                unique_options = []
                for data in meta_data:
                    if ques_type_dict[ques_type] == "text":
                        data['answer'] = replace_s3_links_with_keys(data['answer'])
                    else:
                        # fetching s3_key of image present in option
                        data['option'] = replace_s3_links_with_keys(data['option'])
                        # checking the duplicity of options
                        bs_data = BeautifulSoup(data['option'])
                        bs_data = bs_data.text.replace("\n", "").replace(" ", "")
                        if bs_data in unique_options:
                            return {'message': "Options with same value cannot be added.", 'id': ''}, 400
                        unique_options.append(bs_data)
        question_text = filtered_html_tags(question)
        in_assessment = mongo_session.get_all_data_for_particular_condition_fields(collection="add_questions",
                                                                                   condition={
                                                                                       "_id": ObjectId(question_id)},
                                                                                   )['message'][0]['in_assessment']
        document = {
            'user_id': ObjectId(user_id),
            'course_id': ObjectId(course_id),
            'question': question,
            'filtered_question': question_text,
            'tags': tag_ids,
            'complexity': ObjectId(complexity),
            'questype': ObjectId(ques_type),
            'duration': duration,
            "in_import_table": False,
            "organisation": org_name,
            "in_assessment": in_assessment,
            "marks": marks
        }
        if ques_type_dict[str(ques_type)] == 'comprehension':
            document['sub_qus'] = sub_qus
        else:
            document['meta_data'] = meta_data
        if import_ques:
            document['in_assessment'] = False
            res = mongo_session.insert_documnet("add_questions", document)
            import_ques_coll = connection.add_questions_temp
            import_ques_coll.delete_one({"_id": ObjectId(question_id)})
            document['_id'] = res['_id']
        else:
            res = mongo_session.update_multiple_fields("add_questions", {"_id": ObjectId(question_id)}, document)
            document['_id'] = question_id
        res_data = {}
        api_status = res['status']
        if index_question(document):
            res_data['message'] = "question updated"
        else:
            api_status = 500

    except Exception as e:
        traceback.print_exc()
        res_data = {"message": "failed"}
        api_status = 400

    return res_data, api_status


def insert_created_assessment(user_id, assessment_name, type, total_time, tags, questions,
                              publish, negative_marking, negative_value, total_marks, assign_marks, org_name,assessment_description):
    """
    It is used to Create Assessment and insert it in Mongodb
    1. A document is created with different attributes that can be inserted in Mongodb.
    """
    assessment_data = mongo_session.find_one_in_db(collection="assessment",
                                                   condition={"assessment_name": assessment_name
                                                       , "organisation": org_name},
                                                   columns=["assessment_name"])
    if assessment_data['message']:
        raise InvalidUsage(message="Assessment with this name already exist, can't Proceed.", status_code=400)

    current_time = convert_utc_ist(format="%Y-%m-%dT%H:%M:%S.%f",
                                   time_obj=datetime.now()).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + 'Z'
    tags = [ObjectId(t) for t in tags]
    ques_type_collection = mongo_session.get_all_data("question_type")['message']
    ques_type_dict = dict(map(lambda x: (x['_id'], x['value']), ques_type_collection))
    question_set = set()
    question_marks_sum = 0
    for q in questions:
        # check negative value in mark
        if q['marks'] < 0:
            raise InvalidUsage(message="Marks can not be negative", status_code=400)
        question_marks_sum += q['marks']
        q_id = q['question_id']
        question_data = mongo_session.get_all_data_for_particular_condition_fields(collection="add_questions",
                                                                                   condition={"_id": ObjectId(q_id)}
                                                                                   )['message'][0]
        if ques_type_dict[str(question_data['questype'])] == 'comprehension':
            raise InvalidUsage(message="Cannot add Comprehension type question to assessment", status_code=400)

        if q_id in question_set:
            raise InvalidUsage(message="Duplicate questions not allowed", status_code=400)
        else:
            question_set.add(q_id)
        q['question_id'] = ObjectId(q_id)
        update_res = mongo_session.update_multiple_fields("add_questions", {"_id": ObjectId(q_id)},
                                                          {"in_assessment": True})
    if int(total_marks) != question_marks_sum:
        raise InvalidUsage(message="Total Marks is not equal to sum of marks of each question", status_code=400)
    docs = {
        "user_id": user_id,
        'assessment_name': assessment_name,
        'assessment_type': type,
        'total_time': total_time,
        'tags': tags,
        'questions': questions,
        'publish': publish,
        'organisation': org_name,
        'module_name': "assessment",
        'created_date': current_time,
        'negative_marking': negative_marking,
        'negative_value': negative_value,
        "assign_marks": assign_marks,
        "total_marks": total_marks,
        "assessment_description" : assessment_description
    }

    collection = connection.assessment
    cursor = collection.insert_one(docs)
    id = str(cursor.inserted_id)
    res_data = {"message": "assessment_saved", "assessment_id": id}

    return res_data


def update_assessment(user_id, assessment_name, questions, tags, total_time, publish, assessment_id, assessment_type,
                      negative_marking, negative_value, total_marks, assign_marks, org_name, created_by,assessment_description):
    """
         it is used update assessment in db
         1. It is checked whether the assessment is published
         2. If yes then it is inserted in db with different name else it gets updated
    """
    assessment_data = mongo_session.find_one_in_db(collection="assessment",
                                                   condition={"assessment_name": assessment_name,
                                                              "organisation": org_name,
                                                              "_id":
                                                                  {"$ne": ObjectId(assessment_id)}},
                                                   columns=["assessment_name"])
    if assessment_data['message']:
        raise InvalidUsage(message="Assessment with this name already exist, can't Proceed.", status_code=400)
    assessment_coll = mongo_session.get_all_data_for_particular_condition_fields("assessment",
                                                                                 {"_id": ObjectId(assessment_id)}
                                                                                 )['message'][0]
    current_time = convert_utc_ist(format="%Y-%m-%dT%H:%M:%S.%f", time_obj=datetime.now()).strftime(
        "%Y-%m-%dT%H:%M:%S.%f")[:-3] + 'Z'
    tags = [ObjectId(t) for t in tags]
    ques_type_collection = mongo_session.get_all_data("question_type")['message']
    ques_type_dict = dict(map(lambda x: (x['_id'], x['value']), ques_type_collection))
    question_set = set()
    question_marks_sum = 0
    for q in questions:
        if q['marks'] < 0:
            raise InvalidUsage(message="Marks can not be negative", status_code=400)
        question_marks_sum += q['marks']
        q_id = q['question_id']
        question_data = mongo_session.get_all_data_for_particular_condition_fields(collection="add_questions",
                                                                                   condition={"_id": ObjectId(q_id)}
                                                                                   )['message'][0]
        if ques_type_dict[str(question_data['questype'])] == 'comprehension':
            raise InvalidUsage(message="Cannot add Comprehension type question to assessment", status_code=400)

        if q_id in question_set:
            raise InvalidUsage(message="Duplicate questions not allowed", status_code=400)
        else:
            question_set.add(q_id)
        q['question_id'] = ObjectId(q_id)
        update_res = mongo_session.update_multiple_fields("add_questions", {"_id": ObjectId(q_id)},
                                                          {"in_assessment": True})
    if int(total_marks) != question_marks_sum:
        raise InvalidUsage(message="Total Marks is not equal to sum of marks of each question", status_code=400)
    docs = dict()
    docs['user_id'] = user_id
    docs['assessment_name'] = assessment_name
    docs['assessment_type'] = assessment_type
    docs['total_time'] = total_time
    docs['tags'] = tags
    docs['questions'] = questions
    docs['publish'] = publish
    docs['organisation'] = org_name
    docs['module_name'] = "assessment"
    docs['created_date'] = current_time
    docs['negative_marking'] = negative_marking
    docs['negative_value'] = negative_value
    docs['assign_marks'] = assign_marks
    docs['total_marks'] = total_marks
    docs['assessment_description'] = assessment_description
 
    if assessment_coll['publish']:
        assessment_previous_name = assessment_coll['assessment_name']
        if assessment_previous_name.strip() == assessment_name.strip():
            raise InvalidUsage(message="Same name not allowed", status_code=400)
        else:
            res = mongo_session.insert_documnet("assessment", docs)
       
    else:
        if created_by != user_id:
            if assessment_coll['assessment_name'].strip() == assessment_name.strip():
                raise InvalidUsage(message="Same name not allowed", status_code=400)
            else:
                res = mongo_session.insert_documnet("assessment", docs)
                res['message'] = 'new assessment with different name is created as the assessment was created by ' \
                                 'different user.'
        else:
            res = mongo_session.update_multiple_fields("assessment", {"_id": ObjectId(assessment_id)}, docs)
    res_data = {"message": res['message']}
    api_status = res["status"]

    if api_status != 200:
        raise Exception("Failed to update assessment")

    return res_data


def saved_assessment_info(user_id, page_num, assessment_type):
    try:
        org_name_res = mongo_session.get_data_for_particular_columns_with_condition("user_profile",
                                                                                    {"_id": ObjectId(user_id)},
                                                                                    ["organisation"])
        
        org_name = org_name_res['message'][0]['organisation']
        if assessment_type == 'published':
            mongo_res = mongo_session.get_saved_assessment_list("assessment",
                                                                {"organisation": org_name, "module_name": "assessment",
                                                                 "publish": True}, page_num)
            
        elif assessment_type == 'unpublished':
            mongo_res = mongo_session.get_saved_assessment_list("assessment",
                                                                {"organisation": org_name, "module_name": "assessment",
                                                                 "publish": False}, page_num)
        else:
            mongo_res = mongo_session.get_saved_assessment_list("assessment",
                                                                {"organisation": org_name, "module_name": "assessment"
                                                                 }, page_num)
        res_data = {"saved_assessment": mongo_res['message'], "total_assessments": mongo_res['total_assessments']}
        api_status = mongo_res['status']

    except Exception as e:
        traceback.print_exc()
        res_data = {"message": "failed"}
        api_status = 400

    return res_data, api_status


def delete_assessment(user_id, assessment_id):
    assessment_data = mongo_session.find_one_in_db(collection="assessment",
                                                   condition={"_id": ObjectId(assessment_id), "user_id": user_id},
                                                   columns=["_id"])
    course_data = mongo_session.find_one_in_db(collection="courses_bank",
                                                   condition={"course_assessments": {"$elemMatch": {"_id": ObjectId(assessment_id)}}},
                                                   columns={"_id"})
    topic_data = mongo_session.find_one_in_db(collection="course_topics",
                                                   condition={"assessments": {"$elemMatch": {"_id": ObjectId(assessment_id)}}},
                                                   columns={"_id"})
    session_data = mongo_session.find_one_in_db(collection="course_sessions",
                                                   condition={"course_assessments": {"$elemMatch": {"_id": ObjectId(assessment_id)}}},
                                                   columns={"_id"})
    if course_data['message']:
        raise InvalidUsage("Cannot delete assessment already being used in course", 403)
    if topic_data['message']:
        raise InvalidUsage("Cannot delete assessment already being used in topic", 403)
    if session_data['message']:
        raise InvalidUsage("Cannot delete assessment already being used in session", 403)
    if assessment_data["message"]:
        status = mongo_session.delete_records("assessment", condition={"_id": ObjectId(assessment_id), "user_id": user_id})
        if status == 200:
            res = "assessment deleted successfully"
        else: 
            raise Exception("Failed to delete assessment")
    else: 
        res = "assessment not found"
        status = 404
    return res, status


def search_assessment(user_id, search_text, page):
    """return the questions after string matching with the questions in database after filtering same school
    and grade lower and of same level"""
    assessments = []
    final_assessments = []
    final_tags = []
    assessment_list = mongo_session.get_all_data_for_particular_condition_fields(collection='assessment',
                                                                                    condition={"user_id": user_id})["message"]
    #assessment_list = mongo_session.get_all_data(collection='assessment')["message"]
    global_tag_list = mongo_session.get_all_data(collection="global_tags")["message"]
    question_tag_list = mongo_session.get_all_data(collection="question_tags")["message"]
    search_text = search_text.lower()
    for assessment in assessment_list:
        try:
            final_tags = []
            if search_text in assessment["assessment_name"].lower():
                if assessment["publish"] == True:
                    assessment["status"] = "published"
                elif assessment["publish"] == False:
                    assessment["status"] = "unpublished"
                for tags in assessment["tags"]:
                    for tag in global_tag_list:
                        if str(tags) == str(tag["_id"]):
                            final_tags.append({
                                        "_id": str(tag["_id"]),
                                        "tag": tag["tag"]
                                        })
                    for tag in question_tag_list:
                        if str(tags) == str(tag["_id"]):
                            final_tags.append({
                                        "_id": str(tag["_id"]),
                                        "tag": tag["tag"]
                                        })
                assessment["tags"] = final_tags
                for question in assessment["questions"]:
                    question["question_id"] = str(question["question_id"])
                assessments.append(assessment)
        except:
            continue
    if len(assessments) == 0: 
        return "No search data found", 404
    max_assessment_per_page = 10
    assessment_data = [assessments[i: i + max_assessment_per_page] for i in range(0, len(assessments), max_assessment_per_page)]
    if page > len(assessment_data):
        raise Exception("You are exceeding maximum page limit")
    try:
        for assessment_index in assessment_data[page]:
            # get course name for each assessment
            course_name_check = mongo_session.get_data_for_particular_columns_with_condition(collection="courses_bank",
                                                                            condition={"course_assessments": {"$elemMatch": {"_id": ObjectId(assessment_index['_id'])}}},
                                                                            columns={"subject", "tags"})
            if course_name_check["message"]:
                course_detail = course_name_check["message"][0]
                if course_detail:
                    course_detail["_id"] = str(course_detail["_id"])
                    assessment_index['courses'] = {"_id": course_detail["_id"],
                                                    "course": course_detail["subject"]}
            else:
                assessment_index['courses'] = []
            final_assessments.append(assessment_index)
    except:
        for assessment_index in assessment_data[0]:
            # get course name for each assessment
            course_name_check = mongo_session.get_data_for_particular_columns_with_condition(collection="courses_bank",
                                                                            condition={"course_assessments": {"$elemMatch": {"_id": ObjectId(assessment_index['_id'])}}},
                                                                            columns={"subject", "tags"})
            if course_name_check["message"]:
                course_detail = course_name_check["message"]
                detail_course = []
                for detail in course_detail:
                    if detail:
                        detail["_id"] = str(detail["_id"])
                        detail_course.append({"_id": detail["_id"],
                                                        "course": detail["subject"]})
                assessment_index['courses'] = detail_course
            else:
                assessment_index['courses'] = []
            final_assessments.append(assessment_index)
    assessments_data = {"assessments": final_assessments, "total_pages": len(assessment_data), "current_page": int(page)}
    api_status = 200
    return assessments_data, api_status


def get_list_assessments(user_id):
    try:

        org_name_res = mongo_session.get_data_for_particular_columns_with_condition("user_profile",
                                                                                    {"_id": ObjectId(user_id)},
                                                                                    ["organisation"])
        org_name = org_name_res['message'][0]['organisation']

        mongo_res = mongo_session.get_assessment_info("assessment",
                                                      {"organisation": org_name, "module_name": "assessment",
                                                       "publish": True})
        res_data = {}
        res_data['assessment_list'] = mongo_res['message']
        res_data["assessment_list"] = res_data["assessment_list"][::-1]
        api_status = mongo_res['status']

    except Exception as e:
        traceback.print_exc()
        res_data = {"assessment_list": mongo_res['message']}
        api_status = 400

    return res_data, api_status


def time_remaining_to_start_assessment(schedule_assessment_id):
    """
    Calculate the time remaining for assessment to start
    """
    current_time = convert_utc_ist(format="%Y:%m:%dT%H:%M", time_obj=datetime.now())
    schedule_collection = mongo_session.get_all_data_for_particular_condition_fields("schedule_assessment",
                                                                                     {"_id": ObjectId(
                                                                                         schedule_assessment_id)}
                                                                                     )["message"][0]
    start_time = schedule_collection['start_time']
    start_time_obj = datetime.strptime(start_time, "%Y:%m:%dT%H:%M")
    time_diff = int((start_time_obj - current_time).total_seconds() / 60)

    return time_diff


def search_similar_questions(question_id, role, org_type, grade, search_text, user_id):
    """ this function returns similar questions to the one user is visiting after filtering same school and grade lower
    and of same level"""
    if role == "student":
        if org_type == "school":
            user_condition = {"grade": {"$lt": int(grade) + 1}, "institute_type": org_type}
        elif org_type in ["college", "university"]:
            user_condition = {"$or": [{"grade": {"$lt": int(grade) + 1}, "institute_type": org_type},
                                      {"institute_type": "school"}]}
    else:
        user_condition = {}
    valid_users_from_db = mongo_session.access_specific_fields(collection="user_profile",
                                                               condition=user_condition,
                                                               columns={"_id": 1},
                                                               return_keys=["_id"])
    user_list = [str(user["_id"]) for user in valid_users_from_db]
    questions_from_question_bank = mongo_session.access_specific_fields(collection="question_bank",
                                                                        condition={})
    
    #track user data
    datetime = utc_datetime_now()
    doc = {"user_id": user_id, "question_id": question_id, "datetime": datetime}
    mongo_session.insert_documnet('question_tracking', doc)
    #track user data end

    questions = []
    stop_words = set(stopwords.words("english"))
    for question in questions_from_question_bank:
        question['_id'] = str(question['_id'])
        if question['_id'] != question_id:
            question["course_category_id"] = str(question["course_category_id"])
            for answer in question["answers"]:
                answer["_id"] = str(answer["_id"])
            similarity_status = False
            for word in word_tokenize(search_text):
                if word not in stop_words and word.lower() in word_tokenize(question['questions'].lower()):
                    similarity_status = True
            if question['user_id'] in user_list and similarity_status:
                if question.get("course_id"):
                    question["course_id"] = str(question["course_id"])
                    question["course_session_id"] = str(question["course_session_id"])
                questions.append(question)
    similar_questions = Similar_questions.find_similarity_search_question_string_matching(search_text,
                                                                                          questions,
                                                                                          is_similar=True)
    similar_questions = similar_questions[0:20]
    question_data = {"status": "success", "questions": similar_questions}
    api_status = 200
    return question_data, api_status


def submit_answer(question_id, user_id, answer_html, speech_text, video_info, answer_image, answer_video, answer_doc,
                  coordinates=None):
    """To submit answers given by users on questions asked by others.
       Note: question does not accept answers if status is equal to true, that means it is closed for answers.
       :param question_id: mongo id of the question to answer.
       :param user_id: mongo id of the user who is answering.
       :param answer_html: html containing the answer content.
       :param speech_text: speech captured text.
       :param video_info: video details.
       :param coordinates: screen coordinates for the mobile(optional)
       :param answer_image: array of images uploaded
       :param answer_video: array of videos uploaded
       :param answer_doc: array of docs uploaded
       :type question_id: str.
       :type user_id: str.
       :type answer_html: html.
       :type speech_text: str.
       :type video_info: object containing "video_path" and "thumbnail" in s3_keys form.

       )"""
    # Note: As answer html already contain s3 keys so need of processing.
    question_info = mongo_session.check_existance_return_info(collection="question_bank",
                                                              condition={"_id": ObjectId(question_id)},
                                                              columns={"user_id": 1,
                                                                       "status": 1,
                                                                       "Course_Category": 1},
                                                              return_keys=["user_id", "status", "Course_Category"]
                                                              )
    if not question_info:
        raise InvalidUsage("Sorry this question is not available right now.", 400)
    # user should not answer his/her own question
    if question_info["user_id"] == user_id:
        raise InvalidUsage("You cannot answer your own question.", 403)
    # check question is open for answers
    if question_info["status"]:
        raise InvalidUsage("Oops! This Question is closed for submissions.", 400)

    # list containing s3 keys to delete from temp collection
    delete_files = []
    # validate s3 keys in video info if video exists
    return_video_info = copy.deepcopy(video_info)
    if return_video_info:
        if not s3_function._key_existing_size__list(return_video_info["video_path"]):
            raise InvalidUsage("Some error occurs, please upload the video again.", 400)
        delete_files.append(return_video_info["video_path"])
        return_video_info["video_path"], status = s3_function.generate_presigned_url_from_s3(
            return_video_info["video_path"])

        if return_video_info["thumbnail"]:
            if not s3_function._key_existing_size__list(return_video_info["thumbnail"]):
                raise InvalidUsage("Some error occurs, please check the thumbnail for the video again.", 400)
            delete_files.append(return_video_info["thumbnail"])
            return_video_info["thumbnail"], status = s3_function.generate_presigned_url_from_s3(
                return_video_info["thumbnail"])

    # replace s3 links with keys
    if answer_html != "":
        answer_html = replace_s3_links_with_keys(answer_html)
        # process html content to get s3 keys to delete
        answer_s3_keys = extract_s3_keys_from_html_str(answer_html)
        delete_files.extend(answer_s3_keys)

    # delete files from temp collection
    if delete_files:
        response = mongo_session.delete_data(collection="temp_uploaded_files",
                                             condition={"s3_key": {"$in": delete_files}})
        if len(delete_files) != int(response['n']):
            raise InvalidUsage("Please check the files you attached in your answer.", 400)

    doc_to_insert = {"user_id": ObjectId(user_id),
                     "answer_html": answer_html,
                     "question_id": ObjectId(question_id),
                     "Rating": [],
                     "Feedback": [],
                     "course_category": question_info['Course_Category'],
                     "Liked": [],
                     "Disliked": [],
                     "approval_status": 0,
                     "speech_text": speech_text,
                     "created_at": utc_datetime_now()}
    file_size = 0
    if video_info:
        doc_to_insert["video"] = video_info
    if answer_image:
        for a_image in answer_image:
            size, size_status = s3_function.get_size_s3key(a_image)
            file_size = file_size + size
        doc_to_insert["answer_image"] = answer_image
    if answer_video:
        for a_video in answer_video:
            size, size_status = s3_function.get_size_s3key(a_video)
            file_size = file_size + size
        doc_to_insert["answer_video"] = answer_video
    if answer_doc:
        for a_doc in answer_doc:
            size, size_status = s3_function.get_size_s3key(a_doc)
            file_size = file_size + size
        doc_to_insert["answer_doc"] = answer_doc
    if coordinates:
        doc_to_insert["coordinates"] = coordinates
    #  utc_datetime_now(): utc datetime when the answer was given
    if file_size > 20480:
        raise Exception("File size limit exceeded, Please reduce the size to 20MB")
    notification_status = ""

    answer_inserted = mongo_session.insert_documnet(
        collection='answer_bank',
        doc_to_insert=doc_to_insert)
    if answer_inserted['status'] != 200:
        raise InvalidUsage("Oops! Something is wrong on our side. Please continue answering after some time.", 500)

    answer_id = answer_inserted['_id'].inserted_id

    update_user_profile = mongo_session.update_record_into_db(
        collection="user_profile",
        condition={"_id": ObjectId(user_id)},
        update_info={"$push": {"answers": {"_id": answer_id}}})

    update_question_bank = mongo_session.update_record_into_db(
        collection="question_bank",
        condition={"_id": ObjectId(question_id)},
        update_info={"$push": {"answers": {"_id": answer_id}}})

    if question_info['user_id'] != "celery_service":
        device_tokens = mongo_session.get_device_tokens(
            collection="user_profile",
            condition={"_id": ObjectId(question_info['user_id']), "user_device_tokens": {"$exists": True}},
            columns={"user_device_tokens": 1, "_id": 0})
        if device_tokens['status'] == 200:
            firebase_response = Notification.notify_inquisitive_answer_question(
                user_id=ObjectId(question_info['user_id']),
                device_tokens=device_tokens['message'],
                question_id=question_id)
            if firebase_response['status'] == 200:
                notification_status = firebase_response['notification_status']

    return {
        "answer_id": str(answer_id),
        "video": return_video_info,
        "notification_status": notification_status,
        "question_id": question_id,
        "course_category": question_info['Course_Category'],
        "message": "Thanks for collaborating by giving awesome answers."}


def aiken_regex(data):
    return re.sub("\r", "", data)


def fetch_text_tags(link, tag):
    soup = BeautifulSoup(link)
    tags_content = soup.find_all(tag)
    return tags_content


def filtered_html_tags(text):
    """
    filtered the text contained in an html string using beautiful soup
    """
    soup = BeautifulSoup(text)
    return " ".join(soup.text.split())



def aiken_format_questions(file_path, qtype, user_id):
    """
    It parse an aiken format file (text file) and insert it in a temp collection
    1. file is uploaded to s3
    2. file content is decode to utf-8 and split into question,options,answer
    3. iterate over the questions,options and answer and insert in the database
    """
    try:
        file_path.seek(0)
        file_type = file_checker.from_buffer(file_path.read(1024), mime=True)
        if file_type == "text/plain" or file_type == 'text/csv' or file_type == 'application/csv':
            if not file_path.filename.lower().endswith('.txt'):
                file_path.filename += ".txt"
        else:
            raise IOError
    except IOError as e:
        res_data = {"message": "only text files are allowed for Aiken", }
        api_status = 400
        return res_data, api_status

    uploaded_data, status = upload_files_questionbank(file_path=file_path, user_id=user_id)
    assessment_list = list()
    assessment_list.append('')

    if status == 200:
        file_key = uploaded_data['file_path']
        file_path.seek(0)
        csv_result = chardet.detect(file_path.read())
        file_path.seek(0)
        df = pandas.read_csv(file_path, encoding=csv_result['encoding'])
        df = df.fillna(0)
        column_names = list(df.columns)
        question_validations = {"multianswermcq": ['Question', 'Answer', 'Options', 'Tags', 'Complexity', 'Duration', 'Marks'],
                                "singleanswermcq": ['Question', 'Answer', 'Options', 'Tags', 'Complexity', 'Duration', 'Marks'],
                                "bool": ['Question', 'Answer', 'Options', 'Tags', 'Complexity', 'Duration', 'Marks'],
                                "text": ['Question', 'Answer', 'Tags', 'Complexity', 'Duration', 'Marks'],
                                "fib": ['Question', 'Answer', 'Tags', 'Complexity', 'Duration', 'Marks'],
                                "comprehension": ['Question', 'Tags', 'Complexity', 'Duration', 'Marks']}
        if column_names != question_validations[qtype.lower()]:
            raise InvalidUsage("Please check the file uploaded. Columns are incorrect.", 406)
        assessment_dict = df.to_dict()
        question = []
        answer = []
        option = []
        tags = []
        complexity = []
        duration = []
        marks = []
        for k, v in assessment_dict.items():
            for k1, v1 in v.items():
                if k == 'Question':
                    question.append(v1)
                elif k == 'Answer':
                    answer.append(v1)
                elif k == 'Tags':
                    try:
                        v1 = v1.split(',')
                    except:
                        raise InvalidUsage('Tags invalid in one of the Questions.', 406)
                    tags.append(v1)
                elif k == 'Complexity':
                    complexity.append(v1)
                elif k == 'Duration':
                    duration.append(v1)
                elif k == 'Marks':
                    marks.append(v1)
                if qtype == "SingleAnswerMCQ" or qtype == "MultiAnswerMCQ" or qtype == "SingleAnswerMCQ".lower() or qtype == "MultiAnswerMCQ".lower() or qtype == "bool":
                    if k == 'Options':
                        option.append(v1)

        records = []
        org_name_res = mongo_session.get_data_for_particular_columns_with_condition("user_profile",
                                                                                    {"_id": ObjectId(user_id)},
                                                                                    ["organisation"])
        org_name = org_name_res['message'][0]['organisation']

        type_collection = mongo_session.get_all_data("question_type")['message']
        type_dict = dict(map(lambda x: (x['value'], str(x['_id'])), type_collection))
        name_dict = dict(map(lambda x: (x['value'], str(x['name'])), type_collection))
        original_tags = []
        option_list = [i.split('~') for i in option if i != 0]
        check = 1
        if qtype == "SingleAnswerMCQ" or qtype == "MultiAnswerMCQ" or qtype == "SingleAnswerMCQ".lower() or qtype == "MultiAnswerMCQ".lower() or qtype == "bool":
            for ques, ans, opt, tag, comp, dur, mar in zip(question, answer, option_list, tags,
                                                      complexity, duration, marks):
                if not ques:
                    raise InvalidUsage('Question is missing in Ques. {}'.format(check), 406)
                elif not ans:
                    raise InvalidUsage('Answer is missing in Ques. {}'.format(check), 406)
                elif not tag:
                    raise InvalidUsage('Tags are missing in Ques. {}'.format(check), 406)
                elif not comp:
                    raise InvalidUsage('Complexity missing in Ques. {}'.format(check), 406)
                elif not dur:
                    raise InvalidUsage('Duration missing in Ques. {}'.format(check), 406)
                elif not mar:
                    raise InvalidUsage('Marks missing in Ques. {}'.format(check), 406)

                comp_list = ['Advanced', 'Difficult', 'Easy', 'Very Easy', 'Average']
                if comp not in comp_list:
                    raise InvalidUsage('Complexity invalid in Ques. {}'.format(check), 406)

                filtered_ques = filtered_html_tags(ques)
                tags_list = []
                tags_org = []
                for t in tag:
                    tags_collection = mongo_session.access_specific_fields(collection='question_tags',
                                                                           condition={'tag': t.strip()})
                    tags_collection_global = mongo_session.access_specific_fields(collection='global_tags',
                                                                                  condition={'tag': t.strip()})
                    if tags_collection:
                        tags_list.append(tags_collection[0]['_id'])
                        tags_org.append(t.strip())
                    elif tags_collection_global:
                        tags_list.append(tags_collection_global[0]['_id'])
                        tags_org.append(t.strip())
                if len(tags_org) != len(tag):
                    raise InvalidUsage("Please check the tags in Question {}".format(check), 406)
                comp = mongo_session.access_specific_fields(collection='question_complexity',
                                                                  condition={'name': comp})
                document = {
                    'user_id': ObjectId(user_id),
                    'organisation': org_name,
                    'question': ques,
                    'filtered_question': filtered_ques,
                    'in_assessment': False,
                    'questype': ObjectId(type_dict[qtype.lower()]),
                    'meta_data': [],
                    "in_import_table": True,
                    "answer": ans,
                    'tags': tags_list,
                    'complexity': comp,
                    'duration': dur,
                    'marks': mar
                }
                for o in opt:
                    meta_data = {}
                    meta_data["option"] = o
                    meta_data['question_type'] = name_dict[qtype.lower()]
                    meta_data['answer_max_len'] = len(o)

                    if o == ans:
                        meta_data['answer'] = True
                    else:
                        meta_data['answer'] = False
                    document['meta_data'].append(meta_data)
                records.append(document)
                original_tags.append(tags_org)
                check += 1
        else:
            for ques, ans, tag, comp, dur, mar in zip(question, answer, tags, complexity, duration, marks):
                if not ques:
                    raise InvalidUsage('Question is missing in Ques. {}'.format(check), 406)
                elif not ans and qtype.lower() != 'comprehension':
                    raise InvalidUsage('Answer is missing in Ques. {}'.format(check), 406)
                elif not tag:
                    raise InvalidUsage('Tags are missing in Ques. {}'.format(check), 406)
                elif not comp:
                    raise InvalidUsage('Complexity missing in Ques. {}'.format(check), 406)
                elif not dur:
                    raise InvalidUsage('Duration missing in Ques. {}'.format(check), 406)
                elif not mar:
                    raise InvalidUsage('Marks missing in Ques. {}'.format(check), 406)                

                comp_list = ['Advanced', 'Difficult', 'Easy', 'Very Easy', 'Average']
                if comp not in comp_list:
                    raise InvalidUsage('Complexity invalid in Ques. {}'.format(check), 406)

                filtered_ques = filtered_html_tags(ques)
                tags_list = []
                tags_org = []
                for t in tag:
                    tags_collection = mongo_session.access_specific_fields(collection='question_tags',
                                                                           condition={'tag': t.strip()})
                    tags_collection_global = mongo_session.access_specific_fields(collection='global_tags',
                                                                                  condition={'tag': t.strip()})
                    if tags_collection:
                        tags_list.append(tags_collection[0]['_id'])
                        tags_org.append(t.strip())
                    elif tags_collection_global:
                        tags_list.append(tags_collection_global[0]['_id'])
                        tags_org.append(t.strip())
                if len(tags_org) != len(tag):
                    raise InvalidUsage("Please check the tags in Question {}".format(check), 406)
                comp = mongo_session.access_specific_fields(collection='question_complexity',
                                                                  condition={'name': comp})
                document = {
                    'user_id': ObjectId(user_id),
                    'organisation': org_name,
                    'question': ques,
                    'filtered_question': filtered_ques,
                    'in_assessment': False,
                    'questype': ObjectId(type_dict[qtype.lower()]),
                    'meta_data': [],
                    "in_import_table": True,
                    "answer": ans,
                    'tags': tags_list,
                    'complexity': comp,
                    'duration': dur,
                    'marks': mar
                }
                meta_data = {}
                meta_data['question_type'] = name_dict[qtype.lower()]
                meta_data['answer_max_len'] = len(ans)
                if ans:
                    meta_data['answer'] = True
                else:
                    meta_data['answer'] = False
                document['meta_data'].append(meta_data)

                records.append(document)
                original_tags.append(tags_org)
                check =+ 1
        res_data = {
            "message": "success",
            "records": records
        }
        # insert_res = mongo_session.insert_import_questions(collection="add_questions_temp", records=records)
        for x in range(len(original_tags)):
            res_data["records"][x]['tags'] = original_tags[x]
            res_data["records"][x]['complexity'] = res_data["records"][x]['complexity'][0]['name']
        api_status = 200
        # res = mongo_session.get_all_data_for_particular_condition_fields(collection="add_questions_temp", condition="")
    else:
        api_status = 400
        res_data = {"message": "failed to upload to S3"}

    return res_data, api_status

def moodle_format_questions(file_path, user_id):
    """
    It parse an moodle format file (xml file) and insert it in a temp collection
    1. file is uploaded to s3
    2. file content is decode to utf-8 and converted into a dictionary
    3. iterate over the questions,options and answer and insert in the database
    """
    try:
        file_path.seek(0)
        file_type = file_checker.from_buffer(file_path.read(1024), mime=True)
        if file_type == 'text/xml':
            if not file_path.filename.lower().endswith('.xml'):
                file_path.filename += ".xml"
        else:
            raise IOError
    except IOError as e:
        res_data = {"message": "only xml files are allowed for Moodle", }
        api_status = 400
        return res_data, api_status

    try:
        uploaded_data, status = upload_files_questionbank(file_path=file_path, user_id=user_id)
        if status == 200:
            file_path.seek(0)
            data = file_path.read().decode('utf-8')
            dict_data = xmltodict.parse(data)
            test = dict_data['quiz']['question']
            records = []
            org_name_res = mongo_session.get_data_for_particular_columns_with_condition("user_profile",
                                                                                        {"_id": ObjectId(user_id)},
                                                                                        ["organisation"])
            org_name = org_name_res['message'][0]['organisation']
            type_collection = mongo_session.get_all_data("question_type")['message']
            type_dict = dict(map(lambda x: (x['value'], str(x['_id'])), type_collection))
            for i in range(1, len(test)):
                question_obj = test[i]
                if question_obj['@type'] == 'multichoice':
                    questype = ObjectId(type_dict['singleanswermcq'])
                elif question_obj['@type'] == 'truefalse':
                    questype = ObjectId(type_dict['bool'])
                else:
                    questype = ObjectId(type_dict['text'])

                question_text = question_obj['questiontext']['text']
                filtered_ques = filtered_html_tags(question_text)
                document = {
                    'user_id': ObjectId(user_id),
                    'organisation': org_name,
                    'question': question_text,
                    'filtered_question': filtered_ques,
                    'files': [],
                    'in_assessment': False,
                    'questype': questype,
                    'meta_data': [],
                    "in_import_table": True
                }
                if "answer" in question_obj.keys():
                    answer = question_obj['answer']
                    answer_count = 0
                    for ans in answer:
                        meta_data = {}
                        option = ans['text']
                        meta_data['option'] = option
                        if ans['@fraction'] == "100":
                            meta_data['answer'] = True
                            answer_count += 1
                        else:
                            meta_data['answer'] = False

                        meta_data['answer_max_len'] = "0"
                        document['meta_data'].append(meta_data)

                    if answer_count > 1:
                        document['questype'] = ObjectId(type_dict['multianswermcq'])
                records.append(document)
            print(records[0])
            insert_res = mongo_session.insert_import_questions(collection="add_questions_temp", records=records)
            api_status = insert_res['status']
            res_data = {"message": insert_res['message']}
        else:
            api_status = 400
            res_data = {"message": "failed to upload to S3"}

    except Exception as e:
        traceback.print_exc()
        res_data = {"message": "failed to parse the file"}
        api_status = 400

    return res_data, api_status


def import_question_info(user_id):
    try:
        org_name_res = mongo_session.get_data_for_particular_columns_with_condition("user_profile",
                                                                                    {"_id": ObjectId(user_id)},
                                                                                    ["organisation"])
        org_name = org_name_res['message'][0]['organisation']
        data = \
        mongo_session.get_all_data_for_particular_condition_fields("add_questions", {"organisation": org_name}
                                                                   )['message']
        type_collection = mongo_session.get_all_data("question_type")['message']
        type_dict = dict(map(lambda x: (str(x['_id']), x['name']), type_collection))
        complexity_question = mongo_session.get_all_data("question_complexity")['message']
        comp_dict = dict(map(lambda x: (str(x['_id']), x['name']), complexity_question))
        tags_data = mongo_session.get_all_data("question_tags")['message']
        tags_dict = dict(map(lambda x: (str(x['_id']), x['tag']), tags_data))
        tags_data_global = mongo_session.get_all_data("global_tags")['message']
        tags_dict_global = dict(map(lambda x: (str(x['_id']), x['tag']), tags_data_global))
        for d in data:
            type_obj = {}
            d['_id'] = str(d['_id'])
            d['user_id'] = str(d['user_id'])
            type_obj['_id'] = str(d['questype'])
            type_obj['type'] = type_dict[str(d['questype'])]
            d['questype'] = type_obj
            d['course_id'] = str(d['course_id'])
            d['complexity'] = {'_id': str(d['complexity']), 'complexity': comp_dict[str(d['complexity'])]}
            d['tags'] = [{'_id': str(tag), 'tag': tags_dict[str(tag)] if tags_dict.get(str(tag)) else tags_dict_global[str(tag)]} for tag in d['tags']]
            d['marks'] = str(d.get('marks',1))
        res_data = {"questions": data}
        api_status = 200

    except Exception as e:
        traceback.print_exc()
        res_data = {"message": "failed"}
        api_status = 400

    return res_data, api_status


def get_s3_key_in_question(question):
    bs_img = BeautifulSoup(question)
    image_tags = bs_img.findAll("img")
    image_keys = []
    for i in image_tags:
        s3_url = i['src'].split('?')[0]
        key = s3_url.split('/')[-2] + '/' + s3_url.split('/')[-1]
        image_keys.append(key)

    return image_keys


def edit_questions(user_id, role, question_id, text):
    """This is to make changes in resource bank.
    :param user_id: id of the resource which is getting changed.
    :type user_id: str
    """
    condition = {"_id": ObjectId(question_id)}
    set_columns = {}
    previous_user_info = mongo_session.check_existance_return_info(collection="user_profile",
                                                                  condition={"_id": ObjectId(user_id)},
                                                                  columns={"_id": 1,
                                                                           "name": 1,
                                                                           "last_name": 1,
                                                                           "email": 1},
                                                                  return_keys=["_id", "name",
                                                                               "last_name", "email"])

    question_info= mongo_session.check_existance_return_info(collection="question_bank",
                                                            condition={"_id": ObjectId(question_id)},
                                                            columns={"_id": 1,
                                                                     "Course_category": 1,
                                                                     "course_category_id": 1,
                                                                     "reward": 1,
                                                                     "question_image_path": 1,
                                                                     "course_id": 1,
                                                                     "Timestamp": 1,
                                                                     "video_time": 1,
                                                                     "questions": 1,
                                                                     "course_session_id": 1},
                                                            return_keys = ["_id", "reward","course_session_id", "Course_category", "course_category_id","course_id","Timestamp","video_time","questions","question_image_path"])
    
    
    for key in question_info.keys():
        if type(question_info[key]) == ObjectId:
            question_info[key] = str(question_info[key])

    if not previous_user_info:
        raise InvalidUsage("Bad Request", 400)

    if not is_empty(role): 
        find_role = mongo_session.check_existance_return_info(collection="roles",
                                                              condition={"name": role})
        if not find_role:
            raise InvalidUsage("Please select appropriate role to change.", 400)

        if role == "super_admin" or role == "teacher":
    
            if not is_empty(text):
                set_columns['questions'] = str(text)

            question_update = mongo_session.update_multiple_fields(collection='question_bank',
                                                                    condition=condition,
                                                                    set_columns=set_columns)
            
            if question_update['status'] != 200:
                raise InvalidUsage("Something went wrong, Please try again later.", 400)
            if question_update['document_updated'] == 1:
                updated = {
                    "edited_question": question_info,
                    "message" : "Question Updated Successfully", "status": 200
                }
                return updated
            else:
                raise InvalidUsage("Something is wrong, Try editing again.", 400)
        else:
            raise InvalidUsage("Please select appropriate role to change.", 400)


def delete_question(user_id, role, question_id, answer_id):
    """This is to make changes in resource bank.
    :param user_id: id of the resource which is getting changed.
    :type user_id: str
    :param question_id: id of the question which has to be deleted
    type question_id: str
    """
    condition = {"_id": ObjectId(question_id)}
    if role == "student":
        condition['user_id'] = str(user_id)
    set_columns = {}
    previous_user_info = mongo_session.check_existance_return_info(collection="user_profile",
                                                                   condition={"_id": ObjectId(user_id)},
                                                                   columns={"_id": 1,
                                                                            "name": 1,
                                                                            "last_name": 1,
                                                                            "email": 1},
                                                                   return_keys=["_id", "name",
                                                                                "last_name", "email"])
    if not previous_user_info:
        raise InvalidUsage("Bad Request", 400)

    if not is_empty(role):
        find_role = mongo_session.check_existance_return_info(collection="roles",
                                                              condition={"name": role})
        if not find_role:
            raise InvalidUsage("Please select appropriate role to change.", 400)
        if role == "super_admin" or role == "teacher" or role == "student":
            question = mongo_session.check_existance_return_info(collection="question_bank",
                                                                 condition=condition,
                                                                 return_keys=["answers", "user_id", "reward"])
            answer = mongo_session.check_existance_return_info(collection="answer_bank",
                                                               condition={"_id": ObjectId(answer_id)})
            if question_id != None and answer_id == None:

                if question:
                    fetch_answer_ids = question["answers"]
                    mongo_session.delete_data(collection='question_bank',
                                              condition=condition)
                    for _id in fetch_answer_ids:
                        fetch_id = _id["_id"]

                        mongo_session.delete_data(collection='answer_bank',
                                                  condition={"_id": fetch_id})
                    user_data_updation = mongo_session.update_record_into_db(collection="user_profile",
                                                                             condition=
                                                                             {"_id": ObjectId(str(question["user_id"]))},
                                                                             update_info=
                                                                             {"$inc": {"coin": question["reward"]}})
                    message = "Question deleted Successfully"
                    status = 200
                else:
                    message = "Question does not exist"
                    status = 400

            elif question_id != None and answer_id != None :
                if answer:
                    mongo_session.del_value_from_array(collection='question_bank',
                                                       id=ObjectId(question_id),
                                                       field="answers",
                                                       value={"_id": ObjectId(answer_id)})
                    mongo_session.delete_data(collection='answer_bank',
                                              condition={"_id": ObjectId(answer_id)})
                    message = "Answer deleted"
                    status = 200
                else:
                    message = "Answer does not exist"
                    status = 400
            return {"message": message, "status": status}
        else:
            raise InvalidUsage("Something is wrong, Try editing again.", 400)
    else:
        raise InvalidUsage("Please select appropriate role to change.", 400)


def delete_answer(user_id, role, question_id, answer_id):
    """This is to make changes in resource bank.
    :param user_id: id of the resource which is getting changed.
    :type user_id: str
    :param answer_id: id of the answer which has to be deleted
    type answer_id: str
    """
    # condition = {"user_id": user_id, "answers": {"_id": ObjectId(answer_id)}}
    condition = {"_id": ObjectId(question_id)}
    set_columns = {}
    previous_user_info = mongo_session.check_existance_return_info(collection="user_profile",
                                                                   condition={"_id": ObjectId(user_id)},
                                                                   columns={"_id": 1,
                                                                            "name": 1,
                                                                            "last_name": 1,
                                                                            "email": 1},
                                                                   return_keys=["_id", "name",
                                                                                "last_name", "email"])
    print(previous_user_info)
    if not previous_user_info:
        raise InvalidUsage("user doesn't exist ", 400)

    if not is_empty(role):
        find_role = mongo_session.check_existance_return_info(collection="roles",
                                                              condition={"name": role})
        if not find_role:
            raise InvalidUsage("Please select appropriate role to change.", 400)
        if role == "super_admin" or role == "teacher" or role == "student":
            question = mongo_session.check_existance_return_info(collection="question_bank",
                                                                 condition=condition,
                                                                 return_keys=["_id", "answers"]
                                                                 )
            answer = mongo_session.check_existance_return_info(collection="answer_bank",
                                                               condition={"_id": ObjectId(answer_id)})
            if question_id == None and answer_id != None:
                if question :
                    if answer :
                        fetch_answer_ids = question["answers"]
                        fetch_question_id = question["_id"]
                        mongo_session.del_value_from_array(collection='question_bank',
                                                           id=fetch_question_id,
                                                           field="answers",
                                                           value={"_id": ObjectId(answer_id)})
                        for _id in fetch_answer_ids:
                            fetch_id = _id["_id"]
                            if fetch_id == ObjectId(answer):
                                mongo_session.delete_data(collection='answer_bank',
                                                          condition={"_id": fetch_id})
                    else:
                        fetch_question_id = question["_id"]
                        mongo_session.del_value_from_array(collection='question_bank',
                                                           id=fetch_question_id,
                                                           field="answers",
                                                           value={"_id": ObjectId(answer_id)})

                    message = "Answer deleted Successfully"
                    status = 200
                elif answer:
                    mongo_session.delete_data(collection='answer_bank',
                                              condition={"_id": ObjectId(answer_id)})
                    message = "Answer deleted Successfully"
                    status = 200

                else:
                    message = "Answer does not exist"
                    status = 400

            elif question_id != None and answer_id != None:
                if question:
                    if answer:
                        fetch_answer_ids = question["answers"]
                        fetch_question_id = question["_id"]
                        mongo_session.del_value_from_array(collection='question_bank',
                                                           id=fetch_question_id,
                                                           field="answers",
                                                           value={"_id": ObjectId(answer_id)})
                        for _id in fetch_answer_ids:
                            fetch_id = _id["_id"]
                            if fetch_id == ObjectId(answer):
                                mongo_session.delete_data(collection='answer_bank',
                                                          condition={"_id": fetch_id})
                    else:
                        fetch_question_id = question["_id"]
                        mongo_session.del_value_from_array(collection='question_bank',
                                                           id=fetch_question_id,
                                                           field="answers",
                                                           value={"_id": ObjectId(answer_id)})

                    message = "Answer deleted Successfully"
                    status = 200
                elif answer:
                    mongo_session.delete_data(collection='answer_bank',
                                              condition={"_id": ObjectId(answer_id)})
                    message = "Answer deleted Successfully"
                    status = 200

                else:
                    message = "Answer does not exist"
                    status = 400

            else:
                message = "Answer_id not declared, kindly share answer_id "
                status = 400

            return {"message": message, "status": status}
        else:
            raise InvalidUsage("Something is wrong, Try editing again.", 400)
    else:
        raise InvalidUsage("Please  appropriate role to change.", 400)


def delete_by_ids(index, ids):
    query = {"query": {"terms": {"_id": ids}}}
    res = es.delete_by_query(index=index, body=query)
    print(res)


def delete_add_question(user_id, role, question_id):
    """This is to make changes in resource bank.
    :param user_id: id of the resource which is getting changed.
    :type user_id: str
    :param question_id: id of the question which has to be deleted
    type question_id: str
    """
    condition = {"_id": ObjectId(question_id)}
    if not is_empty(role):
        find_role = mongo_session.check_existance_return_info(collection="roles",
                                                              condition={"name": role})
        if not find_role:
            raise InvalidUsage("Please select appropriate role to change.", 400)
        if role == "super_admin" or role == "teacher":
            question = mongo_session.check_existance_return_info(collection="add_questions",
                                                                 condition=condition)
            for assessments in mongo_session.get_all_data(collection='assessment')['message']:
                if assessments.get('questions'):
                    for ques in assessments['questions']:
                        if str(ques['question_id']) == str(question_id):
                            raise InvalidUsage('Question used in assessments, unable to delete', 406)
            if question:
                mongo_session.delete_data(collection='add_questions', condition=condition)
                delete_by_ids(ES_QUESTION_INDEX, [str(question_id)])
                message = "Question deleted Successfully"
                status = 200
            else:
                delete_by_ids(ES_QUESTION_INDEX, [str(question_id)])
                message = "Question not found in db, deleted from search."
                status = 404
            return {"message": message, "status": status}
        else:
            raise InvalidUsage("Student cannot delete questions.", 400)
    else:
        raise InvalidUsage("Please appropriate role to change.", 400)


def add_uploaded_ques(user_id, role, organisation, question_data):
    previous_user_info = mongo_session.check_existance_return_info(collection="user_profile",
                                                                   condition={"_id": ObjectId(user_id)},
                                                                   columns={"_id": 1,
                                                                            "name": 1,
                                                                            "last_name": 1,
                                                                            "email": 1},
                                                                   return_keys=["_id", "name",
                                                                                "last_name", "email"])
    if not previous_user_info:
        raise InvalidUsage("Bad Request", 400)

    if not is_empty(role):
        find_role = mongo_session.check_existance_return_info(collection="roles",
                                                              condition={"name": role})
        if not find_role:
            raise InvalidUsage("Please select appropriate role to change.", 400)
        if role == "super_admin" or role == "teacher":
            message, api_status = "", ""
            for data in question_data:
                doc_to_import = {
                    "user_id": ObjectId(user_id),
                    "organisation": organisation,
                    "course_id": ObjectId(data['category']),
                    "question": data['question'],
                    "meta_data": data['meta_data'],
                    "questype": ObjectId(data["questype"]),
                    "duration": str(data['duration']),
                    "in_import_table": data['in_import_table'],
                    "filtered_question": data["filtered_question"],
                    "in_assessment": data["in_assessment"],
                    "marks": data['marks']
                }
                tags_list = []
                for t in data['tags']:
                    tags_collection = mongo_session.access_specific_fields(collection='question_tags',
                                                                           condition={'tag': t.strip()})
                    tags_collection_global = mongo_session.access_specific_fields(collection='global_tags',
                                                                                  condition={'tag': t.strip()})
                    if tags_collection:
                        tags_list.append(tags_collection[0]['_id'])
                    elif tags_collection_global:
                        tags_list.append(tags_collection_global[0]['_id'])
                comp = mongo_session.access_specific_fields(collection='question_complexity',
                                                            condition={'name': data['complexity']})[0]['_id']
                doc_to_import["tags"] = tags_list
                doc_to_import["complexity"] = comp

                add_question_collection = connection.add_questions
                cursor = add_question_collection.insert_one(doc_to_import)
                id = str(cursor.inserted_id)
                doc_to_import['_id'] = id
                if index_question(doc_to_import):
                    message = "question added"
                    api_status = 201
                else:
                    message = "failed to insert in elastic"
                    api_status = 500
            return message, api_status
        else:
            raise InvalidUsage("You can't add questions.", 400)

    else:
        raise InvalidUsage("Please  appropriate role to change.", 400)