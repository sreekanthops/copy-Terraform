from db_wrapper.fetch_functions import Fetch
from model.tango_wrapper import tango_services
from werkzeug.utils import secure_filename
import os, shutil
fetch = Fetch()
from bson import ObjectId
import time


def autograde(_id, files):
    object_id = fetch.check_existance_return_info("autograded_coursework", {"_id":ObjectId(_id)})
    check = str(object_id)
    for file in files.getlist('resource'):
        filename = secure_filename(file.filename)
        
        if "temp_storage" in os.listdir(os.getcwd()):
            shutil.rmtree(os.path.join(os.getcwd(), "temp_storage"))
            os.mkdir(os.path.join(os.getcwd(), "temp_storage"))
            if check in os.listdir(os.path.join(os.getcwd(), "temp_storage")):
                shutil.rmtree(os.path.join(os.getcwd(), "temp_storage", check))
                os.mkdir(os.path.join(os.getcwd(), "temp_storage", check))
                save_path = os.path.join(os.getcwd(), "temp_storage", check, filename)
            else:
                os.mkdir(os.path.join(os.getcwd(), "temp_storage", check))
                save_path = os.path.join(os.getcwd(), "temp_storage", check, filename)
        else:
            os.mkdir(os.path.join(os.getcwd(), "temp_storage"))
            if check in os.listdir(os.path.join(os.getcwd(), "temp_storage")):
                shutil.rmtree(os.path.join(os.getcwd(), "temp_storage", check))
                os.mkdir(os.path.join(os.getcwd(), "temp_storage", check))
                save_path = os.path.join(os.getcwd(), "temp_storage", check, filename)
            else:
                os.mkdir(os.path.join(os.getcwd(), "temp_storage", check))
                save_path = os.path.join(os.getcwd(), "temp_storage", check, filename)

        file.save(save_path)
    f = open(save_path, "r")
    tango_services.upload_file(check, filename, f.read())
    f.close()
    tango_services.add_job(check, filename)
    print(tango_services.poll(check))
    shutil.rmtree(os.path.join(os.getcwd(), "temp_storage"))
    #     os.remove(filename)

