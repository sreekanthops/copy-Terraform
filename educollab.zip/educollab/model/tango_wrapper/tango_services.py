from config import TANGO_SERVER
import requests
import json
import re

def open_course(coursename):
    response = requests.get('{}open/test/{}/'.format(TANGO_SERVER, coursename)).json()
    if response['statusId'] == 0 and response["statusMsg"] == "Created directory":
        return True, response
    else:
        return False, response


def upload_file(coursename, filename, file_data):
    url = '{}upload/test/{}/'.format(TANGO_SERVER, coursename)
    response = requests.post(url, data=file_data, headers={'Filename':'{}'.format(filename)}).json()
    if response['statusId'] == 0 and response["statusMsg"] == "Uploaded file":
        return True, response
    else:
        return False, response


def create_test_cases(coursename, json_data):
    url = '{}CreateTestCases/test/{}/'.format(TANGO_SERVER, coursename)
    response = requests.post(url, data=json.dumps(json_data)).json()
    if response:
        return True, response
    else:
        return False, response


def add_job(coursename, filename):
    url = '{}addJob/test/{}/'.format(TANGO_SERVER, coursename)
    json_data = {
    "image": "autograding_image",
    "files": [
        {
            "localFile": "{}".format(filename),
            "destFile": "main.py"
        },
        {
            "localFile": "autograde-Makefile",
            "destFile": "Makefile"
        },
        {
            "localFile": "autograde.zip",
            "destFile": "autograde.zip"
        }
    ],
    "output_file": "autograde.txt",
    "timeout": 180,
    "jobName": "test-1"
                }
    response = requests.post(url, data=json.dumps(json_data)).json()
    if response['statusId'] == 0 and response["statusMsg"] == "Job added":
        return True, response
    else:
        return False, response


def poll(coursename):
    url = '{}poll/test/{}/autograde.txt/'.format(TANGO_SERVER, coursename)
    response = requests.get(url)
    start_idx = [x.start() for x in re.finditer('{', response.text)][-1]
    end_idx = response.text.find('}')
    response = response.text[start_idx:end_idx+1]
    response = response[1:-1].split(':')
    response = {response[0]:response[1].strip()}
    # print(response)
    if response['Correctness']:
        return True, response
    else:
        return False, response