from db_wrapper.tasks import Mongo
from bson import ObjectId
from services.storage.s3_services import s3_storage

s3_function = s3_storage()
mongo_session = Mongo()

from db_wrapper.fetch_functions import Fetch
from bson import ObjectId
import re
import youtube_dl
from routes.exception import InvalidUsage
import config

fetch = Fetch()


# method to get subscribed courses
def get_subscribed_courses(user_id, organisation):
    output = []
    org_id = mongo_session.get_all_data_for_particular_condition_fields(collection='organisations',
                                                                        condition={'name': organisation})["message"][
        0]["_id"]
    courses_data = fetch.access_specific_fields(collection='courses_bank',
                                             condition={'subscribers':
                                                            {'$elemMatch': {'user_id': ObjectId(user_id)}},
                                                            "status": "publish",
                                                            "active": True,
                                                            "$or": [{"is_public": True},
                                                                    {"organisations": {"$elemMatch": {"_id": ObjectId(org_id)}}}]
                                })
    if not courses_data:
        return output

    for data in courses_data:
        user_data = mongo_session.get_all_data_for_particular_condition_fields(collection='user_profile',
                                                                               condition={'_id': ObjectId(
                                                                                   str(data['created_by']))})[
            "message"][0]
        name = "{} {}".format(user_data.get('name', ""), user_data.get('last_name', ""))
        data_out = {'banner_img': s3_function.generate_presigned_url_from_s3(data['banner_img'])[0],
                    'course_category': data['course_category'],
                    'course_category_id': str(data['course_category_id']),
                    'course_id': str(data['_id']),
                    'created_by': str(data['created_by']),
                    'learning_objectives': data['learning_objectives'],
                    'rating': data['overall_rating'],
                    'status': data['status'],
                    'subject': data['subject'],
                    'subscribers_length': len(data['subscribers']) if data.get('subscribers') else 0,
                    'created_by_name': name}
        output.append(data_out)
    return output


# method to get top courses in organisation
def get_public_courses(organisation_id, view_more=None):
    """
    Retrieve top-rated courses for Edu-Collab.
    """
    limit_1 = 10
    limit_2 = 8
    if view_more is not None:
        limit_1 = 30
        limit_2 = 20
    output = []
    org_id = mongo_session.get_all_data_for_particular_condition_fields(collection='organisations',
                                                                        condition={'name': organisation_id})["message"][
        0]["_id"]
    # print(org_id)
    for data in mongo_session.get_all_data_for_particular_condition_fields(collection='courses_bank',
                                                                           condition={'organisations':
                                                                                          {'$elemMatch': {
                                                                                              '_id': ObjectId(
                                                                                                  org_id)}},
                                                                                        "active": True})[
                    "message"][:limit_1]:
        user_data = mongo_session.get_all_data_for_particular_condition_fields(collection='user_profile',
                                                                               condition={'_id': ObjectId(
                                                                                   str(data['created_by']))})[
            "message"][0]
        name = "{} {}".format(user_data.get('name', ""), user_data.get('last_name', ""))
        data_out = {'banner_img': s3_function.generate_presigned_url_from_s3(data['banner_img'])[0],
                    'course_category': data['course_category'],
                    'course_category_id': str(data['course_category_id']),
                    'course_id': str(data['_id']),
                    'created_by': str(data['created_by']),
                    'learning_objectives': data['learning_objectives'],
                    'rating': data['overall_rating'],
                    'status': data['status'],
                    'subject': data['subject'],
                    'subscribers_length': len(data['subscribers']) if data.get('subscribers') else 0,
                    'created_by_name': name}
        output.append(data_out)
    output = sorted(output, key=lambda d: (d['subscribers_length'], d['rating']))
    output.reverse()
    return output[:limit_2]


# method to get top categories in organisation
def get_categories_info(organisation):
    required_column_name = {"_id": 1, "name": 1, "parent_id": 1}
    cursor = mongo_session.get_all_data_for_particular_fields_course_category_api(collection='Course_Category',
                                                                                  columns=required_column_name)[
        'message']
    organisation_data = mongo_session.get_data_for_particular_columns_with_condition(collection='organisations',
                                                                                     condition={"name": organisation},
                                                                                     columns={"_id": 1})
    org_id = organisation_data['message'][0]["_id"]
    data = []
    for cat in cursor:
        column_name = {"_id": 1, "status": 1}
        course_count = mongo_session.get_data_for_particular_columns_with_condition(collection='courses_bank',
                                                                                    condition={
                                                                                        "course_category_id": ObjectId(
                                                                                            str(cat['_id'])),
                                                                                        "status": "publish",
                                                                                        "active": True,
                                                                                        "organisations._id": {"$in": [
                                                                                            ObjectId(str(org_id))]}},
                                                                                    columns=column_name)
        if len(course_count['message']) > 0:
            d = {"id": str(cat['_id']), "course_count": len(course_count['message']), "name": cat['name']}
            # static - in progress
            d['banner_img'] = s3_function.generate_presigned_url_from_s3('orgainsation_icons/2022-06-06_21-53.png')[0]
            data.append(d)
    data = sorted(data, key=lambda d: (d['course_count']))
    data.reverse()

    return data[:9]


# method to get recently viewed sessions
def recently_viewed_sessions(user_id):
    data = []
    user_profile = mongo_session.get_all_data_for_particular_condition_fields(collection='courses_progress_tracking',
                                                                              condition={'user_id': user_id})["message"]
    if user_profile:
        user_profile = user_profile[0]
        if user_profile.get('courses'):
            for course in user_profile['courses']:
                d = {}
                d['course_id'] = str(course)
                try:
                    course_data = mongo_session.get_all_data_for_particular_condition_fields(collection='courses_bank',
                                                                                         condition={'_id': ObjectId(
                                                                                             str(course)),
                                                                                            "active": True})["message"][
                    0]
                except:
                    print(course)
                    continue
                d['course_name'] = course_data.get('subject', 'Course')
                d["courseCategoryId"] = str(course_data.get('course_category_id', 'Course Category Id'))
                course_category = mongo_session.get_all_data_for_particular_condition_fields("Course_Category", {
                    "_id": course_data["course_category_id"]})['message'][0]
                d["courseCategoryTaxonomy"] = category_taxonomy_by_category_id(course_category)
                session = []
                for topic in user_profile['courses'][course]:
                    if user_profile['courses'][course][topic]:
                        session.extend(user_profile['courses'][course][topic])
                d['session_id'] = sorted(session, key=lambda k: (k['log_time']))[-1]['session_id']
                for topic in user_profile['courses'][course][topic]:
                    if topic['session_id'] == d['session_id']:
                        for top in user_profile['courses'][course].keys():
                            d['topic_id'] = top
                            break
                        break
                d['session_time'] = sorted(session, key=lambda k: (k['log_time']))[-1]['log_time']
                session_data = mongo_session.get_all_data_for_particular_condition_fields(collection='course_sessions',
                                                                                          condition={'_id': ObjectId(
                                                                                              str(d['session_id']))})[
                    "message"][0]
                d['session_name'] = session_data.get('title', 'Course')
                d['session_type'] = session_data.get('key', 'Session')
                d['type'] = session_data.get('type')
                d['description'] = session_data.get('description', 'Description')

                transcriptions = mongo_session.access_specific_fields(collection="video_transcriptions",
                                                                      condition={"s3_key": session_data.get('url')})
                if transcriptions:
                    if transcriptions[0].get('vtt'):
                        vtt = transcriptions[0]['vtt'].split('/')[3:]
                        key = '{}/{}'.format(vtt[0], vtt[1])
                        vtt = s3_function.generate_presigned_url_from_s3(s3_key=key)[0]
                    else:
                        vtt = ""
                else:
                    vtt = ""
                if transcriptions:
                    transcriptions = transcriptions[0]['transcription']['results']
                    if transcriptions['items']:
                        for t in transcriptions['items']:
                            t['word'] = t['alternatives'][0]['content']
                            t.pop('alternatives')
                    else:
                        transcriptions = {'transcripts': [], 'items': []}
                else:
                    transcriptions = {'transcripts': [], 'items': []}
                d['transcriptions'] = transcriptions

                try:
                    pattern = re.compile(
                        "^((?:https?:)?\/\/)?((?:www|m)\.)?((?:youtube(-nocookie)?\.com|youtu.be))(\/(?:[\w\-]+\?v=|embed\/|v\/)?)([\w\-]+)(\S+)?$")
                    if pattern.match(session_data.get('url')):
                        d['videoLink'] = session_data.get('url')
                        video_query = mongo_session.get_all_data_for_particular_condition_fields(
                            collection="youtube_video_duration",
                            condition={"video_url": session_data.get('url')})
                        if video_query['status'] != 200:
                            raise InvalidUsage("Something went wrong, please try again later.", 500)
                        video_data = video_query["message"]
                        if video_data:
                            d['duration'] = video_data[0]['duration']
                        else:
                            ydl_opts = {}
                            with youtube_dl.YoutubeDL(ydl_opts) as ydl:
                                dictmeta = ydl.extract_info(session_data.get('url'), download=False)
                            seconds = dictmeta['duration']
                            seconds = seconds % (24 * 3600)
                            hour = seconds // 3600
                            seconds %= 3600
                            minutes = seconds // 60
                            seconds %= 60
                            d['duration'] = "%02d:%02d:%02d" % (hour, minutes, seconds)
                    else:
                        d['videoLink'] = s3_function.generate_presigned_url_from_s3(session_data.get('url'))[0]
                        res = config.s3_connection.head_object(Bucket=config.bucket, Key=session_data.get('url'))
                        d['duration'] = str(res['Metadata'].get('duration', "00:00:00"))
                except Exception as e:
                    print("S3 duration block ", e)
                    d['duration'] = "00:00:00"

                # static - in progress
                d['banner_img'] = s3_function.generate_presigned_url_from_s3('orgainsation_icons/2022-06-06_21-53.png')[
                    0]
                data.append(d)
    data = sorted(data, key=lambda k: (k['session_time']))
    data.reverse()

    return data[:3]


# Main Pipeline
def main_pipeline(user_id, organisation):
    data = {}
    data['subscribed_courses'] = get_subscribed_courses(user_id, organisation)
    data['top_courses'] = get_public_courses(organisation)
    data['top_categories'] = get_categories_info(organisation)
    data['recently_viewed_sessions'] = recently_viewed_sessions(user_id)
    # static - in progress
    data['recommended_courses'] = data['top_courses']
    return data, 200


def category_taxonomy_by_category_id(category):
    generated_string = category['name']
    while category['parent_id']:
        category = mongo_session.get_all_data_for_particular_condition_fields("Course_Category",
                                                                              {"_id": ObjectId(category['parent_id'])})[
            'message'][0]
        generated_string = category['name'] + " / " + generated_string
    return generated_string


def get_all_recommended_courses(user_id, organisation):
    """
       this function returns list of all recommended courses
    """
    top_courses = get_public_courses(organisation, "view_more")
    # top courses and recommended courses are same (static - in progress)
    data = {
        'recommended_courses': top_courses
    }
    return data, 200


def get_all_top_courses(user_id, organisation):
    """
       this function returns list of all top courses
    """
    data = {
        'top_courses': get_public_courses(organisation, "view_more")
    }

    return data, 200


# method to get top courses in organisation
def discover_courses():
    """
    Retrieve top-rated courses for Edu-Collab.
    """
    output = []
    course_data = mongo_session.get_all_data(collection='courses_bank')["message"]
    for data in course_data[:40]:
        user_data = mongo_session.get_all_data_for_particular_condition_fields(collection='user_profile',
                                                                               condition={'_id': ObjectId(
                                                                                   str(data['created_by']))})[
            "message"][0]
        name = "{} {}".format(user_data.get('name', ""), user_data.get('last_name', ""))
        data_out = {'banner_img': s3_function.generate_presigned_url_from_s3(data['banner_img'])[0],
                    'course_category': data['course_category'],
                    'course_category_id': str(data['course_category_id']),
                    'course_id': str(data['_id']),
                    'created_by': str(data['created_by']),
                    'learning_objectives': data['learning_objectives'],
                    'rating': data['overall_rating'],
                    'status': data['status'],
                    'subject': data['subject'],
                    'subscribers_length': len(data['subscribers']) if data.get('subscribers') else 0,
                    'created_by_name': name}
        output.append(data_out)
        output = sorted(output, key=lambda d: (d['subscribers_length'], d['rating']), reverse=True)
    return output[:9], 200
