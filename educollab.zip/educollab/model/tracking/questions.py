from routes.exception import InvalidUsage
from bson import ObjectId
from utils.misc import validate_ObjectId
from utils.time_conversions import utc_datetime_now
from db_wrapper.tasks import Mongo

mongo_session = Mongo()


def user_ques_history(user_id, question_id):
    """to track the user actions for questions store the action in database.
    :param user_id: user accessing the question.
    :type user_id: str
    :param question_id: question user accessed.
    :type question_id: str"""
    # validate question id
    if not validate_ObjectId(question_id):
        raise InvalidUsage("Bad Request.", 400)
    # utc datetime
    datetime = utc_datetime_now()

    # information to store in database
    data = {"user_id": ObjectId(user_id),
            "created_at": datetime,
            "data": {"_id": ObjectId(question_id)},
            "type": "question"}

    response = mongo_session.insert_documnet(collection="search_log",
                                             doc_to_insert=data)
    return response
