import json
from datetime import datetime, timezone

from bs4 import BeautifulSoup
from flask import jsonify, Response

from db_wrapper.tasks import Mongo
import traceback
from bson import ObjectId
from model.Question import insert_tags
from model.chat_func import update_course_groupchat
from services.storage.s3_services import s3_storage
from routes.exception import InvalidUsage
from config import DEFAULT_AVATAR
from utils.time_conversions import utc_datetime_now, convert_utc_to_ist

s3_function = s3_storage()
mongo_session = Mongo()
from utils.misc import validate_ObjectId, replace_s3_links_with_keys, renew_s3_links

from utils.misc import validate_ObjectId

from db_wrapper.fetch_functions import Fetch
from bson import ObjectId

fetch = Fetch()


def get_project_names(user_id, organisation, role):
    """
    In this the list of app the passion projects that are
    present in the db are returned.
    """
    user = user_id
    try:
        column_to_fetch_dict = {
            "_id": 1,
            "project_title": 1,
            "project_image": 1,
            "project_description": 1,
            "project_tags": 1,
            "created_by": 1,
            "project_mentors": 1,
            "project_resources": 1,
            "is_active": 1
        }
        res = mongo_session.get_all_data_for_particular_fields(collection='passion_projects',
                                                               columns=column_to_fetch_dict)

        tags_collection = mongo_session.get_all_data("question_tags")['message']
        tags_dict = dict(map(lambda x: (x['_id'], x['tag']), tags_collection))
        project = res['message']
        projects = []
        for i in project:
            if i.get("is_active"):
                if i['is_active']['value']:
                    projects.append(i)
            else:
                projects.append(i)
        for i in projects:
            i["_id"] = str(i["_id"])
            tags = i.get('project_tags', [])

            m_project_tags = []
            for t in tags:
                try:
                    m_project_tags.append({'tag': tags_dict[str(t)], "_id": str(t)})
                except KeyError:
                    continue

            i['project_tags'] = m_project_tags

            res_data = fetch.check_existance_return_info(collection="chat_rooms",
                                                         condition={"passion_project_id": ObjectId(str(i["_id"])),
                                                                    "created_by": ObjectId(user), "mentor_chat": True})
            if res_data:
                i["mentor_chat"] = {"room_status": True,
                                    "chat_room": chat_room_data({"_id": ObjectId(res_data)}, ObjectId(user))}
            else:
                i["mentor_chat"] = {"room_status": False, "chat_room": None}
            i['project_image'] = s3_function.generate_presigned_url_from_s3(i['project_image'])[0]
            user_id = i['created_by']
            user_profile = mongo_session.get_all_data_for_particular_condition_fields(collection="user_profile",
                                                                                      condition={
                                                                                          "_id": ObjectId(user_id)}
                                                                                      )['message'][0]
            first_name = user_profile['name']
            last_name = user_profile['last_name']
            i['created_by'] = {"name": first_name + " " + last_name,
                               "_id": str(user_id)}
            if role == 'super_admin':
                edit_rights = True
            elif organisation.lower() == user_profile['organisation'].lower() and role == 'teacher':
                edit_rights = True
            else:
                edit_rights = False

            project_mentors_list = []
            for mentor_id in i.get("project_mentors", []):
                condition = {"_id": mentor_id}
                columns = {"_id": 1, "name": 1, "last_name": 1, "username": 1, "profile_pic": 1}
                column_request_response_key_mapping = {
                    "_id": "id",
                    "name": "first_name",
                    "last_name": "last_name",
                    "username": "user_name",
                    "profile_pic": "profile_pic"
                }
                mentor_data_res = mongo_session.get_data_for_particular_columns_with_condition(
                    collection='user_profile',
                    condition=condition,
                    columns=columns, column_request_response_key_mapping=column_request_response_key_mapping)

                project_mentors_list.extend(mentor_data_res["message"])

            i["project_mentors"] = project_mentors_list

            project_resources_list = []
            for resource_id in i.get("project_resources", []):
                if type(resource_id) == dict:
                    condition = {"resource_id": resource_id['resource_id'], '_id': resource_id['instance_id']}
                    resource_data = mongo_session.check_existance_return_info(collection='resource_bank_instance',
                                                                              condition=condition,
                                                                              whole_doc=True)
                    resource_s3_key = mongo_session.check_existance_return_info(collection='global_resource_bank',
                                                                                condition={
                                                                                    '_id': ObjectId(
                                                                                        resource_id['resource_id'])
                                                                                },
                                                                                return_keys=['s3_key'])
                    if resource_s3_key:
                        s3url = s3_function.generate_presigned_url_from_s3(resource_s3_key["s3_key"])[0]
                    else:
                        s3url = ""
                    project_resources_list.append({
                        '_id': str(resource_id['resource_id']),
                        "type": "file",
                        "title": resource_data['title'],
                        "s3url": s3url,
                        "url": s3url,
                        "resource_type": "file"
                    })

                else:
                    condition = {"_id": resource_id}
                    columns = {"_id": 1, "file_type": 1, "title": 1, "s3_key": 1, "type": 1, "url": 1}
                    column_request_response_key_mapping = {
                        "_id": "id",
                        "file_type": "type",
                        "title": "title",
                        "s3_key": "s3url",
                        "url": "url",
                        "type": "resource_type"
                    }
                    resource_data_res = mongo_session.get_data_for_particular_columns_with_condition(
                        collection='resources',
                        condition=condition,
                        columns=columns,
                        column_request_response_key_mapping=column_request_response_key_mapping)

                    if resource_data_res["status"] == 200:
                        for resource in resource_data_res["message"]:
                            if resource["type"] != "text":
                                resource["s3url"] = s3_function.generate_presigned_url_from_s3(resource["s3url"])[0]
                        project_resources_list.extend(resource_data_res["message"])

            i["project_resources"] = project_resources_list
            i["edit_rights"] = edit_rights

        projects_name_res = {"projects": projects,
                             "message": "success"
                             }
        status = res['status']
    except Exception as e:
        traceback.print_exc()
        projects_name_res = {"message": "error in fetching data", "projects": []}
        status = 400
    return projects_name_res, status


def project_catalogue(user_id, organisation, role, page_name):
    """
    In this the list of app the passion projects that are
    present in the db are returned.
    """
    try:
        projects = []
        if page_name == "all" and role != "student":
            condition = {}
        elif page_name == "published":
            condition = {"is_active.value": True}
        elif page_name == "unpublished" and role != "student":
            condition = {"is_active.value": False}
        res = mongo_session.get_data_for_particular_columns_with_condition(collection='passion_projects',
                                                                        condition= condition,
                                                                        columns={
                                                                            "project_title": 1,
                                                                            "project_image": 1,
                                                                            "created_by": 1,
                                                                        })
        for passion in res['message']:
            user_details = mongo_session.get_data_for_particular_columns_with_condition(collection='user_profile',
                                                                                        condition={"_id": ObjectId(str(passion['created_by']))},
                                                                                        columns={
                                                                                            "name": 1,
                                                                                            "last_name": 1,
                                                                                            "email": 1,
                                                                                            "username": 1
                                                                                        })['message']
            project_image_s3 = s3_function.generate_presigned_url_from_s3(passion["project_image"])[0]
            projects.append({
                "_id": passion['_id'],
                "project_title": passion['project_title'],
                "project_image": project_image_s3,
                "created_by": user_details
            })
        projects_name_res = {"projects": projects,
                             "message": "success",
                             'status': 200
                             }
        status = res['status']
    except Exception as e:
        traceback.print_exc()
        projects_name_res = {"message": "error in fetching data", "projects": []}
        status = 400
    return projects_name_res, status


def validate_project_mentors(project_mentors):
    """This function will validate that each passion project can have three mentors at max and each mentor should be an
    educollab user."""
    if len(project_mentors) > 3:
        raise InvalidUsage("Maximum three mentors are allowed in a passion project.", 400)
    if len(set(project_mentors)) < len(project_mentors):
        raise InvalidUsage("Please check the mentors added for the project.", 400)
    processed_mentors = []
    for mentor in project_mentors:
        if not validate_ObjectId(mentor):
            raise InvalidUsage(message="Please enter a valid mentor.", status_code=400)
        mentor_existence = mongo_session.find_one_in_db(collection="user_profile",
                                                        condition={"_id": ObjectId(mentor)},
                                                        columns=["_id"])
        if not mentor_existence['message']:
            raise InvalidUsage(message="Please enter a valid mentor.", status_code=400)
        processed_mentors.append(ObjectId(mentor))
    return processed_mentors


def insert_project(user_id, key_data_with_default_mapping_dict):
    """
    In this a new passion_project is inserted
    """

    title = key_data_with_default_mapping_dict['project_title']
    image_key = key_data_with_default_mapping_dict['project_image']
    description = key_data_with_default_mapping_dict['project_description']
    tags = key_data_with_default_mapping_dict['project_tags']
    project_mentors = key_data_with_default_mapping_dict["project_mentors"]
    project_file_resources = [doc for doc in key_data_with_default_mapping_dict["project_resources"] if
                              doc["type"] == 'file']
    project_text_resources = [doc for doc in key_data_with_default_mapping_dict["project_resources"] if
                              doc["type"] == 'text']

    def validate_project_name():
        existing_project = mongo_session.find_one_in_db(collection="passion_projects",
                                                        condition={"project_title": title},
                                                        columns=["_id"])
        if existing_project['message']:
            raise InvalidUsage(message="Project with this name already exists", status_code=400)

    validate_project_name()

    def validate_resouces(resources_id_list):
        valid_resources = []
        unvalid_resouces = []
        for _id in resources_id_list:
            existed = mongo_session.find_one_in_db(collection="global_resource_bank", condition={"_id": ObjectId(_id)},
                                                   columns=["_id"])
            if existed["status"] == 500:
                Exception("We ran into a problem. Could not insert into database")
            else:
                if existed["message"] == False:
                    unvalid_resouces.append(ObjectId(_id))
                elif existed["message"] == True:
                    valid_resources.append(ObjectId(_id))
        return {"valid_resources": valid_resources, "unvalid_resouces": unvalid_resouces}

    def validate_tags(tags):
        tags_collection = mongo_session.get_all_data("question_tags")['message']
        tags_dict = dict(map(lambda x: (x['tag'], x['_id']), tags_collection))
        new_tags = []
        tag_ids = []
        for t in tags:
            if t['_id'] == t['tag']:
                if t['tag'] in tags_dict.keys():
                    tag_ids.append(ObjectId(tags_dict[t['tag']]))
                else:
                    new_tags.append(t['tag'])
            else:
                tag_ids.append(ObjectId(t['_id']))
        if new_tags:
            tag_ids.extend(insert_tags(new_tags))
        tag_ids = list(set(tag_ids)) if tag_ids else []
        return tag_ids

    resources_validation_response = validate_resouces([doc["_id"] for doc in project_file_resources])
    if len(resources_validation_response["unvalid_resouces"]) > 0:
        raise Exception("Resource are you provide not all vaild ({0})".format(
            " ,".join([str(id) for id in resources_validation_response["unvalid_resouces"]])))
    else:
        addition_keys_dict = {}
        instance_ids = []
        project_instance_ids = []
        for resource in project_file_resources:
            resource_id = resource['_id']
            check_resource = mongo_session.check_existance_return_info(collection='global_resource_bank',
                                                                       condition={'_id': ObjectId(resource_id)},
                                                                       whole_doc=True)
            if check_resource:
                doc_to_insert = {
                    "resource_id": ObjectId(resource_id),
                    "tags": [],
                    "description": "",
                    "title": resource['title'],
                    "module": "course",
                    "used_at": "",
                    "updated_at": utc_datetime_now(),
                    "updated_by": ObjectId(user_id),
                }
                resource['url'] = check_resource['s3_key']
                resource['_id'] = ObjectId(resource_id)
                resp_id = mongo_session.insert_documnet(collection="resource_bank_instance",
                                                        doc_to_insert=doc_to_insert)
                resource['instance_id'] = resp_id['_id'].inserted_id
                instance_ids.append(resource['instance_id'])
                project_instance_ids.append({'resource_id': ObjectId(resource_id),
                                             'instance_id': resource['instance_id']})

            elif check_resource is None:
                course_bank_find = mongo_session.check_existance_return_info(collection='course_resource_bank',
                                                                             condition={
                                                                                 "_id": ObjectId(resource_id)
                                                                             },
                                                                             whole_doc=True)
                if course_bank_find:
                    some = mongo_session.transfer_docs_another_collection(from_collection='course_resource_bank',
                                                                          to_collection='global_resource_bank',
                                                                          condition={"_id": ObjectId(resource_id)})
                    resource['url'] = course_bank_find['s3_key']
                    resource['_id'] = ObjectId(resource_id)
                passion_project_find = mongo_session.check_existance_return_info(collection='resources',
                                                                                 condition={
                                                                                     "_id": ObjectId(resource_id)
                                                                                 },
                                                                                 whole_doc=True)
                if passion_project_find:
                    some = mongo_session.transfer_docs_another_collection(from_collection='resources',
                                                                          to_collection='global_resource_bank',
                                                                          condition={"_id": ObjectId(resource_id)})
                    resource['url'] = passion_project_find['s3_key']
                    resource['_id'] = ObjectId(resource_id)
                if passion_project_find or course_bank_find:
                    doc_to_insert = {
                        "resource_id": ObjectId(resource_id),
                        "tags": [],
                        "description": "",
                        "title": resource['title'],
                        "module": "course",
                        "used_at": "",
                        "updated_at": utc_datetime_now(),
                        "updated_by": ObjectId(user_id),
                    }
                    resp_id = mongo_session.insert_documnet(collection="resource_bank_instance",
                                                            doc_to_insert=doc_to_insert)
                    resource['instance_id'] = resp_id['_id'].inserted_id
                    instance_ids.append(resource['instance_id'])
                    project_instance_ids.append({'resource_id': ObjectId(resource_id),
                                                 'instance_id': resource['instance_id']})
    #     for doc in project_file_resources:
    #         inner_dict = {
    #             "title": doc["title"],
    #             "url": doc["url"],
    #             "type": "file",
    #             "module_name": "passion_project"
    #
    #         }
    #         addition_keys_dict[doc["_id"]] = inner_dict
    #     insert_response = mongo_session.insert_date_into_resource_and_temp_delete(collection="resources",
    #                                                                               temp_record="temp_uploaded_files",
    #                                                                               records_to_modify=
    #                                                                               resources_validation_response[
    #                                                                                   "valid_resources"],
    #                                                                               addition_keys_dict=addition_keys_dict)
    #
    #     if insert_response["status"] != 200:
    #         Exception("We ran into a problem. Could not insert into database")
    #
    project_text_insert_list = []
    for doc in project_text_resources:
        inner_dict = {
            "title": doc["title"],
            "url": doc["url"],
            "type": "text",
            "file_type": "text",
            "module_name": "passion_project"
        }
        project_text_insert_list.append(inner_dict)

    project_text_insert_response = mongo_session.insert_date_into_resource_with_dict(collection="resources",
                                                                                     project_text_insert_list=project_text_insert_list)
    if project_text_insert_response["status"] != 200:
        Exception("We ran into a problem. Could not insert into database")

    all_insert_documented_ids = []
    all_insert_documented_ids.extend(project_text_insert_response["inserted_document_ids"])
    all_insert_documented_ids.extend(project_instance_ids)

    document = {
        'project_title': title,
        'project_image': image_key,
        'project_description': description,
        'project_tags': validate_tags(tags),
        'created_by': user_id,
        "project_mentors": project_mentors,
        "project_resources": all_insert_documented_ids,
        "is_active": {
            "value": True,
            "updated_by": user_id,
            "updated_at": datetime.now(timezone.utc)
        }
    }
    res = mongo_session.insert_documnet(collection="passion_projects", doc_to_insert=document)
    project_insert_res = {
        'message': res['message'],
        '_id': str(res['_id'].inserted_id)
    }
    used_at = {"$set": {"used_at": {'passion_project_id': ObjectId(res['_id'].inserted_id)}}}
    condition = {"_id": {"$in": instance_ids}}
    updation = mongo_session.update_db_data(collection='resource_bank_instance', condition=condition,
                                            update_info=used_at, multi=True)
    status = res['status']
    if status != 200:
        raise Exception("We ran into a problem. Could not insert into database")

    project_insert_res = {
        'message': "Project added successfully!",
        '_id': str(res['_id'].inserted_id)
    }
    return project_insert_res


def update_project(user_id, role, title, image_url, description, tags, project_id, mentors, resources):
    """
    In this an existing passion_project with a given project_id is updated
    """
    if role != "super_admin" and role != 'teacher':
        if not mongo_session.check_existance(collection="passion_projects",
                                             condition={"created_by": user_id}):
            raise InvalidUsage("You don't have permission to edit this passion project.", 403)
    if not title:
        raise InvalidUsage("Please enter a valid project name.", 400)
    if not description:
        raise InvalidUsage("Please add description for your passion project.", 400)
    existing_project = mongo_session.find_one_in_db(collection="passion_projects", condition={"project_title": title,
                                                                                              "_id": {
                                                                                                  "$ne": ObjectId(
                                                                                                      project_id)},
                                                                                              }, columns=["_id"])

    if existing_project['message']:
        raise InvalidUsage(message="Project with this name already exists", status_code=400)
    tags_collection = mongo_session.get_all_data("question_tags")['message']
    tags_dict = dict(map(lambda x: (x['tag'], x['_id']), tags_collection))
    new_tags = []
    tag_ids = []
    for t in tags:
        if t['_id'] == t['tag']:
            if t['tag'] in tags_dict.keys():
                tag_ids.append(ObjectId(tags_dict[t['tag']]))
            else:
                new_tags.append(t['tag'])
        else:
            tag_ids.append(ObjectId(t['_id']))
    if new_tags:
        tag_ids.extend(insert_tags(new_tags))
    if tag_ids:
        tag_ids = list(set(tag_ids))

    image_url = image_url.split('?')[0]
    image_key = image_url.split('/')[-2] + '/' + image_url.split('/')[-1]

    mentors = [doc["id"] for doc in mentors]
    mentors.append(user_id)
    processed_mentors = validate_project_mentors(mentors)
    # process resources
    fetch_resources = mongo_session.get_data_for_particular_columns_with_condition(collection="passion_projects",
                                                                                   condition={
                                                                                       "_id": ObjectId(project_id)},
                                                                                   columns={"project_resources": 1})

    db_resources = fetch_resources["message"][0]["project_resources"] if fetch_resources["message"][0].get("project_resources") == 200 else []

    existing_resources = []
    if db_resources:
        for res in db_resources:
            if isinstance(res, dict):
                existing_resources.append(res)
    if existing_resources:
        for res in db_resources:
            if isinstance(res, dict):
                continue
            else:
                if str(res) in [str(x['resource_id']) for x in existing_resources]:
                    continue
                else:
                    existing_resources.append({'resource_id':res, 'instance_id': ''})
        existing_resources_ids = set([str(x['resource_id']) for x in existing_resources])
        resource_ids = set([str(x['_id']) for x in resources]) & existing_resources_ids
    else:
        resource_ids = set([str(x['_id']) for x in resources])

    resource_to_add = []
    for res in resources:
        if str(res['_id']) in resource_ids:
            resource_to_add.append(res)
    instance_ids = []
    project_instance_ids = []
    for resource in resource_to_add:
        if not resource["title"]:
            raise InvalidUsage("Please enter a valid title for the resource.", 400)
        resource_id = resource['_id']
        check_resource = mongo_session.check_existance_return_info(collection='global_resource_bank',
                                                                   condition={'_id': ObjectId(resource_id)},
                                                                   whole_doc=True)
        if check_resource:
            doc_to_insert = {
                "resource_id": ObjectId(resource_id),
                "tags": [],
                "description": "",
                "title": resource['title'],
                "module": "course",
                "used_at": "",
                "updated_at": utc_datetime_now(),
                "updated_by": ObjectId(user_id),
            }
            resource['url'] = check_resource['s3_key']
            resource['_id'] = ObjectId(resource_id)
            resp_id = mongo_session.insert_documnet(collection="resource_bank_instance",
                                                    doc_to_insert=doc_to_insert)
            resource['instance_id'] = resp_id['_id'].inserted_id
            instance_ids.append(resource['instance_id'])
            project_instance_ids.append({'resource_id': ObjectId(resource_id),
                                         'instance_id': resource['instance_id']})

        elif check_resource is None:
            course_bank_find = mongo_session.check_existance_return_info(collection='course_resource_bank',
                                                                         condition={
                                                                             "_id": ObjectId(resource_id)
                                                                         },
                                                                         whole_doc=True)
            if course_bank_find:
                some = mongo_session.transfer_docs_another_collection(from_collection='course_resource_bank',
                                                                      to_collection='global_resource_bank',
                                                                      condition={"_id": ObjectId(resource_id)})
                resource['url'] = course_bank_find['s3_key']
                resource['_id'] = ObjectId(resource_id)
            passion_project_find = mongo_session.check_existance_return_info(collection='resources',
                                                                             condition={
                                                                                 "_id": ObjectId(resource_id)
                                                                             },
                                                                             whole_doc=True)
            if passion_project_find:
                some = mongo_session.transfer_docs_another_collection(from_collection='resources',
                                                                      to_collection='global_resource_bank',
                                                                      condition={"_id": ObjectId(resource_id)})
                resource['url'] = passion_project_find['s3_key']
                resource['_id'] = ObjectId(resource_id)
            if passion_project_find or course_bank_find:
                doc_to_insert = {
                    "resource_id": ObjectId(resource_id),
                    "tags": [],
                    "description": "",
                    "title": resource['title'],
                    "module": "course",
                    "used_at": "",
                    "updated_at": utc_datetime_now(),
                    "updated_by": ObjectId(user_id),
                }
                resp_id = mongo_session.insert_documnet(collection="resource_bank_instance",
                                                        doc_to_insert=doc_to_insert)
                resource['instance_id'] = resp_id['_id'].inserted_id
                instance_ids.append(resource['instance_id'])
                project_instance_ids.append({'resource_id': ObjectId(resource_id),
                                             'instance_id': resource['instance_id']})
    document = {
        'project_title': title,
        'project_image': image_key,
        'project_description': description,
        'project_tags': tag_ids,
        'created_by': user_id,
        'project_resources': project_instance_ids,
        'project_mentors': processed_mentors
    }
    res = mongo_session.update_multiple_fields(collection="passion_projects", condition={"_id": ObjectId(project_id)}
                                               ,set_columns=document)
    used_at = {"$set": {"used_at": {'passion_project_id': ObjectId(project_id)}}}
    condition = {"_id": {"$in": instance_ids}}
    updation = mongo_session.update_db_data(collection='resource_bank_instance', condition=condition,
                                            update_info=used_at, multi=True)
    project_update_res = {
        'message': res['message']
    }
    if res['status'] != 200:
        raise Exception("We ran into a problem. Could not update into database")

    project_update_res = {
        'message': "Project updated successfully!"
    }

    mentor_chat_room = mongo_session.get_data_for_particular_columns_with_condition(collection="chat_rooms",
                                                                                    condition={
                                                                                        "passion_project_id": ObjectId(
                                                                                            project_id),
                                                                                        "mentor_chat": True})

    mentor_chat_room_admins_array = []
    for mentor in mentors:
        document_mcu = {
            "admin_id": ObjectId(mentor),
            "added_by": ObjectId(user_id),
            "status": "active"
        }
        mentor_chat_room_admins_array.append(document_mcu)

    for chat_rooms in mentor_chat_room['message']:
        res = mongo_session.update_multiple_fields(collection="chat_rooms",
                                                   condition={"_id": ObjectId(chat_rooms['_id']),
                                                              "passion_project_id": ObjectId(project_id),
                                                              "mentor_chat": True},
                                                   set_columns={"admins": mentor_chat_room_admins_array})
    return project_update_res


def delete_project(project_id, user_id):
    condition = {"_id": ObjectId(project_id)}

    message = mongo_session.check_existance_return_info(collection='passion_projects',
                                                        condition=condition)

    if message is None:
        raise InvalidUsage("This project does not exist", 404)

    set_columns = {
        "is_active": {
            "value": False,
            "updated_by": user_id,
            "updated_at": datetime.now(timezone.utc)
        }
    }
    message = mongo_session.update_multiple_fields(collection='passion_projects',
                                                   condition=condition,
                                                   set_columns=set_columns)
    return message


def create_pp_team_chat(members, group_name, admins, created_by, group_description, subheading,
                        resource_bank_resource_id,
                        s3_key_info, pp_id=None, team_id=None):
    room_members = {}
    members = [str(mem) for mem in members]
    for member in members:
        room_members[member] = {"created_by": ObjectId(created_by),
                                "created_at": utc_datetime_now(),
                                "status": "active"}

    photo_id = resource_bank_resource_id
    url = s3_key_info

    admin_list = []
    for admin in admins:
        admin_list.append({"admin_id": ObjectId(admin), "added_by": ObjectId(created_by), "status": "active"})

    doc_to_insert = {
        "name": group_name,
        "created_by": ObjectId(created_by),
        "created_at": utc_datetime_now(),
        "admins": admin_list,
        "room_members": room_members,
        "group_photo": {
            "avatar_url": url,
            "edited_by": ObjectId(created_by),
            "photo_id": ObjectId(photo_id) if photo_id else ""
        },
        "sub_heading": subheading if subheading else "",
        "group_description": {
            "description": group_description if group_description else "",
            "edited_by": ObjectId(created_by) if group_description else ""
        },
        "type": "group"
    }
    if pp_id:
        doc_to_insert['passion_projects'] = [ObjectId(pp_id[0])]
    if team_id:
        doc_to_insert['team_id'] = ObjectId(team_id)

    response = mongo_session.insert_documnet(collection="chat_rooms",
                                             doc_to_insert=doc_to_insert)
    room_info = mongo_session.check_existance_return_info(collection='chat_rooms',
                                                          condition={
                                                              '_id': ObjectId(response['_id'].inserted_id)
                                                          },
                                                          whole_doc=True)
    if not room_info:
        raise InvalidUsage("Room not found", 400)
    room_info['_id'] = str(room_info['_id'])
    room_info['created_by'] = str(room_info['created_by'])
    room_info['admins'][0]['admin_id'] = str(room_info['admins'][0]['admin_id'])
    room_info['admins'][0]['added_by'] = str(room_info['admins'][0]['added_by'])
    room_info['group_description']['edited_by'] = str(room_info['group_description']['edited_by'])
    room_info['group_photo']['edited_by'] = str(room_info['group_photo']['edited_by'])
    room_info['group_photo']['photo_id'] = str(room_info['group_photo']['photo_id'])
    for member in room_info['room_members']:
        room_info['room_members'][member]['created_by'] = str(
            room_info['room_members'][member]['created_by'])
    if pp_id:
        for pid in range(len(room_info['passion_projects'])):
            room_info['passion_projects'][pid] = str(room_info['passion_projects'][pid])
    return room_info


def insert_team(user_id, team_name, team_members, team_logo_key, project_id, original_team=None):
    """
    In this a new team is inserted in db
    1. Team members should consist of only students

    2. If there is some original team, a clone can be created using this function. Which will break the connection of
    original team to the given project and clone will get associated to the project.
    """
    # check if there is some original team then match the leads
    if original_team:
        if not validate_ObjectId(original_team):
            raise InvalidUsage(message="Bad Request", status_code=400)
        original_team_info = mongo_session.check_existance_return_info(collection="passion_project_teams",
                                                                       condition={"_id": ObjectId(original_team)},
                                                                       columns={"lead": 1, "projects": 1},
                                                                       return_keys=["lead", "projects"])
        if not original_team_info:
            raise InvalidUsage(message="Bad Request", status_code=400)
        if user_id != str(original_team_info["lead"]):
            raise InvalidUsage(message="Only team lead is allowed to edit.", status_code=400)
        team_logo_key = team_logo_key.split('/')[-2] + '/' + team_logo_key.split('/')[-1].split('?')[-2]

    # check if team already exist
    data = mongo_session.find_one_in_db(collection="passion_project_teams", condition={"name": team_name},
                                        columns=["name"])
    if data['message']:
        raise InvalidUsage(message="Team already exist for this name", status_code=400)
    # check if at least one member should be present in team
    if not team_members:
        raise InvalidUsage(message="team should have at least one member", status_code=400)
    # check if team lead is not present in members list
    if user_id not in team_members:
        raise InvalidUsage(message="Team lead not present in team members", status_code=400)
    # check if team contains duplicate members
    if len(team_members) != len(set(team_members)):
        raise InvalidUsage(message="duplicate members in team", status_code=400)
    # check if member is there in db
    for member_id in team_members:
        user_data = mongo_session.get_all_data_for_particular_condition_fields(collection="user_profile",
                                                                               condition={"_id": ObjectId(member_id)}
                                                                               )['message']
        if not user_data:
            raise InvalidUsage(message="Member is not present in db", status_code=400)
        role = user_data[0]['role']
        if role != "student":
            raise InvalidUsage(message="Only students can be member of team", status_code=400)
    # check if project is there in db
    project_data = mongo_session.find_one_in_db(collection="passion_projects",
                                                condition={"_id": ObjectId(project_id[0])},
                                                columns=["title"])
    if not project_data['message']:
        raise InvalidUsage(message="Following project in not in db", status_code=400)

    team_members = [ObjectId(t) for t in team_members]
    project_id = [ObjectId(p) for p in project_id]
    document = {
        'name': team_name,
        'logo': team_logo_key,
        'members': team_members,
        'lead': ObjectId(user_id),
        'projects': project_id
    }
    res = mongo_session.insert_documnet(collection="passion_project_teams", doc_to_insert=document)
    team_members.remove(ObjectId(user_id))
    create_pp_team_chat(members=team_members, group_name=team_name, admins=[ObjectId(user_id)], created_by=user_id,
                        group_description="", subheading="", resource_bank_resource_id="", s3_key_info=team_logo_key,
                        pp_id=project_id, team_id=str(res['_id'].inserted_id))
    team_insert_res = {
        'message': res['message'],
        '_id': str(res['_id'].inserted_id)
    }
    if res['status'] != 200:
        raise Exception("Unable to Create Team")

    if original_team:
        # update data from the original team to the new one for submissions
        if mongo_session.check_existance_return_info(collection="passion_project_reports",
                                                     condition={"project": ObjectId(project_id[0]),
                                                                "team": ObjectId(original_team)}):
            update_submission = mongo_session.update_record_into_db(collection="passion_project_reports",
                                                                    condition={"project": ObjectId(project_id[0]),
                                                                               "team": ObjectId(original_team)},
                                                                    update_info={"$set": {
                                                                        "team": ObjectId(team_insert_res["_id"])}})
            if update_submission["status"] != 200:
                raise InvalidUsage("Oops! Something went wrong!", 500)
        if original_team_info["projects"]:
            project_list = list(set(original_team_info["projects"]))
            project_list.remove(ObjectId(project_id[0]))
            cut_org_team_connection = mongo_session.update_record_into_db(collection="passion_project_teams",
                                                                          condition={"_id": ObjectId(original_team)},
                                                                          update_info={
                                                                              "$set": {"projects": project_list}})
            if cut_org_team_connection["status"] != 200:
                raise InvalidUsage("Oops! Something went wrong!", 500)
    return team_insert_res


def get_teams(project_id=None, team_id=None, user_id=None, user_info_id=None):
    """
    In this a all the teams that are present in the db are listed
    1. Name of members are fetched with respect to there id.
    2. Profile pic of every team member has to be displayed , default profile pic is displayed if none is available.
    """
    condition = {}
    if project_id:
        condition['projects'] = {"$in": [ObjectId(project_id)]}
    if team_id:
        condition['_id'] = ObjectId(team_id)
    if user_id:
        condition['lead'] = ObjectId(user_id)

    res = mongo_session.get_all_data_for_particular_condition_fields(collection="passion_project_teams",
                                                                     condition=condition)
    teams = res['message']
    team_user_id = ""
    for i in teams:
        projects = []
        for project_id in i['projects']:
            passion_project = mongo_session.get_all_data_for_particular_condition_fields(collection="passion_projects",
                                                                                         condition={"_id": project_id}
                                                                                         )['message'][0]
            project_title = passion_project['project_title']
            project_obj = {
                '_id': str(project_id),
                'title': project_title,
            }
            projects.append(project_obj)
        i['projects'] = projects
        i['logo'] = s3_function.generate_presigned_url_from_s3(i['logo'])[0]
        user_profile = mongo_session.get_all_data_for_particular_condition_fields(collection="user_profile",
                                                                                  condition={"_id": i['lead']}
                                                                                  )['message'][0]
        if ObjectId(user_info_id) in i['members'] or ObjectId(user_info_id) == i['lead']:
            team_user_id = i['_id']
            current_user = "room_members." + user_info_id
            condition = {"$and": [
                {"$or": [{current_user: {"$exists": True}},
                         {"admins.admin_id": {"$in": [ObjectId(user_info_id)]}}
                         ]},
                {"passion_projects": {"$in": [ObjectId(project_id)]}},
                {"team_id": ObjectId(team_user_id)}]}
            room_info = mongo_session.check_existance_return_info(collection='chat_rooms',
                                                                  condition=condition,
                                                                  whole_doc=True)
            if room_info and room_info['room_members']:
                check_message_count = mongo_session.get_total_count(collection='messages',
                                                                    condition={
                                                                        'room_id': str(room_info['_id']),
                                                                        "receiver_status":
                                                                            {"$elemMatch": {"$and": [
                                                                                {"_id": ObjectId(user_info_id)},
                                                                                {"status": False}
                                                                            ]}
                                                                            }})
                if check_message_count:
                    room_info['total_unread_messages'] = check_message_count
                else:
                    room_info['total_unread_messages'] = 0

                message_info = mongo_session.check_existance_return_info(collection='messages',
                                                                         condition={'room_id': str(room_info['_id'])},
                                                                         return_keys=['message', 'created_at',
                                                                                      'sender_id', 'content'])
                if message_info:
                    message_info['sender_id'] = str(message_info['sender_id'])
                    date = message_info['created_at']
                    message_info['created_at'] = convert_utc_to_ist(date).replace(tzinfo=None).isoformat(' ')
                    room_info['messages'] = [message_info]
                else:
                    room_info['messages'] = []

                room_members = []
                members = [ObjectId(member) for member in room_info['room_members']]
                room_members.extend(members)
                admins = [member['admin_id'] for member in room_info['admins'] if member['status'] == "active"]
                room_members.extend(admins)
                admins = [str(member['admin_id']) for member in room_info['admins'] if member['status'] == "active"]

                user_info = mongo_session.access_specific_fields(collection='user_profile',
                                                                 condition={
                                                                     "_id": {"$in": room_members}
                                                                 },
                                                                 return_keys=['_id', 'name', 'last_name', 'email',
                                                                              'username',
                                                                              'profile_pic'])
                user_details = {}
                for user in user_info:
                    user_details[str(user['_id'])] = user
                    user['_id'] = str(user['_id'])
                    user['user_id'] = user['_id']
                    user['avatar_url'] = user['profile_pic']
                    # print(user['profile_pic'])
                    user['color'] = ""
                    if user['avatar_url'] is None:
                        user['avatar_url'] = ""
                    del user['_id']

                room_info['_id'] = str(room_info['_id'])
                room_info['room_id'] = room_info['_id']
                del room_info['_id']
                room_info['created_by'] = str(room_info['created_by'])
                room_info['created_at'] = convert_utc_to_ist(room_info['created_at']).replace(tzinfo=None)
                if room_info.get('type'):
                    admin_list = []
                    for admin in room_info['admins']:
                        admin['admin_id'] = str(admin['admin_id'])
                        if admin['admin_id'] == user_info_id and admin['status'] == 'active':
                            room_info['current_user_admin'] = True
                        else:
                            room_info['current_user_admin'] = False
                        admin['added_by'] = str(admin['added_by'])
                        if room_info['room_members']:
                            room_info['room_members'][admin['admin_id']] = {"status": admin['status']}
                        else:
                            dict_1 = {admin['admin_id']: {"status": admin['status']}}
                            room_info['room_members'] = dict_1

                member_list = []
                for member in room_info['room_members']:
                    if member in user_details:
                        s3_url, status_code = s3_function.generate_presigned_url_from_s3(
                            user_details[member]['profile_pic'])
                        user_details[member]['avatar_url'] = s3_url
                        if room_info['name'] == "" and not room_info.get('type'):
                            if member != user_info_id:
                                room_info['name'] = user_details[member]['username']
                                room_info['avatar_url'] = s3_url
                        if room_info.get('type'):
                            if member in admins:
                                user_details[member]['is_admin'] = True
                            else:
                                user_details[member]['is_admin'] = False
                            if member == user_info_id:
                                room_info['user_status'] = room_info['room_members'][member]['status']
                            user_details[member]['user_status'] = room_info['room_members'][member]['status']
                        else:
                            if member == user_info_id:
                                room_info['user_status'] = "active"
                            user_details[member]['user_status'] = "active"
                        d = {key: value for key, value in user_details[member].items() if key not in 'profile_pic'}
                        if user_details[member].get('user_status'):
                            del user_details[member]['user_status']
                        if user_details[member].get('is_admin'):
                            del user_details[member]['is_admin']
                        member_list.append(d)
                room_info['room_members'] = member_list
                if room_info.get('group_photo'):
                    room_info['avatar_url'], status = s3_function.generate_presigned_url_from_s3(
                        room_info['group_photo']['avatar_url'])
                    del room_info['group_photo']

                if room_info.get('group_description'):
                    room_info['description'] = str(room_info['group_description']['description'])
                    del room_info['group_description']

                if room_info.get('passion_projects'):
                    for pid in range(len(room_info['passion_projects'])):
                        room_info['passion_projects'][pid] = str(room_info['passion_projects'][pid])
                if room_info.get('team_id'):
                    room_info['team_id'] = str(room_info['team_id'])
                del room_info['admins']
                i['group_chat'] = room_info
        if not i.get('group_chat'):
            i['group_chat'] = {}
        team_lead_first_name = user_profile['name']
        team_lead_last_name = user_profile['last_name']

        team_lead_user_name = user_profile['username']
        team_lead_obj = {
            '_id': str(i['lead']),
            'name': team_lead_first_name + " " + team_lead_last_name,
            'username': team_lead_user_name
        }
        i['lead'] = team_lead_obj
        team_members = []
        for member in i['members']:
            user_profile = mongo_session.get_all_data_for_particular_condition_fields(collection="user_profile",
                                                                                      condition={
                                                                                          "_id": member}
                                                                                      )['message'][0]
            first_name = user_profile['name']
            last_name = user_profile['last_name']
            user_name = user_profile['username']
            avatar = user_profile['profile_pic'] if user_profile['profile_pic'] is not None else DEFAULT_AVATAR
            avatar = s3_function.generate_presigned_url_from_s3(avatar)[0]
            team_obj = {
                'name': first_name + " " + last_name,
                'profile_pic': avatar,
                '_id': str(member),
                'username': user_name
            }
            team_members.append(team_obj)
        i['members'] = team_members
    current_user = "room_members." + user_info_id
    team_res = {"teams": teams,
                "message": "success"
                }
    if res['status'] != 200:
        raise Exception("Unable to Get Teams")

    return team_res


def update_team(user_id, team_name, team_members, team_logo_url, team_id, project_id):
    """
    In this an existing team is updated in db
    1. Only team lead can edit the team
    """
    existing_team = mongo_session.find_one_in_db(collection="passion_project_teams", condition={"name": team_name,
                                                                                                "_id": {
                                                                                                    "$ne": ObjectId(
                                                                                                        team_id)}
                                                                                                }, columns=["name"])
    if existing_team['message']:
        raise InvalidUsage(message="Team already exist for this name", status_code=400)

    if not team_members:
        raise InvalidUsage(message="Team should have at least on member", status_code=400)

    if len(project_id) != len(set(project_id)):
        raise InvalidUsage(message="Team is already working on this project", status_code=400)

    if len(team_members) != len(set(team_members)):
        raise InvalidUsage(message="duplicate member", status_code=400)

    team = mongo_session.get_all_data_for_particular_condition_fields(collection="passion_project_teams",
                                                                      condition={"_id": ObjectId(team_id)}
                                                                      )['message'][0]
    # check if team lead is editing
    team_lead = str(team['lead'])
    if user_id != team_lead:
        raise InvalidUsage(message="Only team lead is allowed to edit", status_code=400)
    # check if team lead is present id members list
    if team_lead not in team_members:
        raise InvalidUsage(message="Cannot remove team lead from members list", status_code=400)
    # check if user is present in database
    for member_id in team_members:
        user_data = mongo_session.get_all_data_for_particular_condition_fields(collection="user_profile",
                                                                               condition={"_id": ObjectId(member_id)}
                                                                               )['message']
        if not user_data:
            raise InvalidUsage(message="Member is not present in db", status_code=400)
        role = user_data[0]['role']
        if role != "student":
            raise InvalidUsage(message="Only students can be member of team", status_code=400)
    # check if project is there in db
    project_data = mongo_session.find_one_in_db(collection="passion_projects", condition={"_id": ObjectId(project_id[0])
                                                                                          },
                                                columns=["title"])
    if not project_data['message']:
        raise InvalidUsage(message="Following project in not in db", status_code=400)

    team_logo_url = team_logo_url.split('?')[0]
    team_logo_key = team_logo_url.split('/')[-2] + '/' + team_logo_url.split('/')[-1]
    team_members = [ObjectId(t) for t in team_members]
    project_id = [ObjectId(p) for p in project_id]
    document = {
        'name': team_name,
        'logo': team_logo_key,
        'members': team_members,
        'projects': project_id
    }
    res = mongo_session.update_multiple_fields(collection="passion_project_teams", condition={"_id": ObjectId(team_id)},
                                               set_columns=document)
    room_id = mongo_session.check_existance_return_info(collection='chat_rooms',
                                                        condition={'team_id': ObjectId(team_id)})
    if room_id:
        update_course_groupchat(user_id, room_id, team_name, photo_url=team_logo_key, projects=ObjectId(project_id[0]),
                                team_members=team_members)
    team_update_res = {
        'message': res['message']
    }
    if res['status'] != 200:
        raise Exception("Error while connecting, Please try again.")
    return team_update_res


def get_processed_resources(resource_list):
    project_resources_list = []
    for resource_id in resource_list:
        condition = {"_id": resource_id}
        columns = {"_id": 1, "file_type": 1, "title": 1, "s3_key": 1, "type": 1, "url": 1}
        column_request_response_key_mapping = {
            "_id": "_id",
            "file_type": "type",
            "title": "title",
            "s3_key": "s3url",
            "url": "url",
            "type": "resource_type"
        }
        resource_data_res = mongo_session.get_data_for_particular_columns_with_condition(
            collection='resources',
            condition=condition,
            columns=columns,
            column_request_response_key_mapping=column_request_response_key_mapping)

        if resource_data_res["status"] == 200:
            for resource in resource_data_res["message"]:
                if resource["type"] != "text":
                    resource["s3url"] = s3_function.generate_presigned_url_from_s3(resource["s3url"])[0]
            project_resources_list.extend(resource_data_res["message"])
    return project_resources_list


def get_project_report(user_id, project_id=None, team_id=None, report_id=None):
    """
    In this report of a passion project is returned with a
    specific project_id and team_id given.
    """
    user_id = ObjectId(user_id)
    condition = {}

    condition['project'] = ObjectId(project_id)
    condition['team'] = ObjectId(team_id)
    if report_id:
        condition['_id'] = ObjectId(report_id)
    tags_collection = mongo_session.get_all_data("question_tags")['message']
    tags_dict = dict(map(lambda x: (x['_id'], x['tag']), tags_collection))
    res = mongo_session.get_all_data_for_particular_condition_fields(collection="passion_project_reports",
                                                                     condition=condition)
    team_data = mongo_session.get_all_data_for_particular_condition_fields(collection="passion_project_teams",
                                                                           condition={"_id": condition['team']}
                                                                           )["message"][0]
    team_members = team_data["members"]
    reports = res['message']
    if user_id in team_members:
        for report in reports:
            project_id = report['project']
            team_id = report['team']

            if not mongo_session.get_all_data_for_particular_condition_fields(collection="passion_projects",
                                                                              condition={"_id": project_id}
                                                                              )['message']:
                raise InvalidUsage("Passion Project not available")
            else:
                project_data = mongo_session.get_all_data_for_particular_condition_fields(collection="passion_projects",
                                                                                          condition={"_id": project_id}
                                                                                          )['message'][0]
            project_title = project_data['project_title']

            if not mongo_session.get_all_data_for_particular_condition_fields(collection="passion_project_teams",
                                                                              condition={"_id": team_id}
                                                                              )['message']:
                raise InvalidUsage("Team is not available")
            else:
                team_data = \
                    mongo_session.get_all_data_for_particular_condition_fields(collection="passion_project_teams",
                                                                               condition={"_id": team_id}
                                                                               )['message'][0]
            team_name = team_data['name']
            report['project'] = {
                "_id": str(project_id),
                "title": project_title
            }
            report['team'] = {
                "_id": str(team_id),
                'name': team_name
            }
            tags = report['tags']
            report['tags'] = [{'tag': tags_dict[str(t)], "_id": str(t)} for t in tags]
            report['content'] = renew_s3_links(report['content'])

            report['code_links'] = get_processed_resources(report.get('code_links', []))
            report['webinar_links'] = get_processed_resources(report.get('webinar_links', []))
            report['resource_links'] = get_processed_resources(report.get('resource_links', []))

        current_user = "room_members." + str(user_id)
        condition = {"$and": [
            {"$or": [{current_user: {"$exists": True}},
                     {"admins.admin_id": {"$in": [ObjectId(user_id)]}}
                     ]},
            {"passion_projects": {"$in": [ObjectId(project_id)]}},
            {"team_id": ObjectId(team_id)}]}
        room_info = mongo_session.check_existance_return_info(collection='chat_rooms',
                                                              condition=condition,
                                                              whole_doc=True)
        if room_info and room_info['room_members']:
            check_message_count = mongo_session.get_total_count(collection='messages',
                                                                condition={
                                                                    'room_id': str(room_info['_id']),
                                                                    "receiver_status":
                                                                        {"$elemMatch": {"$and": [
                                                                            {"_id": ObjectId(user_id)},
                                                                            {"status": False}
                                                                        ]}
                                                                        }})
            if check_message_count:
                room_info['total_unread_messages'] = check_message_count
            else:
                room_info['total_unread_messages'] = 0

            message_info = mongo_session.check_existance_return_info(collection='messages',
                                                                     condition={'room_id': str(room_info['_id'])},
                                                                     return_keys=['message', 'created_at',
                                                                                  'sender_id', 'content'])
            if message_info:
                message_info['sender_id'] = str(message_info['sender_id'])
                date = message_info['created_at']
                message_info['created_at'] = convert_utc_to_ist(date).replace(tzinfo=None).isoformat(' ')
                room_info['messages'] = [message_info]
            else:
                room_info['messages'] = []

            room_members = []
            members = [ObjectId(member) for member in room_info['room_members']]
            room_members.extend(members)
            admins = [member['admin_id'] for member in room_info['admins'] if member['status'] == "active"]
            room_members.extend(admins)
            admins = [str(member['admin_id']) for member in room_info['admins'] if member['status'] == "active"]

            user_info = mongo_session.access_specific_fields(collection='user_profile',
                                                             condition={
                                                                 "_id": {"$in": room_members}
                                                             },
                                                             return_keys=['_id', 'name', 'last_name', 'email',
                                                                          'username',
                                                                          'profile_pic'])
            user_details = {}
            for user in user_info:
                user_details[str(user['_id'])] = user
                user['_id'] = str(user['_id'])
                user['user_id'] = user['_id']
                user['avatar_url'] = user['profile_pic']
                # print(user['profile_pic'])
                user['color'] = ""
                if user['avatar_url'] is None:
                    user['avatar_url'] = ""
                del user['_id']

            room_info['_id'] = str(room_info['_id'])
            room_info['room_id'] = room_info['_id']
            del room_info['_id']
            room_info['created_by'] = str(room_info['created_by'])
            room_info['created_at'] = convert_utc_to_ist(room_info['created_at']).replace(tzinfo=None)
            if room_info.get('type'):
                admin_list = []
                for admin in room_info['admins']:
                    admin['admin_id'] = str(admin['admin_id'])
                    if admin['admin_id'] == user_id and admin['status'] == 'active':
                        room_info['current_user_admin'] = True
                    else:
                        room_info['current_user_admin'] = False
                    admin['added_by'] = str(admin['added_by'])
                    if room_info['room_members']:
                        room_info['room_members'][admin['admin_id']] = {"status": admin['status']}
                    else:
                        dict_1 = {admin['admin_id']: {"status": admin['status']}}
                        room_info['room_members'] = dict_1

            member_list = []
            for member in room_info['room_members']:
                if member in user_details:
                    s3_url, status_code = s3_function.generate_presigned_url_from_s3(
                        user_details[member]['profile_pic'])
                    user_details[member]['avatar_url'] = s3_url
                    if room_info['name'] == "" and not room_info.get('type'):
                        if member != user_id:
                            room_info['name'] = user_details[member]['username']
                            room_info['avatar_url'] = s3_url
                    if room_info.get('type'):
                        if member in admins:
                            user_details[member]['is_admin'] = True
                        else:
                            user_details[member]['is_admin'] = False
                        if member == user_id:
                            room_info['user_status'] = room_info['room_members'][member]['status']
                        user_details[member]['user_status'] = room_info['room_members'][member]['status']
                    else:
                        if member == user_id:
                            room_info['user_status'] = "active"
                        user_details[member]['user_status'] = "active"
                    d = {key: value for key, value in user_details[member].items() if key not in 'profile_pic'}
                    if user_details[member].get('user_status'):
                        del user_details[member]['user_status']
                    if user_details[member].get('is_admin'):
                        del user_details[member]['is_admin']
                    member_list.append(d)
            room_info['room_members'] = member_list
            if room_info.get('group_photo'):
                room_info['avatar_url'], status = s3_function.generate_presigned_url_from_s3(
                    room_info['group_photo']['avatar_url'])
                del room_info['group_photo']

            if room_info.get('group_description'):
                room_info['description'] = str(room_info['group_description']['description'])
                del room_info['group_description']

            if room_info.get('passion_projects'):
                for pid in range(len(room_info['passion_projects'])):
                    room_info['passion_projects'][pid] = str(room_info['passion_projects'][pid])
            if room_info.get('team_id'):
                room_info['team_id'] = str(room_info['team_id'])
            del room_info['admins']
        if not reports:
            project_report_res = {"reports": reports,
                                  "message": "reports not available with this project and team",
                                  "group_chat": room_info if room_info else {}
                                  }
        else:
            project_report_res = {"reports": reports,
                                  "message": "success",
                                  "group_chat": room_info if room_info else {}
                                  }
        return project_report_res
    else:
        project_report_res = {
            "message": "Only team member can view report"
        }
        return project_report_res


def validate_resource_array(resources, db_resources=None):
    unchanged_resources = []
    deleted_resources = []
    if db_resources:
        for res in resources:
            if res["_id"] and ObjectId(res["_id"]) in db_resources:
                unchanged_resources.append(ObjectId(res["_id"]))
                update_info = mongo_session.update_data(collection="resources",
                                                        find_condition={"_id": ObjectId(res["_id"])},
                                                        update_condition={},
                                                        update_info={"$set": {"title": res["title"],
                                                                              "url": res["url"]}})

    if db_resources:
        deleted_resources = set(db_resources) - set(unchanged_resources)
        deleted_resources = list(deleted_resources) if deleted_resources else []

    all_insert_documented_ids = []
    project_file_resources = []
    project_text_resources = []
    valid_resources = []
    for doc in resources:
        if not doc["title"]:
            raise InvalidUsage("Please provide a title for the resource.", 400)
        if doc["type"] == "file" and ObjectId(doc["_id"]) not in unchanged_resources:
            res_exist = mongo_session.check_existance_return_info(collection="temp_uploaded_files",
                                                                  condition={"_id": ObjectId(doc["_id"])})
            if not res_exist:
                raise InvalidUsage("Please check the resource you have entered.", 400)
            valid_resources.append(ObjectId(doc["_id"]))
            project_file_resources.append(doc)
        elif doc["type"] == 'text' and not doc["_id"]:
            project_text_resources.append(doc)

    addition_keys_dict = {}
    for doc in project_file_resources:
        inner_dict = {
            "title": doc["title"],
            "url": doc["url"],
            "type": "file",
            "module_name": "passion_project"

        }
        addition_keys_dict[doc["_id"]] = inner_dict
    insert_response = mongo_session.insert_date_into_resource_and_temp_delete(collection="resources",
                                                                              temp_record="temp_uploaded_files",
                                                                              records_to_modify=valid_resources,
                                                                              addition_keys_dict=addition_keys_dict)

    if insert_response["status"] != 200:
        raise InvalidUsage("We ran into a problem. Please try again later", 500)

    project_text_insert_list = []
    for doc in project_text_resources:
        inner_dict = {
            "title": doc["title"],
            "url": doc["url"],
            "type": "text",
            "file_type": "text",
            "module_name": "passion_project"
        }
        project_text_insert_list.append(inner_dict)

    project_text_insert_response = mongo_session.insert_date_into_resource_with_dict(collection="resources",
                                                                                     project_text_insert_list=project_text_insert_list)
    if project_text_insert_response["status"] != 200:
        raise InvalidUsage("We ran into a problem. Please try again later", 500)
    if project_text_resources:
        all_insert_documented_ids.extend(project_text_insert_response["inserted_document_ids"])
    all_insert_documented_ids.extend(valid_resources)
    if unchanged_resources:
        all_insert_documented_ids.extend(unchanged_resources)

    # delete all the deleted resources
    if deleted_resources:
        delete_status = mongo_session.insert_data_temp_delete_project_resource(collection="resources",
                                                                               temp_record="temp_uploaded_files",
                                                                               records_to_modify=deleted_resources)
    return all_insert_documented_ids


def insert_project_report(project_id, team_id, title, content, tags, code_links, webinar_links, resource_links,
                          user_id):
    """
    This function insert a report submitted by students for a passion project.
    """
    if not title:
        raise InvalidUsage("Please add a title for the project report.", 400)

    team_data = mongo_session.get_all_data_for_particular_condition_fields(collection="passion_project_teams",
                                                                           condition={"_id": ObjectId(team_id)}
                                                                           )['message']
    if not team_data:
        raise InvalidUsage(message="following team does not exist", status_code=400)
    project_data = mongo_session.find_one_in_db(collection="passion_projects", condition={"_id": ObjectId(project_id)},
                                                columns=['_id'])
    if not project_data['message']:
        raise InvalidUsage(message="following project does not exist", status_code=400)

    if ObjectId(project_id) not in team_data[0]["projects"]:
        raise InvalidUsage("You don't have permission to submit reports in this project.", 403)
    team_members = team_data[0]['members']
    if ObjectId(user_id) not in team_members:
        raise InvalidUsage(message="Only team members are allowed to create reports", status_code=400)

    report_existence = mongo_session.find_one_in_db(collection="passion_project_reports",
                                                    condition={"project": ObjectId(project_id),
                                                               "team": ObjectId(team_id)},
                                                    columns=["title"])
    if report_existence['message']:
        raise InvalidUsage(message="You cannot add more than one report for project. Try editing the report.",
                           status_code=400)

    tags_collection = mongo_session.get_all_data("question_tags")['message']
    tags_dict = dict(map(lambda x: (x['tag'], x['_id']), tags_collection))
    new_tags = []
    tag_ids = []
    for t in tags:
        if t['_id'] and t['_id'] == t['tag']:
            if t['tag'] in tags_dict.keys():
                tag_ids.append(ObjectId(tags_dict[t['tag']]))
            else:
                new_tags.append(t['tag'])
        elif t['_id']:
            tag_ids.append(ObjectId(t['_id']))
    if new_tags:
        tag_ids.extend(insert_tags(new_tags))

    if not tag_ids:
        raise InvalidUsage("Please enter some tags for the report.", 400)
    tag_ids = list(set(tag_ids))

    team_id = ObjectId(team_id)
    project_id = ObjectId(project_id)

    # process code links
    code_links = validate_resource_array(code_links)
    # process webinar links
    webinar_links = validate_resource_array(webinar_links)
    # process resource links
    resource_links = validate_resource_array(resource_links)
    # process content
    content = replace_s3_links_with_keys(content)
    document = {
        'project': project_id,
        'team': team_id,
        'title': title,
        'content': content,
        'tags': tag_ids,
        'code_links': code_links,
        'webinar_links': webinar_links,
        'resource_links': resource_links,
    }

    res = mongo_session.insert_documnet(collection="passion_project_reports", doc_to_insert=document)
    report_insert_res = {
        'message': res['message'],
        '_id': str(res['_id'].inserted_id)
    }
    if res['status'] != 200:
        raise Exception("Unable to Create Report")
    return report_insert_res


def update_project_report(project_id, team_id, title, content, tags, code_links, webinar_links, resource_links,
                          user_id, report_id):
    """
    In this report of a passion project is updated with a
    specific project_id and team_id given.
    """
    if not title:
        raise InvalidUsage("Please add a title for the project report.", 400)
    report_data = mongo_session.check_existance_return_info(collection="passion_project_reports",
                                                            condition={"team": ObjectId(team_id),
                                                                       "project": ObjectId(project_id)})
    if report_data and str(report_data) != report_id:
        raise InvalidUsage("Only one submission is allowed in passion project.")
    team_data = mongo_session.get_all_data_for_particular_condition_fields(collection="passion_project_teams",
                                                                           condition={"_id": ObjectId(team_id)}
                                                                           )['message']
    if not team_data:
        raise InvalidUsage(message="following team does not exist", status_code=400)
    project_data = mongo_session.find_one_in_db(collection="passion_projects", condition={"_id": ObjectId(project_id)},
                                                columns=['_id'])
    if not project_data['message']:
        raise InvalidUsage(message="following project does not exist", status_code=400)

    if ObjectId(project_id) not in team_data[0]["projects"]:
        raise InvalidUsage("You don't have permission to submit reports in this project.", 403)

    team_members = team_data[0]['members']
    if ObjectId(user_id) not in team_members:
        raise InvalidUsage(message="Only team members are allowed to update reports", status_code=400)

    tags_collection = mongo_session.get_all_data("question_tags")['message']
    tags_dict = dict(map(lambda x: (x['tag'], x['_id']), tags_collection))
    new_tags = []
    tag_ids = []
    for t in tags:
        if t['_id'] and t['_id'] == t['tag']:
            if t['tag'] in tags_dict.keys():
                tag_ids.append(ObjectId(tags_dict[t['tag']]))
            else:
                new_tags.append(t['tag'])
        elif t['_id']:
            tag_ids.append(ObjectId(t['_id']))
    if new_tags:
        tag_ids.extend(insert_tags(new_tags))

    if not tag_ids:
        raise InvalidUsage("Please enter some tags for the report.", 400)
    tag_ids = list(set(tag_ids))

    team_id = ObjectId(team_id)
    project_id = ObjectId(project_id)

    content = replace_s3_links_with_keys(content)
    # code links
    db_code_links = mongo_session.check_existance_return_info(collection="passion_project_reports",
                                                              condition={
                                                                  "_id": ObjectId(report_id)},
                                                              columns={"code_links": 1},
                                                              return_keys=["code_links"])
    db_resources = db_code_links["code_links"] if db_code_links else []
    code_links = validate_resource_array(code_links, db_resources)

    # webinar_links
    db_webinar_links = mongo_session.check_existance_return_info(collection="passion_project_reports",
                                                                 condition={
                                                                     "_id": ObjectId(report_id)},
                                                                 columns={"webinar_links": 1},
                                                                 return_keys=["webinar_links"])
    db_resources = db_webinar_links["webinar_links"] if db_webinar_links else []
    webinar_links = validate_resource_array(webinar_links, db_resources)

    # resource_links
    db_resource_links = mongo_session.check_existance_return_info(collection="passion_project_reports",
                                                                  condition={
                                                                      "_id": ObjectId(report_id)},
                                                                  columns={"resource_links": 1},
                                                                  return_keys=["resource_links"])
    db_resources = db_resource_links["resource_links"] if db_resource_links else []
    resource_links = validate_resource_array(resource_links, db_resources)

    document = {
        'project': project_id,
        'team': team_id,
        'title': title,
        'content': content,
        'tags': tag_ids,
        'code_links': code_links,
        'webinar_links': webinar_links,
        'resource_links': resource_links,
    }
    res = mongo_session.update_multiple_fields(collection="passion_project_reports",
                                               condition={"_id": ObjectId(report_id)},
                                               set_columns=document)
    report_update_res = {
        'message': res['message']
    }
    if res['status'] != 200:
        raise Exception("Unable to Update Team")
    return report_update_res


def chat_room_data(condition, user_id):
    room_info = mongo_session.check_existance_return_info(collection='chat_rooms',
                                                          condition=condition,
                                                          whole_doc=True)
    if room_info:
        check_message_count = mongo_session.get_total_count(collection='messages',
                                                            condition={
                                                                'room_id': str(room_info['_id']),
                                                                "receiver_status":
                                                                    {"$elemMatch": {"$and": [
                                                                        {"_id": ObjectId(user_id)},
                                                                        {"status": False}
                                                                    ]}
                                                                    }})
        if check_message_count:
            room_info['total_unread_messages'] = check_message_count
        else:
            room_info['total_unread_messages'] = 0

        message_info = mongo_session.check_existance_return_info(collection='messages',
                                                                 condition={'room_id': str(room_info['_id'])},
                                                                 return_keys=['message', 'created_at',
                                                                              'sender_id', 'content'])
        if message_info:
            message_info['sender_id'] = str(message_info['sender_id'])
            date = message_info['created_at']
            message_info['created_at'] = convert_utc_to_ist(date).replace(tzinfo=None).isoformat(' ')
            room_info['messages'] = [message_info]
        else:
            room_info['messages'] = []

        room_members = []
        members = [ObjectId(member) for member in room_info['room_members']]
        room_members.extend(members)
        admins = [member['admin_id'] for member in room_info['admins'] if member['status'] == "active"]
        room_members.extend(admins)
        admins = [str(member['admin_id']) for member in room_info['admins'] if member['status'] == "active"]

        user_info = mongo_session.access_specific_fields(collection='user_profile',
                                                         condition={
                                                             "_id": {"$in": room_members}
                                                         },
                                                         return_keys=['_id', 'name', 'last_name', 'email', 'username',
                                                                      'profile_pic'])
        user_details = {}
        for user in user_info:
            user_details[str(user['_id'])] = user
            user['_id'] = str(user['_id'])
            user['user_id'] = user['_id']
            user['avatar_url'] = user['profile_pic']
            # print(user['profile_pic'])
            user['color'] = ""
            if user['avatar_url'] is None:
                user['avatar_url'] = ""
            del user['_id']

        room_info['_id'] = str(room_info['_id'])
        room_info['room_id'] = room_info['_id']
        del room_info['_id']
        room_info['created_by'] = str(room_info['created_by'])
        room_info['created_at'] = convert_utc_to_ist(room_info['created_at']).replace(tzinfo=None)
        if room_info.get('type'):
            admin_list = []
            for admin in room_info['admins']:
                admin['admin_id'] = str(admin['admin_id'])
                if admin['admin_id'] == user_id and admin['status'] == 'active':
                    room_info['current_user_admin'] = True
                else:
                    room_info['current_user_admin'] = False
                admin['added_by'] = str(admin['added_by'])
                if room_info['room_members']:
                    room_info['room_members'][admin['admin_id']] = {"status": admin['status']}
                else:
                    dict_1 = {admin['admin_id']: {"status": admin['status']}}
                    room_info['room_members'] = dict_1

        member_list = []
        for member in room_info['room_members']:
            if member in user_details:
                s3_url, status_code = s3_function.generate_presigned_url_from_s3(user_details[member]['profile_pic'])
                user_details[member]['avatar_url'] = s3_url
                if room_info['name'] == "" and not room_info.get('type'):
                    if member != user_id:
                        room_info['name'] = user_details[member]['username']
                        room_info['avatar_url'] = s3_url
                if room_info.get('type'):
                    if member in admins:
                        user_details[member]['is_admin'] = True
                    else:
                        user_details[member]['is_admin'] = False
                    if str(member) == str(user_id):
                        room_info['user_status'] = room_info['room_members'][member]['status']
                    user_details[member]['user_status'] = room_info['room_members'][member]['status']
                else:
                    if member == user_id:
                        room_info['user_status'] = "active"
                    user_details[member]['user_status'] = "active"
                d = {key: value for key, value in user_details[member].items() if key not in 'profile_pic'}
                if user_details[member].get('user_status'):
                    del user_details[member]['user_status']
                if user_details[member].get('is_admin'):
                    del user_details[member]['is_admin']
                member_list.append(d)
        room_info['room_members'] = member_list
        if room_info.get('group_photo'):
            room_info['avatar_url'], status = s3_function.generate_presigned_url_from_s3(
                room_info['group_photo']['avatar_url'])
            del room_info['group_photo']

        if room_info.get('group_description'):
            room_info['description'] = str(room_info['group_description']['description'])
            del room_info['group_description']

        if room_info.get('course_id'):
            room_info['course_id'] = str(room_info['course_id'])
        if room_info.get('passion_project_id'):
            room_info['passion_project_id'] = str(room_info['passion_project_id'])
        del room_info['admins']
        return room_info


def insert_passion_project(user_id, project_title, project_image, project_overview, project_tags, project_mentors, project_resources, project_goals, 
                project_details, publish):
    """
    In this a new passion_project is inserted
    """

    title = project_title
    image_key = project_image
    tags = project_tags
    project_mentors = project_mentors

    def validate_project_name():
        existing_project = mongo_session.find_one_in_db(collection="passion_projects",
                                                        condition={"project_title": title},
                                                        columns=["_id"])
        if existing_project['message']:
            raise InvalidUsage(message="Project with this name already exists", status_code=400)

    validate_project_name()

    def validate_tags(tags):
        tags_collection = mongo_session.get_all_data("question_tags")['message']
        tags_dict = dict(map(lambda x: (x['tag'], x['_id']), tags_collection))
        new_tags = []
        tag_ids = []
        for t in tags:
            if t['_id'] == t['tag']:
                if t['tag'] in tags_dict.keys():
                    tag_ids.append(ObjectId(tags_dict[t['tag']]))
                else:
                    new_tags.append(t['tag'])
            else:
                tag_ids.append(ObjectId(t['_id']))
        if new_tags:
            tag_ids.extend(insert_tags(new_tags))
        tag_ids = list(set(tag_ids)) if tag_ids else []
        return tag_ids

    instance_ids = []
    project_instance_ids = []
    for resource in project_resources:
        resource_id = resource['_id']
        # to support upload resource api, need to insert resource from temp_uploaded_files collection to global_resource_bank collection
        check_resource = mongo_session.check_existance_return_info(collection='global_resource_bank',
                                                                    condition={'_id': ObjectId(resource_id)},
                                                                    whole_doc=True)
        if not check_resource:
            insert_resource = mongo_session.insert_files_resource_bank(collection="global_resource_bank", 
                                                                        resource_id=ObjectId(resource_id),
                                                                        temp_collection="temp_uploaded_files")

        doc_to_insert = {
            "resource_id": ObjectId(resource_id),
            "tags": [],
            "description": "",
            "title": resource['title'],
            "module": "course",
            "used_at": "",
            "updated_at": utc_datetime_now(),
            "updated_by": ObjectId(user_id),
        }
        resp_id = mongo_session.insert_documnet(collection="resource_bank_instance", doc_to_insert=doc_to_insert)
        resource['instance_id'] = resp_id['_id'].inserted_id
        instance_ids.append(resource['instance_id'])
        project_instance_ids.append({'resource_id': ObjectId(resource_id),
                                        'instance_id': resource['instance_id']})

    document = {
        'project_title': title,
        'project_image': image_key,
        'project_tags': validate_tags(tags),
        'created_by': user_id,
        "project_mentors": project_mentors,
        "project_resources": project_instance_ids,
        "is_active": {
            "value": publish,
            "updated_by": user_id,
            "updated_at": datetime.now(timezone.utc)
        },
        "project_overview" : project_overview,
        "project_goals" : project_goals,
        "project_details" : project_details
    }
    res = mongo_session.insert_documnet(collection="passion_projects", doc_to_insert=document)
    project_insert_res = {
        'message': res['message'],
        '_id': str(res['_id'].inserted_id)
    }
    used_at = {"$set": {"used_at": {'passion_project_id': ObjectId(res['_id'].inserted_id)}}}
    condition = {"_id": {"$in": instance_ids}}
    updation = mongo_session.update_db_data(collection='resource_bank_instance', condition=condition,
                                            update_info=used_at, multi=True)
    status = res['status']
    if status != 200:
        raise Exception("We ran into a problem. Could not insert into database")

    project_insert_res = {
        'message': "Project added successfully!",
        '_id': str(res['_id'].inserted_id)
    }
    return project_insert_res


def view_project(user_id, organisation, role, project_id):
    """
    In this function, fetching detail of passion project on the basis of project id.
    """
    user = user_id
    try:
        res = mongo_session.get_all_data_for_particular_condition_fields(collection='passion_projects',
                                                                         condition={'_id': ObjectId(project_id)})

        tags_collection = mongo_session.get_all_data("question_tags")['message']
        tags_dict = dict(map(lambda x: (x['_id'], x['tag']), tags_collection))
        project_data = res['message'][0]
        project_detail = {"_id": str(project_data["_id"])}
        tags = project_data.get('project_tags', [])

        m_project_tags = []
        for t in tags:
            try:
                m_project_tags.append({'tag': tags_dict[str(t)], "_id": str(t)})
            except KeyError:
                continue

        project_detail['project_tags'] = m_project_tags
        project_detail['project_title'] = project_data['project_title']

        if project_data.get("project_overview"):
            project_overview = {"description": project_data["project_overview"]["description"],
                                "path": s3_function.generate_presigned_url_from_s3(project_data["project_overview"]
                                                                                   ["path"])[0]}
        else:
            project_overview = {"details": project_data["project_description"],
                                "path": ""}
        project_detail['project_overview'] = project_overview
        project_detail['project_goals'] = project_data.get("project_goals", [])

        project_details_list = []
        if project_data.get("project_details"):
            for p_detail in project_data["project_details"]:
                project_details_list.append({"title": p_detail["title"],
                                             "details": p_detail["details"],
                                             "path": s3_function.generate_presigned_url_from_s3(p_detail["path"])[0]})
        project_detail['project_details'] = project_details_list

        res_data = fetch.check_existance_return_info(collection="chat_rooms",
                                                     condition={"passion_project_id": ObjectId(str(project_data["_id"])),
                                                                "created_by": ObjectId(user), "mentor_chat": True})
        if res_data:
            project_detail["mentor_chat"] = {"room_status": True,
                                             "chat_room": chat_room_data({"_id": ObjectId(res_data)}, ObjectId(user))}
        else:
            project_detail["mentor_chat"] = {"room_status": False, "chat_room": None}
        project_detail['project_image'] = s3_function.generate_presigned_url_from_s3(project_data['project_image'])[0]
        user_id = project_data['created_by']
        user_profile = mongo_session.get_all_data_for_particular_condition_fields(collection="user_profile",
                                                                                  condition={
                                                                                      "_id": ObjectId(user_id)}
                                                                                  )['message'][0]
        first_name = user_profile['name']
        last_name = user_profile['last_name']
        project_detail['created_by'] = {"name": first_name + " " + last_name,
                                        "_id": str(user_id)}
        if role == 'super_admin':
            edit_rights = True
        elif organisation.lower() == user_profile['organisation'].lower() and role == 'teacher':
            edit_rights = True
        else:
            edit_rights = False

        project_mentors_list = []
        for mentor_id in project_data.get("project_mentors", []):
            condition = {"_id": mentor_id}
            columns = {"_id": 1, "name": 1, "last_name": 1, "username": 1, "profile_pic": 1}
            column_request_response_key_mapping = {
                "_id": "id",
                "name": "first_name",
                "last_name": "last_name",
                "username": "user_name",
                "profile_pic": "profile_pic"
            }
            mentor_data_res = mongo_session.get_data_for_particular_columns_with_condition(
                collection='user_profile',
                condition=condition,
                columns=columns, column_request_response_key_mapping=column_request_response_key_mapping)

            project_mentors_list.extend(mentor_data_res["message"])

        project_detail["project_mentors"] = project_mentors_list

        project_resources_list = []
        for resource_id in project_data.get("project_resources", []):
            if type(resource_id) == dict:
                condition = {"resource_id": resource_id['resource_id'], '_id': resource_id['instance_id']}
                resource_data = mongo_session.check_existance_return_info(collection='resource_bank_instance',
                                                                          condition=condition,
                                                                          whole_doc=True)
                resource_s3_key = mongo_session.check_existance_return_info(collection='global_resource_bank',
                                                                            condition={
                                                                                '_id': ObjectId(
                                                                                    resource_id['resource_id'])
                                                                            },
                                                                            return_keys=['s3_key'])
                if resource_s3_key:
                    s3url = s3_function.generate_presigned_url_from_s3(resource_s3_key["s3_key"])[0]
                else:
                    s3url = ""
                project_resources_list.append({
                    '_id': str(resource_id['resource_id']),
                    "title": resource_data['title'],
                    "url": s3url,
                    "resource_type": "file"
                })

            else:
                condition = {"_id": resource_id}
                columns = {"_id": 1, "file_type": 1, "title": 1, "s3_key": 1, "type": 1, "url": 1}
                column_request_response_key_mapping = {
                    "_id": "id",
                    "file_type": "type",
                    "title": "title",
                    "s3_key": "s3url",
                    "url": "url",
                    "type": "resource_type"
                }
                resource_data_res = mongo_session.get_data_for_particular_columns_with_condition(
                    collection='resources',
                    condition=condition,
                    columns=columns,
                    column_request_response_key_mapping=column_request_response_key_mapping)

                if resource_data_res["status"] == 200:
                    for resource in resource_data_res["message"]:
                        if resource["type"] != "text":
                            resource["s3url"] = s3_function.generate_presigned_url_from_s3(resource["s3url"])[0]
                    project_resources_list.extend(resource_data_res["message"])

            project_detail["project_resources"] = project_resources_list
            project_detail["edit_rights"] = edit_rights

        projects_name_res = {"projects": project_detail,
                             "message": "success"
                             }
        status = res['status']
    except Exception as e:
        traceback.print_exc()
        projects_name_res = {"message": "error in fetching data", "projects": []}
        status = 400
    return projects_name_res, status


# method to get top project
def discover_project():
    """
    Retrieve top project based on number student in projects for Edu-Collab.
    """
    best_project = []
    project_data = mongo_session.get_all_data(collection='passion_projects')["message"]
    for data in project_data:
        team_members = 0
        project_detail = {"_id": str(data['_id']), 'project_image': s3_function.generate_presigned_url_from_s3(data['project_image'])[0]}
        user_id = data['created_by']
        user_profile = mongo_session.get_all_data_for_particular_condition_fields(collection="user_profile",
                                                                                  condition={
                                                                                      "_id": ObjectId(user_id)}
                                                                                  )['message'][0]
        project_detail['created_by'] = user_profile['name'] + " " + user_profile['last_name']
        project_detail['project_title'] = data['project_title']

        project_team_data = mongo_session.get_all_data_for_particular_condition_fields(
            collection='passion_project_teams',
            condition={'projects': {'$elemMatch': {"$eq": ObjectId(data['_id'])}}})['message']
        if project_team_data:
            for project_team in project_team_data:
                team_members = team_members + len(project_team['members'])
        project_detail['members'] = team_members
        best_project.append(project_detail)
    output = sorted(best_project, key=lambda d: (d['members']), reverse=True)
    return output[:9], 200
