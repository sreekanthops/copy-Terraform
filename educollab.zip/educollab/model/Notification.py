import config
from db_wrapper.tasks import Mongo
mongo_session=Mongo()

from pyfcm import FCMNotification
from bson import ObjectId



def check_app_version_function(appVersion):
    try:
        if appVersion != "null" and appVersion!="":
            condition_one = {"appVersion":{"$gt":int(appVersion)},"backward_compatible":False}
            condition_two = {"appVersion":{"$gt":int(appVersion)},"backward_compatible":True}
            condition_three = {"appVersion":int(appVersion)}
            condition = {"appVersion":{"$gt":int(appVersion)}}
            query_response = mongo_session.check_app_version(collection="app_version_bank",condition_one=condition_one,condition_two = condition_two,condition_three=condition_three,condition=condition)
            if query_response['query_status'] == 200:
                doc = query_response['message']
                return {"status": query_response['status'],"launchUrl": doc['launchUrl'],"appVersion":int(doc['appVersion'])},200
            else:
                return {"status": "error while communicating with db", "launchUrl": "","appVersion":""}, 400
        else:
            return {"status": "app version should not be null", "launchUrl": "","appVersion":""}, 400
    except Exception as e:
        print(e)
        return {"status": e,"launchUrl": "","appVersion":""},400

def store_user_device_token(user_id,deviceToken,jwt_expiry_time):
    try:
        if deviceToken != "null" and deviceToken!="":
            updated_response = mongo_session.store_user_device_token_task(user_id=user_id,deviceToken=deviceToken,collection= "user_profile",jwt_expiry_time=jwt_expiry_time)
            if updated_response['status'] ==200:
                status_code = 200
                return {"status": 'Success'},status_code
            else:
                status_code = 400
                return {"status":"Failed"},status_code
        else:
            return {"status": "Device token should not be empty"}, 400
    except Exception as e:
        print(e)
        status_code = 400
        return {"status":e},status_code

def notify_inquisitive_answer_question(user_id,device_tokens,question_id):
    try:
        if user_id != "null" and user_id!="" and len(device_tokens)>0 :
            print('user_id',user_id)
            push_service = FCMNotification(api_key=config.firebase_api_key)

            valid_registration_ids = push_service.clean_registration_ids(device_tokens)

            extra_ids = [id for id in device_tokens if id not in valid_registration_ids]
            print('difference ', extra_ids)

            remove_id_db = mongo_session.delete_device_ids_answer_question(collection="user_profile",condition={"_id":user_id},id_list=extra_ids)
            print('removed id',remove_id_db)

            registration_ids = [id for id in device_tokens if id not in extra_ids]
            print('registered id', registration_ids)
            message_title = "Answer Added"
            message_body = " Someone just submitted an answer to your question!"
            data_message = {
                "question_id":question_id,
                "click_action": "FLUTTER_NOTIFICATION_CLICK",
                "module_name": "AnswerSubmit"
            }
            result = push_service.notify_multiple_devices(registration_ids=registration_ids,
                                                          message_title=message_title, message_body=message_body,data_message= data_message)
            
            print('notify ', result)
            return {"message": "sent notification to user", "status": 200,'notification_status': result}
        else:
            return {"message":"something went wrong while sending notification to user","status":400,'notification_status':"Error"}
    except Exception as e:
        print(e)
        return {"message":e,"status":400,'notification_status':"Error"}

def notify_multiple_users(user_id_list,device_tokens,data_message,message_title,message_body):
    try:
        if user_id_list != "null" and user_id_list!="" and len(device_tokens)>0 :
            print('user_id',user_id_list)
            push_service = FCMNotification(api_key=config.firebase_api_key)

            valid_registration_ids = push_service.clean_registration_ids(device_tokens)

            extra_ids = [id for id in device_tokens if id not in valid_registration_ids]
            print('difference ', extra_ids)

            remove_id_db = mongo_session.delete_device_ids_answer_question(collection="user_profile",condition={"_id":{"$in":user_id_list}},id_list=extra_ids)
            print('removed id',remove_id_db)

            registration_ids = [id for id in device_tokens if id not in extra_ids]
            print('registered id', registration_ids)

            result = push_service.notify_multiple_devices(registration_ids=registration_ids,
                                                          message_title=message_title, message_body=message_body,data_message= data_message)
            
            print('notify ', result)
            return {"message": "sent notification to user", "status": 200,'notification_status': result}
        else:
            return {"message":"something went wrong while sending notification to user","status":400,'notification_status':"Error"}
    except Exception as e:
        print(e)
        return {"message":e,"status":400,'notification_status':"Error"}