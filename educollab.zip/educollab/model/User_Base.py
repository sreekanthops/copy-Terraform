import config
from model import User as u

class User_Base(object):

    def __init__(self):
        self.load(config.USER_BASE_PATH)

    def load(self,pathname):
        self.my_users=[]
        with open(pathname,"r") as fp:
            for line in fp:
                self.my_users.append(u.User(line))

    def get_user(self,name):
        for user in self.my_users:
            if user.user_name == name:
                return user

from services.common import io

# from services import Embedding as e
#
ub = User_Base()
d = ub.get_user('Darves')
print(d.__dict__)
print(io.MyJSONEncoder().encode(d.__dict__))

# from services.common.io import jsonize
# print (jsonize(d.__dict__))