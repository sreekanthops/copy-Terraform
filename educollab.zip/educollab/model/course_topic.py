import json
from bson import ObjectId
import datetime
from routes.exception import InvalidUsage
from services.storage.s3_services import s3_storage

s3_function = s3_storage()

from db_wrapper.tasks import Mongo

mongo_session = Mongo()


def fetch_course_zoom_recordings(user_id, course_id, role):
    """To fetch the zoom recordings of the lectures conducted on a particular course
    :param user_id: user accessing the recordings.
    :type user_id: str (mongo ObjectId)
    :param course_id: course for which recordings are required
    :type course_id: str (mongo ObjectID)
    :param role: role of the user
    :type role: str (slug)
    :returns list of recordings information"""
    # validate the users only users with publish rights and super_admin can access it
    course_data = mongo_session.check_existance_return_info(
        collection="courses_bank",
        condition={"_id": ObjectId(course_id)},
        columns={"active": 1,
                 "editors": 1,
                 "instructors": 1,
                 "created_by": 1,
                 "live_sessions": 1},
        return_keys=["_id",
                     "active",
                     "editors",
                     "instructors",
                     "created_by",
                     "live_sessions"])
    if not course_data:
        raise InvalidUsage("Bad Request", 400)

    if not course_data['active']:
        raise InvalidUsage("Oops, course is not active anymore.", 400)

    publish_rights = [str(user['_id']) for user in course_data["editors"]] + \
                     [str(user['_id']) for user in course_data["instructors"]] + \
                     [str(course_data["created_by"])]
    if not role == "super_admin" and user_id not in publish_rights:
        raise InvalidUsage("You don't have permission to edit courses.", 403)

    response_data = []
    total_meetings = []
    for data in course_data["live_sessions"]:
        if data.get("meeting_details"):
            # calculate time of the live sessions, we only need the past ones
            start_time_str = "{year}:{month}:{day}".format(year=data['start_date']['year'],
                                                           month=data['start_date']['month'],
                                                           day=data['start_date']['day'])
            start_date = datetime.datetime.strptime(start_time_str, "%Y:%m:%d")
            if start_date > datetime.datetime.now():
                continue
            total_meetings.append(data["meeting_details"]["meeting_id"])

    meetings_info = mongo_session.access_specific_fields(
        collection="zoom_meetings",
        condition={"meeting_id": {"$in": total_meetings}},
        columns={"meeting_id": 1,
                 "total_recordings": 1},
        return_keys=["meeting_id", "total_recordings"])

    if not meetings_info:
        return response_data

    for meeting in meetings_info:
        if meeting["total_recordings"]:
            for recording in meeting["total_recordings"]:
                if not recording.get("recording_s3_key") or recording.get("is_used"):
                    continue
                url, status = s3_function.generate_presigned_url_from_s3(s3_key=recording["recording_s3_key"])
                response_data.append(
                    {"meeting_id": meeting["meeting_id"],
                     "s3_path": recording["recording_s3_key"],
                     "url": url,
                     "uuid": recording["uuid"],
                     "start_time": recording.get("start_time", "")})
    return response_data


def process_course_session_details(session):
    """Purpose: To upload a session which is a part of a topic in the course into db under course_sessions.
     It involves
                1. Zoom recorded videos attached to that particular session.
                2. Empty resources, assessments as of now.

     session: it contains all the information related to zoom video recording.
    """
    if session['key'] == "session":
        video_existence = s3_function._key_existing_size__list(session["url"])
        if not video_existence:
            raise InvalidUsage("Recording does not exist anymore.", 400)
        # check s3 path existence in database
        return {"title": session["title"],
                "description": session["description"],
                "key": "session",
                "url": session["url"],
                "file_id": "",
                "type": "",
                "assessments": [],
                "resources": [],
                "status": "zoom_recorded"}
    else:
        raise InvalidUsage("Please select the recording again and try creating session again.", 400)


def add_zoom_record_as_sessions(user_id, course_id, role, course_topics):
    """To add the zoom recordings of the lectures conducted on a particular course
    as new sessions in new or old topics.
    :param user_id: user adding the recordings as sessions.
    :type user_id: str (mongo ObjectId)
    :param course_id: course on which to save recordings as sessions
    :type course_id: str (mongo ObjectID)
    :param role: role of the user
    :type role: str (slug)
    :param course_topics: new or old topics containing new sessions
    :type course_topics: list
    :returns updated course information"""
    # validate the users only users with publish rights and super_admin can add it
    course_data = mongo_session.check_existance_return_info(
        collection="courses_bank",
        condition={"_id": ObjectId(course_id)},
        columns={"active": 1,
                 "editors": 1,
                 "instructors": 1,
                 "created_by": 1,
                 "topics": 1},
        return_keys=["_id",
                     "active",
                     "editors",
                     "instructors",
                     "created_by",
                     "topics"])
    if not course_data:
        raise InvalidUsage("Bad Request", 400)

    if not course_data['active']:
        raise InvalidUsage("Oops, course is not active anymore.", 400)

    publish_rights = [str(user['_id']) for user in course_data["editors"]] + \
                     [str(user['_id']) for user in course_data["instructors"]] + \
                     [str(course_data["created_by"])]
    if not role == "super_admin" and user_id not in publish_rights:
        raise InvalidUsage("You don't have permission to edit courses.", 403)

    for data in course_topics:
        new_sessions = []
        if data["_id"]:
            # Old Topic
            for session in data["sessions"]:
                new_sessions.append(process_course_session_details(session))
            # create sessions
            inserted_sessions = mongo_session.insert_docs_to_db(
                collection="course_sessions",
                docs=new_sessions)
            if inserted_sessions:
                # update topic
                inserted_sessions = [{"_id": ObjectId(sess)} for sess in inserted_sessions.inserted_ids]
                mongo_session.update_db_data(collection="course_topics",
                                             condition={"_id": ObjectId(data["_id"])},
                                             update_info={"$push": {"sessions": {"$each":inserted_sessions}}})
        else:
            # New Topic
            for session in data["sessions"]:
                new_sessions.append(process_course_session_details(session))
            # create sessions
            inserted_sessions = mongo_session.insert_docs_to_db(
                collection="course_sessions",
                docs=new_sessions)
            if inserted_sessions:
                # update topic
                inserted_sessions = [{"_id": ObjectId(sess)} for sess in inserted_sessions.inserted_ids]
                new_topic = {"title": data['title'],
                             "description": data['description'],
                             "sessions": inserted_sessions,
                             "resources": [],
                             "course_work": [],
                             "assessments": []}
                response = mongo_session.insert_docs_to_db(collection="course_topics",
                                                docs=[new_topic])
                topic_ids = []
                for topic_id in response.inserted_ids:
                    insert = {"_id": topic_id}
                    topic_ids.append(insert)
                mongo_session.update_db_data(collection="courses_bank",
                                             condition={"_id": course_data['_id']},
                                             update_info={"$push": {"topics": {"$each": topic_ids}}})
    # fetch view course info and show it.
    return "Success"
