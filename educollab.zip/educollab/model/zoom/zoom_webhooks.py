import time
from model.zoom import Zoom
from routes.exception import InvalidUsage
from services.storage.s3_services import s3_storage

s3_function = s3_storage()
from db_wrapper.tasks import Mongo

mongo_session = Mongo()
from new_celery import celery_app

def add_joined_participant(account_id, other_details):
    meeting_id = other_details["id"]
    db_meeting_details = mongo_session.check_existance_return_info(
        collection="zoom_meetings",
        condition={"meeting_id": int(meeting_id)})
    if not db_meeting_details:
        raise Exception("There is no meeting with the given meeting id in our records.")

    check_previous_participants = mongo_session.check_existance_return_info(
        collection="zoom_participants",
        condition={"meeting_id": int(meeting_id),
                   "uuid": other_details["uuid"]})

    if not check_previous_participants:
        # add the attendance in DataBase
        add_doc = mongo_session.insert_docs_to_db(
            collection="zoom_participants",
            docs=[{"meeting_id": int(meeting_id),
                   "uuid": other_details["uuid"],
                   "account_id_host": account_id,
                   "start_time": other_details["start_time"],
                   "participants": [other_details["participant"]]}])
    else:
        # add the attendance in DataBase along with meeting details
        update_doc = mongo_session.update_db_data(
            collection="zoom_participants",
            condition={"meeting_id": int(meeting_id),
                       "uuid": other_details["uuid"]},
            update_info={"$push": {"participants": other_details["participant"]}})

    return {"message": "Participant detail recorded.",
            "response": {"meeting_id": meeting_id}}


def process_zoom_meeting(meeting_id, uuid, response, module_name):
    """To upload recording of zoom meeting fetched from cloud to s3 and store details into database.
    :param meeting_id: meeting id for the zoom.
    :type meeting_id: int
    :param uuid: uuid for meeting.
    :type uuid: str.
    :param response: data got from the webhook.
    :type response: dict.
    :param module_name: module name for which file is being uploaded.
    :type module_name: str."""
    print("response", response)
    db_meeting_details = mongo_session.check_existance_return_info(collection="zoom_meetings",
                                                                   condition={"meeting_id": meeting_id},
                                                                   whole_doc=True)
    if not db_meeting_details:
        raise Exception("There is no meeting with the given meeting id in our records.")

    all_recorded_files = response["payload"]["object"]["recording_files"]
    recorded_mp4_download_url = [recording["download_url"] for recording in all_recorded_files if
                                 recording["file_type"] == "MP4"]

    recorded_mp4_download_url = recorded_mp4_download_url[0] if recorded_mp4_download_url else ""
    print("download urllllllll", recorded_mp4_download_url)
    filename = "zoom-{added_time}-{meeting_id}.mp4".format(added_time=str(int(time.time())),
                                                           meeting_id=str(meeting_id))
    zoom_app = Zoom(jwt_api_key=db_meeting_details["zoom_account"]["api_key"],
                    jwt_secret_key=db_meeting_details["zoom_account"]["secret_key"],
                    zoom_email=db_meeting_details["zoom_account"]["email"])

    zoom_jwt_token = zoom_app.generate_jwt_token()
    print("tokencvvvvcddd", zoom_jwt_token)
    recording_s3_key = module_name + "/" + str(int(time.time())) + '-' + str(meeting_id) + ".mp4"
    print("entering celery task")
    db_occurrences = db_meeting_details["occurrences"]
    # remove object id
    for occurrence in db_occurrences:
        if occurrence.get("course_id"):
            occurrence["course_id"] = str(occurrence["course_id"])
        if occurrence.get("topic_id"):
            occurrence["topic_id"] = str(occurrence["topic_id"])
        if occurrence.get("session_id"):
            occurrence["session_id"] = str(occurrence["session_id"])

    celery_args = [zoom_jwt_token.decode('utf-8'), recorded_mp4_download_url, recording_s3_key, db_occurrences, meeting_id, uuid, response["payload"]["object"]["start_time"], filename]
    rec_status = celery_app.send_task("zoom_multipart_upload_s3", args=celery_args)
    print("task_id", rec_status)
    if not rec_status:
        raise InvalidUsage("Something went wrong while uploading resource", 500)
    return {"message": "File is getting uploaded.",
            "task_id": str(rec_status),
            "response": "Success"}


def add_uuid_to_occurrence_id(meeting_id, uuid, event):
    db_meeting_details = mongo_session.check_existance_return_info(
        collection="zoom_meetings",
        condition={"meeting_id": meeting_id},
        whole_doc=True)
    if not db_meeting_details:
        raise Exception("There is no meeting with the given meeting id in our records.")
    db_occurrences = db_meeting_details["occurrences"]

    # fetch attendance if present from zoom participants collection
    participants = mongo_session.check_existance_return_info(collection="zoom_participants",
                                                             condition={"meeting_id": meeting_id,
                                                                        "uuid": uuid},
                                                             whole_doc=True)
    participants = participants["participants"] if participants else []

    # to attach the newly generated uuid with the last occurrence used by the recurring meeting
    occurrence_id = ""
    for instance in db_occurrences:
        if instance.get("uuid") and instance["uuid"] == uuid:
            instance["participants"] = participants
            occurrence_id = instance["occurrence_id"]
            break
        if not instance.get("uuid"):
            instance["uuid"] = uuid
            instance["participants"] = participants
            occurrence_id = instance["occurrence_id"]
            break
    uuid_detail = {"uuid": uuid,
                   "occurrence_id": occurrence_id,
                   "start_time": event["payload"]["object"]["start_time"]}
    update_meeting = mongo_session.update_db_data(collection="zoom_meetings",
                                                  condition={"meeting_id": int(meeting_id)},
                                                  update_info={"$set": {"occurrences": db_occurrences},
                                                               "$push": {"total_meetings": uuid_detail}})
    return {"message": "Meeting Ended successfully"}


# def download_zoom_rec_upload_s3(jwt_token: bytes, download_url, s3_key, filename=None):
#     """
#        read and upload to s3 using multipart upload
#
#        Call requests.get(url, stream) to download a file from url
#        and set stream to True to allow iter_content on the Response object to iterate the data
#        while maintaining an open connection.
#        Use Response.iter_content(chunk_size) to load a fixed chunk_size in bytes each time
#        while iter_content is iterated."""
#
#     URL = f"{download_url}/?access_token={jwt_token.decode('utf-8')}"
#     response = requests.get(URL,
#                             stream=True,
#                             headers={"Authorization":
#                                          f"Bearer {jwt_token.decode('utf-8')}"})
#
#     response.raise_for_status()
#     # chunk size in bytes--kb---mb  for now keep 5 mb
#     print(" file size", response.headers['Content-length'])
#
#     # if file size is smaller than the said limit use single upload operation
#     if int(response.headers['Content-length']) > 1024 * 1024 * 6:
#         mpu_id = s3_function.create_multipart_upload_id(s3_key)
#         parts = []
#         part_index = 1
#         uploaded_bytes = 0
#
#         for chunk in response.iter_content(chunk_size=1024 * 1024 * 5):
#             # chunk size 5mb for now
#             # filter out keep-alive new chunks
#             if chunk:
#                 uploaded_part = s3_function.upload_chunk(chunk, mpu_id, s3_key, part_index)
#                 if uploaded_part:
#                     parts.append(uploaded_part)
#
#                     uploaded_bytes += len(chunk)
#                     print("each chunk size", uploaded_bytes)
#                     part_index += 1
#         status = s3_function.complete_multipart_upload(mpu_id, parts, s3_key)
#         print("result", status)
#     else:
#         with open(filename, 'wb') as recorded_local_file:
#             recorded_local_file.write(response.content)
#             recorded_local_file.close()
#         # use only one go to upload file to s3
#         s3_res = s3_function.upload_data_to_s3_private(file=filename,
#                                                        Content_Type="video/mp4",
#                                                        s3_key=s3_key)
#         status = True if s3_res["status"] == 200 else False
#     return status
