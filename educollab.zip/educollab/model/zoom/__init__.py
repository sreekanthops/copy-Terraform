import json
import secrets
import time
import requests
from authlib.jose import jwt
from requests import Response
from config import ZOOM_JWT_TOKEN_EXP
import http.client
import random


class Zoom:
    def __init__(self, jwt_api_key, jwt_secret_key, zoom_email):
        self.api_key = jwt_api_key
        self.api_secret = jwt_secret_key
        self.userId = zoom_email
        self.base_url = "https://api.zoom.us/v2/"
        self.create_url = f"{self.base_url}/users/{self.userId}/meetings"
        self.jwt_token_exp = ZOOM_JWT_TOKEN_EXP
        self.jwt_token_algo = "HS256"

    def validate_api_secret_key(self, jwt_token: bytes, app_email):
        """
        To validate the api and secret key for jwt tokens a user is entering.
        """
        headers = {
            'authorization': f"Bearer {jwt_token.decode('utf-8')}",
            'content-type': "application/json"
        }
        # this will list the current users using the zoom account
        Response = requests.get(url=self.base_url + "users?status=active&page_size=30&page_number=1",
                                headers=headers)
        is_valid = True if Response.status_code == 200 else False
        if is_valid:
            accounts_linked = json.loads(Response.content)["users"]
            if app_email not in [user["email"] for user in accounts_linked]:
                is_valid = False
        return is_valid

    def get_particular_meeting(self, jwt_token: bytes, meetingId) -> Response:
        """function to get the meeting's details"""
        showOccur = False

        URL = f"{self.base_url}/meetings/{meetingId}"

        body: dict = {
            "show_previous_occurrences": showOccur,
        }

        r: Response = requests.get(URL,
                                   headers={"Authorization":
                                                f"Bearer {jwt_token.decode('utf-8')}"},
                                   json=body)
        return r

    def generate_jwt_token(self) -> bytes:
        """function to generate zoom jwt tokens"""
        iat = int(time.time())

        jwt_payload: dict = {"aud": None,
                             "iss": self.api_key,
                             "exp": iat + self.jwt_token_exp,
                             "iat": iat
                             }

        head: dict = {"alg": self.jwt_token_algo}

        jwt_token: bytes = jwt.encode(head, jwt_payload, self.api_secret)

        return jwt_token

    def create_meeting(self, jwt_token: bytes, topic, agenda, type, start_time, duration, recurrence_type, end_times,
                       week_day, waiting_room, password=None) -> Response:
        """
        function to create meetings
        ----------------------------------------------------
        start_url: URL to start the meeting, should only be used by the host of the meeting and
                   anyone with this URL will be able to login to the Zoom Client as the host of the meeting."
        -----------------------------------------------------
        join_url: URL for participants to join the meeting, should only be shared with users that you would like
                  to invite for the meeting.
        """
        body = {"topic": topic,
                "type": type,
                "start_time": start_time,
                "duration": duration,
                "timezone": "Asia/Kolkata",
                "agenda": agenda,
                "settings": {"host_video": False,
                             "participant_video": False,
                             "cn_meeting": False,
                             "in_meeting": True,
                             "join_before_host": False,
                             "waiting_room": waiting_room,  # could be true or false
                             "mute_upon_entry": True,
                             "auto_recording": "cloud",
                             "allow_multiple_devices": True,
                             "approval_type": 0,
                             "registration_type": 1,
                             "registrants_email_notification": False
                             }
                }
        if password:
            body["password"] = password
        if recurrence_type:
            if recurrence_type == 2:

                recurrence = {"recurrence": {"type": recurrence_type,
                                             "weekly_days": week_day,
                                             "end_times": end_times}
                              }
                body.update(recurrence)

            elif recurrence_type == 1:
                recurrence = {"recurrence": {"type": recurrence_type,
                                             "end_times": end_times}
                              }
                body.update(recurrence)

        r: Response = requests.post(self.create_url,
                                    headers={"Authorization":
                                                 f"Bearer {jwt_token.decode('utf-8')}"},
                                    json=body)

        return r

    def get_meeting_list_host(self, jwt_token: bytes, user_id):
        """To list all the meetings of the host for particular date"""
        URL = f"{self.base_url}/users/{user_id}/meetings?type=upcoming"
        body: dict = {
            "start_time": True,
        }
        r: Response = requests.get(URL,
                                   headers={"Authorization":
                                                f"Bearer {jwt_token.decode('utf-8')}"},
                                   json=body)
        return r

    def delete_meeting(self, jwt_token: bytes, meetingID, occurID=None) -> Response:
        """function to delete meeting"""
        reminder = False

        URL = f"{self.base_url}/meetings/{meetingID}"

        body: dict = {
            "schedule_for_reminder": reminder,
        }
        if occurID:
            body["occurrence_id"] = occurID

        r: Response = requests.delete(URL,
                                      headers={"Authorization":
                                                   f"Bearer {jwt_token.decode('utf-8')}"},
                                      json=body)
        return r

    def get_participants_info_in_detail(self, jwt_token: bytes, meetingID) -> Response:
        """function to get the list of participants"""
        URL = f"{self.base_url}/metrics/meetings/{meetingID}/participants"

        r: Response = requests.get(URL,
                                   headers={"Authorization":
                                                f"Bearer {jwt_token.decode('utf-8')}"})
        return r

    def download_cloud_recording(self, jwt_token: bytes, download_url):
        URL = f"{download_url}/?access_token={jwt_token.decode('utf-8')}"
        r: Response = requests.get(URL,
                                   headers={"Authorization":
                                                f"Bearer {jwt_token.decode('utf-8')}"})
        return r

    def register_participants(self, email, username, jwt_token: bytes, meetingID) -> Response:
        URL = f"{self.base_url}/meetings/{meetingID}/registrants"
        body = {"email": email,
                "first_name": username,
                "last_name": ""}
        r: Response = requests.post(URL,
                                    headers={"Authorization":
                                                 f"Bearer {jwt_token.decode('utf-8')}"},
                                    json=body)
        return r
