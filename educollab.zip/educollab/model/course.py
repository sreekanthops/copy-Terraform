import ast
import datetime
import json
import re
import string
import time
import copy
from config import es, ES_GLOBAL_SEARCH_COURSE, EDUCOLLAB_ENVIRONMENT

from db_wrapper.tasks import Mongo
from model import Notification
from model.team.team_creation import notify_team
from routes.exception import InvalidUsage
from utils.elasticsearch.resource_bank import insert_resource_elastic
from model.courses.misc import upload_course_topic, update_schedule_course_work, schedule_course_work, \
    manage_course_s3_resources

mongo_session = Mongo()

from services.storage.s3_services import s3_storage
import model.Question as Question

s3_function = s3_storage()

import config

from bson import ObjectId
import model.Content as Content
from utils.time_conversions import utc_datetime_now, str_to_utc_datetime_obj, \
    convert_utc_to_ist

from utils.misc import validate_ObjectId, get_profile_pic, extract_s3_keys_from_html_str, replace_s3_links_with_keys, \
    renew_s3_links
import random
from model.zoom import Zoom
from model.chat_func import update_course_groupchat

from model.User import User_Profile
from model.courses import refactored_resources, refactored_sessions, refactored_topics, refactored_courseworks, \
    refactored_assessments

def process_live_session(live_sessions, user_id, subject, learning_objectives, db_live_sessions=None,
                         subscribers=None):
    """
    --------------------
    start_url expires, so in get api always generate a new url for meeting using meeting id and uuid
       """
    db_auto_sessions = {}
    # prepare a dict for existing auto generated live sessions in db
    if db_live_sessions:
        for sess in db_live_sessions:
            if sess.get("meeting_details"):
                key = str(sess["meeting_details"]["meeting_id"]) + "_" + str(sess["meeting_details"]["uuid"])
                db_auto_sessions[key] = sess
    for session in live_sessions:
        # process existing live sessions
        if session.get("meeting_details"):
            # get zoom details from db
            existance_key = str(session["meeting_details"]["meeting_id"]) + "_" + str(
                session["meeting_details"]["uuid"])
            if db_auto_sessions.get(existance_key):
                session["zoom_account"] = db_auto_sessions[existance_key]["zoom_account"]
                session["password"] = db_auto_sessions[existance_key].get("password", "")
                try:
                    session["waiting_room"] = db_auto_sessions[existance_key]["waiting_room"]
                except:
                    session["waiting_room"] = True
                del db_auto_sessions[existance_key]

        if session["url"] == "" and session["zoom_account"] and session["zoom_account"]["email"]:
            # create zoom object to perform various zoom operations
            zoom_app = Zoom(jwt_api_key=session["zoom_account"]["api_key"],
                            jwt_secret_key=session["zoom_account"]["secret_key"],
                            zoom_email=session["zoom_account"]["email"])
            zoom_jwt_token = zoom_app.generate_jwt_token()

            # calculate start date and end date for the live session
            start_time_str = "{year}:{month}:{day}".format(year=session['start_date']['year'],
                                                           month=session['start_date']['month'],
                                                           day=session['start_date']['day'])
            start_date = datetime.datetime.strptime(start_time_str, "%Y:%m:%d").date()

            end_time_str = "{year}:{month}:{day}".format(year=session['end_date']['year'],
                                                         month=session['end_date']['month'],
                                                         day=session['end_date']['day'])
            end_date = datetime.datetime.strptime(end_time_str, "%Y:%m:%d").date()

            week_day = start_date.weekday()
            days = (end_date - start_date).days + 1
            week = int(days / 7) + 1

            """
            recurrence_type: 
            Recurrence meeting types:`1` - Daily.
                                     `2` - Weekly.
                                     `3` - Monthly.
            """
            if session["frequency"] == "daily":
                recurrence_type = 1
                end_times = days
            elif session["frequency"] == "weekly":
                recurrence_type = 2
                end_times = week
            elif session["frequency"] == "monthly":
                recurrence_type = 3
                end_times = None
            else:
                recurrence_type = None
                end_times = None
            # convert start date into allowed format is "2020-03-31T12:02:00Z"
            start_date = datetime.datetime.strptime(start_time_str + "T" + session['start_time'],
                                                    "%Y:%m:%dT%H:%M") - datetime.timedelta(minutes=10)
            # make sure the meeting time specified is in the future only
            if start_date < datetime.datetime.now() - datetime.timedelta(minutes=10):
                raise InvalidUsage("PLease select the appropriate time for the meeting,"
                                   " we can't schedule meetings for past.", 400)
            """
            type: 2 indicates Scheduled Meeting
                  8 indicates Recurring Meeting with fixed time.
            ----------------------------------
            start_time: "Meeting start date-time in UTC/GMT. Example: '2020-03-31T12:02:00Z'"
            -----------------------------------
            duration: meeting duration is specified in minutes
            ------------------------------------
            end_times: Select how many times the meeting should recur before it is canceled.
            """
            # compare if meeting already exist for the current period or not
            upcoming_meeting_host = zoom_app.get_meeting_list_host(zoom_jwt_token, session["zoom_account"]["email"])
            if upcoming_meeting_host.status_code == 400:
                raise InvalidUsage("Something went wrong while creating the link, "
                                   "Please reselect the zoom account and add available time slot only.", 409)

            upcoming_meeting_host = json.loads(upcoming_meeting_host.content)
            if upcoming_meeting_host.get("meetings"):
                for meeting in upcoming_meeting_host["meetings"]:
                    # convert start time into local time zone
                    if meeting.get("start_time"):
                        # time of existing upcoming meetings
                        local_time = datetime.datetime.strptime(meeting["start_time"], "%Y-%m-%dT%H:%M:%SZ")
                        # time of the meeting which user wants to create
                        meet_start_time = str_to_utc_datetime_obj(start_date.strftime("%Y:%m:%dT%H:%M"),
                                                                  "%Y:%m:%dT%H:%M").replace(tzinfo=None)

                        if not (local_time - meet_start_time):
                            raise InvalidUsage("Please select different time slot for the meeting, "
                                               "looks like current time slot is already occupied.", 409)
            # generate and assign random alphanumeric password for the meeting
            meeting_password = ''.join(random.choices(string.ascii_letters + string.digits, k=8))

            session["to_create"] = {"jwt_token": zoom_jwt_token,
                                    "topic": subject,
                                    "agenda": learning_objectives,
                                    "type": 8,
                                    "start_time": datetime.datetime.strftime(start_date, "%Y-%m-%dT%H:%M:%S"),
                                    "duration": int(session["duration"]) + 10,
                                    "recurrence_type": recurrence_type,
                                    "end_times": end_times,
                                    "week_day": week_day,
                                    "waiting_room": bool(session["waiting_room"]),
                                    "password": meeting_password if session.get("password") else ""}
    # process live sessions to delete
    live_sessions_to_del = list(db_auto_sessions.values())
    return live_sessions, live_sessions_to_del


def schedule_live_sessions(live_sessions, course_id=None, subscribers=None):
    processed_live_sessions = []
    schedule_zoom_meetings = []

    for session in live_sessions:
        if session["url"]:
            processed_live_sessions.append(session)
        else:
            zoom_app = Zoom(jwt_api_key=session["zoom_account"]["api_key"],
                            jwt_secret_key=session["zoom_account"]["secret_key"],
                            zoom_email=session["zoom_account"]["email"])
            response = zoom_app.create_meeting(
                jwt_token=session["to_create"]["jwt_token"],
                topic=session["to_create"]["topic"],
                agenda=session["to_create"]["agenda"],
                type=session["to_create"]["type"],
                start_time=session["to_create"]["start_time"],
                duration=session["to_create"]["duration"],
                recurrence_type=session["to_create"]["recurrence_type"],
                end_times=session["to_create"]["end_times"],
                week_day=session["to_create"]["week_day"],
                waiting_room=session["to_create"]["waiting_room"],
                password=session["to_create"]["password"])
            # if response.status_code
            if response.status_code == 401:
                raise InvalidUsage("Something went wrong while creating the link, "
                                   "Please reselect the zoom account and add available time slot only.", 401)

            if response.status_code == 404:
                raise InvalidUsage("Something went wrong while creating the link, "
                                   "Please check the zoom account details carefully.", 404)
            response = json.loads(response.content)
            session["meeting_details"] = {"host_id": response["host_id"],
                                          "uuid": response["uuid"],
                                          "meeting_id": response["id"],
                                          "start_url": response["start_url"],
                                          "join_url": response["join_url"]
                                          }
            session["url"] = response["start_url"]

            if subscribers:
                user_ids = []
                for ids in subscribers:
                    user_ids.append(ids['user_id'])
                user_info = mongo_session.access_specific_fields(collection='user_profile',
                                                                 condition={'_id': {"$in": user_ids}},
                                                                 return_keys=['username', 'email', '_id'])
                if user_info:
                    user_urls = {}
                    for user in user_info:
                        r = zoom_app.register_participants(email=user['email'],
                                                           username=user['username'],
                                                           jwt_token=session["to_create"]["jwt_token"],
                                                           meetingID=response["id"])
                        r = json.loads(r.content)
                        if r.get('join_url'):
                            user_urls[str(user['_id'])] = {'url': r['join_url'],
                                                           'registrant_id': r['registrant_id']}
                    session['subscriber_url'] = user_urls

            # append the schedule meetings to a list to store in database at the end of course creation
            meeting_details = {"host_id": response["host_id"],
                               "uuid": response["uuid"],
                               "meeting_id": response["id"],
                               "host_email": response["host_email"],
                               "start_url": response["start_url"],
                               "join_url": response["join_url"],
                               "occurrences": response["occurrences"],
                               "zoom_account": session["zoom_account"],
                               "waiting_room": session["to_create"]["waiting_room"],
                               "password": session["to_create"]["password"]
                               }
            if course_id:
                meeting_details["course_id"] = ObjectId(course_id)
            schedule_zoom_meetings.append(meeting_details)
            session["password"] = session["to_create"]["password"]
            session["waiting_room"] = session["to_create"]["waiting_room"]
            del session["to_create"]
    inserted_doc = None
    if schedule_zoom_meetings:
        # insert meeting details to meeting collection in database
        inserted_doc = mongo_session.insert_docs_to_db(collection="zoom_meetings",
                                                       docs=schedule_zoom_meetings)
    return live_sessions, inserted_doc


def manage_group_photo_s3_resources(resource_id):
    resource_bank_resource_id = mongo_session.insert_files_resource_bank(
        collection="group-photo",
        resource_id=ObjectId(resource_id),
        temp_collection="course_resource_bank")['message']
    s3_key_info = mongo_session.fetch_s3_key_temp_uploaded_files(
        collection="course_resource_bank",
        condition={
            "_id": ObjectId(resource_id)},
        columns={"s3_key": 1})
    return resource_bank_resource_id, s3_key_info


def create_group_chat(members, group_name, admins, created_by, group_description, subheading, resource_bank_resource_id,
                      s3_key_info, course_id=None, passion_project_id=None):
    """
    This function creates room for a group of users. The creator of the group is by default the
    admin of the group.
    """
    room_members = {}
    for member in members:
        room_members[member] = {"created_by": ObjectId(created_by),
                                "created_at": utc_datetime_now(),
                                "status": "active"}
    # room_members[admin] = {"created_by": ObjectId(admin),
    #                        "created_at": utc_datetime_now(),
    #                        "status": "active"}
    # admin_id = "room_members." + str(admin)
    # condition = {"$or": [
    #     {"admins": {"$in": [ObjectId(admin)]}},
    #     {admin_id: {"$exists": True}}
    # ]}
    # check_admin_existance = mongo_session.access_specific_fields(collection='chat_rooms',
    #                                                              condition=condition,
    #                                                              return_keys=['name'])
    # if check_admin_existance:
    #     for name in check_admin_existance:
    #         if name['name'] == group_name:
    #             raise InvalidUsage("Group with this name already exists", 400)

    photo_id = resource_bank_resource_id
    url = s3_key_info

    admin_list = []
    for admin in admins:
        admin_list.append({"admin_id": ObjectId(admin), "added_by": ObjectId(created_by), "status": "active"})

    doc_to_insert = {
        "name": group_name,
        "created_by": ObjectId(created_by),
        "created_at": utc_datetime_now(),
        "admins": admin_list,
        "room_members": room_members if passion_project_id else members,
        "group_photo": {
            "avatar_url": url,
            "edited_by": ObjectId(created_by),
            "photo_id": ObjectId(photo_id) if photo_id else ""
        },
        "sub_heading": subheading if subheading else "",
        "group_description": {
            "description": group_description if group_description else "",
            "edited_by": ObjectId(created_by) if group_description else ""
        },
        "type": "group"
    }
    if course_id:
        doc_to_insert['course_id'] = ObjectId(course_id)
    if passion_project_id:
        doc_to_insert['passion_project_id'] = ObjectId(passion_project_id)
        doc_to_insert['mentor_chat'] = True
    response = mongo_session.insert_documnet(collection="chat_rooms",
                                             doc_to_insert=doc_to_insert)
    room_info = mongo_session.check_existance_return_info(collection='chat_rooms',
                                                          condition={
                                                              '_id': ObjectId(response['_id'].inserted_id)
                                                          },
                                                          whole_doc=True)
    if not room_info:
        raise InvalidUsage("Room not found", 400)
    room_info['_id'] = str(room_info['_id'])
    room_info['created_by'] = str(room_info['created_by'])
    room_info['admins'][0]['admin_id'] = str(room_info['admins'][0]['admin_id'])
    room_info['admins'][0]['added_by'] = str(room_info['admins'][0]['added_by'])
    room_info['group_description']['edited_by'] = str(room_info['group_description']['edited_by'])
    room_info['group_photo']['edited_by'] = str(room_info['group_photo']['edited_by'])
    room_info['group_photo']['photo_id'] = str(room_info['group_photo']['photo_id'])
    for member in room_info['room_members']:
        room_info['room_members'][member]['created_by'] = str(
            room_info['room_members'][member]['created_by'])
    if course_id:
        room_info['course_id'] = str(room_info['course_id'])
    if passion_project_id:
        room_info['passion_project_id'] = str(room_info['passion_project_id'])
    return room_info


def create_index_for_global_search():
    """To  create index in ElasticSearch if not exists"""
    index_body = {
        "mappings": {
            "properties": {
                "id": {
                    "type": "keyword"
                },
                "title": {
                    "type": "search_as_you_type"
                },
                "mongo_collection": {
                    "type": "text"
                },
                "search_type": {
                    "type": "text"
                },
                "url": {
                    "type": "text"
                },
                "obj_id": {
                    "type": "text"
                }
            }
        }
    }

    res = es.indices.create(index=ES_GLOBAL_SEARCH_COURSE, body=index_body)


def insert_to_es(doc_id, description, data_title):
    """To insert the course to ES for Global search"""
    if not es.indices.exists(index=ES_GLOBAL_SEARCH_COURSE):
        create_index_for_global_search()
    data_block = {'obj_id': doc_id, 'search_type': 'course'}
    descript_title = description + " " + data_title
    url_title = data_title.replace(" ", "%20")
    env = EDUCOLLAB_ENVIRONMENT.lower()
    if env == "prod":
        env = "www"
    url = 'https://' + env + '.edu-collab.com/courses/single-course?course_id=' + doc_id + "&course=" + url_title
    data_block['url'] = url


    data_block["title"] = descript_title
    es.index(index=ES_GLOBAL_SEARCH_COURSE, id=doc_id, body=data_block)
    return True


def upload_course(course_category_id,
                  subject,
                  learning_objectives,
                  banner_img,
                  authors,
                  instructors,
                  editors,
                  teach_assis,
                  organisations,
                  live_sessions,
                  topics,
                  course_assessments,
                  course_work,
                  course_resources,
                  role,
                  user_id,
                  course_status,
                  course_class_id,
                  requirement,
                  what_will_you_learn):
    """Purpose: To upload a course into db"""
    if role not in ["teacher", "super_admin"]:
        raise InvalidUsage("you don't have permission to perform this operation.", 403)

    # added course class
    if course_class_id:
        course_class = mongo_session.get_all_data_for_particular_condition_fields(
            collection='course_class',
            condition={"_id": ObjectId(course_class_id)})['message'][0]
        if not course_class['active']:
            raise InvalidUsage("Course Class is not active yet", 406)
        course_class = course_class['value']
    else:
        course_class = None
    # process live sessions - no need to refactor
    if live_sessions:
        if course_class == "Self Paced Course":
            raise InvalidUsage("Live sessions not allowed in Self Paced Courses.", 406)
        live_sessions, live_session_to_del = process_live_session(live_sessions, user_id, subject, learning_objectives)

    delete_record_list = [ObjectId(banner_img)]

    # banner image - no need to refactor
    resource_bank_resource_id, s3_key_info = manage_course_s3_resources(banner_img)
    banner_rb_id = resource_bank_resource_id
    resource_id = banner_img
    if s3_key_info['status'] != 200:
        raise Exception("Error occurred while adding resources")
    banner_img = s3_key_info['message']

    # check and fetch category - no need to refactor
    if not course_category_id:
        raise InvalidUsage("Please select some category to upload the course.", 400)
    category_query = mongo_session.get_data_for_particular_columns_with_condition(
        collection='Course_Category',
        condition={"_id": ObjectId(course_category_id)},
        columns={"_id": 1, "name": 1})
    if category_query['status'] != 200:
        raise Exception("Error occurred while adding resources")
    category = category_query['message'][0]['name']

    # authors - no need to refactor
    authors = [author for author in authors if type(author["name"]) == str]
    # instructors - no need to refactor
    processed_instructors = []
    for inst in instructors:
        if not mongo_session.find_data_in_db(collection="user_profile",
                                             condition={"_id": ObjectId(inst["_id"])},
                                             columns={"_id": 1})["message"]:
            raise InvalidUsage("Instructors must be Educollab users.", 400)
        processed_instructors.append({"_id": ObjectId(inst['_id'])})

    # editors - no need to refactor
    processed_editors = []
    for editor in editors:
        if not mongo_session.find_data_in_db(collection="user_profile",
                                             condition={"_id": ObjectId(editor["_id"])},
                                             columns={"_id": 1})["message"]:
            raise InvalidUsage("Instructors must be Educollab users.", 400)
        processed_editors.append({"_id": ObjectId(editor['_id'])})

    # organisations - no need to refactor
    processed_organisations = []
    org_list = []
    for org in organisations:
        if not mongo_session.find_data_in_db(collection="organisations",
                                             condition={"_id": ObjectId(org["_id"])},
                                             columns={"_id": 1})["message"]:
            raise InvalidUsage("Organisations must be registered to educollab.", 400)
        org_list.append(ObjectId(org['_id']))
        processed_organisations.append({"_id": ObjectId(org['_id'])})

    if course_status == "publish":
        if not processed_instructors:
            raise InvalidUsage("There must be one instructor at least for course to get publish.", 400)
        if not subject:
            raise InvalidUsage("Title of the course is compulsory for course to get publish.", 400)
        if not learning_objectives:
            raise InvalidUsage("Learning Objectives are compulsory for course to get publish.", 400)

    """process teaching assistant - no need to refactor
    * should belong to organisation which has access to course."""
    processed_assistants = []
    for assistant in teach_assis:
        if not mongo_session.check_existance_return_info(collection="user_profile",
                                                         condition={"_id": ObjectId(assistant["_id"]),
                                                                    "organisation_id": {"$in": org_list}}):
            raise InvalidUsage("Teaching Assistant must belong to accessible organisations only.", 400)

        processed_assistants.append({"_id": ObjectId(assistant['_id']),
                                     "created_by": ObjectId(user_id),
                                     "created_at": utc_datetime_now(),
                                     "assignees": []
                                     })

    # course resources - refactored
    instance_ids, delete_record_list = refactored_resources.upload_course_resources(course_resources,
                                                                                    delete_record_list, user_id)

    # course assessments - no need to refactor
    unique_assess = []
    # all assessments which will be used in the course will be appended to this list so that we can
    # check the duplicate assessments. An assessment can only be used once in a course
    processed_assessments = []
    for assessment in course_assessments:
        if str(assessment['_id']) in unique_assess:
            raise InvalidUsage("An assessment can be used only once in a course.", 400)
        unique_assess.append(str(assessment['_id']))
        if assessment["calendered"] or assessment["is_timed"]:
            if course_class == "Self Paced Course":
                raise InvalidUsage("Calendered or Timed assessment not allowed in Self Paced Courses.", 406)
        if not assessment['calendered']:
            processed_assessments.append({"_id": ObjectId(assessment['_id']),
                                          "is_timed": bool(assessment["is_timed"])})
        if assessment['calendered']:
            schedule_assessment_id = Content.schedule_assessment(
                assessment_data=assessment,
                assessment_type="course")
            processed_assessments.append({"_id": ObjectId(assessment['_id']),
                                          "schedule_id": schedule_assessment_id,
                                          "is_timed": bool(assessment["is_timed"])})

    # course work - no need to refactor
    processed_course_work = []
    for work in course_work:
        schedule_course_work_id = schedule_course_work(
            course_work_data=work,
            course_work_type="course")
        processed_course_work.append({"_id": ObjectId(work['_id']),
                                      "schedule_id": schedule_course_work_id})

    # topics - no need to refactor
    processed_topics = []
    for topic in topics:
        processed_topic, delete_resources, unique_assess = upload_course_topic(topic, unique_assess, user_id,
                                                                               course_class)
        processed_topics.append(processed_topic)
        delete_record_list = delete_record_list + delete_resources

    # schedule live sessions - no need to refactor
    created_live_sessions = None
    if live_sessions:
        live_sessions, created_live_sessions = schedule_live_sessions(live_sessions)

    data_to_insert = {"course_category_id": ObjectId(course_category_id),
                      "course_category": category,
                      "subject": subject,
                      "learning_objectives": learning_objectives,
                      "banner_img": banner_img,
                      "authors": authors,
                      "instructors": processed_instructors,
                      "editors": processed_editors,
                      "teach_assis": processed_assistants,
                      "organisations": processed_organisations,
                      "created_by": ObjectId(user_id),
                      "overall_rating": 0.0,
                      "active": True,
                      "live_sessions": live_sessions,
                      "resources": course_resources,
                      "course_assessments": processed_assessments,
                      "course_work": processed_course_work,
                      "topics": processed_topics,
                      "status": course_status,
                      "is_public": False,
                      "course_class": course_class_id,
                      "requirement": requirement,
                      "what_will_you_learn": what_will_you_learn,
                      "updated_at": Question.indian_standard_time()
                      }

    course_uploaded = mongo_session.insert_documnet(collection='courses_bank', doc_to_insert=data_to_insert)
    used_at = {"$set": {"used_at": {'course_id': ObjectId(course_uploaded['_id'].inserted_id)}}}
    condition = {"_id": {"$in": instance_ids}}
    updation = mongo_session.update_db_data(collection='resource_bank_instance', condition=condition,
                                            update_info=used_at, multi=True)
    # insert course detail in ES
    insert_to_es(doc_id=str(course_uploaded['_id'].inserted_id), description=learning_objectives, data_title=subject)
    record_removed_temp = mongo_session.delete_record_temp_uploaded_files(collection="temp_uploaded_files",
                                                                          id_list=delete_record_list)
    user_ids = []
    admins = [user_id]
    inst = [inst['_id'] for inst in instructors]
    edit = [ed['_id'] for ed in editors]
    admins.extend(inst)
    admins.extend(edit)
    admins = list(set(admins))
    create_group_chat(user_ids, subject, admins, user_id, "", "", banner_rb_id, banner_img,
                      str(course_uploaded['_id'].inserted_id))

    if record_removed_temp['status'] != 200 or course_uploaded['status'] != 200:
        raise Exception("Something went wrong while dealing with resources.")
    if created_live_sessions and created_live_sessions.inserted_ids:
        mongo_session.update_db_data(collection="zoom_meetings",
                                     condition={"_id": {"$in": created_live_sessions.inserted_ids}},
                                     update_info={"$set": {"course_id": course_uploaded['_id'].inserted_id}},
                                     multi=True)
    return {"_id": str(course_uploaded['_id'].inserted_id)}, "Course uploaded successfully."


def view_course(course_id, role, user_id, organisation):
    response = {}
    announcements = []
    if role == "super_admin":
        course_condition={
            "_id": ObjectId(course_id)
        }
    else:
        course_condition = {
            "_id": ObjectId(course_id),
            "active": True
        }
    course_query = mongo_session.get_all_data_for_particular_condition_fields(
        collection='courses_bank',
        condition=course_condition)
    if course_query['status'] != 200:
        raise InvalidUsage("Something went wrong, Please try again later.", 500)
    print(course_id)
    course_data = course_query['message'][0]
    # if not course_data['active']:
    #     raise InvalidUsage("Oops, course is not active anymore.", 500)

    publish_rights = [str(user['_id']) for user in course_data["editors"]] + \
                     [str(user['_id']) for user in course_data["instructors"]] + [str(course_data["created_by"])]
    publish_right = True
    if role != "super_admin":
        if course_data['status'] == "unpublish":
            if user_id not in publish_rights:
                raise InvalidUsage("Course is not published yet", 500)
        if course_data['status'] == "publish":
            org_list = [org["_id"] for org in course_data["organisations"]]
            organisation_query = mongo_session.get_all_data_for_particular_condition_fields(
                collection="organisations",
                condition={"name": organisation}
            )
            if organisation_query['status'] != 200:
                raise InvalidUsage("Something went wrong, please try again later.", 500)
            if (ObjectId(organisation_query['message'][0]['_id']) not in org_list) and (user_id not in publish_rights) \
                    and not course_data['is_public']:
                raise InvalidUsage("You don't have access to this course", 403)
        if user_id not in publish_rights:
            publish_right = False

    # Live Sessions - refactored
    response["live_sessions"] = refactored_sessions.view_course_live_sessions(course_data, user_id, publish_rights,
                                                                              role)
    response["course_category_id"] = str(course_data["course_category_id"])
    response["publish_right"] = publish_right

    # taxonomy - no need to refactor
    course_category = mongo_session.get_all_data_for_particular_condition_fields(
        "Course_Category", {"_id": course_data["course_category_id"]})['message'][0]
    response["course_category_taxonomy"] = Content.category_taxonomy_by_category_id(course_category)
    response["course_category_name"] = course_data["course_category"]
    s3_link, s3_status = s3_function.generate_presigned_url_from_s3(course_data['banner_img'])
    if s3_status != 200:
        raise InvalidUsage("Error occurred while communicating with s3.", 500)
    response["banner_img"] = s3_link

    # individual rating - no need to refactor
    individual_rating = None
    if course_data.get("Rating"):
        for rating in course_data["Rating"]:
            if rating["user_id"] == str(user_id):
                individual_rating = rating["Rating"]
    response["individual_rating"] = individual_rating if individual_rating else 0.0
    response["rating"] = course_data["overall_rating"]
    response["subject"] = course_data["subject"]
    response["learning_objectives"] = course_data["learning_objectives"]
    response['reviews'] = {"total_reviews": len(course_data['Rating']) if course_data.get("Rating") else 0,
                           'total_subscribers': len(course_data['subscribers']) if course_data.get(
                               "subscribers") else 0}
    if course_data.get("subscribers"):
        response['total_subscribers'] = len(course_data.get("subscribers"))
    else:
        response['total_subscribers'] = 0
    response["what_will_you_learn"] = course_data.get('what_will_you_learn', "")
    response["requirement"] = course_data.get('requirement', "")

    # overall rating provided count
    if course_data.get('Rating'):
        response['rating_count'] = len(course_data['Rating'])
    else:
        response['rating_count'] = 0
    # course resources - no need to refactor
    for resource in course_data["resources"]:
        if resource['type'] == 'file':
            if resource.get('schedule_id'):
                resource['schedule_id'] = str(resource['schedule_id'])
            if resource.get('instance_id'):
                resource['instance_id'] = str(resource['instance_id'])
            resource['_id'] = str(resource['_id'])
            if resource.get('instance_id'):
                resource['instance_id'] = str(resource['instance_id'])
            if resource.get('schedule_id'):
                resource['schedule_id'] = str(resource['schedule_id'])
            resource['url'], s3_status = s3_function.generate_presigned_url_from_s3(resource['url'])
            if s3_status != 200:
                raise InvalidUsage("Error occurred while communicating with s3", 500)
    response["course_resources"] = course_data["resources"]

    # authors - no need to refactor
    response["authors"] = course_data["authors"]
    # instructors - no need to refactor
    processed_inst = []

    for inst in course_data["instructors"]:

        inst_query = mongo_session.get_data_for_particular_columns_with_condition(
            collection="user_profile",
            condition={"_id": inst['_id']},
            columns={'username': 1, 'role': 1, 'organisation': 1})

        if inst_query['status'] != 200:
            raise InvalidUsage("Something went wrong, please try again later.", 500)
        processed_inst.append({"_id": str(inst["_id"]), "name": inst_query['message'][0]['username'],
                               "role": inst_query['message'][0]['role'],
                               "organisation": inst_query['message'][0]['organisation']})
    response["instructors"] = processed_inst

    # editors - no need to refactor
    processed_editors = []

    for editor in course_data["editors"]:
        editor_query = mongo_session.get_data_for_particular_columns_with_condition(
            collection="user_profile",
            condition={"_id": editor['_id']},
            columns={"username": 1})

        if editor_query['status'] != 200:
            raise InvalidUsage("Something went wrong, please try again later.", 500)
        processed_editors.append({"_id": str(editor["_id"]), "name": editor_query['message'][0]['username']})
    response["editors"] = processed_editors

    # organisations - no need to refactor
    processed_org = []
    for org in course_data["organisations"]:
        org_query = mongo_session.get_data_for_particular_columns_with_condition(
            collection="organisations",
            condition={"_id": org['_id']},
            columns={"name": 1})
        if org_query['status'] != 200:
            raise InvalidUsage("Something went wrong, please try again later.", 500)
        processed_org.append({"_id": str(org["_id"]), "name": org_query['message'][0]['name']})
    response["organisations"] = processed_org

    # process teaching assistant - no need to refactor
    teach_assis_info = mongo_session.access_specific_fields(collection="user_profile",
                                                            condition={"_id": {"$in": [user["_id"] for user in
                                                                                       course_data["teach_assis"]]}},
                                                            columns={"_id": 1, "organisation": 1, "username": 1,
                                                                     "role": 1})
    teach_assis = []
    if teach_assis_info:
        for assistant in teach_assis_info:
            assistant["_id"] = str(assistant["_id"])

    response["teach_assis"] = teach_assis_info if teach_assis_info else []

    # course assessments - refactored
    response["course_assessments"] = refactored_assessments.view_course_course_assessments(course_data, user_id, role,
                                                                                           course_id)
    # courseworks - refactored
    response["course_work"] = refactored_courseworks.view_course_coursework(course_data, user_id, role)

    # topics - refactored
    response["topics"] = refactored_topics.view_course_topics(course_data, user_id, role, course_id)

    # announcements - no need to refactor
    if course_data.get("announcements"):
        for announce in course_data["announcements"]:
            announcements.append({"announcement_html": renew_s3_links(announce["announcement_html"]),
                                  "created_by": str(announce["created_by"]),
                                  "created_at": str(convert_utc_to_ist(announce['created_at'])),
                                  "time_format": "IST"})
        announcements.reverse()
    response["announcements"] = announcements

    # subscription status - no need to refactor
    subscription_status = False
    if course_data.get("subscribers"):
        subscribers = [str(user["user_id"]) for user in course_data["subscribers"]]
        if user_id in subscribers:
            subscription_status = True

    # group chat for course - not refactored
    response['group_chat'] = {}
    condition = {"course_id": ObjectId(course_data['_id'])}
    room_info = mongo_session.check_existance_return_info(collection='chat_rooms',
                                                          condition=condition,
                                                          whole_doc=True)
    if room_info:
        check_message_count = mongo_session.get_total_count(collection='messages',
                                                            condition={
                                                                'room_id': str(room_info['_id']),
                                                                "receiver_status":
                                                                    {"$elemMatch": {"$and": [
                                                                        {"_id": ObjectId(user_id)},
                                                                        {"status": False}
                                                                    ]}
                                                                    }})
        if check_message_count:
            room_info['total_unread_messages'] = check_message_count
        else:
            room_info['total_unread_messages'] = 0

        message_info = mongo_session.check_existance_return_info(collection='messages',
                                                                 condition={'room_id': str(room_info['_id'])},
                                                                 return_keys=['message', 'created_at',
                                                                              'sender_id', 'content'])
        if message_info:
            message_info['sender_id'] = str(message_info['sender_id'])
            date = message_info['created_at']
            message_info['created_at'] = convert_utc_to_ist(date).replace(tzinfo=None).isoformat(' ')
            room_info['messages'] = [message_info]
        else:
            room_info['messages'] = []

        room_members = []
        members = [ObjectId(member) for member in room_info['room_members']]
        room_members.extend(members)
        admins = [member['admin_id'] for member in room_info['admins'] if member['status'] == "active"]
        room_members.extend(admins)
        admins = [str(member['admin_id']) for member in room_info['admins'] if member['status'] == "active"]

        user_info = mongo_session.access_specific_fields(collection='user_profile',
                                                         condition={
                                                             "_id": {"$in": room_members}
                                                         },
                                                         return_keys=['_id', 'name', 'last_name', 'email', 'username',
                                                                      'profile_pic'])
        user_details = {}
        for user in user_info:
            user_details[str(user['_id'])] = user
            user['_id'] = str(user['_id'])
            user['user_id'] = user['_id']
            user['avatar_url'] = user['profile_pic']
            # print(user['profile_pic'])
            user['color'] = ""
            if user['avatar_url'] is None:
                user['avatar_url'] = ""
            del user['_id']

        room_info['_id'] = str(room_info['_id'])
        room_info['room_id'] = room_info['_id']
        del room_info['_id']
        room_info['created_by'] = str(room_info['created_by'])
        room_info['created_at'] = convert_utc_to_ist(room_info['created_at']).replace(tzinfo=None)
        if room_info.get('type'):
            admin_list = []
            for admin in room_info['admins']:
                admin['admin_id'] = str(admin['admin_id'])
                if admin['admin_id'] == user_id and admin['status'] == 'active':
                    room_info['current_user_admin'] = True
                else:
                    room_info['current_user_admin'] = False
                admin['added_by'] = str(admin['added_by'])
                if room_info['room_members']:
                    room_info['room_members'][admin['admin_id']] = {"status": admin['status']}
                else:
                    dict_1 = {admin['admin_id']: {"status": admin['status']}}
                    room_info['room_members'] = dict_1

        member_list = []
        for member in room_info['room_members']:
            if member in user_details:
                s3_url, status_code = s3_function.generate_presigned_url_from_s3(user_details[member]['profile_pic'])
                user_details[member]['avatar_url'] = s3_url
                if room_info['name'] == "" and not room_info.get('type'):
                    if member != user_id:
                        room_info['name'] = user_details[member]['username']
                        room_info['avatar_url'] = s3_url
                if room_info.get('type'):
                    if member in admins:
                        user_details[member]['is_admin'] = True
                    else:
                        user_details[member]['is_admin'] = False
                    if member == user_id:
                        room_info['user_status'] = room_info['room_members'][member]['status']
                    user_details[member]['user_status'] = room_info['room_members'][member]['status']
                else:
                    if member == user_id:
                        room_info['user_status'] = "active"
                    user_details[member]['user_status'] = "active"
                d = {key: value for key, value in user_details[member].items() if key not in 'profile_pic'}
                if user_details[member].get('user_status'):
                    del user_details[member]['user_status']
                if user_details[member].get('is_admin'):
                    del user_details[member]['is_admin']
                member_list.append(d)
        room_info['room_members'] = member_list
        if room_info.get('group_photo'):
            room_info['avatar_url'], status = s3_function.generate_presigned_url_from_s3(
                room_info['group_photo']['avatar_url'])
            del room_info['group_photo']

        if room_info.get('group_description'):
            room_info['description'] = str(room_info['group_description']['description'])
            del room_info['group_description']

        if room_info.get('course_id'):
            room_info['course_id'] = str(room_info['course_id'])
        del room_info['admins']
        response['group_chat'] = room_info
    response["subscription_status"] = subscription_status
    response["status"] = course_data['status'] if course_data.get('status') else "unpublish"
    response["is_public"] = bool(course_data["is_public"]) if course_data.get("is_public") else False
    response["active"] = bool(course_data["active"]) if course_data.get("active") else False
    course_class = course_data.get('course_class')
    if course_class:
        course_class_data = mongo_session.get_all_data_for_particular_condition_fields(collection="course_class",
                                                                                       condition={
                                                                                           "_id": ObjectId(
                                                                                               course_class)}
                                                                                       )['message'][0]
        course_class = course_class_data['_id']
        course_class_name = str(course_class_data['value'])
    else:
        course_class = '627b63824250da4d6a8c40af'
        course_class_name = 'Old Structure'
    response['course_class'] = course_class
    response['course_class_name'] = course_class_name

    response['topics_completed'] = False
    check_existance = mongo_session.access_specific_fields(collection='courses_progress_tracking',
                                                           condition={"user_id": user_id})

    topics_completed_by_user = []
    if check_existance and role == 'student':
        check_existance = check_existance[0]
        for c_id in response['topics']:
            if str(c_id['_id']) in check_existance['topics_completed']:
                print('here')
                topics_completed_by_user.append(str(c_id['_id']))
        if len(topics_completed_by_user) == len(response['topics']):
            response['topics_completed'] = True
    elif role == 'teacher' or role == 'super_admin' or role == 'student' and course_class_name == 'Old Structure':
        response['topics_completed'] = True

    course_category = mongo_session.get_all_data_for_particular_condition_fields(
        collection="Course_Category",
        condition={"_id": course_data["course_category_id"]})["message"][0]
    taxonomy = Content.category_taxonomy_by_category_id(course_category)
    response['sub_category'] = taxonomy.split(" / ")
    return response, "Data retrieved successfully", 200


def single_view_course(course_id, role, user_id, organisation):
    response = {}
    if role == "super_admin":
        course_condition={
            "_id": ObjectId(course_id)
        }
    else:
        course_condition = {
            "_id": ObjectId(course_id),
            "active": True
        }
    course_query = mongo_session.get_all_data_for_particular_condition_fields(
        collection='courses_bank',
        condition=course_condition)
    if course_query['status'] != 200:
        raise InvalidUsage("Something went wrong, Please try again later.", 500)
    
    course_data = course_query['message'][0]
    # if not course_data['active']:
    #     raise InvalidUsage("Oops, course is not active anymore.", 500)

    publish_rights = [str(user['_id']) for user in course_data["editors"]] + \
                     [str(user['_id']) for user in course_data["instructors"]] + [str(course_data["created_by"])]
    publish_right = True
    if role != "super_admin":
        if course_data['status'] == "unpublish":
            if user_id not in publish_rights:
                raise InvalidUsage("Course is not published yet", 500)
        if course_data['status'] == "publish":
            org_list = [org["_id"] for org in course_data["organisations"]]
            organisation_query = mongo_session.get_all_data_for_particular_condition_fields(
                collection="organisations",
                condition={"name": organisation}
            )
            if organisation_query['status'] != 200:
                raise InvalidUsage("Something went wrong, please try again later.", 500)
            if (ObjectId(organisation_query['message'][0]['_id']) not in org_list) and (user_id not in publish_rights) \
                    and not course_data['is_public']:
                raise InvalidUsage("You don't have access to this course", 403)
        if user_id not in publish_rights:
            publish_right = False

    response["course_category_id"] = str(course_data["course_category_id"])
    response["publish_right"] = publish_right

    # taxonomy - no need to refactor
    course_category = mongo_session.get_all_data_for_particular_condition_fields(
        "Course_Category", {"_id": course_data["course_category_id"]})['message'][0]
    response["course_category_taxonomy"] = Content.category_taxonomy_by_category_id(course_category)
    response["course_category_name"] = course_data["course_category"]
    s3_link, s3_status = s3_function.generate_presigned_url_from_s3(course_data['banner_img'])
    if s3_status != 200:
        raise InvalidUsage("Error occurred while communicating with s3.", 500)
    response["banner_img"] = s3_link

    # individual rating - no need to refactor
    individual_rating = None
    if course_data.get("Rating"):
        for rating in course_data["Rating"]:
            if rating["user_id"] == str(user_id):
                individual_rating = rating["Rating"]
    response["individual_rating"] = individual_rating if individual_rating else 0.0
    response["rating"] = course_data["overall_rating"]
    response["subject"] = course_data["subject"]
    response["learning_objectives"] = course_data["learning_objectives"]
    response['reviews'] = {"total_reviews": len(course_data['Rating']) if course_data.get("Rating") else 0,
                           'total_subscribers': len(course_data['subscribers']) if course_data.get(
                               "subscribers") else 0}
    if course_data.get("subscribers"):
        response['total_subscribers'] = len(course_data.get("subscribers"))
    else:
        response['total_subscribers'] = 0
    response["what_will_you_learn"] = course_data.get('what_will_you_learn', "")
    response["requirement"] = course_data.get('requirement', "")

    # overall rating provided count
    if course_data.get('Rating'):
        response['rating_count'] = len(course_data['Rating'])
    else:
        response['rating_count'] = 0

    # authors - no need to refactor
    response["authors"] = course_data["authors"]

    #group chat info
    response['group_chat'] = {}
    condition = {"course_id": ObjectId(course_data['_id'])}
    room_info = mongo_session.get_data_for_particular_columns_with_condition(collection='chat_rooms',
                                                          condition=condition,
                                                          columns={
                                                            "_id": 1,
                                                            "name": 1
                                                          })
    if room_info.get("status") == 200 and len(room_info["message"]) > 0:
        response['group_chat'] = {
            "room_id": room_info["message"][0]["_id"],
            "name": room_info["message"][0]["name"]
        }

    # editors - no need to refactor
    processed_editors = []

    for editor in course_data["editors"]:
        editor_query = mongo_session.get_data_for_particular_columns_with_condition(
            collection="user_profile",
            condition={"_id": editor['_id']},
            columns={"username": 1})

        if editor_query['status'] != 200:
            raise InvalidUsage("Something went wrong, please try again later.", 500)
        processed_editors.append({"_id": str(editor["_id"]), "name": editor_query['message'][0]['username']})
    response["editors"] = processed_editors

    # organisations - no need to refactor
    processed_org = []
    for org in course_data["organisations"]:
        org_query = mongo_session.get_data_for_particular_columns_with_condition(
            collection="organisations",
            condition={"_id": org['_id']},
            columns={"name": 1})
        if org_query['status'] != 200:
            raise InvalidUsage("Something went wrong, please try again later.", 500)
        processed_org.append({"_id": str(org["_id"]), "name": org_query['message'][0]['name']})
    response["organisations"] = processed_org

    # subscription status - no need to refactor
    subscription_status = False
    if course_data.get("subscribers"):
        subscribers = [str(user["user_id"]) for user in course_data["subscribers"]]
        if user_id in subscribers:
            subscription_status = True

    response["subscription_status"] = subscription_status
    response["status"] = course_data['status'] if course_data.get('status') else "unpublish"
    response["is_public"] = bool(course_data["is_public"]) if course_data.get("is_public") else False
    response["active"] = bool(course_data["active"]) if course_data.get("active") else False
    course_class = course_data.get('course_class')
    if course_class:
        course_class_data = mongo_session.get_all_data_for_particular_condition_fields(collection="course_class",
                                                                                       condition={
                                                                                           "_id": ObjectId(
                                                                                               course_class)}
                                                                                       )['message'][0]
        course_class = course_class_data['_id']
        course_class_name = str(course_class_data['value'])
    else:
        course_class = '627b63824250da4d6a8c40af'
        course_class_name = 'Old Structure'
    response['course_class'] = course_class
    response['course_class_name'] = course_class_name

    response['topics_completed'] = False
    check_existance = mongo_session.access_specific_fields(collection='courses_progress_tracking',
                                                           condition={"user_id": user_id})


    # topics - refactored
    topics = refactored_topics.view_course_topics(course_data, user_id, role, course_id)

    topics_completed_by_user = []
    if check_existance and role == 'student':
        check_existance = check_existance[0]
        for c_id in topics:
            if str(c_id['_id']) in check_existance['topics_completed']:
                print('here')
                topics_completed_by_user.append(str(c_id['_id']))
        if len(topics_completed_by_user) == len(topics):
            response['topics_completed'] = True
    elif role == 'teacher' or role == 'super_admin' or role == 'student' and course_class_name == 'Old Structure':
        response['topics_completed'] = True

    course_category = mongo_session.get_all_data_for_particular_condition_fields(
        collection="Course_Category",
        condition={"_id": course_data["course_category_id"]})["message"][0]
    taxonomy = Content.category_taxonomy_by_category_id(course_category)
    response['sub_category'] = taxonomy.split(" / ")
    return response, "Data retrieved successfully", 200


def view_announcement(course_id, role, user_id, organisation):
    """To add announcement in particular course
    :param course_id: course on which announcement need to add.
    :type: str (object id)
    :param announcement_html: html for announcement
    :type: html string
    """
    announcements = []
    course__announcement_data = mongo_session.check_existance_return_info(
        collection="courses_bank",
        condition={"_id": ObjectId(course_id)},
        columns={"active": 1,
                 "announcements": 1},
        return_keys=["_id",
                     "announcements"])
    if not course__announcement_data:
        raise InvalidUsage("Bad Request", 400)

    if course__announcement_data.get("announcements"):
        for announce in course__announcement_data["announcements"]:
            title = ""
            if announce.get('title'):
               title = announce['title']

            resources = []
            if announce.get("resources"):
                for res in announce['resources']:
                    response, status = s3_function.generate_presigned_url_from_s3(res)
                    resources.append(response)

            announcements.append({"announcement_html": renew_s3_links(announce["announcement_html"]),
                                  "created_by": str(announce["created_by"]),
                                  "created_at": str(convert_utc_to_ist(announce['created_at'])),
                                  "time_format": "IST",
                                  "title": title,
                                  "resources": resources})
        announcements.reverse()


    return announcements, "Announcements retrieved successfully", 200


def add_announcement(course_id, role, user_id, announcement_html, title, resources):
    """To add announcement in particular course
    :param course_id: course on which announcement need to add.
    :type: str (object id)
    :param announcement_html: html for announcement
    :type: html string
    """
    course_data = mongo_session.check_existance_return_info(
        collection="courses_bank",
        condition={"_id": ObjectId(course_id)},
        columns={"active": 1,
                 "editors": 1,
                 "instructors": 1,
                 "created_by": 1,
                 "announcements": 1,
                 "teach_assis": 1,
                 "subscribers": 1,
                 "subject": 1},
        return_keys=["_id",
                     "active",
                     "editors",
                     "instructors",
                     "created_by",
                     "announcements",
                     "teach_assis",
                     "subscribers",
                     "subject"])
    if not course_data:
        raise InvalidUsage("Bad Request", 400)

    if not course_data['active']:
        raise InvalidUsage("Oops, course is not active anymore.", 400)

    announce_rights = [str(user['_id']) for user in course_data["editors"]] + \
                      [str(user['_id']) for user in course_data["instructors"]] + \
                      [str(course_data["created_by"])] + \
                      [str(user['_id']) for user in course_data["teach_assis"]]
    if not role == "super_admin" and user_id not in announce_rights:
        raise InvalidUsage("You don't have permission to add announcement.", 403)
    #  get files s3 path
    files = extract_s3_keys_from_html_str(announcement_html)

    data_to_insert = {
        "announcement_html": replace_s3_links_with_keys(announcement_html),
        "created_at": utc_datetime_now(),
        "created_by": ObjectId(user_id),
        "title":title,
        "resources":resources
    }
    add_announce = mongo_session.update_db_data(collection="courses_bank",
                                                condition={"_id": ObjectId(course_id)},
                                                update_info={"$push": {"announcements": data_to_insert}}
                                                )
    if not add_announce["nModified"]:
        raise InvalidUsage("Internal Server Error, couldn't add announcement.", 500)

    remove_query = mongo_session.delete_records(collection="temp_uploaded_files",
                                                condition={"s3_key": {"$in": files}})

    if course_data['subscribers']:
        user_id_list = [user['user_id'] for user in course_data['subscribers']]
        data_message = {"courseId": str(course_data['_id']),
                        "click_action": "FLUTTER_NOTIFICATION_CLICK",
                        "module_name": "CourseUpdated",
                        "courseName": course_data['subject']}
        message_title = "New Announcement"
        message_body = "New Annoucement added under " + course_data['subject']
        notify_team(user_id_list=user_id_list,
                    data_message=data_message,
                    message_title=message_title,
                    message_body=message_body)

    return "Announcement added successfully."


def catalogue(role, user_id, organisation, course_category_id=None, subscription_status=None, page=None,
              page_name=None):
    response = []
    if course_category_id and subscription_status:
        condition = {"active": True,
                     "course_category_id": ObjectId(course_category_id),
                     "subscribers.user_id": ObjectId(user_id)}
    elif course_category_id:
        category_list = [course_category_id]
        required_column_name = {"_id": 1}
        child_category_list = mongo_session.get_data_for_particular_columns_with_condition(collection='Course_Category',
                                                                            columns=required_column_name,
                                                                        condition={'parent_id': ObjectId(course_category_id)})['message']
        if child_category_list:
            child_category_list = [doc['_id'] for doc in child_category_list]
            category_list.extend(child_category_list)
            for category in child_category_list: 
                sub_child_category_list = mongo_session.get_data_for_particular_columns_with_condition(collection='Course_Category',
                                                                            columns=required_column_name,
                                                                            condition={'parent_id': ObjectId(category)})['message']
                if sub_child_category_list:
                    sub_child_category_list = [doc['_id'] for doc in sub_child_category_list]
                    category_list.extend(sub_child_category_list)
        category_list = [ObjectId(doc) for doc in category_list]
        condition = {"active": True, "course_category_id": {"$in":category_list}}
    elif subscription_status:
        condition = {"active": True, "subscribers.user_id": ObjectId(user_id)}
    else:
        condition = {"active": True}

    course_query = mongo_session.get_data_for_particular_columns_with_condition(
        collection='courses_bank',
        condition=condition)
    if course_query['status'] != 200:
        raise InvalidUsage(message="Something went wrong, Please try again later.", status_code=500)
    courses_info = course_query['message']

    for course_data in courses_info:
        course_dict = {}
        publish_rights = [str(user['_id']) for user in course_data["editors"]] + \
                         [str(user['_id']) for user in course_data["instructors"]] + [str(course_data["created_by"])]

        course_dict["edit_right"] = (True if user_id in publish_rights or role == "super_admin" else False)
        if role != "super_admin":
            if course_data['status'] == "unpublish":
                if user_id not in publish_rights:
                    continue
            if course_data['status'] == "publish":
                if not course_data.get("is_public"):
                    org_list = [org["_id"] for org in course_data["organisations"]]
                    organisation_query = mongo_session.get_all_data_for_particular_condition_fields(
                        collection="organisations",
                        condition={"name": organisation}
                    )
                    if organisation_query['status'] != 200:
                        raise InvalidUsage(message="Something went wrong, Please try again later.", status_code=500)
                    if (ObjectId(organisation_query['message'][0]['_id']) not in org_list) and (
                            user_id not in publish_rights):
                        continue
        course_dict["course_category_id"] = str(course_data["course_category_id"])
        course_dict["course_category"] = course_data["course_category"]
        if course_data.get("created_by"):
            creator = mongo_session.get_data_for_particular_columns_with_condition(
                collection="user_profile",
                condition={"_id": ObjectId(course_data.get("created_by"))},
                columns={"name": 1,
                         "last_name": 1,
                         "email": 1}
            )["message"][0]
            course_dict["created_by"] = creator
        if course_data.get('authors'):
            course_dict['authors'] = course_data.get('authors')
        else:
            course_dict['authors'] = []
        instructors = []
        if course_data.get('instructors'):
            for instructor in course_data.get('instructors'):
                instructor_detail = mongo_session.get_data_for_particular_columns_with_condition(
                    collection="user_profile",
                    condition={"_id": ObjectId(instructor['_id'])},
                    columns={"name": 1,
                             "last_name": 1,
                             "email": 1}
                )["message"][0]
                instructors.append({
                    "_id": str(instructor_detail.get('_id')),
                    "name": instructor_detail.get('name'),
                    "last_name": instructor_detail.get('last_name'),
                    "email": instructor_detail.get('email')
                })
        course_dict['instructors'] = instructors
        s3_link, s3_status = s3_function.generate_presigned_url_from_s3(course_data['banner_img'])
        if s3_status != 200:
            raise Exception("Error occurred while communicating with s3")
        course_dict["banner_img"] = s3_link
        course_dict["rating"] = course_data["overall_rating"]
        course_dict["subject"] = course_data["subject"]
        course_dict["learning_objectives"] = course_data["learning_objectives"]
        course_dict["course_id"] = str(course_data["_id"])
        course_dict["status"] = course_data["status"]
        course_dict["is_public"] = bool(course_data["is_public"]) if course_data.get("is_public") else False
        course_dict["subscribed"] = False
        if course_data.get("subscribers"):
            subscribers = [str(user["user_id"]) for user in course_data["subscribers"]]
            if user_id in subscribers:
                course_dict["subscribed"] = True
        if course_data.get("subscribers"):
            course_dict['total_subscribers'] = len(course_data.get("subscribers"))
        else:
            course_dict['total_subscribers'] = 0

        if course_data.get('Rating'):
            course_dict['rating_count'] = len(course_data['Rating'])
        else:
            course_dict['rating_count'] = 0

        instructor_dict = mongo_session.access_specific_fields(collection='user_profile',
                                                               condition={"_id": course_data["created_by"]},
                                                               return_keys=['role', 'organisation'])[0]
        course_dict['instructor_designation'] = instructor_dict['role']
        course_dict['instructor_organisation'] = instructor_dict['organisation']
        course_dict["what_will_you_learn"] = course_data.get('what_will_you_learn', "")
        course_dict["requirement"] = course_data.get('requirement', "")
        response.append(course_dict)

    if not subscription_status and not course_category_id and not page:
        message = "Data retrieved successfully"
        return response, message
    elif subscription_status and not page:
        if not response:
            raise InvalidUsage("No Subscribed Courses", 400)
        else:
            message = "Data retrieved successfully"
            return response, message
    elif course_category_id and not page:
        if not response:
            raise InvalidUsage("No Courses available in this Category", 400)
        else:
            message = "Data retrieved successfully"
            return response, message
    elif subscription_status and course_category_id and not page:
        if not response:
            raise InvalidUsage("No Subscribed Courses", 400)
        else:
            message = "Data retrieved successfully"
            return response, message
    elif subscription_status and course_category_id and page:
        if not response:
            raise InvalidUsage("No Subscribed Courses", 400)
    elif subscription_status and page:
        if not response:
            raise InvalidUsage("No Subscribed Courses", 400)
    elif course_category_id and page:
        if not response:
            raise InvalidUsage("No Courses available in this Category", 400)

    total_courses = 10
    total_courses_count = len(response)
    response = response[::-1]
    response_data = [response[i: i + total_courses] for i in range(0, len(response), total_courses)]

    if page_name == 'teach' and page:
        response_data = [x for x in response if x["edit_right"] == True]
        response_data = [response_data[i: i + total_courses] for i in range(0, len(response_data), total_courses)]
    elif page_name == 'learner' and page:
        response_data = [x for x in response if x["subscribed"] == True]
        response_data = [response_data[i: i + total_courses] for i in range(0, len(response_data), total_courses)]
    elif page_name == 'other' and page:
        if role == 'student':
            response_data = [x for x in response if x["subscribed"] == False]
            response_data = [response_data[i: i + total_courses] for i in range(0, len(response_data), total_courses)]
        else:
            response_data = [x for x in response if x["edit_right"] == False]
            response_data = [response_data[i: i + total_courses] for i in range(0, len(response_data), total_courses)]

    if int(page) > len(response_data):
        response = []
        raise InvalidUsage("No Content Available on this Page", 400)
    else:
        message = "Data retrieved successfully"
        response = {
            "total_courses": total_courses_count,
            "total_pages": len(response_data),
            "data": response_data[int(page) - 1],
            "current_page": int(page)
        }

    return response, message


def edit_announcement(course_id, role, user_id, announcement_html, index, title, resources):
    """To edit announcement in particular course
    :param course_id: course on which announcement need to be edit.
    :type: str (object id)
    :param announcement_html: html for announcement
    :type: html string
    :param index: index to see which announcement need to be edit.
    :type index: int
    """
    course_data = mongo_session.check_existance_return_info(
        collection="courses_bank",
        condition={"_id": ObjectId(course_id)},
        columns={"active": 1,
                 "editors": 1,
                 "instructors": 1,
                 "created_by": 1,
                 "announcements": 1,
                 "teach_assis": 1,
                 "subject": 1,
                 "subscribers": 1},
        return_keys=["_id",
                     "active",
                     "editors",
                     "instructors",
                     "created_by",
                     "announcements",
                     "teach_assis",
                     "subject",
                     "subscribers"])
    if not course_data:
        raise InvalidUsage("Bad Request", 400)

    if not course_data['active']:
        raise InvalidUsage("Oops, course is not active anymore.", 400)
    data = copy.deepcopy(course_data["announcements"])
    data.reverse()
    course_data["announcements"] = data
    announce_rights = [str(user['_id']) for user in course_data["editors"]] + \
                      [str(user['_id']) for user in course_data["instructors"]] + \
                      [str(course_data["created_by"])] + \
                      [str(user['_id']) for user in course_data["teach_assis"]]
    if not role == "super_admin" and user_id not in announce_rights:
        raise InvalidUsage("You don't have permission to update announcement.", 403)

    #  get files s3 path
    files = extract_s3_keys_from_html_str(announcement_html)

    # get previous files
    previous_files = extract_s3_keys_from_html_str(course_data["announcements"][index]["announcement_html"])
    course_data["announcements"][index]["announcement_html"] = replace_s3_links_with_keys(announcement_html)
    course_data["announcements"][index]["updated_at"] = utc_datetime_now()
    course_data["announcements"][index]["updated_by"] = ObjectId(user_id)
    course_data["announcements"][index]["title"] = title
    course_data["announcements"][index]["resources"] = resources
    data = copy.deepcopy(course_data["announcements"])
    data.reverse()
    course_data["announcements"] = data
    update_announce = mongo_session.update_db_data(
        collection="courses_bank",
        condition={"_id": ObjectId(course_id)},
        update_info={"$set": {"announcements": course_data["announcements"]}}
    )
    if not update_announce["nModified"]:
        raise InvalidUsage("Internal Server Error, couldn't update announcement.", 500)

    remove_query = mongo_session.delete_records(collection="temp_uploaded_files",
                                                condition={"s3_key": {"$in": files}})
    temp_data = []
    for file in previous_files:
        file_data = {"s3_key": file,
                     "deleted_by": ObjectId(user_id),
                     "module_name": "announcements",
                     "active": False}
        temp_data.append(file_data)
    add_files_to_temp = mongo_session.insert_multiple_documents(collection="temp_uploaded_files",
                                                                doc_to_insert=temp_data)
    user_id_list = [user['user_id'] for user in course_data['subscribers']]
    data_message = {"courseId": str(course_data['_id']),
                    "click_action": "FLUTTER_NOTIFICATION_CLICK",
                    "module_name": "CourseUpdated",
                    "course_name": course_data['subject']}
    message_title = "Announcement Updated"
    message_body = "Announcement updated under " + course_data['subject']
    notify_team(user_id_list=user_id_list,
                data_message=data_message,
                message_title=message_title,
                message_body=message_body)

    return "Success"


def delete_announcement(course_id, role, user_id, index):
    """To delete announcement in particular course
    :param course_id: course on which announcement need to be deleted.
    :type: str (object id)
    :param index: index to see which announcement need to be deleted.
    :type index: int
    """
    course_data = mongo_session.check_existance_return_info(
        collection="courses_bank",
        condition={"_id": ObjectId(course_id)},
        columns={"active": 1,
                 "editors": 1,
                 "instructors": 1,
                 "created_by": 1,
                 "announcements": 1,
                 "teach_assis": 1},
        return_keys=["_id",
                     "active",
                     "editors",
                     "instructors",
                     "created_by",
                     "announcements",
                     "teach_assis"])
    if not course_data:
        raise InvalidUsage("Bad Request", 400)

    if not course_data['active']:
        raise InvalidUsage("Oops, course is not active anymore.", 400)

    announce_rights = [str(user['_id']) for user in course_data["editors"]] + \
                      [str(user['_id']) for user in course_data["instructors"]] + \
                      [str(course_data["created_by"])] + \
                      [str(user['_id']) for user in course_data["teach_assis"]]
    if not role == "super_admin" and user_id not in announce_rights:
        raise InvalidUsage("You don't have permission to delete announcement.", 403)

    # get previous files
    previous_files = extract_s3_keys_from_html_str(course_data["announcements"][index]["announcement_html"])

    course_data["announcements"].reverse()
    course_data["announcements"].pop(index)
    course_data["announcements"].reverse()

    update_announce = mongo_session.update_db_data(
        collection="courses_bank",
        condition={"_id": ObjectId(course_id)},
        update_info={"$set": {"announcements": course_data["announcements"]}}
    )
    if not update_announce["nModified"]:
        raise InvalidUsage("Internal Server Error, couldn't delete announcement.", 500)

    temp_data = []
    for file in previous_files:
        file_data = {"s3_key": file,
                     "deleted_by": ObjectId(user_id),
                     "module_name": "announcements",
                     "active": False}
        temp_data.append(file_data)
    add_files_to_temp = mongo_session.insert_multiple_documents(collection="temp_uploaded_files",
                                                                doc_to_insert=temp_data)

    return "Success"


def get_subscribers(course_id, role, user_id, filter_role):
    """To get all the subscribers in particular course based on role filters"""
    course_info = mongo_session.check_existance_return_info(
        collection='courses_bank',
        condition={"_id": ObjectId(course_id), "subscribers": {"$exists": True}},
        columns={"subscribers": 1, "organisations": 1, "is_public": 1},
        return_keys=["subscribers", "_id", "organisations", "is_public"])
    if not course_info:
        raise InvalidUsage("No one has subscribe this course yet", 200)

    users_list = [user["user_id"] for user in course_info["subscribers"]]

    org_list = [org["_id"] for org in course_info["organisations"]]

    user_condition = {"_id": {"$in": users_list}}

    # if course is not public then only allowed organisation's subscribers should be visible
    if course_info["is_public"]:
        user_condition = {"_id": {"$in": users_list}}
    else:
        user_condition = {"$and": [{"_id": {"$in": users_list}}, {"organisation_id": {"$in": org_list}}]}

    if filter_role:
        filter_role = ast.literal_eval(filter_role)
        user_condition["role"] = {"$in": filter_role}

    user_query = mongo_session.access_specific_fields(
        collection='user_profile',
        condition=user_condition,
        columns={"username": 1,
                 "organisation": 1,
                 "role": 1,
                 "profile_pic": 1,
                 "name": 1,
                 "last_name": 1},
        return_keys=["username", "organisation", "role", "_id", "profile_pic", "name", "last_name"])

    if not user_query:
        raise InvalidUsage("No one has subscribe this course yet", 200)
    for user in user_query:
        user["_id"] = str(user["_id"])
        user["profile_pic"] = get_profile_pic(s3_key=user["profile_pic"])
        user["name"] = user["name"] + " " + user["last_name"]
    user_query = sorted(user_query, key=lambda k: k['name'], reverse=False)
    return user_query, "Success"


# def update_course_groupchat(user_id, room_id, group_name, photo_url=None, photo_id=None, admins=None, projects=None,
#                             remove_users=None, more_users=None,
#                             team_members=None):
#     room_info = mongo_session.check_existance_return_info(collection='chat_rooms',
#                                                           condition={"_id": ObjectId(room_id)},
#                                                           whole_doc=True)
#     if team_members:
#         room_info = {}
#         for users in team_members:
#             room_info[users] = {"created_by": ObjectId(user_id),
#                                 "created_at": utc_datetime_now(),
#                                 "status": "active"}
#         update_info = {"$set": {"room_members": room_info}}
#         response = mongo_session.update_db_data(collection='chat_rooms',
#                                                 condition={'_id': ObjectId(room_id)},
#                                                 update_info=update_info)
#     if photo_id:
#         update_info = {"$set": {"group_photo": {"avatar_url": photo_url, "edited_by": ObjectId(user_id),
#                                                 "photo_id": ObjectId(photo_id)}}}
#         response = mongo_session.update_db_data(collection='chat_rooms',
#                                                 condition={'_id': ObjectId(room_id)},
#                                                 update_info=update_info)
#     if admins:
#         admin_list = []
#         for admin in admins:
#             admin_list.append({"admin_id": ObjectId(admin), "added_by": ObjectId(user_id), "status": "active"})

#         update_info = {"$set": {"admins": admin_list}}
#         response = mongo_session.update_db_data(collection='chat_rooms',
#                                                 condition={'_id': ObjectId(room_id)},
#                                                 update_info=update_info)

#     if group_name:
#         update_info = {"$set": {"name": group_name}}
#         response = mongo_session.update_db_data(collection='chat_rooms',
#                                                 condition={'_id': ObjectId(room_id)},
#                                                 update_info=update_info)

#     if remove_users is not None:
#         for users in remove_users:
#             if users in room_info['room_members']:
#                 del room_info['room_members'][users]

#         update_info = {"$set": {"room_members": room_info['room_members']}}
#         response = mongo_session.update_db_data(collection='chat_rooms',
#                                                 condition={'_id': ObjectId(room_id)},
#                                                 update_info=update_info)

#     if more_users is not None:
#         for users in more_users:
#             room_info['room_members'][users] = {"created_by": ObjectId(user_id),
#                                                 "created_at": utc_datetime_now(),
#                                                 "status": "active"}
#         update_info = {"$set": {"room_members": room_info['room_members']}}
#     if projects:
#         update_info = {"$push": {"passion_projects": projects}}
#         response = mongo_session.update_db_data(collection='chat_rooms',
#                                                 condition={'_id': ObjectId(room_id)},
#                                                 update_info=update_info)


def edit_course_detail(user_id, role, course_id, subject, category_id, learning_objectives, banner_img,
                       topics, authors, instructors, editors, teach_assis, organisations, course_resources,
                       live_sessions,
                       course_work, course_assessments, course_status, course_class_id, requirement, what_will_you_learn):
    """to edit the course details for a particular course"""
    timestamp = Question.indian_standard_time()
    timestamp_obj = datetime.datetime.strptime(timestamp, "%d %b %Y, %I:%M %p")
    course_query = mongo_session.get_all_data_for_particular_condition_fields(
        collection='courses_bank',
        condition={"_id": ObjectId(course_id)})
    if course_query['status'] != 200:
        raise Exception("Something went wrong, Please try again later.")
    course_data = course_query['message'][0]

    if not course_data['active']:
        return "Oops, course is not active anymore.", 409
    if course_data["status"] == "publish" and course_status == "unpublish":
        return "you can't unpublish a published course.", 409

    # added course class
    if course_class_id:
        course_class = mongo_session.get_all_data_for_particular_condition_fields(
        collection='course_class',
        condition={"_id": ObjectId(course_class_id)})['message'][0]
        if not course_class['active']:
            raise InvalidUsage("Course Class is not active yet", 406)
        course_class = course_class['value']
    else:
        course_class = None
    # Added check for submissions of assessments
    added_assessments = []
    if course_assessments:
        for c_assessment_id in course_assessments:
            added_assessments.append(str(c_assessment_id['_id']))
    if topics:
        for t_assessment_id in topics:
            for t_a_id in t_assessment_id['assessments']:
                added_assessments.append(str(t_a_id['_id']))

    # Checking existing assessments
    existing_assessments = []
    existing_c_assessments = mongo_session.access_specific_fields(collection="courses_bank",
                                                                  condition={"_id": ObjectId(str(course_id))})[0]
    if existing_c_assessments.get('course_assessments'):
        for e_c_id in existing_c_assessments['course_assessments']:
            existing_assessments.append(str(e_c_id['_id']))
    if topics:
        for a_topic in topics:
            if a_topic.get('_id'):
                existing_t_assessments = mongo_session.access_specific_fields(collection="course_topics",
                                                                              condition={"_id": ObjectId(
                                                                                  str(a_topic['_id']))})[0]
                if existing_t_assessments.get('assessments'):
                    for e_t_id in existing_t_assessments['assessments']:
                        existing_assessments.append(str(e_t_id['_id']))
    for assess in added_assessments:
        if assess not in existing_assessments:
            check = mongo_session.check_existance_return_info(collection="assessments_result",
                                                              condition={"assessment_id": ObjectId(str(assess)),
                                                                         "course_id": ObjectId(str(course_id))})
            if check:
                raise InvalidUsage("Submissions for this assessment already present.", 406)

    # live sessions - no need to refactor
    live_sessions_to_del = []
    if live_sessions:
        if course_class == "Self Paced Course":
            raise InvalidUsage("Live sessions not allowed in Self Paced Courses.", 406)
        live_sessions, live_sessions_to_del = process_live_session(live_sessions, user_id, subject,
                                                                   learning_objectives,
                                                                   course_data["live_sessions"])

    publish_rights = [str(user['_id']) for user in course_data["editors"]] + \
                     [str(user['_id']) for user in course_data["instructors"]] + [str(course_data["created_by"])]

    if role != "super_admin" and user_id not in publish_rights:
        return "You don't have permission to edit this course", 403

    # authors - no need to refactor
    authors = [author for author in authors if type(author["name"]) == str]

    # instructors - no need to refactor
    processed_instructors = []
    for inst in instructors:
        if not mongo_session.find_data_in_db(collection="user_profile",
                                             condition={"_id": ObjectId(inst["_id"])},
                                             columns={"_id": 1})["message"]:
            return "Instructors must be educollab users.", 409
        processed_instructors.append({"_id": ObjectId(inst['_id'])})

    # editors - no need to refactor
    processed_editors = []
    for editor in editors:
        if not mongo_session.find_data_in_db(collection="user_profile",
                                             condition={"_id": ObjectId(editor["_id"])},
                                             columns={"_id": 1})["message"]:
            return "Editors must be educollab users.", 409
        processed_editors.append({"_id": ObjectId(editor['_id'])})

    # organisations - no need to refactor
    processed_organisations = []
    org_list = []
    for org in organisations:
        if not mongo_session.find_data_in_db(collection="organisations",
                                             condition={"_id": ObjectId(org["_id"])},
                                             columns={"_id": 1})["message"]:
            return "Organisations must be registered to educollab.", 409
        org_list.append(ObjectId(org['_id']))
        processed_organisations.append({"_id": ObjectId(org['_id'])})

    if course_status == "publish":
        if not instructors:
            return "There must be one instructor at least for course to get publish.", 409
        if not subject:
            return "Title of the course is compulsory for course to get publish.", 409
        if not learning_objectives:
            return "Learning Objectives are compulsory for course to get publish.", 409

    """process teaching assistant - no need to refactor
        * should belong to organisation which has access to course.
        * should not be a subscriber of that course."""
    processed_assistants = []
    previous_assistants = [user["_id"] for user in course_data["teach_assis"]]
    for assistant in teach_assis:
        if ObjectId(assistant["_id"]) in previous_assistants:
            processed_assistants.extend([
                user for user in course_data["teach_assis"] if user["_id"] == ObjectId(assistant["_id"])])
        else:
            # TA should not be a subscriber of the course
            if course_data.get("subscribers") and \
                    any(subscriber["user_id"] == ObjectId(assistant["_id"]) for subscriber in
                        course_data["subscribers"]):
                raise InvalidUsage("Teaching Assistant should not be a subscriber of that course.", 400)

            teach_assis_condition = {"_id": ObjectId(assistant["_id"])}
            if not course_data["is_public"]:
                teach_assis_condition["organisation_id"] = {"$in": org_list}
            if not mongo_session.check_existance_return_info(collection="user_profile",
                                                             condition=teach_assis_condition):
                raise InvalidUsage("Teaching Assistant must belong to accessible organisations only.", 400)

            processed_assistants.append({"_id": ObjectId(assistant['_id']),
                                         "created_by": ObjectId(user_id),
                                         "created_at": utc_datetime_now(),
                                         "assignees": []
                                         })
    # category_id - no need to refactor
    if not category_id:
        return "Please select some category to upload the course.", 409

    category_name = mongo_session.get_data_for_particular_columns_with_condition(
        collection='Course_Category', condition={"_id": ObjectId(category_id)}, columns={"name": 1, "_id": 1})
    if category_name['status'] != 200 or not category_name["message"]:
        return "Please check nad validate the course category.", 409
    category = category_name['message'][0]['name']

    delete_list_temp_files = []
    delete_resource_list = []
    existing_resources = []

    # banner image - no need to refactor
    if len(banner_img) > 24:
        banner_img = course_data["banner_img"]
    else:
        if not mongo_session.check_existance_return_info(collection="global_resource_bank",
                                                         condition={'_id': ObjectId(banner_img)}):
            resource_bank_resource_id, s3_key_info = manage_course_s3_resources(banner_img)
            banner_rb_id = resource_bank_resource_id
            resource_id = banner_img
            if s3_key_info['status'] != 200:
                raise Exception("Some internal error occurred, Please try again later")
            banner_img = s3_key_info['message']
            delete_list_temp_files.append(resource_bank_resource_id)
        else:
            banner_rb_id = None
        room_id = mongo_session.check_existance_return_info(collection='chat_rooms',
                                                            condition={"course_id": ObjectId(course_id)})
        if room_id:
            update_course_groupchat(user_id=user_id, group_name=subject, room_id=room_id, photo_url=banner_img,
                                    photo_id=banner_rb_id)

    # course resources - refactored
    instance_ids, delete_list_temp_files, existing_resources, delete_resource_list = refactored_resources. \
        edit_course_resources(course_data, course_resources, user_id, delete_list_temp_files, existing_resources,
                              delete_resource_list)

    # course assessments - refactored
    # all assessments which will be used in the course will be appended to this list so that we can
    # check the duplicate assessments. An assessment can only be used once in a course
    db_course_assessments = course_data["course_assessments"]
    processed_assessments, unique_assess = refactored_assessments.edit_course_course_assessment(course_assessments,
                                                                                                db_course_assessments,
                                                                                                course_status,
                                                                                                course_class)

    # course level course work - not refactored
    processed_course_work = []
    db_course_work = course_data["course_work"]
    for work in course_work:
        work["_id"] = str(work["_id"])
        schedule_id = ""
        for data in db_course_work:
            if str(data["_id"]) == work["_id"]:
                schedule_id = data["schedule_id"]
        ccw_st_dt_str = Content.webapp_time_to_string(work["date"], work["time"])
        # course level course work start time
        fields_to_update = {
            "start_date": work["date"],
            "start_time": work["time"],
            "start_datetime": str_to_utc_datetime_obj(time_string=ccw_st_dt_str,
                                                      date_format="%Y:%m:%dT%H:%M")
        }
        if not schedule_id:
            # schedule course work
            schedule_course_work_id = schedule_course_work(
                course_work_data=work,
                course_work_type="course")
            processed_course_work.append({"_id": ObjectId(work['_id']),
                                          "schedule_id": schedule_course_work_id})
        elif course_status == "publish":
            schedule_work_info = mongo_session.get_data_for_particular_columns_with_condition(
                collection="course_work_instances",
                condition={"_id": schedule_id},
                columns={"start_time": 1, "start_date": 1})
            if schedule_work_info["status"] != 200:
                raise Exception("Some internal error occurred, please try again later.")
            db_work_start_time = Content.webapp_time_to_string(
                schedule_work_info["message"][0]["start_date"], schedule_work_info["message"][0]["start_time"])
            db_work_start_time = datetime.datetime.strptime(db_work_start_time, "%Y:%m:%dT%H:%M")

            new_start_time = Content.webapp_time_to_string(work['date'], work['time'])
            new_start_time = datetime.datetime.strptime(new_start_time, "%Y:%m:%dT%H:%M")

            if timestamp_obj < db_work_start_time and timestamp_obj < new_start_time:
                schedule_course_work_id = update_schedule_course_work(fields_to_update, "course", schedule_id)
                processed_course_work.append({"_id": ObjectId(work['_id']),
                                              "schedule_id": schedule_course_work_id})
            else:
                processed_course_work.append({"_id": ObjectId(work['_id']),
                                              "schedule_id": schedule_id})
        else:  # unpublish
            schedule_course_work_id = update_schedule_course_work(fields_to_update, "course", schedule_id)
            processed_course_work.append({"_id": ObjectId(work['_id']),
                                          "schedule_id": schedule_course_work_id})
    # topics - refactored
    processed_topics, instance_ids_topics, delete_list_temp_files, delete_resource_list = refactored_topics. \
        edit_course_topics(topics, unique_assess, user_id, course_status, delete_list_temp_files, timestamp_obj,
                           delete_resource_list, course_class)

    if len(delete_list_temp_files) > 0:
        delete_temp_files = mongo_session.delete_record_temp_uploaded_files(collection="temp_uploaded_files",
                                                                            id_list=delete_list_temp_files)
        if delete_temp_files['status'] == 400:
            raise Exception("Some internal error occurred, Try again later.")
    if len(delete_resource_list) > 0:
        insert_date_temp_delete_course_resource = mongo_session.insert_date_temp_delete_course_resource_edit_course(
            collection="course_resource_bank", temp_record="temp_uploaded_files",
            records_to_modify=delete_resource_list)
        if insert_date_temp_delete_course_resource['status'] == 400:
            raise Exception("Some internal error occurred, Try again later.")

    # schedule live sessions - no need to refactor
    if live_sessions:
        if course_data.get('subscribers'):
            if course_data['subscribers']:
                live_sessions, created_live_sessions = schedule_live_sessions(live_sessions, course_id,
                                                                              subscribers=course_data['subscribers'])
            else:
                live_sessions, created_live_sessions = schedule_live_sessions(live_sessions, course_id)
        else:
            live_sessions, created_live_sessions = schedule_live_sessions(live_sessions, course_id)

    # delete live sessions if any - no need to refactor
    if live_sessions_to_del:
        for sess in live_sessions_to_del:
            zoom_app = Zoom(jwt_api_key=sess["zoom_account"]["api_key"],
                            jwt_secret_key=sess["zoom_account"]["secret_key"],
                            zoom_email=sess["zoom_account"]["email"])
            zoom_jwt_token = zoom_app.generate_jwt_token()
            delete_meeting = zoom_app.delete_meeting(jwt_token=zoom_jwt_token,
                                                     meetingID=sess["meeting_details"]["meeting_id"])
    course_update_data = {"course_category_id": ObjectId(category_id),
                          "course_category": category,
                          "subject": subject,
                          "learning_objectives": learning_objectives,
                          "banner_img": banner_img,
                          "authors": authors,
                          "instructors": processed_instructors,
                          "editors": processed_editors,
                          "teach_assis": processed_assistants,
                          "organisations": processed_organisations,
                          "live_sessions": live_sessions,
                          "resources": course_resources,
                          "course_assessments": processed_assessments,
                          "course_work": processed_course_work,
                          "topics": processed_topics,
                          "status": course_status,
                          "requirement": requirement,
                          "what_will_you_learn": what_will_you_learn,
                          "updated_at": Question.indian_standard_time()}

    document_updated = mongo_session.update_multiple_fields(collection='courses_bank',
                                                            condition={"_id": ObjectId(course_id)},
                                                            set_columns=course_update_data)
    # updating course details in ES
    insert_to_es(doc_id=str(course_id), description=learning_objectives, data_title=subject)
    used_at = {"$set": {"used_at": {'course_id': ObjectId(course_id)}}}
    condition = {"_id": {"$in": instance_ids}}
    updation = mongo_session.update_db_data(collection='resource_bank_instance', condition=condition,
                                            update_info=used_at, multi=True)

    user_ids = []
    admins = [user_id]
    inst = [inst['_id'] for inst in instructors]
    edit = [ed['_id'] for ed in editors]
    admins.extend(inst)
    admins.extend(edit)
    admins = list(set(admins))

    room_id = mongo_session.check_existance_return_info(collection='chat_rooms',
                                                        condition={"course_id": ObjectId(course_id)})
    if room_id:
        update_course_groupchat(user_id=user_id, room_id=room_id, admins=admins, group_name=subject)

    if document_updated['status'] == 200:
        if document_updated['document_updated'] == 1 and course_status == "publish":
            user_ids = []
            subscribers_info = mongo_session.check_existance_return_info(collection="courses_bank",
                                                                         condition={"_id": ObjectId(course_id)},
                                                                         columns={"subscribers": 1},
                                                                         return_keys=["subscribers"])
            if not subscribers_info:
                subscribers_info = []
            if subscribers_info.get('subscribers'):
                for user in subscribers_info['subscribers']:
                    user_ids.append(user['user_id'])

            device_tokens = mongo_session.get_device_tokens(collection="user_profile",
                                                            condition={"_id": {"$in": user_ids},
                                                                       "user_device_tokens": {"$exists": True}},
                                                            columns={"user_device_tokens": 1, "_id": 0})

            data_message = {"courseId": course_id, "click_action": "FLUTTER_NOTIFICATION_CLICK",
                            "module_name": "CourseUpdated", "courseName": subject}
            message_title = "Course Updated"
            message_body = "A course you are subscribed to has been updated"
            if device_tokens['status'] == 200:
                firebase_response = Notification.notify_multiple_users(user_id_list=user_ids,
                                                                       device_tokens=device_tokens['message'],
                                                                       data_message=data_message,
                                                                       message_title=message_title,
                                                                       message_body=message_body)
                if firebase_response['status'] == 200:
                    notification_status = firebase_response['notification_status']
            return "Updated Successfully", 200
        elif document_updated['document_updated'] == 1:
            return "Success", 200
        else:
            return "course isn't updated", 200
    else:
        return document_updated['message'], document_updated['status']


def course_deactivate(course_id, user_id, permissions):
    if config.deactivate_course not in permissions:
        raise InvalidUsage("You don't have permission to deactivate a course.", 403)
    if mongo_session.check_existance(collection="courses_bank",
                                     condition={"_id": ObjectId(course_id),
                                                "active": False}):
        raise InvalidUsage("You cannot deactivate an already deactivated course.", 400)
    update_course_status = mongo_session.update_record_into_db(
        collection="courses_bank",
        condition={"_id": ObjectId(course_id)},
        update_info={"$set": {"active": False, "deactivated_by": ObjectId(user_id)}})
    if update_course_status["status"] != 200:
        raise Exception("Some internal error, Please try again later.")
    return "Course successfully deactivated."


def assign_subs_teach_assis(user_id, role, course_id, course_work_id, cw_schedule_id, assignee_data):
    """assign subscribers to teaching assistants(TA).
    :param user_id: user who is assigning assignee(subscribers/teams) to TA.
    :param role: role of the allocator.
    :param course_id: target course for TA assignment.
    :param course_work_id: if group course work, assign TA to individual teams.
    :param cw_schedule_id: instance id for the course work.
    :param assignee_data: object containing data for TA's and assignee(subscribers/teams).
    :type user_id: str (mongo_id)
    :type course_id: str (mongo_id)
    :type course_work_id: str(mongo_id)
    :type cw_schedule_id: str(mongo_id)
    :type assignee_data: list
    """
    course_info = mongo_session.check_existance_return_info(collection="courses_bank",
                                                            condition={"_id": ObjectId(course_id)},
                                                            columns={"teach_assis": 1,
                                                                     "editors": 1,
                                                                     "instructors": 1,
                                                                     "is_public": 1,
                                                                     "organisations": 1,
                                                                     "subscribers": 1,
                                                                     "created_by": 1},
                                                            return_keys=["_id",
                                                                         "teach_assis",
                                                                         "editors",
                                                                         "instructors",
                                                                         "is_public",
                                                                         "organisations",
                                                                         "subscribers",
                                                                         "created_by"])
    if not course_info:
        raise InvalidUsage("Bad Request", 400)

    # allocator: only owner of course/editors/instructors/super_admin are allowed.
    course_info["instructors"].extend(course_info["editors"])
    allocators = [str(user["_id"]) for user in course_info["instructors"]] if course_info["instructors"] else []
    allocators.append(str(course_info["created_by"]))
    if role != "super_admin" and user_id not in allocators:
        raise InvalidUsage("You are not an authorised user to perform this operation.", 403)

    if course_work_id and cw_schedule_id:
        cw_schedule_info = mongo_session.check_existance_return_info(collection="course_work_instances",
                                                                     condition={"_id": ObjectId(cw_schedule_id)},
                                                                     columns={"group_type": 1,
                                                                              "start_date": 1,
                                                                              "start_time": 1,
                                                                              "teams": 1,
                                                                              "teach_assis": 1},
                                                                     return_keys=["group_type",
                                                                                  "start_date",
                                                                                  "start_time",
                                                                                  "teams",
                                                                                  "teach_assis"])
        if not cw_schedule_info or not cw_schedule_info["group_type"]:
            raise InvalidUsage("Oops, something went wrong. Please try again later.", 400)
        if not cw_schedule_info["teams"]:
            raise InvalidUsage("There are no teams as of now to assign to teaching assistant.", 400)
        # validate whether the course work has started or not
        timestamp = Question.indian_standard_time()
        timestamp_obj = datetime.datetime.strptime(timestamp, "%d %b %Y, %I:%M %p")

        start_time = Content.webapp_time_to_string(cw_schedule_info["start_date"], cw_schedule_info["start_time"])
        start_time = datetime.datetime.strptime(start_time, "%Y:%m:%dT%H:%M")

        if timestamp_obj < start_time:
            raise InvalidUsage("Please wait for course work to start before assigning Teaching Assistants.", 400)
        # course level teaching assistants
        cl_teach_assistants = [str(assis["_id"]) for assis in course_info["teach_assis"]]
        cw_teams = [team["name"] for team in cw_schedule_info["teams"]]
        # course work level teaching assistants
        cw_teach_assistants = []
        for data in assignee_data:
            if data["teach_assis"] not in cl_teach_assistants:
                raise InvalidUsage("Please assign Teaching Assistants before assigning teams to them.", 400)
            data["assignees"] = [{"team_name": user,
                                  "assigned_by": ObjectId(user_id)} for user in data["assignees"] if
                                 user in cw_teams]
            cw_teach_assistants.append({"_id": ObjectId(data["teach_assis"]),
                                        "assignees": data["assignees"],
                                        "created_at": utc_datetime_now(),
                                        "created_by": ObjectId(user_id)})
        # update data in courses
        mongo_session.update_record_into_db(collection="course_work_instances",
                                            condition={"_id": ObjectId(cw_schedule_id)},
                                            update_info={"$set": {"teach_assis": cw_teach_assistants}})
    else:
        # course level TA assignment
        # filter subscribers based on whether course is public or not.
        users_list = [user["user_id"] for user in course_info["subscribers"]]

        org_list = [org["_id"] for org in course_info["organisations"]]

        # if course is not public then only allowed organisation's subscribers should be included
        if course_info["is_public"]:
            user_condition = {"_id": {"$in": users_list}, "role": "student"}
        else:
            user_condition = {"role": "student",
                              "$and": [{"_id": {"$in": users_list}},
                                       {"organisation_id": {"$in": org_list}}]}

        user_query = mongo_session.access_specific_fields(
            collection='user_profile',
            condition=user_condition,
            columns={"username": 1,
                     "organisation": 1},
            return_keys=["username", "organisation", "_id"])

        if not user_query:
            raise InvalidUsage("No one has subscribe this course yet", 400)
        subscribers = [user["_id"] for user in user_query]

        if not subscribers:
            raise InvalidUsage("No one has subscribe this course yet", 400)

        for assistant in course_info["teach_assis"]:
            for data in assignee_data:
                if data["teach_assis"] == str(assistant["_id"]):
                    assistant["assignees"] = [{"_id": ObjectId(user),
                                               "assigned_by": ObjectId(user_id)} for user in data["assignees"] if
                                              validate_ObjectId(user) and ObjectId(user) in subscribers]

        # update data in courses
        mongo_session.update_record_into_db(collection="courses_bank",
                                            condition={"_id": ObjectId(course_id)},
                                            update_info={"$set": {"teach_assis": course_info["teach_assis"]}})
    return "Success"


def fetch_subs_teach_assis(user_id, role, course_id, course_work_id, cw_schedule_id):
    """fetch subscribers assigned to teaching assistants(TA).
    :param user_id: user who is accessing subscribers assigned to TA.
    :param role: role of the accessor.
    :param course_id: target course for TA details.
    :param course_work_id: if group course work, get assignees(teams) assigned to TA.
    :param cw_schedule_id: instance id for the course work.
    :type user_id: str (mongo_id)
    :type course_id: str (mongo_id)
    :type course_work_id: str(mongo_id)
    :type cw_schedule_id: str(mongo_id)
    :returns list containing TA and assignee details.
    """
    course_info = mongo_session.check_existance_return_info(collection="courses_bank",
                                                            condition={"_id": ObjectId(course_id)},
                                                            columns={"teach_assis": 1,
                                                                     "editors": 1,
                                                                     "instructors": 1,
                                                                     "subscribers": 1,
                                                                     "created_by": 1,
                                                                     "organisations": 1,
                                                                     "is_public": 1},
                                                            return_keys=["_id",
                                                                         "teach_assis",
                                                                         "editors",
                                                                         "instructors",
                                                                         "subscribers",
                                                                         "created_by",
                                                                         "organisations",
                                                                         "is_public"])
    if not course_info:
        raise InvalidUsage("Bad Request", 400)

    # accessor: only owner of course/editors/instructors/super_admin are allowed.
    course_info["instructors"].extend(course_info["editors"])
    accessors = [str(user["_id"]) for user in course_info["instructors"]] if course_info["instructors"] else []
    accessors.append(str(course_info["created_by"]))

    if role != "super_admin" and user_id not in accessors:
        raise InvalidUsage("You are not an authorised user to access this functionality.", 403)

    # filter subscribers based on whether course is public or not.
    users_list = [user["user_id"] for user in course_info["subscribers"]] if course_info["subscribers"] else []

    org_list = [org["_id"] for org in course_info["organisations"]]

    # if course is not public then only allowed organisation's subscribers should be included
    if course_info["is_public"]:
        user_condition = {"_id": {"$in": users_list}, "role": "student"}
    else:
        user_condition = {"role": "student",
                          "$and": [{"_id": {"$in": users_list}},
                                   {"organisation_id": {"$in": org_list}}]}

    user_query = mongo_session.access_specific_fields(
        collection='user_profile',
        condition=user_condition,
        columns={"_id": 1},
        return_keys=["_id"])

    if not user_query:
        raise InvalidUsage("No one has subscribe this course yet", 400)
    subscribers = [user["_id"] for user in user_query]

    # to reduce db calls
    users_list = []
    teams_dict = {}
    teach_assis_cw_level = []
    if cw_schedule_id and course_work_id:
        cw_schedule_info = mongo_session.check_existance_return_info(collection="course_work_instances",
                                                                     condition={"_id": ObjectId(cw_schedule_id)},
                                                                     columns={"group_type": 1,
                                                                              "start_date": 1,
                                                                              "start_time": 1,
                                                                              "teams": 1,
                                                                              "teach_assis": 1},
                                                                     return_keys=["group_type",
                                                                                  "start_date",
                                                                                  "start_time",
                                                                                  "teams",
                                                                                  "teach_assis"])
        if not cw_schedule_info or not cw_schedule_info["group_type"]:
            raise InvalidUsage("Oops, something went wrong. Please try again later.", 400)

        # teach assistants for that course
        users_list.extend([data["_id"] for data in course_info["teach_assis"]])

        if cw_schedule_info.get("teach_assis") or cw_schedule_info["teach_assis"]:
            # process team members for the course work
            teach_assis_teams = []

            for assis in cw_schedule_info["teach_assis"]:
                teach_assis_cw_level.append(assis["_id"])
                teach_assis_teams.extend([data["team_name"] for data in assis["assignees"]])
            for team in cw_schedule_info["teams"]:
                if team["name"] in teach_assis_teams:
                    teams_dict[team["name"]] = [member["_id"] for member in team["members"]]
                    users_list.extend([member["_id"] for member in team["members"]])
    else:
        for assistant in course_info["teach_assis"]:
            users_list.append(assistant["_id"])
            users_list.extend([data["_id"] for data in assistant["assignees"]])

    # fetch users data from db
    users_info = mongo_session.get_particular_key_value(collection="user_profile",
                                                        condition={"$match": {"_id": {"$in": users_list}}},
                                                        return_info={"$project": {"_id": "$_id",
                                                                                  "username": "$username",
                                                                                  "organisation": "$organisation",
                                                                                  "profile_pic": "$profile_pic"
                                                                                  }
                                                                     },
                                                        all_docs=True)
    users_dict = {}
    for data in users_info:
        data["profile_pic"] = get_profile_pic(s3_key=data["profile_pic"])
        users_dict[str(data["_id"])] = data

    response_data = []
    if cw_schedule_id and course_work_id:
        for assistant in course_info["teach_assis"]:
            if assistant["_id"] not in teach_assis_cw_level:
                assignees = []
            else:
                assistant = [data for data in cw_schedule_info["teach_assis"] if data["_id"] == assistant["_id"]][0]
                assignees = [{"name": team["team_name"],
                              "members": [{"_id": str(member),
                                           "username": users_dict[str(member)]["username"],
                                           "organisation": users_dict[str(member)]["organisation"],
                                           "profile_pic": users_dict[str(member)]["profile_pic"],
                                           "is_subscriber": True if member in subscribers else False} for member in
                                          teams_dict[team["team_name"]]]}
                             for team in assistant["assignees"]]
            response_data.append({"_id": str(assistant["_id"]),
                                  "username": users_dict[str(assistant["_id"])]["username"],
                                  "profile_pic": users_dict[str(assistant["_id"])]["profile_pic"],
                                  "organisation": users_dict[str(assistant["_id"])]["organisation"],
                                  "assignees": assignees})
    else:
        for assistant in course_info["teach_assis"]:
            response_data.append({"_id": str(assistant["_id"]),
                                  "username": users_dict[str(assistant["_id"])]["username"],
                                  "profile_pic": users_dict[str(assistant["_id"])]["profile_pic"],
                                  "organisation": users_dict[str(assistant["_id"])]["organisation"],
                                  "assignees": [{"_id": str(user["_id"]),
                                                 "username": users_dict[str(user["_id"])]["username"],
                                                 "organisation": users_dict[str(user["_id"])]["organisation"],
                                                 "profile_pic": users_dict[str(user["_id"])]["profile_pic"],
                                                 "is_subscriber": True if user["_id"] in subscribers else False}
                                                for user in assistant["assignees"]]})
    return response_data


def get_deactivated_courses(user_id, role, page):
    """
    Get a list of all the deactivated courses from the db and only superadmin has the permission
    to view these courses
    """
    response = []
    if role != "super_admin":
        raise InvalidUsage("You cannot view deactivated courses", 400)

    condition = {"active": False}
    course_query = mongo_session.get_data_for_particular_columns_with_condition(
        collection='courses_bank',
        condition=condition,
        columns={"learning_objectives": 1,
                 "subject": 1,
                 "course_category": 1,
                 "overall_rating": 1,
                 "banner_img": 1,
                 "status": 1,
                 "editors": 1,
                 "instructors": 1,
                 "organisations": 1,
                 "created_by": 1,
                 "course_category_id": 1,
                 "is_public": 1,
                 "subscribers": 1,
                 "active": 1,
                 "_id": 1
                 })
    if course_query['status'] != 200:
        raise InvalidUsage(message="Something went wrong, Please try again later.", status_code=500)
    courses_info = course_query['message']

    if not courses_info:
        raise InvalidUsage("No Deactivated Courses", 400)

    for course_data in courses_info:
        course_dict = {}
        publish_rights = [str(user['_id']) for user in course_data["editors"]] + \
                         [str(user['_id']) for user in course_data["instructors"]] + [str(course_data["created_by"])]

        course_dict["edit_right"] = (True if user_id in publish_rights or role == "super_admin" else False)
        course_dict["_id"] = str(course_data["_id"])
        course_dict["course_category_id"] = str(course_data["course_category_id"])
        course_dict["course_category"] = course_data["course_category"]
        course_dict["created_by"] = str(course_data["created_by"])
        course_dict["active"] = course_data["active"]
        s3_link, s3_status = s3_function.generate_presigned_url_from_s3(course_data['banner_img'])
        if s3_status != 200:
            raise Exception("Error occurred while communicating with s3")
        course_dict["banner_img"] = s3_link
        course_dict["rating"] = course_data["overall_rating"]
        course_dict["subject"] = course_data["subject"]
        course_dict["learning_objectives"] = course_data["learning_objectives"]
        course_dict["course_id"] = str(course_data["_id"])
        course_dict["status"] = course_data["status"]
        course_dict["is_public"] = bool(course_data["is_public"]) if course_data.get("is_public") else False
        course_dict["subscribed"] = False
        if course_data.get("subscribers"):
            subscribers = [str(user["user_id"]) for user in course_data["subscribers"]]
            if user_id in subscribers:
                course_dict["subscribed"] = True
        response.append(course_dict)

    total_courses = 30
    response_data = [response[i: i + total_courses] for i in range(0, len(response), total_courses)]
    if int(page) > len(response_data):
        response = []
        raise InvalidUsage("No Content Available on this Page", 400)
    else:
        message = "Data retrieved successfully"
        response = {"total_pages": len(response_data), "data": response_data[int(page) - 1], "current_page": int(page)}
    return response


def reactivate_course(user_id, role, course_id):
    if role != "super_admin":
        raise InvalidUsage("You cannot reactivate this course", 400)

    update_info = {"$set": {"active": True}}
    condition = {"_id": ObjectId(course_id)}
    response = mongo_session.update_db_data(collection="courses_bank",
                                            condition=condition,
                                            update_info=update_info)

    response = {"message": "Course reactivated successfully !"}
    return response


def get_reviews(user_id, course_id, rating_sort):
    course_data = mongo_session.access_specific_fields(collection='courses_bank',
                                                       condition={'_id': ObjectId(course_id)})[0]
    if course_data.get('Rating'):
        response = dict()
        response['overall_rating'] = round(course_data['overall_rating'], 1)
        total_reviews = len(course_data['Rating'])
        one, two, three, four, five = 0, 0, 0, 0, 0
        for rating in course_data['Rating']:
            user_details = User_Profile(user_id=str(rating['user_id']))
            rating['user_name'] = '{} {}'.format(user_details[0]['first_name'], user_details[0]['last_name'])
            rating['username'] = user_details[0]['username']
            rating['edit'] = True if str(rating['user_id']) == str(user_id) else False
            rating['review'] = rating['review'] if rating.get('review') else ""
            if int(rating['Rating']) == 1:
                one += 1
            elif int(rating['Rating']) == 2:
                two += 1
            elif int(rating['Rating']) == 3:
                three += 1
            elif int(rating['Rating']) == 4:
                four += 1
            elif int(rating['Rating']) == 5:
                five += 1
        stars = {'one_star': "{:.1f}".format(round((one / total_reviews) * 100, 1)),
                 'two_star': "{:.1f}".format(round((two / total_reviews) * 100, 1)),
                 'three_star': "{:.1f}".format(round((three / total_reviews) * 100, 1)),
                 'four_star': "{:.1f}".format(round((four / total_reviews) * 100, 1)),
                 'five_star': "{:.1f}".format(round((five / total_reviews) * 100, 1))}
        response['stars'] = stars
        response['reviews'] = course_data['Rating']
    else:
        response = dict()
        response['overall_rating'] = course_data['overall_rating']
        response['reviews'] = []
        response['stars'] = {
            "five_star": "0.0",
            "four_star": "0.0",
            "one_star": "0.0",
            "three_star": "0.0",
            "two_star": "0.0"
        }
    if "latest" in rating_sort:
        response["reviews"].reverse()
    elif "A2Z" in rating_sort:
        response["reviews"] = sorted(response["reviews"], key=lambda k: (k['user_name'].lower(), k['user_name']))
    return response


def delete_review(user_id, course_id):
    course_data = mongo_session.access_specific_fields(collection='courses_bank',
                                                       condition={'_id': ObjectId(course_id)})[0]
    if course_data.get('Rating'):
        if mongo_session.access_specific_fields(collection='courses_bank',
                                                condition={'_id': ObjectId(course_id), 'Rating.user_id': str(user_id)}):
            idx = 0
            count = 0
            overall_rating = 0
            for rating in course_data['Rating']:
                if str(rating['user_id']) == str(user_id):
                    idx = count
                overall_rating += rating['Rating']
                count += 1
            course_data['Rating'].pop(idx)

            one, two, three, four, five = 0, 0, 0, 0, 0
            for rating in course_data['Rating']:
                if int(rating['Rating']) == 1:
                    one += 1
                elif int(rating['Rating']) == 2:
                    two += 1
                elif int(rating['Rating']) == 3:
                    three += 1
                elif int(rating['Rating']) == 4:
                    four += 1
                elif int(rating['Rating']) == 5:
                    five += 1
            total_rating = ((5 * five) + (4 * four) + (3 * three) + (2 * two) + (1 * one)) / len(course_data['Rating'])
            mongo_session.update_db_data(collection='courses_bank',
                                         condition={'_id': ObjectId(course_id)},
                                         update_info={'$set': {'Rating': course_data['Rating']}})
            mongo_session.update_db_data(collection='courses_bank',
                                         condition={'_id': ObjectId(course_id)},
                                         update_info={'$set': {'overall_rating': total_rating}})
            return {'message': 'Deleted Successfully'}
        else:
            return {'message': 'No review to delete.'}
    else:
        return {'message': 'No review to delete.'}


def get_course_classes():
    """
    To retrieve the classes of the course.
    """
    data = mongo_session.get_all_data(collection='course_class')["message"]
    return data


def get_public_courses():
    """
    Retrieve top-rated courses for Edu-Collab.
    """
    output = []
    for data in mongo_session.get_all_data_for_particular_condition_fields(collection='courses_bank',
                                                                           condition={'is_public': True})["message"]:
        user_data = mongo_session.get_all_data_for_particular_condition_fields(collection='user_profile',
                                                                               condition={'_id': ObjectId(
                                                                                   str(data['created_by']))})[
            "message"][0]
        name = "{} {}".format(user_data.get('name',""), user_data.get('last_name', ""))
        data_out = {'banner_img': s3_function.generate_presigned_url_from_s3(data['banner_img'])[0],
                    'course_category': data['course_category'],
                    'course_category_id': str(data['course_category_id']),
                    'course_id': str(data['_id']),
                    'created_by': str(data['created_by']),
                    'learning_objectives': data['learning_objectives'],
                    'rating': data['overall_rating'],
                    'status': data['status'],
                    'subject': data['subject'],
                    'subscribers_length': len(data['subscribers']) if data.get('subscribers') else 0,
                    'created_by_name': name}
        output.append(data_out)
    output = sorted(output, key=lambda d: (d['subscribers_length'], d['rating']))
    output.reverse()
    return output


def view_assesments(course_id, role, user_id):
    asses_data = mongo_session.check_existance_return_info(collection="courses_bank",
                                                                condition={"_id": ObjectId(course_id)},
                                                                columns={"active" : 1, "course_assessments": 1},
                                                                return_keys=["course_assessments"])
    if not asses_data:
        raise InvalidUsage("Bad Request", 400)

    # course assessments - refactored
    course_assessments = refactored_assessments.view_course_course_assessments(asses_data, user_id, role, course_id)
    return course_assessments, "Data retrieved successfully", 200


def view_resources(course_id):
    resources_data = mongo_session.check_existance_return_info(collection="courses_bank",
                                                                condition={"_id": ObjectId(course_id)},
                                                                columns={"active" : 1, "resources": 1},
                                                                return_keys=["resources"])
    if not resources_data:
        raise InvalidUsage("Bad Request", 400)

    # course resources - no need to refactor
    for resource in resources_data["resources"]:
        if resource['type'] == 'file':
            if resource.get('schedule_id'):
                resource['schedule_id'] = str(resource['schedule_id'])
            if resource.get('instance_id'):
                resource['instance_id'] = str(resource['instance_id'])
            resource['_id'] = str(resource['_id'])
            resource['url'], s3_status = s3_function.generate_presigned_url_from_s3(resource['url'])
            if s3_status != 200:
                raise InvalidUsage("Error occurred while communicating with s3", 500)

    return resources_data["resources"], 'success', 200


def view_coursework(course_id, user_id, role):
    course_data = mongo_session.get_all_data_for_particular_condition_fields(collection="courses_bank",
                                                                condition={"_id": ObjectId(course_id), "active": True})["message"][0]
    # course work list
    processed_course_work = []

    # Self Paced Course
    course_class = course_data.get('course_class', None)
    if course_class:
        course_class = mongo_session.access_specific_fields(collection='course_class',
                                                            condition={'_id': ObjectId(course_class)})[0]['value']
    else:
        course_class = 'Old Structure'

    for work in course_data["course_work"]:
        course_work_query = mongo_session.get_all_data_for_particular_condition_fields(
            collection="course_work_bank",
            condition={"_id": ObjectId(work["_id"])})
        if course_work_query['status'] != 200:
            raise InvalidUsage("Something went wrong, please try again later.", 500)
        work_data = course_work_query['message'][0]
        schedule_work_query = mongo_session.get_all_data_for_particular_condition_fields(
            collection="course_work_instances",
            condition={"_id": ObjectId(work["schedule_id"])})
        if schedule_work_query['status'] != 200:
            raise InvalidUsage("Something went wrong, please try again later.", 500)
        schedule_data = schedule_work_query['message'][0]

        for resource in work_data["course_work_resources"]:
            if resource['resource_type'] == 'file':
                if resource.get('schedule_id'):
                    resource['schedule_id'] = str(resource['schedule_id'])
                resource['resource_id'] = str(resource['resource_id'])
                if resource.get('instance_id'):
                    resource['instance_id'] = str(resource['instance_id'])
                if resource.get('schedule_id'):
                    resource['schedule_id'] = str(resource['schedule_id'])
                if resource.get('_id'):
                    resource['_id'] = str(resource['_id'])
                resource['resource_url'], s3_status = s3_function.generate_presigned_url_from_s3(
                    resource['resource_url'])
                if s3_status != 200:
                    raise InvalidUsage("Error occurred while communicating with s3", 500)

        course_work_resources = work_data["course_work_resources"]
        current_date = str(utc_datetime_now().date()).split('-')
        data = {"_id": str(work['_id']),
                "course_work_resources": course_work_resources,
                "title": work_data['courseWorkTitle'],
                "is_group": work_data["is_group"],
                "date": schedule_data["start_date"] if course_class != 'Self Paced Course' else {'year': int(current_date[0]),'month': int(current_date[1]),'day': int(current_date[2])},
                "time": schedule_data["start_time"] if course_class != 'Self Paced Course' else "00:00",
                "schedule_id": str(work["schedule_id"]),
                "course_id": course_id
                }
        # Added code for peer review and self review
        if schedule_data.get('peer_review'):
            if schedule_data['peer_review'] == True and not schedule_data["group_type"]:
                data['peer_review'] = True
            else:
                data['peer_review'] = False
        else:
            data['peer_review'] = False

        if schedule_data.get('self_review'):
            if schedule_data['self_review'] == True and not schedule_data["group_type"]:
                data['self_review'] = True
            else:
                data['self_review'] = False
        else:
            data['self_review'] = False

        processed_course_work.append(data)
    return processed_course_work, "success", 200


def view_instructors(course_id, role, user_id, organisation):
    response = {}
    processed_inst = []
    processed_assis = []
    publish_right = True
    instructors_data = mongo_session.check_existance_return_info(
        collection="courses_bank",
        condition={"_id": ObjectId(course_id)},
        columns={"active": 1,
                 "instructors":1,
                 "teach_assis":1,
                 "created_by":1,
                 "status":1,
                 "organisations":1,
                 "editors":1,
                 "is_public":1,
                 "subscribers":1},
        return_keys=["_id", "teach_assis", "instructors", "active", "created_by", "status", "organisations","editors","is_public","subscribers"])
    if not instructors_data:
        raise InvalidUsage("Bad Request", 400)

    publish_rights = [str(user['_id']) for user in instructors_data["editors"]] + \
                     [str(user['_id']) for user in instructors_data["instructors"]] + [str(instructors_data["created_by"])]
    publish_right = True
    if role != "super_admin":
        if instructors_data['status'] == "unpublish":
            if user_id not in publish_rights:
                raise InvalidUsage("Course is not published yet", 500)
        if instructors_data['status'] == "publish":
            org_list = [org["_id"] for org in instructors_data["organisations"]]
            organisation_query = mongo_session.get_all_data_for_particular_condition_fields(
                collection="organisations",
                condition={"name": organisation}
            )
            if organisation_query['status'] != 200:
                raise InvalidUsage("Something went wrong, please try again later.", 500)
            if (ObjectId(organisation_query['message'][0]['_id']) not in org_list) and (user_id not in publish_rights) \
                    and not instructors_data['is_public']:
                raise InvalidUsage("You don't have access to this course", 403)
        if user_id not in publish_rights:
            publish_right = False
    
    #instructors - no need to refactor
    for inst in instructors_data["instructors"]:
        inst_query = mongo_session.get_data_for_particular_columns_with_condition(
            collection="user_profile",
            condition={"_id": inst['_id']},
            columns={'username': 1, 'role': 1, 'organisation': 1, 'profile_pic':1})

        if inst_query['status'] != 200:
            raise InvalidUsage("Something went wrong, please try again later.", 500)

        if inst_query['message'][0]['profile_pic'] == None:
            s3_link = ''
        else: 
            s3_link, s3_status = s3_function.generate_presigned_url_from_s3(inst_query['message'][0]['profile_pic'])
            if s3_status != 200:
                raise InvalidUsage("Error occurred while communicating with s3.", 500)
        processed_inst.append({"_id": str(inst["_id"]), "name": inst_query['message'][0]['username'],
                               "role": inst_query['message'][0]['role'],
                               "organisation": inst_query['message'][0]['organisation'], "profile_pic":s3_link})

    #teaching assistant - no need to refactor
    for assis in instructors_data["teach_assis"]:
        assis_query = mongo_session.get_data_for_particular_columns_with_condition(
            collection="user_profile",
            condition={"_id": assis['_id']},
            columns={'username': 1, 'role': 1, 'organisation': 1, 'profile_pic':1})

        if assis_query['status'] != 200:
            raise InvalidUsage("Something went wrong, please try again later.", 500)
        if assis_query['message'][0]['profile_pic'] == None:
            s3_link = ''
        else: 
            s3_link, s3_status = s3_function.generate_presigned_url_from_s3(assis_query['message'][0]['profile_pic'])
            if s3_status != 200:
                raise InvalidUsage("Error occurred while communicating with s3.", 500)
        processed_assis.append({"_id": str(assis["_id"]), "username": assis_query['message'][0]['username'],
                               "role": assis_query['message'][0]['role'],
                               "organisation": assis_query['message'][0]['organisation'],"profile_pic":s3_link})

    check = False
    for subscriber in instructors_data['subscribers']:
        if user_id  == str(subscriber['user_id']):
            response["teach_assis"] = processed_assis
            response["instructors"] = processed_inst
            response["active"] = instructors_data['active']
            response["publish_right"] = publish_right
            check = True
            break
    if not check:
        response["instructors"] = processed_inst
        response["active"] = instructors_data['active']
        response["publish_right"] = publish_right

    return response, 'success', 200


def view_topics(course_id, user_id, role):
    if role == "super_admin":
        course_condition={
            "_id": ObjectId(course_id)
        }
    else:
        course_condition = {
            "_id": ObjectId(course_id),
            "active": True
        }
    course_query = mongo_session.get_all_data_for_particular_condition_fields(
        collection='courses_bank',
        condition=course_condition)
    if course_query['status'] != 200:
        raise InvalidUsage("Something went wrong, Please try again later.", 500)
    course_data = course_query['message'][0]

    # topics - refactored
    response = refactored_topics.view_course_topics(course_data, user_id, role, course_id, topic_list = True)
    return response, 'success', 200


def view_live_sessions(course_id, role, user_id):
    if role == "super_admin":
        course_condition={
            "_id": ObjectId(course_id)
    }
    else:
        course_condition = {
            "_id": ObjectId(course_id),
            "active": True
    }
    course_query = mongo_session.get_all_data_for_particular_condition_fields(
        collection='courses_bank',
        condition=course_condition)

    if course_query['status'] != 200:
        raise InvalidUsage("Something went wrong, Please try again later.", 500)
    course_data = course_query['message'][0]

    publish_rights = [str(user['_id']) for user in course_data["editors"]] + \
                     [str(user['_id']) for user in course_data["instructors"]] + [str(course_data["created_by"])]

    # Live Sessions - refactored
    live_sessions = refactored_sessions.view_course_live_sessions(course_data, user_id, publish_rights,
                                                                              role)
    return live_sessions, 'success', 200


def view_coursework_single(course_id, user_id, role,course_work_id):
    if role == "super_admin":
        course_condition={
            "_id": ObjectId(course_id)
        }
    else:
        course_condition = {
            "_id": ObjectId(course_id),
            "active": True
        }
    course_query = mongo_session.get_all_data_for_particular_condition_fields(
        collection='courses_bank',
        condition=course_condition)
   
    if course_query['status'] != 200:
        raise InvalidUsage("Something went wrong, Please try again later.", 500)
    course_data = course_query['message'][0]
  
    coursework  = refactored_courseworks.view_course_coursework(course_data=course_data, user_id=user_id, role=role, course_work_id=course_work_id)
    return coursework


def catalogue_new(role, user_id, organisation, publish=None, course_category_id=None, subscription_status=None, page=None, page_name=None):
    response = []
    if course_category_id and subscription_status:
        condition = {"active": True,
                     "course_category_id": ObjectId(course_category_id),
                     "subscribers.user_id": ObjectId(user_id)}
    elif course_category_id:
        condition = {"active": True, "course_category_id": ObjectId(course_category_id)}
    elif subscription_status:
        condition = {"active": True, "subscribers.user_id": ObjectId(user_id)}
    elif role == 'teacher':
        if publish == "publish":
            condition = {"active": True, "status":"publish", "created_by":ObjectId(user_id)}
        elif publish == "unpublish":
            condition = {"active": True, "status":"unpublish", "created_by":ObjectId(user_id)}
        else:
            condition = {"active": True,"created_by":ObjectId(user_id)}
    else:
        if publish == "publish":
            condition = {"active": True, "status":"publish"}
        elif publish == "unpublish":
            condition = {"active": True, "status":"unpublish"}  
        else:
            condition = {"active": True}
    course_query = mongo_session.get_data_for_particular_columns_with_condition(
        collection='courses_bank',
        condition=condition)
    if course_query['status'] != 200:
        raise InvalidUsage(message="Something went wrong, Please try again later.", status_code=500)
    courses_info = course_query['message']

    for course_data in courses_info:
        course_dict = {}
        publish_rights = [str(user['_id']) for user in course_data["editors"]] + \
                         [str(user['_id']) for user in course_data["instructors"]] + [str(course_data["created_by"])]

        course_dict["edit_right"] = (True if user_id in publish_rights or role == "super_admin" else False)
        course_dict["course_category_id"] = str(course_data["course_category_id"])
        course_dict["course_category"] = course_data["course_category"]
        s3_link, s3_status = s3_function.generate_presigned_url_from_s3(course_data['banner_img'])
        if s3_status != 200:
            raise Exception("Error occurred while communicating with s3")
        course_dict["banner_img"] = s3_link
        if course_data.get('Rating'):
            course_dict['rating_count'] = len(course_data['Rating'])
        else:
            course_dict['rating_count'] = 0

        course_dict["rating"] = course_data["overall_rating"]
        course_dict["subject"] = course_data["subject"]
        course_dict["course_id"] = str(course_data["_id"])
        course_dict["status"] = course_data["status"]
        course_dict["is_public"] = bool(course_data["is_public"]) if course_data.get("is_public") else False
        course_dict["subscribed"] = False
        if course_data.get("subscribers"):
            subscribers = [str(user["user_id"]) for user in course_data["subscribers"]]
            if user_id in subscribers:
                course_dict["subscribed"] = True
        response.append(course_dict)

    if not subscription_status and not course_category_id and not page:
        message = "Data retrieved successfully"
        return response, message
    elif subscription_status and not page:
        if not response:
            raise InvalidUsage("No Subscribed Courses", 400)
        else:
            message = "Data retrieved successfully"
            return response, message
    elif course_category_id and not page:
        if not response:
            raise InvalidUsage("No Courses available in this Category", 400)
        else:
            message = "Data retrieved successfully"
            return response, message
    elif subscription_status and course_category_id and not page:
        if not response:
            raise InvalidUsage("No Subscribed Courses", 400)
        else:
            message = "Data retrieved successfully"
            return response, message
    elif subscription_status and course_category_id and page:
        if not response:
            raise InvalidUsage("No Subscribed Courses", 400)
    elif subscription_status and page:
        if not response:
            raise InvalidUsage("No Subscribed Courses", 400)
    elif course_category_id and page:
        if not response:
            raise InvalidUsage("No Courses available in this Category", 400)

    total_courses = 10
    total_courses_count = len(response)
    response = response[::-1]
    response_data = [response[i: i + total_courses] for i in range(0, len(response), total_courses)]

    if page_name == 'teach' and page:
        response_data = [x for x in response if x["edit_right"] == True]
        response_data = [response_data[i: i + total_courses] for i in range(0, len(response_data), total_courses)]
    elif page_name == 'learner' and page:
        response_data = [x for x in response if x["subscribed"] == True]
        response_data = [response_data[i: i + total_courses] for i in range(0, len(response_data), total_courses)]
    elif page_name == 'other' and page:
        if role == 'student':
            response_data = [x for x in response if x["subscribed"] == False]
            response_data = [response_data[i: i + total_courses] for i in range(0, len(response_data), total_courses)]
        else:
            response_data = [x for x in response if x["edit_right"] == False]
            response_data = [response_data[i: i + total_courses] for i in range(0, len(response_data), total_courses)]

    if int(page) > len(response_data):
        response = []
        raise InvalidUsage("No Content Available on this Page", 400)
    else:
        message = "Data retrieved successfully"
        response = {
            "total_courses": total_courses_count,
            "total_pages": len(response_data),
            "data": response_data[int(page) - 1],
            "current_page": int(page)
        }
   
    return response, message

