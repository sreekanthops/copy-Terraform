from bson import ObjectId
from db_wrapper.tasks import Mongo
from model.assessment.utils import send_confirmation_email
from config import email_Address, email_password
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from flask import render_template
import smtplib

mongo_session = Mongo()

def mute_chat_notification(mute, user_id):
    """
        function to implement mute and unmute the chat notification
    """
    update_taxonomy_status = mongo_session.update_record_into_db(
        collection="user_profile",
        condition={"_id": ObjectId(user_id)},
        update_info={"$set": {'mute': mute}})
    if update_taxonomy_status["status"] != 200:
        raise Exception("Some internal error, Please try again later.")
    # print(mute)
    if mute:
        message = "Your chat notifications are muted"
    else:
        message = "Your chat notifications are unmuted"
    return {"message": message, "status": 200}


def block_user(block, user_id, target_user_id):
    """
        function to block or unblock user
    """
    if block:
        check = mongo_session.get_all_data_for_particular_condition_fields(collection="user_profile",
                                                                            condition={"_id": ObjectId(user_id),
                                                                                "blocked_users": {"$elemMatch": {"$eq": target_user_id}}})["message"]
        if len(check) == 0:
            update_taxonomy_status = mongo_session.update_record_into_db(
                collection="user_profile",
                condition={"_id": ObjectId(user_id)},
                update_info={"$push": {'blocked_users': target_user_id}})
            if update_taxonomy_status["status"] != 200:
                raise Exception("Some internal error, Please try again later.")
            message = "User has been added to blocked users"
        else:
            message = "User is already part of blocked users"
    else:
        check = mongo_session.get_all_data_for_particular_condition_fields(collection="user_profile",
                                                                            condition={"_id": ObjectId(user_id),
                                                                                "blocked_users": {"$elemMatch": {"$eq": target_user_id}}})["message"]
        if len(check) > 0:
            update_taxonomy_status = mongo_session.update_record_into_db(
                collection="user_profile",
                condition={"_id": ObjectId(user_id)},
                update_info={"$pull": {'blocked_users': target_user_id}})
            if update_taxonomy_status["status"] != 200:
                raise Exception("Some internal error, Please try again later.")
            message = "User has been removed from blocked users"
        else:
            message = "User is not part of blocked users"
    return {"message": message, "status": 200}


def report_user(user_id, target_user_id, reported_by_username, reported_by_email, message):
    """
        function to report user
    """
    check = mongo_session.get_all_data_for_particular_condition_fields(collection="user_profile",
                                                                            condition={"_id": ObjectId(user_id),
                                                                                "blocked_users": {"$elemMatch": {"$eq": target_user_id}}})["message"]
    if len(check) == 0:
        update_taxonomy_status = mongo_session.update_record_into_db(
            collection="user_profile",
            condition={"_id": ObjectId(user_id)},
            update_info={"$push": {'blocked_users': target_user_id}})
        if update_taxonomy_status["status"] != 200:
            raise Exception("Some internal error, Please try again later.")
    
    try:
        subject = "Report Chat User"
        reported_user = mongo_session.get_all_data_for_particular_condition_fields(collection="user_profile",
                                                                            condition={"_id": ObjectId(target_user_id)})["message"][0]
        mail_sent = send_report_email(subject=subject,
                                        reported_username=reported_user['username'],
                                        reported_user_email=reported_user['email'],
                                        reported_by_username=reported_by_username,
                                        reported_by_email=reported_by_email, 
                                        message=message)
    except Exception as e:
        print(e)
        raise Exception("error in sending report email")

    if mail_sent:
        message = "User has been reported"
    return {"message": message, "status": 200}


def send_report_email(subject, reported_username, reported_user_email, reported_by_username, reported_by_email, message):
    """
        :param template_path: path in the project where the template of the email is stored
        :type template_path: str(path)
    """

    password = email_password
    sender_email = email_Address

    super_admin_email_list = mongo_session.get_all_data_for_particular_condition_fields(collection="user_profile",
                                                                            condition={"role": "super_admin"})["message"]

    for admin in super_admin_email_list:
        receiver_email = admin['email']
        msg = MIMEMultipart('alternative')
        msg['Subject'] = subject
        msg['From'] = sender_email
        msg['To'] = receiver_email

        name = admin['name'] + " " + admin['last_name']
        template_path = "report_user"
        confirmation_message = render_template(template_path + ".txt",
                                            name=name,
                                            reported_by_username=reported_by_username,
                                            reported_by_email=reported_by_email,
                                            reported_username=reported_username,
                                            reported_user_email=reported_user_email,
                                            message=message)
        email_text = MIMEText(confirmation_message, 'plain')
        msg.attach(email_text)

        text = msg.as_string()
        # context = ssl.create_default_context()
        # with smtplib.SMTP_SSL("smtp.gmail.com", 465, context=context) as server:
        #     server.login(sender_email, password)
        #     server.sendmail(sender_email, receiver_email, text)

        # PK - Email Service Migration
        smtp = smtplib.SMTP(host="172.31.6.215", port=25)
        smtp.sendmail(sender_email, receiver_email, text)
        smtp.close()
    return True