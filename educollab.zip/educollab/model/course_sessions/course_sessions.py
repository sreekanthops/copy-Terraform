import json
import re

import pandas as pd
import youtube_dl

from config import supported_image_content_type, supported_video_content_type, supported_content_type_with_extension, \
    s3_connection, bucket
from bson import ObjectId

from model import User
from mongo_connection import connection
import datetime
import model.Content as Content
import model.Question as Question
from routes.exception import InvalidUsage
from services.storage.s3_services import s3_storage

from utils.misc import validate_ObjectId, renew_s3_links, get_profile_pic
from utils.time_conversions import utc_datetime_now

s3_function = s3_storage()

from db_wrapper.tasks import Mongo

mongo_session = Mongo()

import time
from utils import time_conversions, misc
from model.zoom import Zoom
from fuzzywuzzy import process
import copy
from model.courses.misc import seen_asess_feedback


def add_session_notes_summary(user_id, session_id, title, content, course_id, topic_id, note_type, timestamp,
                              image_path, resources, video_path):
    """New notes structure with timestamp
    1. If note_type is note then add a note in the session and if note_type is summary then add summary on same
    session.
    2. Collection: course_sessions_notes will contain both notes and summary can be differentiated using type.
    3. Based on the session id fetch course_id and topic_id. Check whether the course is active or not and whether user
    is entitled to add note or not."""

    if not validate_ObjectId(session_id):
        raise InvalidUsage("Bad Request.", 400)
    check_topic_id = mongo_session.check_existance_return_info(collection="course_topics",
                                                               condition={"sessions._id": ObjectId(session_id)})
    check_course_id = mongo_session.check_existance_return_info(collection="courses_bank",
                                                                condition={"topics._id": topic_id, "active": True})
    # check whether session exists or not also whether topic_id and course_id are correct
    if not (check_course_id != course_id and check_topic_id != topic_id and session_id):
        raise InvalidUsage("Bad Request.", 400)

    check_existence = mongo_session.check_existance_return_info(collection="course_sessions",
                                                                condition={"_id": ObjectId(session_id)})
    if not check_existence:
        raise InvalidUsage("Bad Request.", 400)
    # process_content
    content = misc.replace_s3_links_with_keys(content)
    # current datetime
    utc_dtime = time_conversions.utc_datetime_now()
    if note_type == "note":
        data_to_insert = {"title": title.strip(),
                          "course_id": ObjectId(course_id),
                          "topic_id": ObjectId(topic_id),
                          "session_id": ObjectId(session_id),
                          "user_id": ObjectId(user_id),
                          "type": "note",
                          "created_at": utc_dtime,
                          "content": content,
                          "active": True,
                          "timestamp": timestamp,
                          "resources": resources,
                          "image_path": image_path,
                          "video_path": video_path}
        message = "It's a good practice to make notes"
    elif note_type == "summary":
        # check if student has already made summary on this session
        note_condition = {"session_id": ObjectId(session_id),
                          "user_id": ObjectId(user_id),
                          "type": "summary"}
        check_summary_exist = mongo_session.check_existance_return_info(collection="course_sessions_notes",
                                                                        condition=note_condition)
        if check_summary_exist:
            raise InvalidUsage("Summary already exist, try to edit it.", 400)

        data_to_insert = {"course_id": course_id,
                          "topic_id": topic_id,
                          "session_id": ObjectId(session_id),
                          "user_id": ObjectId(user_id),
                          "type": "summary",
                          "created_at": utc_dtime,
                          "content": content,
                          "timestamp": timestamp}

        message = "It's a good practice to summarize your lectures"
    else:
        raise InvalidUsage("Please pass correct type. Available values are 'note' and 'summary'", 400)
    insert_note = mongo_session.insert_documnet(collection='course_sessions_notes',
                                                doc_to_insert=data_to_insert)
    return str(insert_note['_id'].inserted_id), message


def edit_session_notes_summary(course_id, user_id, session_id, topic_id, title, content, role, note_type, _id,
                               timestamp, image_path, resources, video_path):
    """if note_type is note then edit a note in the session and if note_type is summary then edit summary on same
    session. """
    if not (course_id and topic_id and session_id):
        raise InvalidUsage("Bad Request.", 400)
    if not validate_ObjectId(_id):
        raise InvalidUsage("Bad Request.", 400)
    check_existence = mongo_session.access_specific_fields(collection="course_sessions_notes",
                                                           condition={"_id": ObjectId(_id),
                                                                      "course_id": ObjectId(course_id),
                                                                      "topic_id": ObjectId(topic_id),
                                                                      "session_id": ObjectId(session_id),
                                                                      "type": note_type},
                                                           columns={"user_id": 1, "_id": 1},
                                                           return_keys=["user_id", "_id"])
    if not check_existence:
        raise InvalidUsage("Bad Request", 400)
    # to validate user
    db_user = [record["user_id"] for record in check_existence if str(record["_id"]) == _id]
    if not db_user or str(db_user[0]) != user_id:
        raise InvalidUsage("Unauthorised Access", 401)
    # process_content
    content = misc.replace_s3_links_with_keys(content)
    # current datetime
    utc_dtime = time_conversions.utc_datetime_now()
    if image_path:
        image_path = [i.split("?")[0].split(".com/")[1] if "https" in i else i for i in image_path]
    if resources:
        resources = [i.split("?")[0].split(".com/")[1] if "https" in i else i for i in resources]
    if note_type == "note":
        update_info = {"$set": {"created_at": utc_dtime,
                                "content": content,
                                "title": title,
                                "timestamp": timestamp,
                                "resources": resources,
                                "image_path": image_path,
                                "video_path": video_path}}
        message = "Note updated."
    elif note_type == "summary":
        update_info = {"$set": {"created_at": utc_dtime,
                                "content": content,
                                "timestamp": timestamp}}
        message = "Summary updated."
    else:
        raise InvalidUsage("Please pass correct type. Available values are 'note' and 'summary'", 400)
    update_session = mongo_session.update_record_into_db(
        collection="course_sessions_notes",
        condition={"_id": ObjectId(_id),
                   "type": note_type,
                   "session_id": ObjectId(session_id)},
        update_info=update_info)
    if update_session["status"] != 200:
        raise Exception("Some internal error occurred, Please try again later.")
    return message


def delete_session_notes_summary(user_id, session_id, note_type, _id):
    """Purpose: soft delete a note and delete summary on session.
       Parameters:
           1. user_id : only the user who created can delete it.
           2. session_id: course session id
           3. note_type: summary/note
           4. _id: note_id/summary_id
    """
    if not session_id:
        raise InvalidUsage("Bad Request.", 400)
    if not validate_ObjectId(_id):
        raise InvalidUsage("Bad Request.", 400)
    check_existence = mongo_session.access_specific_fields(collection="course_sessions_notes",
                                                           condition={"_id": ObjectId(_id),
                                                                      "session_id": ObjectId(session_id),
                                                                      "type": note_type},
                                                           columns={"user_id": 1, "_id": 1},
                                                           return_keys=["user_id", "_id"])[0]
    if not check_existence:
        raise InvalidUsage("Bad Request", 400)
    # to validate user
    if str(check_existence["user_id"]) != user_id:
        raise InvalidUsage("Unauthorised attempt to delete", 401)
    # delete record from the database
    status = ""
    if check_existence:
        status = mongo_session.delete_records("course_sessions_notes", condition={"_id": ObjectId(_id)})
    # check if deleted
    if status == 200:
        res = "note deleted successfully"
    else:
        raise Exception("Failed to delete assessment")
    # else:
    #     raise InvalidUsage("Please pass correct type. Available value is 'note'", 400)
    return res
