from model.Content import category_taxonomy_by_category_id
from mongo_connection import connection
from bson import ObjectId
from db_wrapper.tasks import Mongo
from db_wrapper.fetch_functions import Fetch
from routes.exception import InvalidUsage
from services.storage.s3_services import s3_storage
from config import es, ES_GLOBAL_SEARCH_COURSE, ES_GLOBAL_SEARCH_QUESTION, ES_GLOBAL_SEARCH_SESSION, \
    ES_GLOBAL_SEARCH_MOSAIC
from utils.time_conversions import convert_utc_to_ist

fetch_session = Fetch()
mongo_session = Mongo()
s3_function = s3_storage()


def find_course(search_text, content_type, user_id, login_user_other_details):
    """searching the courses by title and description."""
    courses_collection = connection.courses_bank
    topic_collection = connection.course_topics
    response = []
    body = {
        "query": {
            "multi_match": {
                "query": None,
                "type": "bool_prefix",
                "fields": [
                    "title"
                ]
            }
        },
        "size": 100
    }
    body["query"]["multi_match"]["query"] = "{}".format(search_text)
    elastic_response = es.search(index=ES_GLOBAL_SEARCH_COURSE,
                                 body=body)
    all_options = elastic_response['hits']['hits']
    search_list = []
    # organisation
    org_id = str(login_user_other_details["organisation_id"])
    user_query = mongo_session.get_all_data_for_particular_condition_fields(collection="user_profile",
                                                                            condition={"_id": ObjectId(user_id)})[
        'message'][0]
    for doc_item in all_options:
        obj_id = doc_item['_source']['obj_id']
        doc_url = doc_item['_source']['url']
        search_type = doc_item['_source']['search_type']
        if str(obj_id) in search_list:
            continue
        search_list.append(str(obj_id))
        if search_type == "course" and content_type == "course":
            course_query = mongo_session.get_data_for_particular_columns_with_condition(
                collection="courses_bank",
                condition={"_id": ObjectId(obj_id),
                           "status": "publish",
                           "active": True,
                           "$or": [{"is_public": True},
                                   {"organisations": {"$elemMatch": {"_id": ObjectId(org_id)}}}]
                           },
                columns={"course_category": 1,
                         "course_category_id": 1,
                         "subject": 1,
                         "overall_rating": 1,
                         "learning_objectives": 1,
                         "banner_img": 1
                         })
            if course_query["status"] != 200 or not course_query['message']:
                continue
            course_data = course_query['message'][0]
            s3_link, s3_status = s3_function.generate_presigned_url_from_s3(course_data['banner_img'])
            if s3_status != 200:
                continue
            data = {"id": str(obj_id),
                    "title": course_data["subject"],
                    "description": course_data["learning_objectives"],
                    "link": doc_url,
                    "rating": str(course_data['overall_rating']),
                    "banner_img": s3_link,
                    "type": search_type,
                    "count": "",
                    "category": []
                    }
            response.append(data)
    return response


def find_session(search_text, content_type, user_id, login_user_other_details):
    """searching the courses by title and description."""
    courses_collection = connection.courses_bank
    topic_collection = connection.course_topics
    response = []
    body = {
        "query": {
            "multi_match": {
                "query": None,
                "type": "bool_prefix",
                "fields": [
                    "title"
                ]
            }
        },
        "size": 100
    }
    body["query"]["multi_match"]["query"] = "{}".format(search_text)
    elastic_response = es.search(index=ES_GLOBAL_SEARCH_SESSION,
                                 body=body)
    all_options = elastic_response['hits']['hits']
    search_list = []
    # organisation
    org_id = str(login_user_other_details["organisation_id"])
    user_query = mongo_session.get_all_data_for_particular_condition_fields(collection="user_profile",
                                                                            condition={"_id": ObjectId(user_id)})[
        'message'][0]
    for doc_item in all_options:
        obj_id = doc_item['_source']['obj_id']
        doc_url = doc_item['_source']['url']
        search_type = doc_item['_source']['search_type']
        if str(obj_id) in search_list:
            continue
        search_list.append(str(obj_id))
        if search_type == 'session' and content_type == 'session':
            course_category = []
            data = {}
            session_query = mongo_session.get_data_for_particular_columns_with_condition(
                collection="course_sessions",
                condition={"_id": ObjectId(obj_id)})
            if session_query["status"] != 200 or not session_query['message']:
                continue
            session_data = session_query['message']
            for session in session_data:
                session_s3_link, s3_status = s3_function.generate_presigned_url_from_s3(session['url'])
                if "https" in session['url']:
                    data = {"id": str(obj_id),
                            "title": session.get('title'),
                            "description": session.get('description'),
                            "link": session['url'],
                            "type": search_type,
                            "video_type": session["type"],
                            "course_status": "unsubscribed",
                            "banner_img": "",
                            "topic_id": "",
                            "course_id": "",
                            "course_category_id": "",
                            "course_name": "",
                            "course_category": []
                            }
                else:
                    session_s3_link, s3_status = s3_function.generate_presigned_url_from_s3(session['url'])
                    if s3_status != 200:
                        continue
                    data = {"id": str(obj_id),
                            "title": session.get('title'),
                            "description": session.get('description'),
                            "link": session_s3_link,
                            "type": search_type,
                            "video_type": session["type"],
                            "course_status": "unsubscribed",
                            "banner_img": "",
                            "topic_id": "",
                            "course_id": "",
                            "course_category_id": "",
                            "course_name": "",
                            "course_category": []
                            }
            for course in user_query['subscribed_courses']:
                if str(course["course_id"]) == doc_url:
                    data['course_status'] = "subscribed"
            topic_query = mongo_session.get_data_for_particular_columns_with_condition(
                collection="course_topics",
                condition={"sessions": {"$elemMatch": {"_id": ObjectId(session_data[0]["_id"])}}})
            if not topic_query["message"]:
                continue
            topic_data = topic_query["message"][0]
            data["topic_id"] = str(topic_data.get("_id"))
            course_query = mongo_session.get_data_for_particular_columns_with_condition(
                collection="courses_bank",
                condition={"topics": {"$elemMatch": {"_id": ObjectId(topic_query["message"][0]["_id"])}}},
                columns={"_id", "course_category_id", "course_category", "subject", "status"})
            if not course_query["message"]:
                continue
            course_data = course_query["message"][0]
            course_category.append(course_data["course_category"])
            data["course_id"] = str(course_data.get("_id", ""))
            data["course_category_id"] = str(course_data.get("course_category_id", ""))
            data["course_name"] = str(course_data.get("subject", ""))
            data["course_category"] = course_category
            if course_data["status"] == "publish":
                response.append(data)
            elif course_data["status"] == "unpublish":
                continue
    return response


def find_question(search_text, content_type, user_id, login_user_other_details):
    """searching the courses by title and description."""
    courses_collection = connection.courses_bank
    topic_collection = connection.course_topics
    response = []
    body = {
        "query": {
            "multi_match": {
                "query": None,
                "type": "bool_prefix",
                "fields": [
                    "title"
                ]
            }
        },
        "size": 100
    }
    body["query"]["multi_match"]["query"] = "{}".format(search_text)
    elastic_response = es.search(index=ES_GLOBAL_SEARCH_QUESTION,
                                 body=body)
    all_options = elastic_response['hits']['hits']
    search_list = []
    # organisation
    org_id = str(login_user_other_details["organisation_id"])
    user_query = mongo_session.get_all_data_for_particular_condition_fields(collection="user_profile",
                                                                            condition={"_id": ObjectId(user_id)})[
        'message'][0]
    for doc_item in all_options:
        obj_id = doc_item['_source']['obj_id']
        doc_url = doc_item['_source']['url']
        search_type = doc_item['_source']['search_type']
        if str(obj_id) in search_list:
            continue
        search_list.append(str(obj_id))
        if search_type == 'question' and content_type == 'question':
            ques_query = mongo_session.get_data_for_particular_columns_with_condition(
                collection="question_bank",
                condition={"_id": ObjectId(obj_id)})
            if ques_query["status"] != 200 or not ques_query['message']:
                continue
            ques_data = ques_query['message'][0]
            course_category = mongo_session.get_all_data_for_particular_condition_fields(
                collection="Course_Category",
                condition={"_id": ques_data["course_category_id"]})["message"][0]

            taxonomy = category_taxonomy_by_category_id(course_category)
            ans_query = mongo_session.get_data_for_particular_columns_with_condition(
                collection="answer_bank",
                condition={"question_id": ObjectId(obj_id), "approval_status": 1},
                columns={"approval_status": 1})
            ans_data = ans_query['message']
            data = {"id": str(obj_id),
                    "title": ques_data["questions"],
                    "user_id": str(ques_data["user_id"]),
                    "description": "",
                    "link": "",
                    "rating": "",
                    "banner_img": "",
                    "type": search_type,
                    "count": str(len(ques_data["answers"])),
                    "category": taxonomy.split(" / "),
                    "approved_answer": str(len(ans_data)),
                    "courseId": str(ques_data.get("course_id", "")),
                    "courseSessionId": str(ques_data.get("course_session_id", "")),
                    "videoTime": str(ques_data.get("video_time", "")),
                    "Timestamp": ques_data["Timestamp"]
                    }
            response.append(data)
    return response


def find_mosaic(search_text, content_type, user_id, login_user_other_details):
    """searching the courses by title and description."""
    courses_collection = connection.courses_bank
    topic_collection = connection.course_topics
    response = []
    body = {
        "query": {
            "multi_match": {
                "query": None,
                "type": "bool_prefix",
                "fields": [
                    "title"
                ]
            }
        },
        "size": 100
    }
    body["query"]["multi_match"]["query"] = "{}".format(search_text)
    elastic_response = es.search(index=ES_GLOBAL_SEARCH_MOSAIC,
                                 body=body)
    all_options = elastic_response['hits']['hits']
    search_list = []
    # organisation
    org_id = str(login_user_other_details["organisation_id"])
    user_query = mongo_session.get_all_data_for_particular_condition_fields(collection="user_profile",
                                                                            condition={"_id": ObjectId(user_id)})[
        'message'][0]
    for doc_item in all_options:
        obj_id = doc_item['_source']['obj_id']
        doc_url = doc_item['_source']['url']
        search_type = doc_item['_source']['search_type']
        if str(obj_id) in search_list:
            continue
        search_list.append(str(obj_id))
        if search_type == 'mosaic' and content_type == 'mosaic':
            tags = []
            project_query = mongo_session.get_data_for_particular_columns_with_condition(
                collection="passion_projects",
                condition={"_id": ObjectId(obj_id)})
            all_tags = mongo_session.get_all_data("global_tags")
            if project_query["status"] != 200 or not project_query['message']:
                continue
            passion_data = project_query['message'][0]
            if all_tags["message"]:
                for tag in passion_data['project_tags']:
                    for t in all_tags["message"]:
                        if tag == t['_id']:
                            tags.append(t['tag'])
            mosaic_s3_link, mosaic_s3_status = s3_function.generate_presigned_url_from_s3(passion_data['project_image'])
            if mosaic_s3_status != 200:
                continue
            mosaic_user_query = mongo_session.get_data_for_particular_columns_with_condition(collection="user_profile",
                                                                                             condition={"_id": ObjectId(
                                                                                                 passion_data[
                                                                                                     'created_by'])},
                                                                                             columns={
                                                                                                 "_id": 1,
                                                                                                 "name": 1,
                                                                                                 "last_name": 1})[
                'message'][0]
            if passion_data.get("is_active"):
                data = {"id": str(obj_id),
                        'title': passion_data['project_title'],
                        'banner_img': mosaic_s3_link,
                        'description': passion_data['project_description'],
                        'category': tags,
                        'created_by': mosaic_user_query,
                        "type": search_type,
                        'mentors': [str(mentors) for mentors in passion_data['project_mentors']],
                        'resources': [str(resources) for resources in passion_data['project_resources']],
                        "is_active": {
                            "value": passion_data['is_active']['value'],
                            "updated_by": str(passion_data['is_active']['updated_by']),
                            "updated_at": passion_data['is_active']['updated_at']
                        }
                        }
            else:
                data = {"id": str(obj_id),
                        'title': passion_data['project_title'],
                        'banner_img': mosaic_s3_link,
                        'description': passion_data['project_description'],
                        'category': tags,
                        'created_by': mosaic_user_query,
                        "type": search_type,
                        'mentors': [str(mentors) for mentors in passion_data['project_mentors']],
                        'resources': [str(resources) for resources in passion_data['project_resources']]
                        }
            response.append(data)
    return response


def find_users_and_message(search_text, content_type, user_id, login_user_other_details):
    """searching the users by name and last name and messages by message."""
    response_array = []
    response = {}
    users_list = []
    messages_list = []
    if content_type == "usersandmessage":
        # users search within organisation
        user_query = mongo_session.get_all_data_for_particular_condition_fields(collection="user_profile",
                                                                                condition={"organisation":
                                                                                               login_user_other_details[
                                                                                                   "organisation"]})[
            'message']
        for user in user_query:
            user_search_temp = user["name"] + " " + user["last_name"]
            if search_text.lower() in user_search_temp.lower():
                if user_id != user["_id"]:
                    user_1 = "room_members." + user_id
                    user_2 = "room_members." + user["_id"]
                    room_status = False
                    request_status = 'not sent'
                    check_room = fetch_session.check_existance_return_info(collection='chat_rooms',
                                                                           condition={
                                                                               user_1: {'$exists': True},
                                                                               user_2: {'$exists': True},
                                                                               "type": {"$exists": False}
                                                                           })
                    room_id = ''
                    if check_room:
                        room_id = str(check_room)
                        request_status = 'accept'
                        room_status = True

                    if not check_room:
                        check_request_status = fetch_session.check_existance_return_info(collection='chat_requests',
                                                                                         condition={"$or": [
                                                                                             {'request_by': ObjectId(
                                                                                                 user_id),
                                                                                                 'request_to': ObjectId(
                                                                                                     user["_id"])},
                                                                                             {'request_by': ObjectId(
                                                                                                 user["_id"]),
                                                                                                 'request_to': ObjectId(
                                                                                                     user_id)}
                                                                                         ]},
                                                                                         return_keys=['_id', 'status',
                                                                                                      'request_by',
                                                                                                      'request_to'])

                        if check_request_status:
                            if check_request_status['status'] == 'decline':
                                request_status = 'decline'

                            elif check_request_status['status'] == '' and str(
                                    check_request_status['request_by']) == user_id:
                                request_status = 'pending'

                            elif check_request_status['status'] == '' and str(
                                    check_request_status['request_to']) == user_id:
                                request_status = 'invites'

                    user_s3_path = ""
                    if user["profile_pic"]:
                        user_s3_path, s3_status = s3_function.generate_presigned_url_from_s3(user['profile_pic'])
                        if s3_status != 200:
                            continue
                    # block to get last message sent in room
                    # db.sales.aggregate(
                    # [
                    #     { $sort: { item: 1, date: 1 } },
                    #     {
                    #     $group:
                    #         {
                    #         _id: "$item",
                    #         lastSalesDate: { $last: "$date" }
                    #         }
                    #     }
                    # ]
                    # )
                    print(room_id)
                    messages_in_room = mongo_session.get_all_data_for_particular_condition_fields(collection="messages",
                                                                                                  condition={
                                                                                                      "room_id": room_id})
                    # for message in messages_in_room:
                    # print(messages_in_room)
                    data = {"id": str(user["_id"]),
                            "name": user.get("name", ""),
                            "last_name": user.get("last_name", ""),
                            "type": "users",
                            "created_at": convert_utc_to_ist(user['registered_at']).replace(tzinfo=None),
                            "avatar_url": user_s3_path,
                            "institute_type": user["institute_type"],
                            "organisation_name": user["organisation"],
                            "request_status": request_status,
                            "role": user["role"],
                            "room_id": room_id,
                            "room_status": room_status,
                            "username": user.get("username", "")}
                    users_list.append(data)

        # message search: one to one message and group message
        message_sender_query = mongo_session.get_data_for_particular_columns_with_condition(collection="messages",
                                                                                            condition={
                                                                                                "sender_id": ObjectId(
                                                                                                    user_id)},
                                                                                            columns={
                                                                                                "_id": 1,
                                                                                                "message": 1,
                                                                                                "sender_id": 1,
                                                                                                "receivers": 1,
                                                                                                "created_at": 1,
                                                                                                "room_id": 1
                                                                                            })["message"]
        if message_sender_query:
            for messages in message_sender_query:
                msg = messages["message"].lower() if messages["message"] else messages["message"]
                if msg:
                    if search_text.lower() in msg:
                        receivers = []
                        sender_query = \
                            mongo_session.get_data_for_particular_columns_with_condition(collection="user_profile",
                                                                                         condition={"_id": ObjectId(
                                                                                             messages["sender_id"])},
                                                                                         columns={
                                                                                             "_id": 1,
                                                                                             "name": 1,
                                                                                             "last_name": 1
                                                                                         })['message'][0]
                        for receiver in messages["receivers"]:
                            receiver_query = \
                                mongo_session.get_data_for_particular_columns_with_condition(collection="user_profile",
                                                                                             condition={
                                                                                                 "username": receiver},
                                                                                             columns={
                                                                                                 "_id": 1,
                                                                                                 "name": 1,
                                                                                                 "last_name": 1
                                                                                             })['message'][0]
                            receivers.append(receiver_query)
                        data = {"id": str(messages["_id"]),
                                "message": messages.get("message", ""),
                                "sender": sender_query,
                                "receivers": receivers,
                                "date": messages.get("created_at", ""),
                                "type": "message",
                                "room_id": messages["room_id"]}
                        messages_list.append(data)
        message_receiver_query = mongo_session.get_data_for_particular_columns_with_condition(collection="messages",
                                                                                              condition={"receivers":
                                                                                                             login_user_other_details[
                                                                                                                 "username"]},
                                                                                              columns={
                                                                                                  "_id": 1,
                                                                                                  "message": 1,
                                                                                                  "sender_id": 1,
                                                                                                  "receivers": 1,
                                                                                                  "created_at": 1
                                                                                              })["message"]
        if message_receiver_query:
            for messages in message_receiver_query:
                msg = messages["message"].lower() if messages["message"] else messages["message"]
                if msg:
                    if search_text.lower() in msg:
                        receivers = []
                        sender_query = \
                            mongo_session.get_data_for_particular_columns_with_condition(collection="user_profile",
                                                                                         condition={"_id": ObjectId(
                                                                                             messages["sender_id"])},
                                                                                         columns={
                                                                                             "_id": 1,
                                                                                             "name": 1,
                                                                                             "last_name": 1
                                                                                         })['message'][0]
                        for receiver in messages["receivers"]:
                            receiver_query = \
                                mongo_session.get_data_for_particular_columns_with_condition(collection="user_profile",
                                                                                             condition={
                                                                                                 "username": receiver},
                                                                                             columns={
                                                                                                 "_id": 1,
                                                                                                 "name": 1,
                                                                                                 "last_name": 1
                                                                                             })['message'][0]
                            receivers.append(receiver_query)
                        data = {"id": str(messages["_id"]),
                                "message": messages.get("message", ""),
                                "sender": sender_query,
                                "receivers": receivers,
                                "date": messages.get("created_at", ""),
                                "type": "message",
                                "room_id": messages["room_id"]}
                        messages_list.append(data)
    if users_list or messages_list:
        response = {"users": users_list,
                    "messages": messages_list}
    response_array.append(response)
    return response_array
