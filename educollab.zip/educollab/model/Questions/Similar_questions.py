# -*- coding: utf-8 -*-


"""
    Finding similar questions related to the question provided
"""
import bson

import services.Embedding as Embedding
from db_wrapper.tasks import Mongo
from model.Content import category_taxonomy_by_category_id
from mongo_connection import connection
from sklearn.feature_extraction.text import TfidfVectorizer
import services.common.translation as translation
import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.decomposition import LatentDirichletAllocation
from sklearn.cluster import KMeans
from sklearn.metrics.pairwise import cosine_similarity
from bson import ObjectId
from sklearn.feature_extraction.text import TfidfVectorizer
import config
from services.storage.s3_services import s3_storage


s3_function = s3_storage()
mongo_session = Mongo()


def fetch_all_translated_questions():
    """fetches translated question from db """
    translated_questions={}
    collection=connection.question_bank
    question_cursor=collection.find({"translated_question":{"$exists":True},"subject":{"$exists":True}},{"translated_question":1,"_id":1,"subject":1})
    for translated_question in question_cursor:
        translated_questions[str(translated_question["_id"])]={"translated_question":translated_question["translated_question"],"subject":translated_question["subject"]}

    return  translated_questions


def find_similarity(asked_question,all_questions,language="en"):
    """find similarity with the current question"""
    cosine_score={}
    Embedding_object = Embedding.Embedding()
    if language!="en":
        asked_question=translation.question_translation(asked_question,dest="en")[0]
    else:
        pass
    current_question_embedding=Embedding_object.get_embedding(asked_question)
    for translated_question_id in all_questions.keys():
        translated_question=all_questions[translated_question_id]["translated_question"]
        subject=all_questions[translated_question_id]['subject']
        translated_question_embedding=Embedding_object.get_embedding(translated_question)
        translation_score=str(cosine_similarity(current_question_embedding,translated_question_embedding))
        translation_score=float(translation_score[2:len(translation_score)-2])
        cosine_score[translation_score]=translated_question_id
    #sorting the score we got to get the top IDs
    score_list=list(cosine_score.keys())
    score_list.sort(reverse=True)
    similar_question_list=[]
    for score in score_list:
        _id=cosine_score[score]
        #translating the question back to original langauge
        #translated_question,language=translation.question_translation(all_questions[_id]["translated_question"]
                                                             #,dest=language)
        translated_question=all_questions[_id]["translated_question"]
        subject=all_questions[_id]["subject"]
        similar_question_list.append({"_id":_id,"question":translated_question,"score":score,"subject":subject})
    return similar_question_list


def get_neighbours(target_tfidf, myHashes, myBuckets):
    hash_length = myHashes[0].shape[1]
    num_hash = len(myHashes)

    powers_of_2 = [2 ** x for x in range(hash_length)]
    to_decimal = np.array(powers_of_2).reshape(hash_length, 1)

    candidate_neighbours = [set() for _ in range(target_tfidf.shape[0])]
    for indx in range(num_hash):
        my_hash = myHashes[indx]
        my_bucket = ((np.sign(target_tfidf.dot(my_hash)) + 1) / 2).dot(to_decimal)
        for test_index in range(target_tfidf.shape[0]):
            candidate_neighbours[test_index] = candidate_neighbours[test_index].union(
                myBuckets[indx][int(my_bucket[test_index])])
    return candidate_neighbours


def get_my_hashes(hash_length,num_hash,my_vocab,matrix,question_queue):
    """return hash"""
    def get_hash_fn(k):
        x = 2*np.random.rand(k,len(my_vocab))-1
        return x.T

    powers_of_2 = [2**x for x in range(hash_length)]
    to_decimal = np.array(powers_of_2).reshape(hash_length,1)

    myHashes = []
    myBuckets = []
    for indx in range(num_hash):
        my_hash = get_hash_fn(hash_length)
        my_buckets = ((np.sign(matrix.dot(my_hash))+1)/2).dot(to_decimal)
        bucket_list = list(my_buckets[:,0])
        bucket_sets = [set() for i in range(2**hash_length)]
        for id in range(len(question_queue)):
            bucket_sets[int(bucket_list[id])].add(id)
        myHashes.append(my_hash)
        myBuckets.append(bucket_sets)
    return myHashes,myBuckets


def get_neighbours_with_lsh(target_id,num_recommendations,candidates,questions_tfidf_matrix):
    """return nearest neighbour"""
    tfidf_neighbours=np.argsort(np.squeeze(questions_tfidf_matrix[candidates].dot(questions_tfidf_matrix[target_id].T).toarray()))[::-1][0:num_recommendations+1]
    tfidf_neighbours=[candidates[x] for x in tfidf_neighbours]
    tfidf_neighbours= [x for x in tfidf_neighbours if x != target_id]
    return tfidf_neighbours


def recommend(asked_question,language):
    """this module recommend the questions"""
    collection = connection.question_bank
    courses_collection=connection.video_questions
    question_queue = []
    if language != "en":
        asked_question = translation.question_translation(asked_question, dest="en")[0]
    else:
        pass
    questions = collection.find({"translated_question": {"$exists": True}}, {"translated_question": 1})
    for question in questions:
        question_queue.append(question["translated_question"])
    if asked_question==None:
        #target_id= -1
        return []
    else:
        target_id = question_queue.index(asked_question)
    tfidf_matrix = TfidfVectorizer(stop_words='english', min_df=2)
    questions_tfidf_matrix = tfidf_matrix.fit_transform(question_queue)
    hash_length = 7
    num_hash = 25
    NUM_RECOMMENDED_ARTICLES = 4
    myHashes, myBuckets = get_my_hashes(hash_length, num_hash, tfidf_matrix.vocabulary_, questions_tfidf_matrix,
                                        question_queue)
    candidates = get_neighbours(questions_tfidf_matrix, myHashes, myBuckets)
    tfidf_neighbours_wlsh = get_neighbours_with_lsh(target_id, NUM_RECOMMENDED_ARTICLES, list(candidates[0]),questions_tfidf_matrix)
    question_recommendation = []
    for id in tfidf_neighbours_wlsh:
        question = question_queue[id]
        question_recommendation.append(question)

    similar_question_list=[]
    for question in question_recommendation:
        question_cursor = collection.find({"translated_question": question})
        for data in question_cursor:
            data["_id"]=str(data["_id"])
            similar_question_list.append(
                {"_id":data["_id"], "question": data["translated_question"],"subject":data["subject"],"reward":data['reward']})
    response = pd.DataFrame(similar_question_list).drop_duplicates().to_dict('records')
    for element in response:
        course_cursor=courses_collection.find({"question_detail.question_id": element['_id']},
              {"question_detail.$": 1, "Course_id": 1, "Week": 1, "video_index": 1,"resume_video":1})
        element['course_id']=""
        element['Week']=""
        element['video_index']=""
        element['resume_video']=""
        for items in course_cursor:
            element['course_id'] = items["Course_id"]
            element['Week'] = items["Week"]
            element['video_index'] = items["video_index"]
            element['resume_video'] = items["resume_video"]
    return response


def prepare_dataset(questions, user_id, cat_filter):
    # category wise filter
    condition = {"user_id": {"$nin": [user_id, 'celery_service']}}
    if cat_filter:
        cat_filter = [ObjectId(category) for category in cat_filter]
        condition['course_category_id'] = {"$in": cat_filter}
    question_collection=connection.question_bank
    question_cursor = list(question_collection.find(condition))
    answer_cursor=connection.answer_bank
    final_doc=pd.DataFrame()
    question_list=list()
    question_id=list()
    for items in question_cursor:
        try:
            if questions:
                if str(items["_id"]) in questions:
                    continue
            question_list.append(items['translated_question'])
            question_id.append(str(items['_id']))
        except:
                pass
    final_doc['question']=question_list
    final_doc['question_id']=question_id
    return final_doc


def create_embedding(dataset):
    bow_transform=CountVectorizer().fit(dataset['question'])
    tf=bow_transform.fit_transform(dataset['question'])
    feature_name=bow_transform.get_feature_names()
    lda=LatentDirichletAllocation(n_components=5)
    x=lda.fit(tf)
    Matrix=lda.transform(tf)
    Matrix=list(Matrix)
    dataset['Embedding'] = Matrix
    dataset['Topic'] = np.argmax(Matrix, axis=1)
    #kmean=KMeans(n_clusters=5).fit(Matrix)
    return lda,feature_name,dataset


def display_topics(model, features_name, no_top_words):
    topic_list = list()
    print('model.components_ :', model.components_.shape)
    for topic_idex, topic in enumerate(model.components_):
        topic_list.append(topic_idex)
    return topic_list


def random_recommend_question(topics,dataset):
    course_id = ""
    course_session_id = ""
    resume_video = ""
    question_recommendation=[]
    question_collection=connection.question_bank
    course_collection=connection.courses_bank
    if len(topics) > 0:
        for item in topics:
            data=dataset.iloc[item]
            question_recommendation.append(data['question_id'])
    else:
        for i in range(0, 15):
            if i in dataset['Topic'].tolist():
                ques_id = (((dataset.loc[dataset['Topic'] == i]).sample())['question_id']).to_string(index=False)
            else:
                ques_id = ((dataset.sample(n=1))['question_id']).to_string(index=False)
            question_recommendation.append(ques_id[1:])
    similar_question_list=[]
    for question in question_recommendation:
        try:
            question_cursor = question_collection.find({"_id": ObjectId(question)})
        except bson.errors.InvalidId:
            continue
        for data in question_cursor:
            data["_id"] = str(data["_id"])
            if data.get("course_id"):
                course_id = str(data["course_id"])
                course_session_id = str(data["course_session_id"])
                resume_video = str(data["video_time"])
                vtt = ""
                transcriptions = {'transcripts': [], 'items': []}
                if course_id and course_session_id:
                    course_session_data = mongo_session.get_all_data_for_particular_condition_fields(
                        collection="course_sessions",
                        condition={"_id": ObjectId(course_session_id)})
                    if course_session_data['message'][0]:
                        video_s3_key = course_session_data['message'][0]['url']
                        transcriptions = mongo_session.access_specific_fields(collection="video_transcriptions",
                                                                              condition={"s3_key": video_s3_key})
                        # adding transcriptions to the searched questions linked to videos
                        if transcriptions:
                            if transcriptions[0].get('vtt'):
                                vtt = transcriptions[0]['vtt'].split('/')[3:]
                                key = '{}/{}'.format(vtt[0], vtt[1])
                                vtt = s3_function.generate_presigned_url_from_s3(s3_key=key)[0]
                            else:
                                vtt = ""
                        else:
                            vtt = ""
                        if transcriptions:
                            transcriptions = transcriptions[0]['transcription']['results']
                            if transcriptions['items']:
                                for t in transcriptions['items']:
                                    t['text'] = t['alternatives'][0]['content']
                                    t.pop('alternatives')
                            else:
                                transcriptions = {'transcripts': [], 'items': []}
                        else:
                            transcriptions = {'transcripts': [], 'items': []}
            else:
                course_id = ""
                course_session_id = ""
                resume_video = ""
                vtt = ""
                transcriptions = {'transcripts': [], 'items': []}
            course_cat = mongo_session.get_all_data_for_particular_condition_fields(
                collection="Course_Category",
                condition={"_id": data["course_category_id"]})["message"][0]

            taxonomy = category_taxonomy_by_category_id(course_cat)
            ans_query = mongo_session.get_data_for_particular_columns_with_condition(
                collection="answer_bank",
                condition={"question_id": ObjectId(str(data['_id'])), "approval_status": 1},
                columns={"approval_status": 1})
            ans_data = ans_query['message']
            similar_question_list.append(
                {"id": str(data["_id"]),
                 "user_id": data["user_id"],
                 "title": data["questions"],
                 "category": taxonomy.split(" / "),
                 "coins": float(data.get('reward', 0.0)),
                 "courseId": course_id,
                 "courseSessionId": course_session_id,
                 "videoTime": resume_video,
                 "approved_answer": str(len(ans_data)) if ans_data else "0",
                 "vtt": vtt,
                 "transcriptions": transcriptions,
                 "count": str(len(data.get("answers", "0"))),
                 "Timestamp": data["Timestamp"]
                 })
    response = pd.DataFrame(similar_question_list).drop_duplicates().to_dict('records')
    return response, question_recommendation


def bottwo(dataset,answered_question):
    article_vectors = dataset['Embedding']
    article_vectors = np.array(article_vectors)
    index_list=[]
    for itr in answered_question:
        question_index = dataset.index[dataset['question_id'] == itr["question_id"]].tolist()
        index_list.append(question_index)
    sum_of_embedding=0
    no_of_question=len(index_list)
    for itr in index_list:
        sum_of_embedding=sum_of_embedding+article_vectors[itr]
    article_vector_1 = sum_of_embedding/no_of_question
    cos_sim = cosine_similarity(article_vector_1[0].reshape(1, -1), article_vectors.tolist())
    sorted_similarity = np.argsort(cos_sim[0], -1)
    top_similarity = sorted_similarity[:15]
    return top_similarity


def botone(user_id,count,answered_question, cat_filter):
    user_collection = connection.user_profile
    answer_collection = connection.answer_bank
    user_query = {"_id": ObjectId(user_id)}
    if count>1 :
        question_list = list(user_collection.find({"_id": ObjectId(user_id)}, {"recommended_question": 1}))
        question_list = question_list[0]['recommended_question'][-5:]
        for question_record in question_list:
            answer_list = list(answer_collection.find({"question_id": question_record, "user_id": user_id
                                                       }))
            if answer_list:
                pass
            else:
                user_collection.update(user_query, {"$push": {"disliked_question": str(question_record)}})
        disliked_list = list(user_collection.find(user_query, {"disliked_question": 1}))[0]['disliked_question'][-5:]
    else:
        disliked_list=None
    dataset = prepare_dataset(disliked_list,user_id, cat_filter)
    lda, feature_name, dataset = create_embedding(dataset)
    if answered_question:
        topics=bottwo(dataset,answered_question)
        response, question_id_list = random_recommend_question(topics,dataset)
    else:
        topics = []
        response, question_id_list = random_recommend_question(topics,dataset)
        print('x', response)

    for question in question_id_list:
        user_collection.update(user_query, {"$push": {"recommended_question": str(question)}})
    return response


def tfidf_function(final_doc):
    tfidf_vectorizer = TfidfVectorizer(use_idf=True)
    tfidf_vectorizer_vectors = tfidf_vectorizer.fit_transform(final_doc['question'])
    cosine_score = cosine_similarity(tfidf_vectorizer_vectors[0], tfidf_vectorizer_vectors)[0]
    final_doc['cosine_scores'] = cosine_score
    return final_doc.sort_values(by=['cosine_scores'],ascending=False)


def find_similarity_search_question_string_matching(search_text, questions, is_similar=None):
    final_doc = pd.DataFrame()
    question_list = list()
    question_id = list()
    question_list.append(search_text)
    question_id.append("search_text")
    for items in questions:
        question_list.append(items['translated_question'])
        question_id.append(items['_id'])
    final_doc['question'] = question_list
    final_doc['question_id'] = question_id

    dataset = tfidf_function(final_doc)

    if is_similar:
        dataset = dataset[dataset['cosine_scores'] > .60]
    similar_question_ids = (dataset['question_id']).to_string(index=False).split('\n')
    similar_questions = []

    for question_id in similar_question_ids[1:]:
        question_data = [dict for dict in questions if (" " + dict['_id']) == question_id]
        similar_questions.append(question_data[0])
    return similar_questions








