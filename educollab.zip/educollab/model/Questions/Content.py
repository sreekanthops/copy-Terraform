import time

from bson import ObjectId

import config
from config import supported_image_content_type
from db_wrapper.tasks import Mongo
from model import Notification
from model.Content import category_taxonomy_by_category_id
from model.Question import indian_standard_time, get_extension_validation
from routes.exception import InvalidUsage
from services.storage.s3_services import s3_storage
from utils.misc import renew_s3_links
from utils.time_conversions import utc_dtime_obj_to_zone_str, utc_datetime_now

mongo_session = Mongo()
s3_function = s3_storage()


def get_questions_info(user_id, cat_filter, sort_by, session_id=None, course_id=None, user_specific=None):
    """
    This function get all questions for
    1. a given session for filter session_id and course_id
    2. all questions asked by user
    :param user_id: questions asked by specific user.
    :type user_id: str
    :param sort_by: to sort the questions
    :type sort_by: str
    :param cat_filter: category wise questions
    :type cat_filter: list
    :param session_id: if question is on some course session
    :type session_id: str
    :param course_id: session belongs to which course.
    :type course_id: str
    :param user_specific: whether to find the user specific questions or not.
    :type user_specific: str(true/false)
    """
    if course_id and session_id:
        condition = {"course_session_id": ObjectId(session_id)}
    elif user_specific == "true" or type(user_specific) == bool and user_specific:
        condition = {"user_id": user_id}
        if cat_filter:
            cat_filter = [ObjectId(category) for category in cat_filter]
            condition['course_category_id'] = {"$in": cat_filter}
    else:
        raise InvalidUsage("Please check request data.", 400)
    question_data = mongo_session.access_specific_fields(collection="question_bank",
                                                         condition=condition)

    if not question_data:
        return []
    # sort filtering
    if sort_by:
        if sort_by == "recent":
            question_data = question_data
        else:
            question_data = sorted(question_data, key=lambda k: len(k['answers']), reverse=True)

    questions_list = []
    for question in question_data:
        question_image_path = ""
        vtt = ""
        question_user_type = ""
        transcriptions = {'transcripts': [], 'items': []}
        if course_id and session_id:
            course_session_data = mongo_session.get_all_data_for_particular_condition_fields(
                collection="course_sessions",
                condition={"_id": ObjectId(session_id)})
            if course_session_data['message'][0]:
                video_s3_key = course_session_data['message'][0]['url']
                transcriptions = mongo_session.access_specific_fields(collection="video_transcriptions",
                                                                      condition={"s3_key": video_s3_key})
                # adding transcriptions to the searched questions linked to videos
                if transcriptions:
                    if transcriptions[0].get('vtt'):
                        vtt = transcriptions[0]['vtt'].split('/')[3:]
                        key = '{}/{}'.format(vtt[0], vtt[1])
                        vtt = s3_function.generate_presigned_url_from_s3(s3_key=key)[0]
                    else:
                        vtt = ""
                else:
                    vtt = ""
                if transcriptions:
                    transcriptions = transcriptions[0]['transcription']['results']
                    if transcriptions['items']:
                        for t in transcriptions['items']:
                            t['text'] = t['alternatives'][0]['content']
                            t.pop('alternatives')
                    else:
                        transcriptions = {'transcripts': [], 'items': []}
                else:
                    transcriptions = {'transcripts': [], 'items': []}

        if question.get("question_image_path") and question["question_image_path"]:
            question_image_path, status = s3_function.generate_presigned_url_from_s3(question['question_image_path'])

        if question["user_id"] == user_id:
            question_user_type = "my_question"
        elif question["user_id"] == 'celery_service':
            question_user_type = "session_question"
        else:
            question_user_type = "others_question"

        course_cat = mongo_session.get_all_data_for_particular_condition_fields(
            collection="Course_Category",
            condition={"_id": question["course_category_id"]})["message"][0]

        taxonomy = category_taxonomy_by_category_id(course_cat)
        ans_query = mongo_session.get_data_for_particular_columns_with_condition(
            collection="answer_bank",
            condition={"question_id": ObjectId(str(question['_id'])), "approval_status": 1},
            columns={"approval_status": 1})
        ans_data = ans_query['message']

        # question_obj = {
        #     'qus_title': question['questions'],
        #     'question_time': question['Timestamp'],
        #     '_id': str(question['_id']),
        #     'course_category_id': str(question["course_category_id"]),
        #     'course_session_id': str(question["course_session_id"]) if question.get("course_session_id") else "",
        #     'course_id': str(question["course_id"]) if question.get("course_id") else "",
        #     'coins': float(question["reward"]),
        #     'video_time': float(question["video_time"]) if question.get("video_time") else 0.0,
        #     'question_image_path': question_image_path,
        #     'answers_count': len(question["answers"]) if question["answers"] else 0,
        #     'course_category': taxonomy.split(" / "),
        #     "vtt": vtt,
        #     "transcriptions": transcriptions,
        #     "question_type": question_user_type,
        #     "approved_answer": len(ans_data) if ans_data else 0
        # }
        question_obj = {"id": str(question['_id']),
                        "user_id": str(question['user_id']),
                        "title": question['questions'],
                        'coins': float(question.get("reward", 0.0)),
                        "count": str(len(question["answers"])) if question["answers"] else "0",
                        "category": taxonomy.split(" / "),
                        "approved_answer": str(len(ans_data)) if ans_data else "0",
                        "courseId": str(question["course_id"]) if question.get("course_id") else "",
                        "courseSessionId": str(question.get("course_session_id", "")),
                        "videoTime": float(question.get("video_time", 0.0)),
                        "Timestamp": question["Timestamp"],
                        "vtt": vtt,
                        "transcriptions": transcriptions,
                        "question_type": question_user_type
                        }
        questions_list.append(question_obj)
    return questions_list


def answer_to_questions(question_id):
    """To return all the details and answer content for particular question"""
    question_data = mongo_session.check_existance_return_info(collection="question_bank",
                                                              condition={"_id": ObjectId(question_id)},
                                                              whole_doc=True)
    if not question_data:
        raise InvalidUsage("Please look for a valid question.", 400)
    question_image_path = []
    question_video_path = []
    question_doc_path = []
    question_image_key = []
    question_video_key = []
    question_doc_key = []

    answer_data = mongo_session.access_specific_fields(collection="answer_bank",
                                                       condition={"question_id": ObjectId(question_id)})
    answers = []
    if answer_data:
        for data in answer_data:
            answer_image_path = []
            answer_video_path = []
            answer_doc_path = []
            answer = {"_id": str(data["_id"]),
                      "course_category": data["course_category"],
                      "user_id": str(data["user_id"]),
                      "created_at": utc_dtime_obj_to_zone_str(data["created_at"])}
            aggregate_rating = float(sum(rating['Rating'] for rating in data['Rating'])) / len(data["Rating"]) if data[
                "Rating"] else 0
            answer["Rating"] = int(round(aggregate_rating, 2))

            for feedback in data['Feedback']:
                feedback["_id"] = str(feedback.get('_id', ''))
                user_info = mongo_session.check_existance_return_info(collection="user_profile",
                                                                      condition={"_id": ObjectId(feedback['user_id'])},
                                                                      columns={"username": 1, "name": 1, "last_name": 1, "profile_pic": 1},
                                                                      return_keys=["username", "name", "last_name", "profile_pic"])
                if user_info:
                    feedback['username'] = user_info['username']
                    feedback["name"] = user_info["name"].capitalize() + " " + user_info["last_name"].capitalize()
                    s3_url, status_code = s3_function.generate_presigned_url_from_s3(user_info['profile_pic'])
                    feedback['profile_pic'] = s3_url
                    feedback['Timestamp'] = utc_dtime_obj_to_zone_str(feedback['Timestamp'])
                    feedback["user_id"] = str(feedback["user_id"])
            answer['Feedback'] = data['Feedback']

            if data.get("video_question"):
                for ques in data["video_question"]:
                    ques["question_id"] = str(ques["question_id"])
                answer["video_question"] = data["video_question"]

            answer["approval_status"] = "approved" if data["approval_status"] == 1 else ""

            # process answer html
            answer['answer_html'] = renew_s3_links(data['answer_html']) if data['answer_html'] else ""

            # process video data if present
            # answer['resource'] = data['video']
            answer['resource'] = {"resource_path": "", "thumbnail": ""}
            if data.get('video'):
                answer['resource']['resource_path'], status = s3_function.generate_presigned_url_from_s3(
                    data['video']['video_path'])
                if data['video'].get('thumbnail'):
                    answer['resource']['thumbnail'], status = s3_function.generate_presigned_url_from_s3(
                        data['video']['thumbnail'])
            # process answer files
            if data.get("answer_video") and data["answer_video"]:
                for a_video in data["answer_video"]:
                    ans_video, status = s3_function.generate_presigned_url_from_s3(a_video)
                    answer_video_path.append(ans_video)
            if data.get("answer_image") and data["answer_image"]:
                for a_image in data["answer_image"]:
                    ans_image, status = s3_function.generate_presigned_url_from_s3(a_image)
                    answer_image_path.append(ans_image)
            if data.get("answer_doc") and data["answer_doc"]:
                for a_files in data["answer_doc"]:
                    ans_doc, status = s3_function.generate_presigned_url_from_s3(a_files)
                    answer_doc_path.append(ans_doc)
            answer["answer_image"] = answer_image_path
            answer["answer_video"] = answer_video_path
            answer["answer_doc"] = answer_doc_path

            answers.append(answer)

    # process question files
    if question_data.get("question_video_path") and question_data["question_video_path"]:
        if isinstance(question_data["question_video_path"], list):
            for q_video in question_data["question_video_path"]:
                question_video, status = s3_function.generate_presigned_url_from_s3(q_video)
                question_video_path.append(question_video)
                question_video_key.append(q_video)
        else:
            question_video, status = s3_function.generate_presigned_url_from_s3(question_data["question_video_path"])
            question_video_path.append(question_video)
            question_video_key.append(question_data["question_video_path"])
    if question_data.get("question_image_path") and question_data["question_image_path"]:
        if isinstance(question_data["question_image_path"], list):
            for q_image in question_data["question_image_path"]:
                question_image, status = s3_function.generate_presigned_url_from_s3(q_image)
                question_image_path.append(question_image)
                question_image_key.append(q_image)
        else:
            question_image, status = s3_function.generate_presigned_url_from_s3(question_data["question_image_path"])
            question_image_path.append(question_image)
            question_image_key.append(question_data["question_image_path"])
    if question_data.get("question_doc_path") and question_data["question_doc_path"]:
        for q_files in question_data["question_doc_path"]:
            question_doc, status = s3_function.generate_presigned_url_from_s3(q_files)
            question_doc_path.append(question_doc)
            question_doc_key.append(q_files)
    # process category taxonomy
    course_category = mongo_session.check_existance_return_info(collection="Course_Category",
                                                                condition={"_id": question_data['course_category_id']},
                                                                whole_doc=True)
    course_category_taxonomy = category_taxonomy_by_category_id(course_category)

    # process answer on which the question was asked.
    answer_id = ""
    answer_video_time = ""
    answer_info_on_ques_asked = mongo_session.access_specific_fields(collection="answer_bank",
                                                                     condition={"video_question.question_id": ObjectId(
                                                                         question_id)})
    if answer_info_on_ques_asked:
        for question_detail in answer_info_on_ques_asked:
            answer_id = str(question_detail['_id'])
            for doc in question_detail['video_question']:
                if str(doc['question_id']) == question_id:
                    answer_video_time = doc['video_time']
    video_time = ""
    course_id = ""
    session_id = ""
    vtt = ""
    transcriptions = {'transcripts': [], 'items': []}
    if question_data.get("course_id"):
        video_time = question_data["video_time"]
        course_id = str(question_data["course_id"])
        session_id = str(question_data["course_session_id"])
        if course_id and session_id:
            course_session_data = mongo_session.get_all_data_for_particular_condition_fields(
                collection="course_sessions",
                condition={"_id": ObjectId(session_id)})
            if course_session_data['message'][0]:
                video_s3_key = course_session_data['message'][0]['url']
                transcriptions = mongo_session.access_specific_fields(collection="video_transcriptions",
                                                                      condition={"s3_key": video_s3_key})
                # adding transcriptions to the searched questions linked to videos
                if transcriptions:
                    if transcriptions[0].get('vtt'):
                        vtt = transcriptions[0]['vtt'].split('/')[3:]
                        key = '{}/{}'.format(vtt[0], vtt[1])
                        vtt = s3_function.generate_presigned_url_from_s3(s3_key=key)[0]
                    else:
                        vtt = ""
                else:
                    vtt = ""
                if transcriptions:
                    transcriptions = transcriptions[0]['transcription']['results']
                    if transcriptions['items']:
                        for t in transcriptions['items']:
                            t['text'] = t['alternatives'][0]['content']
                            t.pop('alternatives')
                    else:
                        transcriptions = {'transcripts': [], 'items': []}
                else:
                    transcriptions = {'transcripts': [], 'items': []}

    return {'answers': answers,
            'answer_id': answer_id,
            'answer_video_time': answer_video_time,
            'question': question_data["questions"],
            'course_category_taxonomy': course_category_taxonomy,
            'question_status': "closed" if question_data['status'] else "open",
            'video_time': video_time,
            'course_id': course_id,
            'course_session_id': session_id,
            'user_id': question_data['user_id'],
            'course_category_id': str(question_data['course_category_id']),
            'reward': question_data['reward'],
            'question_image_path': question_image_path,
            'question_video_path': question_video_path,
            'question_doc_path': question_doc_path,
            'question_image_key': question_image_key,
            'question_video_key': question_video_key,
            'question_doc_key': question_doc_key,
            'course_category': course_category["name"],
            "vtt": vtt,
            "transcriptions": transcriptions,
            "tags": question_data.get('tags', [])}


def fetch_answer_details(answer_id, user_id):
    """function to return answer metadata
    :param answer_id: id of the answer to fetch it's metadata.
    :type answer_id: str
    :param user_id: user who is accessing the answer metadata
    :type user_id: str"""
    answer_info = mongo_session.check_existance_return_info(collection="answer_bank",
                                                            condition={"_id": ObjectId(answer_id)},
                                                            whole_doc=True)
    if not answer_info:
        raise InvalidUsage("Please check request data.", 400)
    # calculate aggregate rating of answer
    aggregate_rating = float(sum(rating['Rating'] for rating in answer_info['Rating'])) / len(answer_info["Rating"]) if \
        answer_info[
            "Rating"] else 0

    # process feedbacks given on answer
    for feedback in answer_info['Feedback']:
        feedback["_id"] = str(feedback.get('_id', ''))
        if feedback.get("Liked"):
            feedback['like_count'] = len(feedback["Liked"])
            feedback["Liked"] = any(user["user_id"] == user_id for user in feedback["Liked"])
        else:
            feedback['like_count'] = 0
            feedback["Liked"] = False
        if feedback.get("Disliked"):
            feedback['dislike_count'] = len(feedback["Disliked"])
            feedback["Disliked"] = any(user["user_id"] == user_id for user in feedback["Disliked"])
        else:
            feedback['dislike_count'] = 0
            feedback["disliked"] = False
        user_info = mongo_session.check_existance_return_info(collection="user_profile",
                                                              condition={"_id": ObjectId(feedback['user_id'])},
                                                              columns={"username": 1},
                                                              return_keys=["username"])
        if user_info:
            feedback['username'] = user_info['username']
        feedback['Timestamp'] = utc_dtime_obj_to_zone_str(feedback['Timestamp'])

    answer_data = {"_id": str(answer_info["_id"]),
                   "user_id": str(answer_info["user_id"]),
                   "course_category": answer_info["course_category"],
                   "question_id": str(answer_info["question_id"]),
                   "speech_text": str(answer_info["speech_text"]),
                   "created_at": utc_dtime_obj_to_zone_str(answer_info["created_at"]),
                   "approval_status": "approved" if answer_info["approval_status"] == 1 else "",
                   "Rating": 1 if aggregate_rating >= 1 else 0,
                   "Feedback": answer_info["Feedback"],
                   "answer_html": renew_s3_links(answer_info['answer_html']) if answer_info['answer_html'] else ""
                   }

    # process if answer is on video question
    if answer_info.get("video_question"):
        for ques in answer_info["video_question"]:
            ques["question_id"] = str(ques["question_id"])
            answer_data["video_question"] = answer_info["video_question"]

    # process video data if present
    answer_data["video"] = answer_info['video']
    if answer_data['video']:
        answer_data['video']['video_path'], status = s3_function.generate_presigned_url_from_s3(
            answer_data['video']['video_path'])
        if answer_data['video'].get('thumbnail'):
            answer_data['video']['thumbnail'], status = s3_function.generate_presigned_url_from_s3(
                answer_data['video']['thumbnail'])

    # process whether user liked the answer or not
    answer_data["Liked"] = any(user["user_id"] == user_id for user in answer_info["Liked"])
    answer_data["Disliked"] = any(user["user_id"] == user_id for user in answer_info["Disliked"])

    # fetch category taxonomy
    course_category = mongo_session.check_existance_return_info(collection="Course_Category",
                                                                condition={"name": answer_info['course_category']},
                                                                whole_doc=True)
    answer_data['course_category_taxonomy'] = category_taxonomy_by_category_id(course_category)

    # process question info
    question_info = mongo_session.check_existance_return_info(collection="question_bank",
                                                              condition={"_id": answer_info["question_id"]},
                                                              columns={"questions": 1, "status": 1},
                                                              return_keys=["questions", "status"])

    answer_data["question"] = question_info["questions"]
    answer_data["question_status"] = "closed" if question_info["status"] else "open"
    return answer_data


def get_other_question(user_id, page, is_extracted, sort_by, cat_filter, total_question):
    """
    This function get all questions for
    all questions asked by other user
    :param user_id: questions asked by other user.
    :type user_id: str
    :param page: page number.
    :type page: int
    :param is_extracted: include/exclude extraction questions from video session transcription
    :type is_extracted: bool
    :param sort_by: to sort the questions
    :type sort_by: str
    :param cat_filter: category wise questions
    :type cat_filter: list
    :param total_question: Number of questions on each page
    :type total_question: int
        """
    # include or exclude extracted questions
    cond = {}
    if is_extracted:
        ques_condition = [user_id]
        cond["user_id"] = {"$nin": ques_condition}
    else:
        ques_condition = ['celery_service', user_id]
        cond["user_id"] = {"$nin": ques_condition}
    # category wise filtering
    if cat_filter:
        cat_filter = [ObjectId(category) for category in cat_filter]
        cond['course_category_id'] = {"$in": cat_filter}
    all_question_data = mongo_session.access_specific_fields(collection="question_bank",
                                                             condition=cond)
    if not all_question_data:
        return []
    # sort filtering
    if sort_by:
        if sort_by == "recent":
            all_question_data = all_question_data
        else:
            all_question_data = sorted(all_question_data, key=lambda k: len(k['answers']), reverse=True)

    questions_list = []
    question_data = [all_question_data[i: i + total_question] for i in range(0, len(all_question_data), total_question)]
    for question in question_data[page - 1]:
        question_image_path = ""
        vtt = ""
        question_user_type = ""
        transcriptions = {'transcripts': [], 'items': []}
        session_id = str(question.get("course_session_id", ""))
        course_id = str(question.get("course_id", ""))
        if course_id and session_id:
            course_session_data = mongo_session.get_all_data_for_particular_condition_fields(
                collection="course_sessions",
                condition={"_id": ObjectId(session_id)})
            if course_session_data['message'][0]:
                video_s3_key = course_session_data['message'][0]['url']
                transcriptions = mongo_session.access_specific_fields(collection="video_transcriptions",
                                                                      condition={"s3_key": video_s3_key})
                # adding transcriptions to the searched questions linked to videos
                if transcriptions:
                    if transcriptions[0].get('vtt'):
                        vtt = transcriptions[0]['vtt'].split('/')[3:]
                        key = '{}/{}'.format(vtt[0], vtt[1])
                        vtt = s3_function.generate_presigned_url_from_s3(s3_key=key)[0]
                    else:
                        vtt = ""
                else:
                    vtt = ""
                if transcriptions:
                    transcriptions = transcriptions[0]['transcription']['results']
                    if transcriptions['items']:
                        for t in transcriptions['items']:
                            t['text'] = t['alternatives'][0]['content']
                            t.pop('alternatives')
                    else:
                        transcriptions = {'transcripts': [], 'items': []}
                else:
                    transcriptions = {'transcripts': [], 'items': []}

        if question.get("question_image_path") and question["question_image_path"]:
            question_image_path, status = s3_function.generate_presigned_url_from_s3(question['question_image_path'])

        if question["user_id"] == user_id:
            question_user_type = "my_question"
        elif question["user_id"] == 'celery_service':
            question_user_type = "session_question"
        else:
            question_user_type = "others_question"

        course_cat = mongo_session.get_all_data_for_particular_condition_fields(
            collection="Course_Category",
            condition={"_id": question["course_category_id"]})["message"][0]

        taxonomy = category_taxonomy_by_category_id(course_cat)
        ans_query = mongo_session.get_data_for_particular_columns_with_condition(
            collection="answer_bank",
            condition={"question_id": ObjectId(str(question['_id'])), "approval_status": 1},
            columns={"approval_status": 1})
        ans_data = ans_query['message']
        question_obj = {"id": str(question['_id']),
                        "user_id": str(question['user_id']),
                        "title": question['questions'],
                        'coins': float(question.get("reward", 0.0)),
                        "count": str(len(question["answers"])) if question["answers"] else "0",
                        "category": taxonomy.split(" / "),
                        "approved_answer": str(len(ans_data)) if ans_data else "0",
                        "courseId": str(question["course_id"]) if question.get("course_id") else "",
                        "courseSessionId": str(question.get("course_session_id", "")),
                        "videoTime": float(question.get("video_time", 0.0)),
                        "Timestamp": question["Timestamp"],
                        "vtt": vtt,
                        "transcriptions": transcriptions,
                        "question_type": question_user_type
                        }
        questions_list.append(question_obj)
    response = {"total_pages": len(question_data), "data": questions_list, "current_page": int(page)}
    return response


def ask_question(question, user_id, language, translated_question, coins, category_id, question_image, question_video,
                 tags, question_doc, coordinates=None):
    """to ask question and add in database"""
    timestamp = indian_standard_time()
    question_image_s3_link = ""
    question_video_s3_link = ""
    question_image_s3_path = None
    question_video_s3_path = None
    available_coin = ""
    message = ""
    notification_status = ""
    # try:
    category_name = mongo_session.get_all_data_for_particular_condition_fields("Course_Category",
                                                                                {"_id": ObjectId(category_id)}
                                                                                )['message'][0]['name']
    file_size = 0
    if question_image:
        for q_image in question_image:
            size, size_status = s3_function.get_size_s3key(q_image)
            file_size = file_size + size
    if question_video:
        for q_video in question_video:
            size, size_status = s3_function.get_size_s3key(q_video)
            file_size = file_size + size
    if question_doc:
        for q_doc in question_doc:
            size, size_status = s3_function.get_size_s3key(q_doc)
            file_size = file_size + size
    if file_size > 20480:
        # print("more than 20 MB")
        raise Exception("File size limit exceeded, Please reduce the size to 20MB")

    insert_doc = {"user_id": user_id,
                    "questions": question,
                    "question_image_path": question_image,
                    "question_video_path": question_video,
                    "course_category_id": ObjectId(category_id),
                    "Course_Category": category_name,
                    "Timestamp": timestamp,
                    "status": False,
                    "answers": [],
                    "reward": coins,
                    "language": language,
                    "translated_question": translated_question,
                    "tags": tags,
                    "question_doc_path": question_doc,
                    "es_flag": False}
    if coordinates:
        insert_doc["coordinates"] = coordinates
    question_cursor_info = mongo_session.insert_data_ask_question(collection="question_bank", record=insert_doc)
    question_cursor = question_cursor_info['message']
    if question_cursor_info['status'] == 200:
        message = "question added"
        user_data_updation = mongo_session.update_user_data_ask_question(collection="user_profile",
                                                                            condition={"_id": ObjectId(user_id)},
                                                                            push_info={
                                                                                "questions": {"_id": question_cursor}},
                                                                            increment_info={"coin": -coins})

    user_cursor = user_data_updation['message']
    for data in user_cursor:
        available_coin = float(round(data['coin'], 2))
    data = str(question_cursor)
    user_ids = [ObjectId(user_id)]
    device_tokens = mongo_session.get_device_tokens(collection="user_profile",
                                                    condition={"_id": {"$in": user_ids},
                                                                "user_device_tokens": {"$exists": True}},
                                                    columns={"user_device_tokens": 1, "_id": 0})
    message_title = "Coins Deducted"
    message_body = "Your coins are deducted for asking a question."
    data_message = {
        "module_name": "Coinsrewarded"
    }
    if device_tokens['status'] == 200:
        firebase_response = Notification.notify_multiple_users(user_id_list=user_ids,
                                                                device_tokens=device_tokens['message'],
                                                                message_title=message_title,
                                                                data_message=data_message,
                                                                message_body=message_body)
    # print("firebase_response", firebase_response)
    if firebase_response['status'] == 200:
        notification_status = firebase_response['notification_status']
    # except Exception as e:
    #     print(e)
    #     data = None
    #     available_coin = None
    #     message = e
    return data, available_coin, question_image_s3_link, question_video_s3_link, message, notification_status


def ask_question_session(question, user_id, language, translated_question, coins, category_id, question_image,
                         question_video, course_id, session_id, video_time, tags, question_doc, coordinates=None):
    """to ask question on session videos and add in database"""
    timestamp = indian_standard_time()
    question_image_s3_link = ""
    question_video_s3_link = ""
    question_image_s3_path = None
    question_video_s3_path = None
    available_coin = ""
    message = ""
    category_name = \
        mongo_session.get_all_data_for_particular_condition_fields("Course_Category", {"_id": ObjectId(category_id)})[
            'message'][0]['name']

    file_size = 0
    if question_image:
        for q_image in question_image:
            size, size_status = s3_function.get_size_s3key(q_image)
            file_size = file_size + size
    if question_video:
        for q_video in question_video:
            size, size_status = s3_function.get_size_s3key(q_video)
            file_size = file_size + size
    if question_doc:
        for q_doc in question_doc:
            size, size_status = s3_function.get_size_s3key(q_doc)
            file_size = file_size + size
    if file_size > 20480:
        raise Exception("File size limit exceeded, Please reduce the size to 20MB")

    insert_doc = {"user_id": user_id,
                  "questions": question,
                  "question_image_path": question_image,
                  "question_video_path": question_video,
                  "course_category_id": ObjectId(category_id),
                  "Course_Category": category_name,
                  "Timestamp": timestamp,
                  "status": False,
                  "answers": [],
                  "reward": coins,
                  "language": language,
                  "translated_question": translated_question,
                  "course_id": ObjectId(course_id),
                  "course_session_id": ObjectId(session_id),
                  "video_time": video_time,
                  "tags": tags,
                  "question_doc_path": question_doc,
                  "es_flag": False}
    if coordinates:
        insert_doc["coordinates"] = coordinates
    question_cursor_info = mongo_session.insert_data_ask_question(collection="question_bank", record=insert_doc)
    question_cursor = question_cursor_info['message']
    if question_cursor_info['status'] == 200:
        message = "question added"
        user_data_updation = mongo_session.update_user_data_ask_question(collection="user_profile",
                                                                         condition={"_id": ObjectId(user_id)},
                                                                         push_info={
                                                                             "questions": {"_id": question_cursor}},
                                                                         increment_info={"coin": -coins})

    user_cursor = user_data_updation['message']
    for data in user_cursor:
        available_coin = float(round(data['coin'], 2))
    data = str(question_cursor)
    session_query = mongo_session.get_data_for_particular_columns_with_condition(
        collection='course_sessions',
        condition={"_id": ObjectId(session_id)},
        columns={"url": 1,
                 "file_id": 1})
    if session_query["status"] != 200:
        raise Exception("Some internal server error, Please try again later.")
    session_file_id = str(session_query["message"][0]["file_id"])
    session_video_link = s3_function.generate_presigned_url_from_s3(session_query["message"][0]["url"]) if \
        session_file_id else session_query["message"][0]["url"]
    return data, available_coin, question_image_s3_link, question_video_s3_link, message, 200, session_video_link, \
           session_file_id


def edit_answer(question_id, answer_id, user_id, answer_html, speech_text, answer_image, answer_video, answer_doc):
    answer_info = mongo_session.check_existance_return_info(collection="answer_bank",
                                                            condition={"_id": ObjectId(answer_id)},
                                                            columns={"user_id": 1, "approval_status": 1},
                                                            return_keys=["user_id", "approval_status"])
    if not answer_info:
        raise InvalidUsage("Sorry this answer is not available right now.", 400)
    # user should not edit other user's answer
    if str(answer_info["user_id"]) != str(user_id):
        raise InvalidUsage("You cannot edit other user's answer.", 403)
    # check answer is approved or not
    if answer_info["approval_status"] == 1:
        raise InvalidUsage("You cannot edit approved answer.", 400)
    # if video_info.get("video_path") and "https" in video_info.get("video_path"):
    #     video_info["video_path"] = video_info["video_path"].split("?")[0].split(".com/")[1]
    # if video_info.get("thumbnail") and "https" in video_info.get("thumbnail"):
    #     video_info["thumbnail"] = video_info["thumbnail"].split("?")[0].split(".com/")[1]
    update_doc = {"answer_html": answer_html,
                  "speech_text": speech_text,
                  "updated_at": utc_datetime_now()}
    file_size = 0
    if answer_image:
        answer_image = [i.split("?")[0].split(".com/")[1] if "https" in i else i for i in answer_image]
        for a_image in answer_image:
            size, size_status = s3_function.get_size_s3key(a_image)
            file_size = file_size + size
    if answer_video:
        answer_video = [i.split("?")[0].split(".com/")[1] if "https" in i else i for i in answer_video]
        for a_video in answer_video:
            size, size_status = s3_function.get_size_s3key(a_video)
            file_size = file_size + size
    if answer_doc:
        answer_doc = [i.split("?")[0].split(".com/")[1] if "https" in i else i for i in answer_doc]
        for a_doc in answer_doc:
            size, size_status = s3_function.get_size_s3key(a_doc)
            file_size = file_size + size
    if file_size > 20480:
        raise Exception("File size limit exceeded, Please reduce the size to 20MB")

    update_doc["answer_image"] = answer_image
    update_doc["answer_video"] = answer_video
    update_doc["answer_doc"] = answer_doc
    update_answer_status = mongo_session.update_record_into_db(
        collection="answer_bank",
        condition={"_id": ObjectId(answer_id)},
        update_info={"$set": update_doc})
    if update_answer_status["status"] != 200:
        raise Exception("Some internal error, Please try again later.")
    return "Answer Edit Successfully", 200


def edit_question(question_id, question, user_id, language, translated_question, coins, reward, category_id,
                  question_image, question_video, tags, question_doc):
    """to edit a question and update in database"""
    timestamp = indian_standard_time()
    category_name = mongo_session.get_all_data_for_particular_condition_fields("Course_Category",
                                                                               {"_id": ObjectId(category_id)}
                                                                               )['message'][0]['name']
    file_size = 0
    if question_image:
        question_image = [i.split("?")[0].split(".com/")[1] if "https" in i else i for i in question_image]
        for q_image in question_image:
            size, size_status = s3_function.get_size_s3key(q_image)
            file_size = file_size + size
    if question_video:
        question_video = [i.split("?")[0].split(".com/")[1] if "https" in i else i for i in question_video]
        for q_video in question_video:
            size, size_status = s3_function.get_size_s3key(q_video)
            file_size = file_size + size
    if question_doc:
        question_doc = [i.split("?")[0].split(".com/")[1] if "https" in i else i for i in question_doc]
        for q_doc in question_doc:
            size, size_status = s3_function.get_size_s3key(q_doc)
            file_size = file_size + size
    if file_size > 20480:
        raise Exception("File size limit exceeded, Please reduce the size to 20MB")
    update_doc = {"questions": question,
                  "question_image_path": question_image,
                  "question_video_path": question_video,
                  "course_category_id": ObjectId(category_id),
                  "Course_Category": category_name,
                  "updated_at": timestamp,
                  "reward": coins,
                  "language": language,
                  "translated_question": translated_question,
                  "tags": tags,
                  "question_doc_path": question_doc}
    update_question_status = mongo_session.update_record_into_db(
        collection="question_bank",
        condition={"_id": ObjectId(question_id)},
        update_info={"$set": update_doc})
    if update_question_status["status"] == 200:
        if reward != 0:
            mongo_session.update_record_into_db(collection="user_profile", condition={"_id": ObjectId(user_id)},
                                                update_info={"$inc": {"coin": -reward}})
    else:
        raise Exception("Some internal error, Please try again later.")
    return "Question Edit Successfully", 200
