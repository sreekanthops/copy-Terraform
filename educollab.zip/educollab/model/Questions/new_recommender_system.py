from sklearn.feature_extraction.text import TfidfVectorizer
import numpy as np
from sklearn.metrics.pairwise import linear_kernel
import random

from model.Content import category_taxonomy_by_category_id
from mongo_connection import connection
from bson import ObjectId
import config
from db_wrapper.tasks import Mongo
from services.storage.s3_services import s3_storage


s3_function = s3_storage()
mongo_session = Mongo()


def rs_check(user_id):
    check = connection['question_tracking'].find_one({"user_id": user_id})
    if check:
        return True
    else:
        return False


def get_recommendation(string, questions, cosine_sim):
    idx = questions.index(string)
    sim_scores = list(enumerate(cosine_sim[idx]))
    sim_scores = sorted(sim_scores, key=lambda x: x[1], reverse=True)
    sim_scores = sim_scores[1:6]
    indices = [i[0] for i in sim_scores]
    return list(set(questions[x] for x in indices))


def recommender_system(user_id, cat_filter):
    print('in new rs')
    # category wise filter
    condition = {"user_id": {"$nin": [user_id, 'celery_service']}}
    if cat_filter:
        cat_filter = [ObjectId(category) for category in cat_filter]
        condition['course_category_id'] = {"$in": cat_filter}
    Questions = connection['question_bank'].find(condition)
    questions = []
    questions_id = []
    for x in Questions:
        questions.append(x['questions'])
        questions_id.append(x['_id'])

    tfidf = TfidfVectorizer(stop_words='english')
    tfidf_matrix = tfidf.fit_transform(np.array(questions))
    cosine_sim = linear_kernel(tfidf_matrix, tfidf_matrix)
    user_specific_questions = connection['question_tracking'].find({"user_id": user_id})
    user_specific_questions = [ObjectId(x['question_id']) for x in user_specific_questions]
    user_question_bank = connection['question_bank'].aggregate(
        [{"$match": {"_id": {"$in": user_specific_questions}}}, {
            "$group":
                {"_id": {"questions": "$questions"}
                 }}
         ])
    questions_seen_by_user = [x['_id']['questions'] for x in user_question_bank]
    questions_set = []
    for x in questions_seen_by_user:
        try:
            questions_set.extend(get_recommendation(x, questions, cosine_sim))
        except:
            continue
    questions_set = random.sample(list(set(questions_set)), 15)
    questions_set_ids = [questions_id[questions.index(x)] for x in questions_set]

    output_data = []
    for x in questions_set_ids:
        temp_dict = {}
        try:
            data_cursor = connection['question_bank'].find({"_id": ObjectId(x)})
        except:
            continue
        for data in data_cursor:
            course_cat = mongo_session.get_all_data_for_particular_condition_fields(
                collection="Course_Category",
                condition={"_id": data["course_category_id"]})["message"][0]

            taxonomy = category_taxonomy_by_category_id(course_cat)
            ans_query = mongo_session.get_data_for_particular_columns_with_condition(
                collection="answer_bank",
                condition={"question_id": ObjectId(str(data['_id'])), "approval_status": 1},
                columns={"approval_status": 1})
            ans_data = ans_query['message']
            temp_dict["id"] = str(data['_id'])
            temp_dict["user_id"] = data["user_id"]
            temp_dict['category'] = taxonomy.split(" / ")
            temp_dict['title'] = data['questions']
            temp_dict['coins'] = float(data.get('reward', 0.0))
            temp_dict["count"] = str(len(data.get("answers", "0")))
            temp_dict["approved_answer"] = str(len(ans_data)) if ans_data else "0"
            temp_dict["Timestamp"] = data["Timestamp"]

            if data.get("course_id"):
                temp_dict['courseId'] = str(data["course_id"])
                temp_dict['courseSessionId'] = str(data["course_session_id"])
                temp_dict['videoTime'] = str(data["video_time"])
                vtt = ""
                transcriptions = {'transcripts': [], 'items': []}
                if data["course_id"] and data["course_session_id"]:
                    course_session_data = mongo_session.get_all_data_for_particular_condition_fields(
                        collection="course_sessions",
                        condition={"_id": ObjectId(data["course_session_id"])})
                    if course_session_data['message'][0]:
                        video_s3_key = course_session_data['message'][0]['url']
                        transcriptions = mongo_session.access_specific_fields(collection="video_transcriptions",
                                                                              condition={"s3_key": video_s3_key})
                        # adding transcriptions to the searched questions linked to videos
                        if transcriptions:
                            if transcriptions[0].get('vtt'):
                                vtt = transcriptions[0]['vtt'].split('/')[3:]
                                key = '{}/{}'.format(vtt[0], vtt[1])
                                vtt = s3_function.generate_presigned_url_from_s3(s3_key=key)[0]
                            else:
                                vtt = ""
                        else:
                            vtt = ""
                        if transcriptions:
                            transcriptions = transcriptions[0]['transcription']['results']
                            if transcriptions['items']:
                                for t in transcriptions['items']:
                                    t['text'] = t['alternatives'][0]['content']
                                    t.pop('alternatives')
                            else:
                                transcriptions = {'transcripts': [], 'items': []}
                        else:
                            transcriptions = {'transcripts': [], 'items': []}
            else:
                temp_dict['courseId'] = ""
                temp_dict['courseSessionId'] = ""
                temp_dict['videoTime'] = ""
                vtt = ""
                transcriptions = {'transcripts': [], 'items': []}
            temp_dict['vtt'] = vtt
            temp_dict['transcriptions'] = transcriptions
        output_data.append(temp_dict)

    return output_data

