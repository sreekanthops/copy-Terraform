import re
import time
from datetime import datetime, timedelta

import config
from db_wrapper.tasks import Mongo
from routes.exception import InvalidUsage
from utils.elasticsearch.resource_bank import insert_resource_elastic

mongo_session = Mongo()
from bson import ObjectId
import traceback
from services.storage.s3_services import s3_storage
from bs4 import BeautifulSoup
from model import Question as question
import model.Content as Content
from utils.time_conversions import utc_datetime_now, utc_dtime_obj_to_zone_str
from utils.misc import replace_s3_links_with_keys, renew_s3_links, extract_s3_keys_from_html_str

s3_function = s3_storage()

#tango services
from model.tango_wrapper import tango_services

def fetch_course_works(role, organisation):
    if role == "super_admin":
        organisation_condition = {}
    elif role == "teacher":
        organisation_condition = {"author.organisation": organisation}
    else:
        raise InvalidUsage("Permission denied, you cannot view this course work.", 403)
    course_works = []
    course_work_query = mongo_session.get_data_for_particular_columns_with_condition(
        collection="course_work_bank",
        condition=organisation_condition,
        columns={"_id": 1, "courseWorkTitle": 1, "is_group": 1, "publish": 1, "updated_at": 1,
                 "created_at": 1, "tags": 1})

    if course_work_query['status'] != 200:
        raise Exception("Error occurred while communicating with database.")

    for each_course_work in course_work_query['message']:
        for tag in each_course_work["tags"]:
            tag["_id"] = str(tag["_id"])
        course_works.append({
            "course_work_id": each_course_work['_id'],
            "course_work_title": each_course_work['courseWorkTitle'],
            "is_group": each_course_work['is_group'],
            "publish": each_course_work['publish'],
            "created_at": utc_dtime_obj_to_zone_str(each_course_work['created_at']),
            "updated_at": utc_dtime_obj_to_zone_str(each_course_work['updated_at']),
            "tags": each_course_work["tags"]
        })
    course_works = course_works[::-1]
    return course_works


def view_course_work(role, course_work_id, organisation, course_id=None, schedule_id=None):
    """ To view one particular course work content, super_admin, teacher and student can view the course work"""
    if role == "super_admin":
        organisation_condition = {"_id": ObjectId(course_work_id)}
    elif role == "teacher":
        organisation_condition = {"_id": ObjectId(course_work_id), "author.organisation": organisation}
    elif role == "student":
        organisation_condition = {"_id": ObjectId(course_work_id), "publish": True}
    else:
        raise InvalidUsage("you don't have permission to view course works", 403)
    s3_link = ""
    course_work_query = mongo_session.get_data_for_particular_columns_with_condition(
        collection="course_work_bank",
        condition=organisation_condition,
        columns={"author": 0})
    if course_work_query['status'] != 200:
        raise InvalidUsage("Something went wrong, Please try again later.", 500)

    course_work_dict = course_work_query['message'][0]
    for tag_dict in course_work_dict["tags"]:
        tag_dict["_id"] = str(tag_dict["_id"])

    course_work_dict["course_work_description"] = renew_s3_links(
        html_string=course_work_dict["course_work_description"])

    for resource in course_work_dict["course_work_resources"]:
        if resource["resource_type"] == "file":
            resource_s3_link, status = s3_function.generate_presigned_url_from_s3(resource["resource_url"])
            if resource_s3_link and status == 200:
                resource["resource_url"] = resource_s3_link
            else:
                resource["resource_url"] = ""
            if resource.get('_id'):
                resource['_id'] = str(resource['_id'])
        resource["resource_id"] = str(resource["resource_id"])
        if resource.get('_id'):
            resource["_id"] = str(resource["_id"])
        if resource.get('instance_id'):
            resource["instance_id"] = str(resource["instance_id"])
        if resource.get('schedule_id'):
            resource["schedule_id"] = str(resource["schedule_id"])
    max_submission_time = []
    for sr in course_work_dict["submissionRequirement"]:
        if sr.get('autograding'):
            if sr['autograding']  == True:
                if course_work_dict.get("autograded_submissions"):
                    for auto_course_work in course_work_dict["autograded_submissions"]:
                        if str(auto_course_work['_id']) == str(sr.get("autograding_id", '')):
                            sr["autograding_input"] = auto_course_work["autograding_data"]["inputs"]
                            sr["autograding_output"] = auto_course_work["autograding_data"]["outputs"]
        if sr["days_of_completion"]:
            max_submission_time.append(int(sr["days_of_completion"]))


    course_work_info = {
        "course_category_id": str(course_work_dict["course_category_id"]),
        "tag": course_work_dict["tags"],
        "course_work_file_id": str(course_work_dict["course_work_file_id"]),
        "is_group": course_work_dict["is_group"],
        "group_size": course_work_dict["group_size"],
        "course_work_title": course_work_dict["courseWorkTitle"],
        "course_work_description": course_work_dict["course_work_description"],
        "submission_requirement": course_work_dict["submissionRequirement"],
        "course_work_resources": course_work_dict["course_work_resources"],
        "publish": course_work_dict["publish"],
        "created_at": utc_dtime_obj_to_zone_str(course_work_dict["created_at"]),
        "updated_at": utc_dtime_obj_to_zone_str(course_work_dict["updated_at"]),
        "course_work_timeline": max(max_submission_time) if max_submission_time else 0}
    if course_id:
        course_work_info['course_work_id'] = course_work_id
        course_work_info['course_id'] = course_id
        course_work_info['schedule_id'] = schedule_id
    return course_work_info, "Success"


def delete_course_work(user_id, course_work_id):
    user_available = False
    status = 0
    course_bank_data = mongo_session.find_one_in_db(collection="courses_bank",
                                                   condition={"course_work": {"$elemMatch": {"_id": ObjectId(course_work_id)}}},
                                                   columns=["_id"])
    if course_bank_data['message']:
        raise InvalidUsage(message="This coursework is being used in a course, cannot delete such coursework", status_code=400)
    course_work_bank_data = mongo_session.get_all_data_for_particular_condition_fields(collection="course_work_bank",
                                                            condition={"_id": ObjectId(course_work_id)})["message"][0]
    for author in course_work_bank_data['author']:
        if str(author["user_id"]) == user_id:
            user_available = True
    if not user_available:
        raise InvalidUsage(message="Unauthorized attempt to delete coursework, coursework could be deleted by author", status_code=400)
    elif user_available:
        status = mongo_session.delete_records("course_work_bank", condition={"_id": ObjectId(course_work_id)})
    if status == 200:
        res = "Coursework deleted successfully"
    else:
        raise Exception("Failed to delete Coursework")
    return res


def course_work_checks(role, submission_requirement, course_work_title, is_group, group_size, publish_status):
    # only teacher can create the course work
    if role not in ["teacher", "super_admin"]:
        return "you don't have permission to do this action", "Failed", 403
    # course work title is compulsory
    if not course_work_title:
        return "please add a title for course work", "Failed", 400
    if publish_status:
        # at least one submission requirement should be there
        if not submission_requirement:
            return "course work should contain at least one submission requirement", "Failed", 400
        # group size must be greater than or equal to 2
        if is_group and int(group_size) < 2:
            return 'group size must be greater than or equal to 2', 'Failed', 400
        elif not is_group and int(group_size) != 1:
            return 'group size should be 1 for individual course works', 'Failed', 400
    return "data passed all validations", "Success", 200


def add_process_tags(tag_collection, tags):
    final_tags = []
    new_tags = []
    tags_collection = mongo_session.get_all_data(tag_collection)['message']
    tags_dict = dict(map(lambda x: (x['tag'], x['_id']), tags_collection))

    for tag in tags:
        if tag['_id'] == tag['tag']:
            if (tag['tag'] in tags_dict.keys()) or (tag['tag'].lower() in tags_dict.keys()):
                final_tags.append({"tag": tag['tag'], "_id": ObjectId(tags_dict[tag['_id']])})
            else:
                new_tags.append(tag['tag'])
        else:
            final_tags.append({"tag": tag['tag'], "_id": ObjectId(tag['_id'])})
    if new_tags:
        new_tags_ids = question.insert_tags(new_tags)
        index = 0
        for new_tag in new_tags_ids:
            final_tags.append({"tag": new_tags[index], "_id": new_tag})
            index = index + 1
    return final_tags


def manage_s3_resource_collections(resource_id):
    status = 200
    resource_bank_resource_id = \
        mongo_session.insert_files_resource_bank(collection="global_resource_bank",
                                                 resource_id=ObjectId(resource_id),
                                                 temp_collection="temp_uploaded_files")[
            'message']
    s3_key_info = mongo_session.fetch_s3_key_temp_uploaded_files(
        collection="temp_uploaded_files",
        condition={
            "_id": ObjectId(resource_id)},
        columns={"s3_key": 1})

    if s3_key_info['status'] != 200:
        status = s3_key_info['status']
    return resource_bank_resource_id, s3_key_info['message'], status


def manage_course_work_s3_resources(existing_course_work_resources, changed_course_work_resources, user_id, course_work_id=None):
    records_to_delete = []
    existing_resources = []
    status = 200
    instance_ids = []
    if existing_course_work_resources:
        for each_resource in changed_course_work_resources:
            if each_resource['resource_type'] == 'file':
                if not any(dict['resource_id'] == each_resource['resource_id'] for dict in
                           existing_course_work_resources):
                    resource_id = each_resource['resource_id']
                    check_resource = mongo_session.check_existance_return_info(collection='global_resource_bank',
                                                                               condition={'_id': ObjectId(resource_id)},
                                                                               whole_doc=True)
                    if check_resource:
                        doc_to_insert = {
                            "resource_id": ObjectId(resource_id),
                            "tags": [],
                            "description": "",
                            "title": each_resource['resource_title'],
                            "module": "course",
                            "used_at": {'course_work_id': ObjectId(course_work_id)} if course_work_id else "",
                            "updated_at": utc_datetime_now(),
                            "updated_by": ObjectId(user_id),
                        }
                        each_resource['resource_url'] = check_resource['s3_key']
                        each_resource['_id'] = ObjectId(resource_id)
                        resp_id = mongo_session.insert_documnet(collection="resource_bank_instance",
                                                                doc_to_insert=doc_to_insert)
                        each_resource['instance_id'] = resp_id['_id'].inserted_id
                        instance_ids.append(each_resource['instance_id'])

                    elif check_resource is None:
                        course_bank_find = mongo_session.check_existance_return_info(collection='course_resource_bank',
                                                                                     condition={
                                                                                         "_id": ObjectId(resource_id)
                                                                                     },
                                                                                     whole_doc=True)
                        if course_bank_find:
                            some = mongo_session.transfer_docs_another_collection(
                                from_collection='course_resource_bank',
                                to_collection='global_resource_bank',
                                condition={"_id": ObjectId(resource_id)})
                            each_resource['resource_url'] = course_bank_find['s3_key']
                            each_resource['_id'] = ObjectId(resource_id)
                        passion_project_find = mongo_session.check_existance_return_info(collection='resources',
                                                                                         condition={
                                                                                             "_id": ObjectId(
                                                                                                 resource_id)
                                                                                         },
                                                                                         whole_doc=True)
                        if passion_project_find:
                            some = mongo_session.transfer_docs_another_collection(from_collection='resources',
                                                                                  to_collection='global_resource_bank',
                                                                                  condition={
                                                                                      "_id": ObjectId(resource_id)})
                            each_resource['resource_url'] = passion_project_find['s3_key']
                            each_resource['_id'] = ObjectId(resource_id)
                        if passion_project_find or course_bank_find:
                            doc_to_insert = {
                                "resource_id": ObjectId(resource_id),
                                "tags": [],
                                "description": "",
                                "title": each_resource['resource_title'],
                                "module": "course",
                                "used_at": {'course_work_id': ObjectId(course_work_id)} if course_work_id else "",
                                "updated_at": utc_datetime_now(),
                                "updated_by": ObjectId(user_id),
                            }
                            resp_id = mongo_session.insert_documnet(collection="resource_bank_instance",
                                                                    doc_to_insert=doc_to_insert)
                            each_resource['instance_id'] = resp_id['_id'].inserted_id
                            instance_ids.append(each_resource['instance_id'])
                        else:
                            resource_id = each_resource['resource_id']
                            resource_bank_resource_id, s3_key_info, status = manage_s3_resource_collections(
                                resource_id=resource_id)
                            each_resource['resource_id'] = resource_bank_resource_id
                            each_resource['resource_url'] = s3_key_info
                            records_to_delete.append(s3_key_info)
                            resource_info = mongo_session.check_existance_return_info(
                                collection='global_resource_bank',
                                condition={
                                    '_id': ObjectId(resource_bank_resource_id)},
                                return_keys=['uploaded_at', 'user_id'])
                            created_at = time.strftime('%Y-%m-%d %H:%M',
                                                       time.localtime(int(resource_info['uploaded_at'])))
                            doc_to_insert = {
                                "resource_id": ObjectId(resource_id),
                                "tags": [],
                                "description": "",
                                "title": each_resource['resource_title'],
                                "module": "course",
                                "used_at": {'course_work_id': ObjectId(course_work_id)} if course_work_id else "",
                                "updated_at": utc_datetime_now(),
                                "updated_by": ObjectId(user_id),
                            }
                            resp_id = mongo_session.insert_documnet(collection="resource_bank_instance",
                                                                    doc_to_insert=doc_to_insert)
                            each_resource['instance_id'] = resp_id['_id'].inserted_id
                            instance_ids.append(each_resource['instance_id'])

                            item_type = ""
                            if re.findall('\.mp4', each_resource['resource_url']):
                                item_type = "video"
                            if re.findall('\.png|\.jpg|\.jpeg', each_resource['resource_url']):
                                item_type = "image"
                            if re.findall(
                                    '\.pdf|\.zip|\.doc|\.docx|\.ppt|\.pptx|\.txt|\.xml|\.rar|\.csv|\.mp3|\.xlsx',
                                    each_resource['resource_url']):
                                item_type = "file"
                            if re.findall('\.py|\.ipynb', each_resource['resource_url']):
                                item_type = "python"

                            data_resource = {'url': each_resource['resource_url'], '_id': resource_bank_resource_id,
                                             'title': each_resource['resource_title'],
                                             'description': "", 'module_name': 'course',
                                             'mongo_collection': 'global_resource_bank',
                                             'tags': [], 'created_by': resource_info['user_id'],
                                             'created_at': created_at,
                                             'file_type': item_type}
                            insert_resource_elastic(data_resource)
                else:
                    for dict in existing_course_work_resources:
                        if dict['resource_id'] == each_resource['resource_id']:
                            each_resource['resource_url'] = dict['resource_url']
                            each_resource['resource_id'] = dict['resource_id']
                            existing_resources.append(dict['resource_url'])
    else:
        for each_resource in changed_course_work_resources:
            if each_resource['resource_type'] == 'file':
                resource_id = each_resource['resource_id']
                check_resource = mongo_session.check_existance_return_info(collection='global_resource_bank',
                                                                           condition={'_id': ObjectId(resource_id)},
                                                                           whole_doc=True)
                if check_resource:
                    doc_to_insert = {
                        "resource_id": ObjectId(resource_id),
                        "tags": [],
                        "description": "",
                        "title": each_resource['resource_title'],
                        "module": "course",
                        "used_at": {'course_work_id': ObjectId(course_work_id)} if course_work_id else "",
                        "updated_at": utc_datetime_now(),
                        "updated_by": ObjectId(user_id),
                    }
                    each_resource['resource_url'] = check_resource['s3_key']
                    each_resource['_id'] = ObjectId(resource_id)
                    resp_id = mongo_session.insert_documnet(collection="resource_bank_instance",
                                                            doc_to_insert=doc_to_insert)
                    each_resource['instance_id'] = resp_id['_id'].inserted_id
                    instance_ids.append(each_resource['instance_id'])

                elif check_resource is None:
                    course_bank_find = mongo_session.check_existance_return_info(collection='course_resource_bank',
                                                                                 condition={
                                                                                     "_id": ObjectId(resource_id)
                                                                                 },
                                                                                 whole_doc=True)
                    if course_bank_find:
                        some = mongo_session.transfer_docs_another_collection(
                            from_collection='course_resource_bank',
                            to_collection='global_resource_bank',
                            condition={"_id": ObjectId(resource_id)})
                        each_resource['resource_url'] = course_bank_find['s3_key']
                        each_resource['_id'] = ObjectId(resource_id)
                    passion_project_find = mongo_session.check_existance_return_info(collection='resources',
                                                                                     condition={
                                                                                         "_id": ObjectId(
                                                                                             resource_id)
                                                                                     },
                                                                                     whole_doc=True)
                    if passion_project_find:
                        some = mongo_session.transfer_docs_another_collection(from_collection='resources',
                                                                              to_collection='global_resource_bank',
                                                                              condition={
                                                                                  "_id": ObjectId(resource_id)})
                        each_resource['resource_url'] = passion_project_find['s3_key']
                        each_resource['_id'] = ObjectId(resource_id)
                    if passion_project_find or course_bank_find:
                        doc_to_insert = {
                            "resource_id": ObjectId(resource_id),
                            "tags": [],
                            "description": "",
                            "title": each_resource['resource_title'],
                            "module": "course",
                            "used_at": {'course_work_id': ObjectId(course_work_id)} if course_work_id else "",
                            "updated_at": utc_datetime_now(),
                            "updated_by": ObjectId(user_id),
                        }
                        resp_id = mongo_session.insert_documnet(collection="resource_bank_instance",
                                                                doc_to_insert=doc_to_insert)
                        each_resource['instance_id'] = resp_id['_id'].inserted_id
                        instance_ids.append(each_resource['instance_id'])
                    else:
                        resource_bank_resource_id, s3_key_info, status = manage_s3_resource_collections(
                            resource_id=resource_id)
                        each_resource['resource_id'] = resource_bank_resource_id
                        each_resource['resource_url'] = s3_key_info
                        records_to_delete.append(each_resource['resource_url'])
                        resource_info = mongo_session.check_existance_return_info(
                            collection='global_resource_bank',
                            condition={
                                '_id': ObjectId(resource_bank_resource_id)},
                            return_keys=['uploaded_at', 'user_id'])
                        created_at = time.strftime('%Y-%m-%d %H:%M',
                                                   time.localtime(int(resource_info['uploaded_at'])))
                        doc_to_insert = {
                            "resource_id": ObjectId(resource_id),
                            "tags": [],
                            "description": "",
                            "title": each_resource['resource_title'],
                            "module": "course",
                            "used_at": {'course_work_id': ObjectId(course_work_id)} if course_work_id else "",
                            "updated_at": utc_datetime_now(),
                            "updated_by": ObjectId(user_id),
                        }
                        resp_id = mongo_session.insert_documnet(collection="resource_bank_instance",
                                                                doc_to_insert=doc_to_insert)
                        each_resource['instance_id'] = resp_id['_id'].inserted_id
                        instance_ids.append(each_resource['instance_id'])
                        item_type = ""
                        if re.findall('\.mp4', each_resource['resource_url']):
                            item_type = "video"
                        if re.findall('\.png|\.jpg|\.jpeg', each_resource['resource_url']):
                            item_type = "image"
                        if re.findall(
                                '\.pdf|\.zip|\.doc|\.docx|\.ppt|\.pptx|\.txt|\.xml|\.rar|\.csv|\.mp3|\.xlsx',
                                each_resource['resource_url']):
                            item_type = "file"
                        if re.findall('\.py|\.ipynb', each_resource['resource_url']):
                            item_type = "python"

                        data_resource = {'url': each_resource['resource_url'], '_id': resource_bank_resource_id,
                                         'title': each_resource['resource_title'],
                                         'description': "", 'module_name': 'course',
                                         'mongo_collection': 'global_resource_bank',
                                         'tags': [], 'created_by': resource_info['user_id'],
                                         'created_at': created_at,
                                         'file_type': item_type}
                        insert_resource_elastic(data_resource)

    return changed_course_work_resources, existing_resources, records_to_delete, status, instance_ids


def create_course_work(course_work_id, role, group_size, is_group, course_category_id, organisation, user_id,
                       tags, course_work_file_id, course_work_title, course_work_description,
                       submission_requirement, course_work_resources, publish_status,
                       # tango 
                       autograding):
    """this function allow teachers to create course works as a separate entity from courses, which could be publish
    later """
    instance_ids = []
    validation_message, success_status, validation_status = course_work_checks(role, submission_requirement,
                                                                               course_work_title, is_group, group_size,
                                                                               publish_status)
    if validation_status != 200:
        return validation_message, success_status, validation_status

    if mongo_session.find_one_in_db(collection="course_work_bank",
                                    condition={"courseWorkTitle": course_work_title},
                                    columns={"courseWorkTitle": 1})['message']:
        return 'course work with same title already exists please choose a different one', 'Failed', 409

    delete_record_list = []
    delete_exist_resource_list = []
    timestamp = question.indian_standard_time()
    course_work_resources_in_db = []

    if submission_requirement:
        submission_name = []
        for sub in submission_requirement:
            submission_name.append(sub["submission_report"].lower())
        if len(submission_name) != len(set(submission_name)):
            raise Exception("Please change submission name, can't use same name for more than one submission")

    if course_work_id:

        #start - tango reference
        autograded_submissions= []
        #end - tango reference

        course_work_query = mongo_session.get_all_data_for_particular_condition_fields(
            collection="course_work_bank",
            condition={"_id": ObjectId(course_work_id)})
        if course_work_query['status'] != 200:
            raise Exception('Error while communicating with db')
        course_work_db = course_work_query['message'][0]
        delete_exist_resource_list = extract_s3_keys_from_html_str(course_work_db["course_work_description"])

        # check and process course work file and s3 key
        course_work_description = replace_s3_links_with_keys(html_string=course_work_description,
                                                             module="course-work")
        delete_record_list.extend(extract_s3_keys_from_html_str(course_work_description))

        if publish_status:
            tags = add_process_tags(tag_collection="question_tags", tags=tags)
        else:
            if tags:
                tags = add_process_tags(tag_collection="question_tags", tags=tags)
        tags = add_process_tags(tag_collection="question_tags", tags=tags)

        for each_resource in course_work_db["course_work_resources"]:
            if each_resource['resource_type'] == "file":
                resource_info = {"resource_id": str(each_resource['resource_id']),
                                 "resource_url": each_resource['resource_url']}
                course_work_resources_in_db.append(resource_info)

        if course_work_resources:
            course_work_resources, existing_resources, records_to_delete, status, instance_ids = \
                manage_course_work_s3_resources(
                    existing_course_work_resources=course_work_resources_in_db,
                    changed_course_work_resources=course_work_resources,
                    user_id=user_id)
            delete_record_list.extend(records_to_delete)
            delete_exist_resource_list.extend(existing_resources)
            if status != 200:
                raise InvalidUsage("Something went wrong, Please try again later.", 500)
    else:
        # check and process course work file and s3 key
        course_work_description = replace_s3_links_with_keys(html_string=course_work_description,
                                                             module="course-work")
        delete_record_list.extend(extract_s3_keys_from_html_str(course_work_description))
        if publish_status:
            tags = add_process_tags(tag_collection="question_tags", tags=tags)
        else:
            if tags:
                tags = add_process_tags(tag_collection="question_tags", tags=tags)
        if course_work_resources:
            course_work_resources, existing_resources, records_to_delete, status, instance_ids = \
                manage_course_work_s3_resources(
                    existing_course_work_resources=[],
                    changed_course_work_resources=course_work_resources,
                    user_id=user_id)
            delete_record_list.extend(records_to_delete)
            delete_exist_resource_list.extend(existing_resources)
            if status != 200:
                raise InvalidUsage("Something went wrong, Please try again later.", 500)
    
    # calling tango service: create test case
        if autograding:
            autograded_submissions= []
            for idx in autograding:
                autograding_data = {"inputs": submission_requirement[idx]['autograding_input'],
                                    "outputs": submission_requirement[idx]['autograding_output']}
                check = 1
                for inputs in submission_requirement[idx]['autograding_input']:
                    for input in inputs:
                        if '“' in input or '”' in input:
                            raise InvalidUsage(
                                'Please remove inverted commas in Inputs for Test Case No. {} in Ques No. {}'.format(
                                    check, int(idx)+1),
                                406)
                    check += 1
                for outputs in submission_requirement[idx]['autograding_output']:
                    if '“' in outputs or '”' in outputs:
                        raise InvalidUsage(
                            'Please remove inverted commas in Output for Ques No. {}'.format(int(idx)+1),
                            406)
                title = submission_requirement[idx]['submission_report']
                autograded_coursework = mongo_session.insert_documnet('autograded_coursework', {"title":title})
                unique_id = str(autograded_coursework['_id'].inserted_id)
                submission_requirement[idx]['autograding_id'] = unique_id
                open_course = tango_services.open_course(unique_id)
                create_test_cases = tango_services.create_test_cases(unique_id, autograding_data)
                if open_course and create_test_cases:
                    query = {"_id": ObjectId(unique_id), "title": title, "autograding_data": autograding_data,
                    "autograding":True}
                    mongo_session.update_data('autograded_coursework', {"_id": ObjectId(unique_id)}, query, None)
                    submission_requirement[idx].pop('autograding_input')
                    submission_requirement[idx].pop('autograding_output')
                    autograded_submissions.append(query)
                else:
                    autograded_submissions = []
        else:
            autograded_submissions = []
    # end - calling tango service: create test case


    course_bank_dict = {"course_category_id": ObjectId(course_category_id) if course_category_id else course_category_id,
                        "is_group": is_group,
                        "group_size": group_size,
                        "course_work_description": course_work_description,
                        "publish_status": False,
                        "timestamp": timestamp,
                        "tags": tags,
                        "author": [{"user_id": ObjectId(user_id),
                                    "organisation": organisation}],
                        "courseWorkTitle": course_work_title,
                        "course_work_file_id": course_work_file_id,
                        "submissionRequirement": submission_requirement,
                        "course_work_resources": course_work_resources,
                        "used_in_courses": [],
                        "publish": publish_status,
                        "created_at": utc_datetime_now(),
                        "updated_at": utc_datetime_now(),
                        # Tango CTC mongodb
                        "autograded_submissions": autograded_submissions}

    course_work_inserted = mongo_session.insert_documnet(collection='course_work_bank',
                                                         doc_to_insert=course_bank_dict)
    if instance_ids:
        used_at = {"$set": {"used_at": {'course_work_id': ObjectId(course_work_inserted['_id'].inserted_id)}}}
        condition = {"_id": {"$in": instance_ids}}
        updation = mongo_session.update_db_data(collection='resource_bank_instance', condition=condition,
                                                update_info=used_at, multi=True)
    if course_work_inserted["status"] != 200:
        return "error while adding document in courses_bank collection", "Failed", 500

    record_removed_temp = mongo_session.delete_data(
        collection="temp_uploaded_files",
        condition={"s3_key": {"$in": delete_record_list}})
        
    for key in delete_exist_resource_list:
        if mongo_session.check_existance(collection='temp_uploaded_files', 
                                        condition={"s3_key":key}):
            delete_exist_resource_list.remove(key)

    if delete_exist_resource_list:
        delete_res_from_res_bank = mongo_session.transfer_docs_another_collection(
            from_collection="course_resource_bank",
            to_collection="temp_uploaded_files",
            condition={"s3_key": {"$in": delete_exist_resource_list}})
    return "Course Work created successfully", "Success", 201


def edit_course_work(course_work_id, role, group_size, is_group, course_category_id, organisation, user_id,
                     tags, course_work_file_id, course_work_title, course_work_description,
                     submission_requirement, course_work_resources, publish_status, autograding):
    validation_message, success_status, validation_status = course_work_checks(role, submission_requirement,
                                                                               course_work_title, is_group, group_size,
                                                                               publish_status)
    if validation_status != 200:
        return validation_message, success_status, validation_status

    course_work_query = mongo_session.get_all_data_for_particular_condition_fields(
        collection="course_work_bank",
        condition={"_id": ObjectId(course_work_id)})
    if course_work_query['status'] != 200:
        raise InvalidUsage("Something went wrong, Please try again later.", 500)
    course_work_db = course_work_query['message'][0]
    # validate publish status
    if course_work_db["publish"] and not publish_status:
        raise InvalidUsage("You cannot un-publish a published course work.", 400)

    if role != "super_admin":
        if user_id != str(course_work_db['author'][0]['user_id']) or \
                user_id == str(course_work_db['author'][0]['user_id']) and course_work_db['used_in_courses']:
            raise InvalidUsage("you cannot update this course work", 403)

    if mongo_session.find_one_in_db(collection="course_work_bank",
                                    condition={"courseWorkTitle": course_work_title},
                                    columns={"courseWorkTitle": 1})['message'] and \
            course_work_title != course_work_db['courseWorkTitle']:
        raise InvalidUsage("course work with same title already exists please choose a different one", 409)

    delete_record_list = []
    delete_exist_resource_list = []
    timestamp = question.indian_standard_time()

    # check and process course work file and s3 key
    course_work_description = replace_s3_links_with_keys(html_string=course_work_description,
                                                         module="course-work")
    delete_record_list.extend(extract_s3_keys_from_html_str(course_work_description))

    if publish_status:
        tags = add_process_tags(tag_collection="question_tags", tags=tags)
    else:
        if tags:
            tags = add_process_tags(tag_collection="question_tags", tags=tags)

    course_work_resources_in_db = []
    for each_resource in course_work_db["course_work_resources"]:
        if each_resource['resource_type'] == "file":
            resource_info = {"resource_id": str(each_resource['resource_id']),
                             "resource_url": each_resource['resource_url']}
            course_work_resources_in_db.append(resource_info)

    if course_work_resources:
        course_work_resources, existing_resources, records_to_delete, status, instance_ids = \
            manage_course_work_s3_resources(
                existing_course_work_resources=course_work_resources_in_db,
                changed_course_work_resources=course_work_resources, user_id=user_id,
                course_work_id=course_work_id)
        if status != 200:
            raise InvalidUsage("Something went wrong, Please try again later.", 500)

    # calling tango service: create test case
    autograded_submissions= []
    if autograding:
        autograded_submissions= []
        for idx in autograding:
            autograding_data = {"inputs": submission_requirement[idx]['autograding_input'],
                                "outputs": submission_requirement[idx]['autograding_output']}
            check = 1
            for inputs in submission_requirement[idx]['autograding_input']:
                for input in inputs:
                    if '“' in input or '”' in input:
                        raise InvalidUsage(
                            'Please remove inverted commas in Inputs for Test Case No. {} in Ques No. {}'.format(check,
                                                                                                                 int(idx)+1),
                            406)
                check += 1

            for outputs in submission_requirement[idx]['autograding_output']:
                if '“' in outputs or '”' in outputs:
                    raise InvalidUsage(
                        'Please remove inverted commas in Output for Ques No. {}'.format(int(idx)+1),
                        406)
            title = submission_requirement[idx]['submission_report']
            autograded_coursework = mongo_session.insert_documnet('autograded_coursework', {"title":title})
            unique_id = str(autograded_coursework['_id'].inserted_id)
            submission_requirement[idx]['autograding_id'] = unique_id
            open_course = tango_services.open_course(unique_id)
            create_test_cases = tango_services.create_test_cases(unique_id, autograding_data)

            if open_course and create_test_cases:
                query = {"_id": ObjectId(unique_id), "title": title, "autograding_data": autograding_data,
                "autograding":True}
                mongo_session.update_data('autograded_coursework', {"_id": ObjectId(unique_id)}, query, None)
                submission_requirement[idx].pop('autograding_input')
                submission_requirement[idx].pop('autograding_output')
                autograded_submissions.append(query)
            else:
                autograded_submissions = []
    else:
        autograded_submissions = []
    # end - calling tango service: create test case
    
    course_bank_dict = {
        "course_category_id": ObjectId(course_category_id) if course_category_id else course_category_id,
        "is_group": is_group,
        "group_size": group_size,
        "course_work_description": course_work_description,
        "publish_status": False,
        "timestamp": timestamp,
        "tags": tags,
        "author": [{"user_id": ObjectId(user_id),
                    "organisation": organisation}],
        "courseWorkTitle": course_work_title,
        "course_work_file_id": course_work_file_id,
        "submissionRequirement": submission_requirement,
        "course_work_resources": course_work_resources,
        "used_in_courses": [],
        "updated_at": utc_datetime_now(),
        "publish": publish_status,
        'autograded_submissions':autograded_submissions}

    course_work_overwritten_query = mongo_session.update_multiple_fields(
        collection='course_work_bank',
        condition={"_id": ObjectId(course_work_id)},
        set_columns=course_bank_dict)
    if course_work_overwritten_query['status'] != 200:
        raise InvalidUsage("Something went wrong, Please try again later.", 500)

    record_removed_temp = mongo_session.delete_record_temp_uploaded_files(
        collection="temp_uploaded_files", id_list=delete_record_list)

    record_removed_temp = mongo_session.delete_data(
        collection="temp_uploaded_files",
        condition={"s3_key": {"$in": delete_record_list}})

    if delete_exist_resource_list:
        delete_res_from_res_bank = mongo_session.transfer_docs_another_collection(
            from_collection="course_resource_bank",
            to_collection="temp_uploaded_files",
            condition={"s3_key": {"$in": delete_exist_resource_list}})
    return "course work successfully saved", "Success", 200
