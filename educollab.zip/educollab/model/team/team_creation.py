import copy
import datetime
import random
import ssl

from bson import ObjectId

from flask import render_template, Flask, redirect
from config import email_Address, email_password, API_BASE_URL, WEB_BASE_URL
from model import course
import model.Question as Question
import model.Content as Content
import model.Notification as Notification

import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

from db_wrapper.tasks import Mongo
from model.chat_func import create_group_chat, update_course_groupchat
from routes.exception import InvalidUsage
from utils.time_conversions import utc_datetime_now

mongo_session = Mongo()

app = Flask(__name__)


def notify_team(user_id_list, data_message, message_title, message_body):
    device_tokens = mongo_session.get_device_tokens(collection="user_profile",
                                                    condition={"_id": {"$in": user_id_list},
                                                               "user_device_tokens": {"$exists": True}},
                                                    columns={"user_device_tokens": 1, "_id": 0})
    if device_tokens['status'] != 200:
        raise Exception("Internal server error.")
    firebase_response = Notification.notify_multiple_users(user_id_list=user_id_list,
                                                           device_tokens=device_tokens['message'],
                                                           data_message=data_message,
                                                           message_title=message_title,
                                                           message_body=message_body)
    if firebase_response['status'] != 200:
        return False
    notification_status = firebase_response['notification_status']
    return True


def send_email_invitation(users, course_instance_id, course_work_id, course_name, course_work_name, invitee_name,
                          course_id):
    password = email_password
    sender_email = email_Address

    for user in users:
        receiver_email = user["email"]

        msg = MIMEMultipart('alternative')
        msg['Subject'] = "Team Invitation"
        msg['From'] = sender_email
        msg['To'] = receiver_email

        template_path = "coursework_team_invitation"

        invite_url = API_BASE_URL + "/course-work/teams/invite?" \
                                    "course_instance_id={course_instance_id}" \
                                    "&course_work_id={course_work_id}" \
                                    "&team_name={team_name}" \
                                    "&user_id={user_id}" \
                                    "&redirect=true" \
                                    "&course_id={course_id}" \
            .format(
            course_instance_id=course_instance_id,
            course_work_id=course_work_id,
            team_name=user["team"],
            user_id=str(user["_id"]),
            course_id=course_id
        )

        accept_url = invite_url + "&response=true"
        reject_url = invite_url + "&response=false"

        text = render_template(template_path + ".txt",
                               accept_url=accept_url,
                               reject_url=reject_url,
                               invitee_name=invitee_name,
                               course_name=course_name,
                               course_work_name=course_work_name,
                               username=user["username"]
                               )
        html_doc = render_template(template_path + ".html",
                                   accept_url=accept_url,
                                   reject_url=reject_url,
                                   invitee_name=invitee_name,
                                   course_name=course_name,
                                   course_work_name=course_work_name,
                                   username=user["username"]
                                   )
        part1 = MIMEText(text, 'plain')
        part2 = MIMEText(html_doc, 'html')

        msg.attach(part1)
        msg.attach(part2)

        text = msg.as_string()

        # context = ssl.create_default_context()
        # with smtplib.SMTP_SSL("smtp.gmail.com", 465, context=context) as server:
        #     server.login(sender_email, password)
        #     server.sendmail(sender_email, receiver_email, text)
        smtp = smtplib.SMTP(host="172.31.6.215", port=25)
        smtp.sendmail(sender_email, receiver_email, text)
        smtp.close()
    return True


def partition(lst, n):
    division = len(lst) / n
    return [lst[round(division * i):round(division * (i + 1))] for i in range(n)]


def create_team(user_id, role, group_type, course_work_id, course_id, course_instance_id, team_info, reset):
    removed_users = []
    new_users = []
    email_users = []
    if not (course_instance_id, course_id, course_work_id, group_type):
        raise InvalidUsage("Please select valid course work.", 400)

    course_query = mongo_session.get_all_data_for_particular_condition_fields(
        collection='courses_bank',
        condition={"_id": ObjectId(course_id)})
    if course_query['status'] != 200:
        raise Exception("Something went wrong, Please try again later.")
    course_data = course_query['message'][0]
    if not course_data['active']:
        raise InvalidUsage("Oops, course is not active anymore.", 403)

    publish_rights = [str(user['_id']) for user in course_data["editors"]] + \
                     [str(user['_id']) for user in course_data["instructors"]] + [str(course_data["created_by"])]

    teach_assis = [str(user['_id']) for user in course_data["teach_assis"]]
    if role != "super_admin":  # slug
        if user_id not in publish_rights and group_type != "Student-led":
            raise InvalidUsage("You don't have permission to create team.", 403)

    course_work_query = mongo_session.get_all_data_for_particular_condition_fields(
        collection="course_work_bank",
        condition={"_id": ObjectId(course_work_id)})
    if course_work_query['status'] != 200:
        raise Exception("Something went wrong, please try again later.")
    work_data = course_work_query['message'][0]

    course_work_instance_query = mongo_session.get_all_data_for_particular_condition_fields(
        collection="course_work_instances",
        condition={"_id": ObjectId(course_instance_id)})
    if course_work_instance_query['status'] != 200:
        raise Exception("Something went wrong, please try again later.")
    work_instance_data = course_work_instance_query['message'][0]

    required_team_size = int(work_data["group_size"])

    course_work_instance_query = mongo_session.get_all_data_for_particular_condition_fields(
        collection="course_work_instances",
        condition={"_id": ObjectId(course_instance_id)})
    if course_work_instance_query['status'] != 200:
        raise Exception("Something went wrong, please try again later.")
    work_instance_data = course_work_instance_query['message'][0]

    if required_team_size == 1:
        raise InvalidUsage("Oops, This course work for individuals only.", 400)

    schedule_work_info = mongo_session.get_data_for_particular_columns_with_condition(
        collection="course_work_instances",
        condition={"_id": ObjectId(course_instance_id)},
        columns={"start_time": 1, "start_date": 1, "teams": 1})
    if schedule_work_info["status"] != 200:
        raise Exception("Some internal error occurred, please try again later.")
    schedule_data = schedule_work_info["message"][0]

    if reset == True:
        update_info = {"$set": {"teams": []}}
        update_team = mongo_session.update_record_into_db(collection="course_work_instances",
                                                          condition={"_id": ObjectId(course_instance_id)},
                                                          update_info=update_info)
        condition = {"course_work_id": ObjectId(course_work_id), "cw_instance_id": ObjectId(course_instance_id)}
        delete = mongo_session.delete_data(collection='chat_rooms', condition=condition)
    if group_type == "auto":
        subscribers, message, status = course.get_subscribers(
            course_id=course_id,
            role=role,
            user_id=user_id,
            filter_role=str(["student"])
        )

        subscribers = [ObjectId(user["_id"]) for user in subscribers]
        if not subscribers:
            raise InvalidUsage("Oops, there are no subscribers yet.", 409)
        random.shuffle(subscribers)
        subs_count = len(subscribers)
        number_of_teams = round(subs_count / required_team_size)
        random_teams = partition(subscribers, number_of_teams)
        teams_array = []
        team_index = 1
        timestamp = Question.indian_standard_time()
        for team in random_teams:
            members = []
            room_members = []
            for member in team:
                members.append({"_id": member,
                                "approval_status": True})
                if str(member) != user_id:
                    room_members.append(str(member))

            room_info = create_group_chat(members=room_members, group_name="Team_" + str(team_index),
                                          admins=[ObjectId(user_id)], created_by=ObjectId(user_id),
                                          group_description="",
                                          subheading="", resource_bank_resource_id="", s3_key_info="",
                                          course_work_id=course_work_id, cw_instance_id=course_instance_id)
            team_data = {"name": "Team_" + str(team_index),
                         "mode": "auto",
                         "created_by": ObjectId(user_id),
                         "timestamp": timestamp,
                         "members": members,
                         "submissions": [],
                         "room_id": ObjectId(room_info['_id'])}
            teams_array.append(team_data)
            team_index = team_index + 1
        update_info = {"$set": {"teams": teams_array}}
        message = "Auto assignment of the students into teams is done."

    elif group_type == "manual":
        team_names = [entity['name'] for entity in team_info]
        if len(team_names) - len(set(team_names)) > 0:
            raise InvalidUsage("Team names must be unique.", 409)
        teams_array = []
        team_index = 1
        timestamp = Question.indian_standard_time()
        if not team_info:
            raise InvalidUsage("Oops, Please enter users to create teams.", 400)
        for team in team_info:
            group_room_id = team['group_room_id']
            members = []
            room_members = []
            existing_users = []
            for member in team["users"]:
                if member['user_room_id'] != group_room_id and group_room_id != "" and member['user_room_id']:
                    existing_users.append({"_id": member['_id'],
                                           "room_id": member['user_room_id']})
                if member['user_room_id'] and group_room_id == "":
                    existing_users.append({"_id": member['_id'],
                                           "room_id": member['user_room_id']})
                members.append({"_id": ObjectId(member["_id"]),
                                "approval_status": True})
                if str(member['_id']) != user_id:
                    room_members.append(str(member['_id']))
            if group_room_id == "" and existing_users == []:
                room_info = create_group_chat(members=room_members, group_name=team['name'], admins=[ObjectId(user_id)],
                                              created_by=ObjectId(user_id), group_description="", subheading="",
                                              resource_bank_resource_id="", s3_key_info="",
                                              course_work_id=course_work_id, cw_instance_id=course_instance_id)
                group_room_id = room_info['_id']
            elif group_room_id == "" and existing_users:
                for user in existing_users:
                    if user['room_id']:
                        update_course_groupchat(user_id, room_id=user['room_id'], group_name="", remove_users=[user['_id']])

                room_info = create_group_chat(members=room_members, group_name=team['name'], admins=[ObjectId(user_id)],
                                              created_by=ObjectId(user_id), group_description="", subheading="",
                                              resource_bank_resource_id="", s3_key_info="",
                                              course_work_id=course_work_id, cw_instance_id=course_instance_id)
                group_room_id = room_info['_id']
            elif group_room_id:
                if existing_users:
                    for user in existing_users:
                        if user['room_id']:
                            update_course_groupchat(user_id, room_id=user['room_id'], group_name="",
                                                    remove_users=[user['_id']])

                    update_course_groupchat(user_id, room_id=group_room_id, group_name=team['name'],
                                            new_users=room_members)
                else:
                    update_course_groupchat(user_id, room_id=group_room_id, group_name=team['name'],
                                            new_users=room_members)
            submissions = []
            if work_instance_data.get('teams'):
                for t in work_instance_data['teams']:
                    if t['name'] == team["name"]:
                        submissions = t['submissions']
            team_data = {"name": team["name"],
                         "mode": "manual",
                         "team_img": team.get("team_img", ""),
                         "created_by": ObjectId(user_id),
                         "timestamp": timestamp,
                         "members": members,
                         "submissions": submissions,
                         "room_id": ObjectId(group_room_id)}
            teams_array.append(team_data)
            team_index = team_index + 1
        update_info = {"$set": {"teams": teams_array}}
        message = "Teams are created successfully."

    elif group_type == "Student-led":
        start_time = Content.webapp_time_to_string(schedule_data["start_date"], schedule_data["start_time"])
        start_time = datetime.datetime.strptime(start_time, "%Y:%m:%dT%H:%M")

        timestamp = Question.indian_standard_time()
        timestamp_obj = datetime.datetime.strptime(timestamp, "%d %b %Y, %I:%M %p")

        if timestamp_obj > start_time and role == 'student' and user_id not in teach_assis:
            raise InvalidUsage("you can't perform this operation. Course work has already started.", 403)

        condition = {"_id": ObjectId(course_instance_id)}

        if role == 'student' and (not schedule_data["teams"] or not any(
                data['created_by'] == ObjectId(user_id) for data in schedule_data["teams"])):
            if role == 'student':
                # there are no teams yet for this course work
                team_names = [entity['name'] for entity in schedule_data["teams"]]
                if team_names and (team_info[0]["name"] in team_names):
                    raise InvalidUsage("Team already exist with given name.", 409)

                members = []
                room_members = []
                for member in team_info[0]["users"]:
                    if member["_id"] != user_id:
                        new_users.append(ObjectId(member["_id"]))
                        email_users.append({"team": team_info[0]["name"],
                                            "_id": member["_id"]})
                    members.append({"_id": ObjectId(member["_id"]),
                                    "approval_status": member["approval_status"]})
                    if str(member['_id']) != user_id:
                        room_members.append(str(member['_id']))
                room_info = create_group_chat(members=room_members, group_name=team_info[0]['name'],
                                              admins=[ObjectId(user_id)],
                                              created_by=ObjectId(user_id), group_description="", subheading="",
                                              resource_bank_resource_id="", s3_key_info="",
                                              course_work_id=course_work_id, cw_instance_id=course_instance_id)
                submissions = []
                if work_instance_data.get('teams'):
                    for t in work_instance_data['teams']:
                        if t['name'] == team_info[0]["name"]:
                            submissions = t['submissions']
                team_data = {"name": team_info[0]["name"],
                             "mode": "Student-led",
                             "team_img": team_info[0].get("team_img", ""),
                             "created_by": ObjectId(user_id),
                             "timestamp": timestamp,
                             "members": members,
                             "submissions": submissions,
                             "room_id": ObjectId(room_info['_id'])}
                update_info = {"$push": {"teams": team_data}}
                message = "Team created successfully."

        elif role == 'super_admin' or role == 'teacher':
            given_team_names = [entity['name'] for entity in team_info]
            team_names = [entity['name'] for entity in schedule_data['teams'] if
                          entity['created_by'] != ObjectId(user_id)]
            common_teams = set(given_team_names).intersection(set(team_names))

            if not team_info:
                raise InvalidUsage("Oops, Please enter users to create teams.", 400)

            same_teams = []
            if len(common_teams) > 0:
                for teams in team_info:
                    if teams['name'] in common_teams:
                        same_teams.append(teams)
                        team_info.remove(teams)
            if len(given_team_names) - len(set(given_team_names)) > 0:
                raise InvalidUsage("Team names must be unique.", 409)
            teams_array = []
            team_index = 1
            timestamp = Question.indian_standard_time()

            delete_teams = mongo_session.del_value_from_array(collection='course_work_instances',
                                                              id=ObjectId(course_instance_id),
                                                              field="teams",
                                                              value={"created_by": ObjectId(user_id)}
                                                              )

            if team_info and not same_teams:
                for team in team_info:
                    members = []
                    existing_users = []
                    group_room_id = team['group_room_id']
                    room_members = []
                    for member in team["users"]:
                        if member['user_room_id'] != group_room_id and group_room_id != "":
                            existing_users.append({"_id": member['_id'],
                                                   "room_id": member['user_room_id']})
                        if member['user_room_id'] and group_room_id == "":
                            existing_users.append({"_id": member['_id'],
                                                   "room_id": member['user_room_id']})
                        members.append({"_id": ObjectId(member["_id"]),
                                        "approval_status": True})
                        if str(member['_id']) != user_id:
                            room_members.append(str(member['_id']))
                    if group_room_id == "" and existing_users == []:
                        room_info = create_group_chat(members=room_members, group_name=team['name'],
                                                      admins=[ObjectId(user_id)],
                                                      created_by=ObjectId(user_id), group_description="", subheading="",
                                                      resource_bank_resource_id="", s3_key_info="",
                                                      course_work_id=course_work_id, cw_instance_id=course_instance_id)
                        group_room_id = room_info['_id']
                    elif group_room_id == "" and existing_users:
                        for user in existing_users:
                            if user['room_id']:
                                update_course_groupchat(user_id, room_id=user['room_id'], group_name="",
                                                        remove_users=[user['_id']])

                        room_info = create_group_chat(members=room_members, group_name=team['name'],
                                                      admins=[ObjectId(user_id)],
                                                      created_by=ObjectId(user_id), group_description="", subheading="",
                                                      resource_bank_resource_id="", s3_key_info="",
                                                      course_work_id=course_work_id, cw_instance_id=course_instance_id)
                        group_room_id = room_info['_id']
                    elif group_room_id:
                        if existing_users != []:
                            for user in existing_users:
                                if user['room_id']:
                                    update_course_groupchat(user_id, room_id=user['room_id'], group_name="",
                                                            remove_users=[user['_id']])

                            update_course_groupchat(user_id, room_id=group_room_id, group_name=team['name'],
                                                    new_users=room_members)
                        else:
                            update_course_groupchat(user_id, room_id=group_room_id, group_name=team['name'],
                                                    new_users=room_members)
                    submissions = []
                    if work_instance_data.get('teams'):
                        for t in work_instance_data['teams']:
                            if t['name'] == team["name"]:
                                submissions = t['submissions']
                    team_data = {"name": team["name"],
                                 "mode": "Student-led",
                                 "team_img": team.get("team_img", ""),
                                 "created_by": ObjectId(user_id),
                                 "timestamp": timestamp,
                                 "members": members,
                                 "submissions": submissions,
                                 "room_id": ObjectId(group_room_id)}
                    teams_array.append(team_data)
                    team_index = team_index + 1
                update_info = {"$push": {"teams": {"$each": teams_array}}}
                condition['teams.created_by'] = ObjectId(user_id)
                message = "Teams are created successfully."

            elif team_info and same_teams:
                team_info.extend(same_teams)
                for team in team_info:
                    members = []
                    existing_users = []
                    group_room_id = team['group_room_id']
                    room_members = []
                    for member in team["users"]:
                        if member['user_room_id'] != group_room_id and group_room_id != "":
                            existing_users.append({"_id": member['_id'],
                                                   "room_id": member['user_room_id']})
                        if member['user_room_id'] and group_room_id == "":
                            existing_users.append({"_id": member['_id'],
                                                   "room_id": member['user_room_id']})
                        members.append({"_id": ObjectId(member["_id"]),
                                        "approval_status": True})
                        if str(member['_id']) != user_id:
                            room_members.append(str(member['_id']))
                    if group_room_id == "" and existing_users == []:
                        room_info = create_group_chat(members=room_members, group_name=team['name'],
                                                      admins=[ObjectId(user_id)],
                                                      created_by=ObjectId(user_id), group_description="", subheading="",
                                                      resource_bank_resource_id="", s3_key_info="",
                                                      course_work_id=course_work_id, cw_instance_id=course_instance_id)
                        group_room_id = room_info['_id']
                    elif group_room_id == "" and existing_users:
                        for user in existing_users:
                            if user['room_id']:
                                update_course_groupchat(user_id, room_id=user['room_id'], group_name="",
                                                        remove_users=[user['_id']])

                        room_info = create_group_chat(members=room_members, group_name=team['name'],
                                                      admins=[ObjectId(user_id)],
                                                      created_by=ObjectId(user_id), group_description="", subheading="",
                                                      resource_bank_resource_id="", s3_key_info="",
                                                      course_work_id=course_work_id, cw_instance_id=course_instance_id)
                        group_room_id = room_info['_id']
                    elif group_room_id:
                        if existing_users != []:
                            for user in existing_users:
                                if user['room_id']:
                                    update_course_groupchat(user_id, room_id=user['room_id'], group_name="",
                                                            remove_users=[user['_id']])

                            update_course_groupchat(user_id, room_id=group_room_id, group_name=team['name'],
                                                    new_users=room_members)
                        else:
                            update_course_groupchat(user_id, room_id=group_room_id, group_name=team['name'],
                                                    new_users=room_members)
                    submissions = []
                    if work_instance_data.get('teams'):
                        for t in work_instance_data['teams']:
                            if t['name'] == team["name"]:
                                submissions = t['submissions']
                    team_data = {"name": team["name"],
                                 "mode": "Student-led",
                                 "team_img": team.get("team_img", ""),
                                 "created_by": ObjectId(user_id),
                                 "timestamp": timestamp,
                                 "members": members,
                                 "submissions": submissions,
                                 "room_id": ObjectId(group_room_id)}
                    teams_array.append(team_data)
                    team_index = team_index + 1
                update_info = {"$set": {"teams": teams_array}}
                condition['teams.created_by'] = ObjectId(user_id)
                message = "Teams are created successfully."

            elif not team_info and same_teams:
                for team in same_teams:
                    members = []
                    existing_users = []
                    group_room_id = team['group_room_id']
                    room_members = []
                    for member in team["users"]:
                        if member['user_room_id'] != group_room_id and group_room_id != "":
                            existing_users.append({"_id": member['_id'],
                                                   "room_id": member['user_room_id']})
                        if member['user_room_id'] and group_room_id == "":
                            existing_users.append({"_id": member['_id'],
                                                   "room_id": member['user_room_id']})
                        members.append({"_id": ObjectId(member["_id"]),
                                        "approval_status": True})
                        if str(member['_id']) != user_id:
                            room_members.append(str(member['_id']))
                    if group_room_id == "" and existing_users == []:
                        room_info = create_group_chat(members=room_members, group_name=team['name'],
                                                      admins=[ObjectId(user_id)],
                                                      created_by=ObjectId(user_id), group_description="", subheading="",
                                                      resource_bank_resource_id="", s3_key_info="",
                                                      course_work_id=course_work_id, cw_instance_id=course_instance_id)
                        group_room_id = room_info['_id']
                    elif group_room_id == "" and existing_users:
                        for user in existing_users:
                            if user['room_id']:
                                update_course_groupchat(user_id, room_id=user['room_id'], group_name="",
                                                        remove_users=[user['_id']])

                        room_info = create_group_chat(members=room_members, group_name=team['name'],
                                                      admins=[ObjectId(user_id)],
                                                      created_by=ObjectId(user_id), group_description="", subheading="",
                                                      resource_bank_resource_id="", s3_key_info="",
                                                      course_work_id=course_work_id, cw_instance_id=course_instance_id)
                        group_room_id = room_info['_id']
                    elif group_room_id:
                        if not existing_users:
                            for user in existing_users:
                                if user['room_id']:
                                    update_course_groupchat(user_id, room_id=user['room_id'], group_name="",
                                                            remove_users=[user['_id']])

                            update_course_groupchat(user_id, room_id=group_room_id, group_name=team['name'],
                                                    new_users=room_members)
                        else:
                            update_course_groupchat(user_id, room_id=group_room_id, group_name=team['name'],
                                                    new_users=room_members)
                    submissions = []
                    if work_instance_data.get('teams'):
                        for t in work_instance_data['teams']:
                            if t['name'] == team["name"]:
                                submissions = t['submissions']
                    team_data = {"name": team["name"],
                                 "mode": "Student-led",
                                 "team_img": team.get("team_img", ""),
                                 "created_by": ObjectId(user_id),
                                 "timestamp": timestamp,
                                 "members": members,
                                 "submissions": submissions,
                                 "room_id": ObjectId(group_room_id)}
                    teams_array.append(team_data)
                    team_index = team_index + 1
                update_info = {"$set": {"teams": teams_array}}
                condition['teams.created_by'] = ObjectId(user_id)
                message = "Teams are created successfully."

        elif any(data['created_by'] == ObjectId(user_id) for data in schedule_data["teams"]) and role == 'student':
            # update team info
            team_names = [entity['name'] for entity in schedule_data["teams"]]

            teams_array = schedule_data["teams"]
            for team in teams_array:
                if team["created_by"] == ObjectId(user_id):
                    if team_names and (team_info[0]["name"] in team_names) and team["name"] != team_info[0]["name"]:
                        raise InvalidUsage("Team already exist with given name.", 409)
                    db_members = [entity["_id"] for entity in team["members"]
                                  if entity["approval_status"] == "true" and entity["_id"] != ObjectId(user_id)]
                    member_ids = []
                    members = []
                    existing_users = []
                    group_room_id = team.get('group_room_id', "")
                    room_members = []
                    for member in team_info[0]["users"]:
                        if member["_id"] != user_id:
                            member_ids.append(ObjectId(member["_id"]))
                            room_members.append(str(member['_id']))
                        if member['user_room_id'] != group_room_id and group_room_id != "":
                            existing_users.append({"_id": member['_id'],
                                                   "room_id": member['user_room_id']})
                        if member['user_room_id'] and group_room_id == "":
                            existing_users.append({"_id": member['_id'],
                                                   "room_id": member['user_room_id']})
                        members.append({"_id": ObjectId(member["_id"]),
                                        "approval_status": member["approval_status"]})
                        if group_room_id == "" and existing_users == []:
                            room_info = create_group_chat(members=room_members, group_name=team['name'],
                                                          admins=[ObjectId(user_id)],
                                                          created_by=ObjectId(user_id), group_description="",
                                                          subheading="",
                                                          resource_bank_resource_id="", s3_key_info="",
                                                          course_work_id=course_work_id,
                                                          cw_instance_id=course_instance_id)
                            group_room_id = room_info['_id']
                        elif group_room_id == "" and existing_users:
                            for user in existing_users:
                                if user['room_id']:
                                    update_course_groupchat(user_id, room_id=user['room_id'], group_name="",
                                                            remove_users=[user['_id']])

                            room_info = create_group_chat(members=room_members, group_name=team['name'],
                                                          admins=[ObjectId(user_id)],
                                                          created_by=ObjectId(user_id), group_description="",
                                                          subheading="",
                                                          resource_bank_resource_id="", s3_key_info="",
                                                          course_work_id=course_work_id,
                                                          cw_instance_id=course_instance_id)
                            group_room_id = room_info['_id']
                        elif group_room_id:
                            if not existing_users:
                                for user in existing_users:
                                    if user['room_id']:
                                        update_course_groupchat(user_id, room_id=user['room_id'], group_name="",
                                                                remove_users=[user['_id']])

                                update_course_groupchat(user_id, room_id=group_room_id, group_name=team['name'],
                                                        new_users=room_members)
                            else:
                                update_course_groupchat(user_id, room_id=group_room_id, group_name=team['name'],
                                                        new_users=room_members)
                    if set(member_ids) - set(db_members):
                        new_users = list(set(member_ids) - set(db_members))
                    for user in new_users:
                        email_users.append({"team": team_info[0]["name"],
                                            "_id": str(user)})
                    if set(db_members) - set(member_ids):
                        removed_users = list(set(db_members) - set(member_ids))

                    team["name"] = team_info[0]["name"]
                    team["team_img"] = team_info.get("team_img", "")
                    team["members"] = members
                    team["room_id"] = ObjectId(group_room_id)
                condition['teams.created_by'] = ObjectId(user_id)
                update_info = {"$set": {"teams": teams_array}}
                message = "Team updated successfully."
        else:
            raise Exception("Internal server error")
    else:
        raise InvalidUsage("Oops, Group type is missing.", 400)

    if update_info:
        update_team = mongo_session.update_record_into_db(collection="course_work_instances",
                                                          condition={"_id": ObjectId(course_instance_id)},
                                                          update_info=update_info)
    if update_team["status"] != 200:
        raise Exception("Oops, Internal server error.")
    if removed_users:
        data_message = {"courseId": course_id,
                        "click_action": "FLUTTER_NOTIFICATION_CLICK",
                        "module_name": "TeamCreation",
                        "courseworkId": course_work_id,
                        "courseworkInstance": course_instance_id}
        message_title = "Team Removal"
        message_body = "You have been removed from a team."
        notify_team(data_message=data_message,
                    message_title=message_title,
                    message_body=message_body,
                    user_id_list=removed_users)
    if new_users:
        invitee_name = mongo_session.get_data_for_particular_columns_with_condition(
            collection="user_profile",
            condition={"_id": ObjectId(user_id)},
            columns={"username": 1})["message"][0]["username"]

        data_message = {"courseId": course_id,
                        "click_action": "FLUTTER_NOTIFICATION_CLICK",
                        "module_name": "TeamCreation",
                        "courseworkId": course_work_id,
                        "courseworkInstance": course_instance_id}
        message_title = "Team Invitation"
        message_body = "you have been invited to a team."
        notify_team(data_message=data_message,
                    message_title=message_title,
                    message_body=message_body,
                    user_id_list=new_users)
        email_list = []
        user_info = mongo_session.get_data_for_particular_columns_with_condition(
            collection="user_profile",
            condition={"_id": {"$in": new_users}},
            columns={"email": 1,
                     "username": 1})
        if user_info["status"] != 200:
            raise Exception("Internal Server Error")
        user_data = user_info["message"]

        for user in email_users:
            for db_user in user_data:
                if user["_id"] == str(db_user["_id"]):
                    data_db = {"email": db_user["email"],
                               "username": db_user["username"]}
                    team_data = user
                    team_data.update(data_db)
                    email_list.append(team_data)
        if email_list:
            email_status = send_email_invitation(users=email_list,
                                                 course_instance_id=course_instance_id,
                                                 course_work_id=course_work_id,
                                                 course_name=course_data["subject"],
                                                 course_work_name=work_data["courseWorkTitle"],
                                                 invitee_name=invitee_name,
                                                 course_id=course_id)
    return message


def update_member_approval(user_id, course_work_id, course_instance_id, response, team_name, redirect_status,
                           course_id):
    course_name = mongo_session.get_data_for_particular_columns_with_condition(
        collection="courses_bank",
        condition={"_id": ObjectId(course_id)},
        columns={"subject": 1})["message"][0]["subject"]
    course_work_query = mongo_session.get_all_data_for_particular_condition_fields(
        collection="course_work_bank",
        condition={"_id": ObjectId(course_work_id)})
    if course_work_query['status'] != 200:
        return "Something went wrong, please try again later.", 500
    work_data = course_work_query['message'][0]

    required_team_size = int(work_data["group_size"])

    if required_team_size == 1:
        return "Oops, This course work for individuals only.", 409

    schedule_work_info = mongo_session.get_data_for_particular_columns_with_condition(
        collection="course_work_instances",
        condition={"_id": ObjectId(course_instance_id)},
        columns={"start_time": 1, "start_date": 1, "teams": 1})
    if schedule_work_info["status"] != 200:
        raise Exception("Some internal error occurred, please try again later.")
    schedule_data = schedule_work_info["message"][0]

    # members who already accepted the invitation i.e. approval_status = "true" (db_team_members)
    start_time = Content.webapp_time_to_string(schedule_data["start_date"], schedule_data["start_time"])
    start_time = datetime.datetime.strptime(start_time, "%Y:%m:%dT%H:%M")

    timestamp = Question.indian_standard_time()
    timestamp_obj = datetime.datetime.strptime(timestamp, "%d %b %Y, %I:%M %p")

    if timestamp_obj >= start_time:
        return "Course work has already started, we cannot register this action.", 409

    team_existance = False
    for team in schedule_data["teams"]:
        if team["name"] == team_name:
            team_existance = True
            db_team_members = [str(member["_id"]) for member in team["members"] if member["approval_status"] == "true"]
            if len(db_team_members) >= required_team_size:
                return "Sorry, Team is full now.", 409
            for member in team["members"]:
                if member["_id"] == ObjectId(user_id):
                    member["approval_status"] = True if response == "true" or type(
                        response) == bool and response else False
                    room_info = mongo_session.check_existance_return_info(collection='chat_rooms',
                                                                          condition={
                                                                              '_id': ObjectId(team['room_id'])},
                                                                          whole_doc=True)
                    if member['_id'] in room_info['room_members'] and not member["approval_status"]:
                        del room_info['room_members'][member['_id']]

                        update_info = {"$set": {"room_members": room_info['room_members']}}
                        response = mongo_session.update_db_data(collection='chat_rooms',
                                                                condition={'_id': ObjectId(team['room_id'])},
                                                                update_info=update_info)

                    update_team = mongo_session.update_record_into_db(
                        collection="course_work_instances",
                        condition={"_id": ObjectId(course_instance_id)},
                        update_info={"$set": {"teams": schedule_data["teams"]}})
                    if update_team["status"] != 200:
                        raise Exception("Some internal error, Please try again later.")
                    if redirect_status == "false":
                        continue
                    if response == "true":
                        redirect_url = WEB_BASE_URL + "/courses/single-course/invite?course_instance_id=" \
                                                      "{course_instance_id}&course_work_id={course_work_id}&" \
                                                      "course_title={course_title}&team_name={team_name}&" \
                                                      "response=true&course_id={course_id}".format(
                            course_id=course_id,
                            course_instance_id=course_instance_id,
                            course_work_id=course_work_id,
                            team_name=team_name,
                            course_title=course_name)

                        return redirect_url, 302

                    if response == "false":
                        redirect_url = WEB_BASE_URL + "/courses/single-course/invite?course_instance_id=" \
                                                      "{course_instance_id}&course_work_id={course_work_id}&" \
                                                      "course_title={course_title}&team_name={team_name}&" \
                                                      "response=false&confirm=true&course_id={course_id}".format(
                            course_id=course_id,
                            course_instance_id=course_instance_id,
                            course_work_id=course_work_id,
                            team_name=team_name,
                            course_title=course_name)
                        print("redirect url", redirect_url)
                        return redirect_url, 302
            break
    if not team_existance:
        return "Oops! the team you are looking for, no longer exists", 409
    return "Response added successfully.", 200
