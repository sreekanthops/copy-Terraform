import traceback
from datetime import datetime, timedelta
from bson import ObjectId
from services.storage.s3_services import s3_storage
from flask import render_template
from config import EVENTS_PRIORITY
from db_wrapper.tasks import Mongo
s3_function = s3_storage()
mongo_session = Mongo()
import model.course as course_utils

def extract_cw_events(cw_id, schedule_id, course_name, from_date_obj, to_date_obj, course_id, topic_name=None,
                      topic_id=None):
    """ To extract events from a given course work and returning information.
    :param cw_id: id of the course work.
    :param schedule_id: id for the course work instance.
    :param course_name: name of the course.
    :type cw_id: mongo object id.
    :type schedule_id: mongo object id.
    :returns: list of events."""
    cw_events = []
    coursework_id = None
    template_path = "events/course_work"
    course_ins_info = mongo_session.check_existance_return_info(collection="course_work_instances",
                                                                condition={"_id": schedule_id},
                                                                columns={"start_date": 1,
                                                                         "start_time": 1},
                                                                return_keys=["start_date", "start_time"])
    cw_info = mongo_session.check_existance_return_info(collection="course_work_bank",
                                                        condition={"_id": cw_id},
                                                        columns={"courseWorkTitle": 1,
                                                                 "submissionRequirement": 1,
                                                                 "_id": 1},
                                                        return_keys=["courseWorkTitle", "submissionRequirement", "_id"])
    if course_ins_info and cw_info:
        start_date = course_ins_info["start_date"]
        st_time_obj = datetime.strptime(str(start_date["year"]) + "-" + str(start_date["month"]) + "-" + str(start_date["day"]) + " " +
                      course_ins_info["start_time"], "%Y-%m-%d %H:%M")

        end_time_obj = st_time_obj + timedelta(days=int(cw_info["submissionRequirement"][-1]["days_of_completion"]))
        if from_date_obj <= st_time_obj <= to_date_obj:
            event_status = "Starting"
            priority = EVENTS_PRIORITY["low"]
        elif from_date_obj <= end_time_obj <= to_date_obj:
            event_status = "Ending"
            priority = EVENTS_PRIORITY["high"]
        else:
            return []
        coursework_id = cw_info["_id"]
        cw_events.append({"title": "Course Work : " + cw_info["courseWorkTitle"],
                          "start": st_time_obj.strftime("%Y-%m-%d %H:%M:%S.%f"),
                          "end": end_time_obj.strftime("%Y-%m-%d %H:%M:%S.%f"),
                          "duration": "all_day",
                          "color": priority,
                          "event_type": "coursework",
                          "description": render_template(template_path + ".html",
                                                         event_title=cw_info["courseWorkTitle"],
                                                         course_name=course_name,
                                                         status=event_status
                                                         ),
                          "recurring": {
                                         "freq": "daily",
                                         "day": "",
                                         "hour": "",
                                         "min": ""
                                         },
                          "event_detail": {
                              "course_id": str(course_id),
                              "coursework_id": str(coursework_id),
                              "course_name": course_name,
                              "topic": topic_name if topic_name else "",
                              "assessment_id": "",
                              "assessment_name": "",
                              "schedule_assessment_id": "",
                              "topic_id": topic_id if topic_id else "",
                          }
                          })
    return cw_events


def extract_assess_events(assess_id, schedule_id, course_name, from_date_obj, to_date_obj, course_id, topic_name=None,
                          topic_id=None):
    """To extract events from a given assessment and returning information.
    :param assess_id: id of the assessments.
    :param schedule_id: id for the schedule instance of assessment.
    :param course_name: name of the course.
    :type assess_id: mongo object id.
    :type schedule_id: mongo object id.
    :returns: list of events."""
    assess_events = []
    template_path = "events/assessments"
    assess_info = mongo_session.check_existance_return_info(collection="schedule_assessment",
                                                            condition={"_id": schedule_id},
                                                            whole_doc=True)
    if assess_info:
        st_time_obj = datetime.strptime(assess_info["start_time"], "%Y:%m:%dT%H:%M")
        if from_date_obj <= st_time_obj <= to_date_obj:
            end_time_obj = datetime.strptime(assess_info["end_time"], "%Y:%m:%dT%H:%M")
            duration = str(int((end_time_obj - st_time_obj).total_seconds()/60))  # in minutes
            assess_events.append({"title": "Assessment : " + assess_info["assessment_name"],
                                  "start": st_time_obj.strftime("%Y-%m-%d %H:%M:%S.%f"),
                                  "end": end_time_obj.strftime("%Y-%m-%d %H:%M:%S.%f"),
                                  "duration": duration,
                                  "color":  EVENTS_PRIORITY["medium"],
                                  "event_type": "assessment",
                                  "description": render_template(template_path + ".html",
                                                                 event_title=assess_info["assessment_name"],
                                                                 course_name=course_name,
                                                                 status="starting",
                                                                 ),
                                  "event_detail": {
                                      "course_id": str(course_id),
                                      "course_name": course_name,
                                      "topic": topic_name if topic_name else "",
                                      "assessment_id": str(assess_info['assessment_id']),
                                      "assessment_name": assess_info["assessment_name"],
                                      "schedule_assessment_id": str(schedule_id),
                                      "topic_id": topic_id if topic_id else "",
                                  }})
    return assess_events


def system_events(user_id, from_date, to_date):
    """This function search events in database and return a complete list.
       Events: course work submissions, calendered assessments, live sessions on courses.
       :param user_id: id of the user accessing calendar.
       :param from_date: The date from which to start looking for events.
       :param to_date: The last date to look for events.
       :type user_id: str
       :type from_date: str ('%Y-%m-%d')
       :type to_date: str ('%Y-%m-%d')
       :returns:  list of events.
       :rtype: list
    """
    event_list = []
    template_path = "events/live_sessions"
    # check user's subscribed courses
    subscribed_courses = mongo_session.access_specific_fields(collection="courses_bank",
                                                              condition={"subscribers.user_id": ObjectId(user_id)},
                                                              columns={"live_sessions": 1,
                                                                       "course_assessments": 1,
                                                                       "course_work": 1,
                                                                       "topics": 1,
                                                                       "subject": 1,
                                                                       "_id": 1},
                                                              return_keys=["live_sessions", "course_assessments",
                                                                           "course_work", "topics", "subject", "_id"])
    if not subscribed_courses:
        return event_list

    # converts str dates to datetime object
    from_date_obj = datetime.strptime(from_date, '%Y-%m-%d')
    to_date_obj = datetime.strptime(to_date, '%Y-%m-%d')
    schedule_assessments = []

    for course in subscribed_courses:
        # process live sessions
        for session in course["live_sessions"]:
            start_date = session["start_date"]
            end_date = session["end_date"]
            st_time_obj = datetime.strptime(str(start_date["year"]) + "-" + str(start_date["month"]) + "-" + str(start_date["day"]) + " " + session["start_time"], "%Y-%m-%d %H:%M")
            end_time_obj = datetime.strptime(str(end_date["year"]) + "-" + str(end_date["month"]) + "-" + str(end_date["day"]), "%Y-%m-%d")
            if from_date_obj <= st_time_obj <= to_date_obj:
                live_sess_status = "Starting"
                priority = EVENTS_PRIORITY["medium"]
            elif from_date_obj <= end_time_obj <= to_date_obj:
                live_sess_status = "Ending"
                priority = EVENTS_PRIORITY["high"]
            else:
                continue

            live_session_event = {"start": st_time_obj.strftime("%Y-%m-%d %H:%M:%S.%f"),
                                  "end": end_time_obj.strftime("%Y-%m-%d %H:%M:%S.%f"),
                                  "duration": session["duration"],
                                  "title": "Live Session On {}".format(course["subject"]),
                                  "description": render_template(template_path + ".html",
                                                                 course_name=course["subject"],
                                                                 status=live_sess_status,
                                                                 joining_link=session["url"],
                                                                 ),
                                  "color": priority,
                                  "event_type": "live_session",
                                  "event_detail": {
                                      "course_id": str(course['_id']),
                                      "course_name": course["subject"],
                                      "topic": "",
                                      "assessment_id": "",
                                      "assessment_name": "",
                                      "schedule_assessment_id": "",
                                      "topic_id": "",
                                      "live_session_url": session["url"]
                                  }
                                  }

            if session["frequency"] == "daily":
                hour, minute = session["start_time"].split(":")
                live_session_event["recurring"] = {
                                                    "freq": session["frequency"],
                                                    "day": "",
                                                    "hour": hour,
                                                    "min": minute
                                                   }
            elif session["frequency"] == "weekly":
                day = st_time_obj.weekday()
                live_session_event["recurring"] = {
                    "freq": session["frequency"],
                    "day": str(day),
                    "hour": "",
                    "min": ""
                }
            event_list.append(live_session_event)

        for assess in course["course_assessments"]:
            if assess.get("schedule_id"):
                event_list.extend(extract_assessment_events(assess["_id"], assess["schedule_id"], course["subject"],
                                                        from_date_obj, to_date_obj, str(course['_id'])))

        for cw in course["course_work"]:
            if cw.get("schedule_id"):
                event_list.extend(extract_coursework_events(cw["_id"], cw["schedule_id"], course["subject"],
                                                    from_date_obj, to_date_obj, str(course['_id'])))

        # process topics
        if course.get("topics"):
            for topic in course["topics"]:
                topic_info = mongo_session.check_existance_return_info(collection="course_topics",
                                                                       condition={"_id": topic["_id"]},
                                                                       whole_doc=True)

                for assess in topic_info["assessments"]:
                    if assess.get("schedule_id"):
                        event_list.extend(extract_assessment_events(assess["_id"], assess["schedule_id"], course["subject"],
                                                                from_date_obj, to_date_obj, course['_id'],
                                                                topic_name=topic_info['title'],
                                                                topic_id=str(topic['_id'])))
                for cw in topic_info["course_work"]:
                    if cw.get("schedule_id"):
                        event_list.extend(extract_coursework_events(cw["_id"], cw["schedule_id"], course["subject"],
                                                            from_date_obj, to_date_obj, str(course['_id']),
                                                            topic_name=topic_info['title'],
                                                            topic_id=str(topic['_id'])))
                # process sessions
                if topic_info.get("sessions"):
                    for c_session in topic_info["sessions"]:
                        session_info = mongo_session.check_existance_return_info(collection="course_sessions",
                                                                                 condition={"_id": c_session["_id"]},
                                                                                 columns={"_id": 1, "title": 1,
                                                                                          "description": 1,
                                                                                          "assessments": 1},
                                                                                 return_keys=["_id", "description", "assessments"])
                        for assess in session_info["assessments"]:
                            if assess.get("schedule_id"):
                                event_list.extend(extract_assessment_events(assess["_id"], assess["schedule_id"],
                                                                        course["subject"], from_date_obj, to_date_obj,
                                                                        str(course['_id']),
                                                                        topic_name=topic_info['title'],
                                                                        topic_id=str(topic['_id'])
                                                                        ))

    return event_list

def get_event_details(systems_events,role,organisation,user_id):
    """To extract event details for a given event."""
    course_ids = []
    if systems_events:
        for event in systems_events:
            course_id = event["event_detail"]["course_id"]
            event_type = event["event_type"]
            course_ids.append(course_id)
            data, message, api_status = course_utils.view_course(course_id=course_id,
                                                                role=role,
                                                                user_id=user_id,
                                                                organisation=organisation)

            if event_type == "coursework":
                coursework_id = event["event_detail"]["coursework_id"]
                event_detail = data["course_work"]
                course_works = []
                if not data['course_work']:
                    for topic_id in data['topics']:
                        course_works.extend(topic_id['course_work'])

                    event_detail = course_works
                for event_coursework in event_detail:
                    event_coursework_id = event_coursework["_id"]
                    
                    additional_keys = ["submission_requirement", "date", "time", "schedule_id", "team_info", "course_work_description", "course_work_resources","group_size","group_type","is_group"]
                    if event_coursework_id == coursework_id:
                        for key in additional_keys:
                            if event_coursework.get(key):
                                event["event_detail"][key]=event_coursework[key] 
                        
            elif event_type == "assessment":
                assessment_id = event["event_detail"]["assessment_id"]
                event_detail = data["course_assessments"]
                for event_assessment in event_detail:
                    event_assessment_id = event_assessment["_id"]

                    additional_keys = ["active", "end_time", "is_timed", "start_time", "total_time", "view_feedback"]
                    if event_assessment_id == assessment_id:
                        for key in additional_keys:
                            event["event_detail"][key]=event_assessment[key]
                        event["event_detail"]['user_submission'] = True if mongo_session.check_existance_return_info(collection="assessments_result",
                                                                                                                                 condition={"course_id":ObjectId(str(course_id)),
                                                                                                                                            "assessment_id":ObjectId(str(assessment_id)),
                                                                                                                                            "user_id": ObjectId(str(user_id))}) \
                                                                                                                                else False
                        event["event_detail"]['one_time_assessment'] = extract_one_time_assessment(course_id=course_id, assessment_id=assessment_id)
                    elif event["event_detail"]["assessment_subtype"] == "topic":
                        topics = data["topics"]
                        for topic in topics:
                            topic_assessments = topic["assessments"]
                            for assessment in topic_assessments:
                                topic_asses_id = assessment["_id"]
                                if topic_asses_id == assessment_id:
                                    for key in additional_keys:
                                        event["event_detail"][key]=assessment[key]
                                        
                                    event["event_detail"]['user_submission'] = True if mongo_session.check_existance_return_info(collection="assessments_result",
                                                                                                                                 condition={"course_id":ObjectId(str(course_id)),
                                                                                                                                            "assessment_id":ObjectId(str(assessment_id)),
                                                                                                                                            "user_id": ObjectId(str(user_id))}) \
                                                                                                                                else False
                                    event["event_detail"]['one_time_assessment'] = extract_one_time_assessment(course_id=course_id, assessment_id=assessment_id)
            else:
                pass
        return course_ids,systems_events
    else: 
        return course_ids,systems_events

def extract_assessment_events(assess_id, schedule_id, course_name, from_date_obj, to_date_obj, course_id, topic_name=None,
                          topic_id=None):
    """To extract events from a given assessment and returning information.
    :param assess_id: id of the assessments.
    :param schedule_id: id for the schedule instance of assessment.
    :param course_name: name of the course.
    :type assess_id: mongo object id.
    :type schedule_id: mongo object id.
    :returns: list of events."""
    assess_events = []
    template_path = "events/assessments"
    assess_info = mongo_session.check_existance_return_info(collection="schedule_assessment",
                                                            condition={"_id": schedule_id},
                                                            whole_doc=True)
    session_assessment_id = mongo_session.check_existance_return_info(collection="course_sessions",
                                                condition={"assesments._id":assess_id},
                                                whole_doc=True)
    if assess_info:
        st_time_obj = datetime.strptime(assess_info["start_time"], "%Y:%m:%dT%H:%M")

        if from_date_obj <= st_time_obj <= to_date_obj.replace(hour = 23, minute = 59, second = 59):
            end_time_obj = datetime.strptime(assess_info["end_time"], "%Y:%m:%dT%H:%M")
            duration = str(int((end_time_obj - st_time_obj).total_seconds()/60))  # in minutes

            assessment_subtype = None
            if topic_id:
                assessment_subtype = "topic"
            elif session_assessment_id:
                assessment_subtype = "session"
            else:
                assessment_subtype = "course"

            assess_events.append({"title": "Assessment : " + assess_info["assessment_name"],
                                  "start": st_time_obj.strftime("%Y-%m-%d %H:%M:%S.%f"),
                                  "end": end_time_obj.strftime("%Y-%m-%d %H:%M:%S.%f"),
                                  "duration": duration,
                                  "color":  EVENTS_PRIORITY["medium"],
                                  "event_type": "assessment",
                                  "description": render_template(template_path + ".html",
                                                                 event_title=assess_info["assessment_name"],
                                                                 course_name=course_name,
                                                                 status="starting",
                                                                 ),
                                  "event_detail": {
                                      "course_id": str(course_id),
                                      "course_name": course_name,
                                      "topic": topic_name if topic_name else "",
                                      "assessment_id": str(assess_info['assessment_id']),
                                      "assessment_name": assess_info["assessment_name"],
                                      "schedule_assessment_id": str(schedule_id),
                                      "topic_id": topic_id if topic_id else "",
                                      "assessment_subtype": assessment_subtype
                                  }})
    return assess_events
    
def extract_coursework_events(cw_id, schedule_id, course_name, from_date_obj, to_date_obj, course_id, topic_name=None,
                      topic_id=None):
    """ To extract events from a given course work and returning information.
    :param cw_id: id of the course work.
    :param schedule_id: id for the course work instance.
    :param course_name: name of the course.
    :type cw_id: mongo object id.
    :type schedule_id: mongo object id.
    :returns: list of events."""
    cw_events = []
    coursework_id = None
    template_path = "events/course_work"
    course_ins_info = mongo_session.check_existance_return_info(collection="course_work_instances",
                                                                condition={"_id": schedule_id},
                                                                columns={"start_date": 1,
                                                                         "start_time": 1},
                                                                return_keys=["start_date", "start_time"])
    cw_info = mongo_session.check_existance_return_info(collection="course_work_bank",
                                                        condition={"_id": cw_id},
                                                        columns={"courseWorkTitle": 1,
                                                                 "submissionRequirement": 1,
                                                                 "_id": 1},
                                                        return_keys=["courseWorkTitle", "submissionRequirement", "_id"])
    if course_ins_info and cw_info:
        start_date = course_ins_info["start_date"]
        st_time_obj = datetime.strptime(str(start_date["year"]) + "-" + str(start_date["month"]) + "-" + str(start_date["day"]) + " " +
                      course_ins_info["start_time"], "%Y-%m-%d %H:%M")

        end_time_obj = st_time_obj + timedelta(days=int(cw_info["submissionRequirement"][-1]["days_of_completion"]))
        if from_date_obj <= st_time_obj <= to_date_obj:
            event_status = "Starting"
            priority = EVENTS_PRIORITY["low"]
        elif from_date_obj <= end_time_obj <= to_date_obj:
            event_status = "Ending"
            priority = EVENTS_PRIORITY["high"]
        else:
            return []
        coursework_id = cw_info["_id"]
        cw_events.append({"title": "Course Work : " + cw_info["courseWorkTitle"],
                          "start": st_time_obj.strftime("%Y-%m-%d %H:%M:%S.%f"),
                          "end": end_time_obj.strftime("%Y-%m-%d %H:%M:%S.%f"),
                          "duration": "all_day",
                          "color": priority,
                          "event_type": "coursework",
                          "description": render_template(template_path + ".html",
                                                         event_title=cw_info["courseWorkTitle"],
                                                         course_name=course_name,
                                                         status=event_status
                                                         ),
                          "recurring": {
                                         "freq": "daily",
                                         "day": "",
                                         "hour": "",
                                         "min": ""
                                         },
                          "event_detail": {
                              "course_id": str(course_id),
                              "coursework_id": str(coursework_id),
                              "course_name": course_name,
                              "topic": topic_name if topic_name else "",
                              "assessment_id": "",
                              "assessment_name": "",
                              "schedule_assessment_id": "",
                              "topic_id": topic_id if topic_id else "",
                              "coursework_subtype": "topic" if topic_id else "course"
                          }
                          })
    return cw_events
    
def extract_one_time_assessment(course_id, assessment_id):
    existing_c_assessments = mongo_session.access_specific_fields(collection="courses_bank",
                                                                    condition={"_id":ObjectId(str(course_id))})[0]
    if existing_c_assessments.get('course_assessments'):
        for e_c_id in existing_c_assessments['course_assessments']:
            if str(e_c_id['_id']) == str(assessment_id):
                if e_c_id.get('one_time_assessment'):
                    return e_c_id['one_time_assessment']
                else:
                    return False
    if existing_c_assessments.get('topics'):
        for a_topic in existing_c_assessments['topics']:
            existing_t_assessments = mongo_session.access_specific_fields(collection="course_topics",
                                                                            condition={"_id":ObjectId(str(a_topic['_id']))})[0]
            if existing_t_assessments.get('assessments'):
                for e_t_id in existing_t_assessments['assessments']:
                    if str(e_t_id['_id']) == str(assessment_id):
                        if e_t_id.get('one_time_assessment'):
                            return e_t_id['one_time_assessment']
                        else:
                            return False