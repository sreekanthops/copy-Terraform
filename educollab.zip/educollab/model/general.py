import json
import math
import os
import re
import time

import requests
from bson import ObjectId
import config
from db_wrapper.tasks import Mongo
from model import Question
from model.zoom import Zoom
from utils.misc import is_empty

mongo_session = Mongo()
import traceback
from services.storage.s3_services import s3_storage
import json
import requests

s3_function = s3_storage()
from bs4 import BeautifulSoup
from routes.exception import InvalidUsage


def upload_resource_to_s3(files, module_name, user_id):
    if not (files and module_name):
        raise InvalidUsage("Please fill all details", 400)
    if not [True for record in config.storage_paths if record['module_name'] == module_name]:
        raise InvalidUsage("{} module does not have permission to upload resource".format(module_name), 403)
    storage_path, supported_content = [(record['path'], record['supported_content']) for record in config.storage_paths
                                       if record['module_name'] == module_name][0]
    response_data = []

    if not files.getlist('resource'):
        raise InvalidUsage("Please check your request data. No resource info found.", 409)
    for file in files.getlist('resource'):
        resource_content_ext_validation = Question.get_extension_validation(file, supported_content)
        if resource_content_ext_validation[0]:
            unique_key = str(file.filename).split('.')[0] + '__' + str(int(time.time())) + '-' + str(user_id)
            resource_content_type = config.supported_content_type_with_extension[resource_content_ext_validation[1]]
            resource_content_s3_info = s3_function.upload_data_to_s3_private(
                file=file,
                unique_key=unique_key,
                folder_name=storage_path,
                file_extension=resource_content_ext_validation[1],
                Content_Type=resource_content_type)
            if resource_content_s3_info['status'] != 200:
                raise InvalidUsage("Something went wrong while uploading resource", 500)
            resource_content_s3_key = resource_content_s3_info['s3_key']
            time_field = int(time.time())
            doc_to_insert = {"s3_key": resource_content_s3_key,
                             "uploaded_at": time_field,
                             "user_id": ObjectId(user_id),
                             "module_name": module_name,
                             "expires_at": time_field + config.course_resource_expiry_in_sec}
            insert_resource_into_db = mongo_session.insert_doc_upload_resource(
                collection="temp_uploaded_files",
                record=doc_to_insert)['resource_id']
            resource_id = str(insert_resource_into_db)
            s3_link, status = s3_function.generate_presigned_url_from_s3(resource_content_s3_key)
            if not s3_link and status != 200:
                raise InvalidUsage("Error while communicating with s3", 500)
            response_data.append({
                "module_name": module_name,
                "resource_id": resource_id,
                "path": resource_content_s3_key,
                "url": s3_link
            })
        if not response_data:
            raise InvalidUsage("Bad Request", 400)
    return response_data


def get_img_in_question(question):
    """
    In this image src is extracted form html text
    and then the url is generated from the key
    """
    bs_img = BeautifulSoup(question)
    image_tags = bs_img.findAll("img")
    image_urls = []
    for i in image_tags:
        key = i['src']
        url = s3_function.generate_presigned_url_from_s3(key)[0]
        image_urls.append(url)

    return image_urls


def get_urls_for_resources(files, module_name, user_id):
    if not (files and module_name):
        raise InvalidUsage("Please fill all details", 400)
    if not [True for record in config.storage_paths if record['module_name'] == module_name]:
        raise InvalidUsage("{} module does not have permission to upload resource".format(module_name), 403)
    storage_path, supported_content = [(record['path'], record['supported_content']) for record in config.storage_paths
                                       if record['module_name'] == module_name][0]
    response_data = []

    if not files:
        raise InvalidUsage("Please check your request data. No resource info found.", 409)
    for file in files:
        resource_content_ext_validation = Question.get_extension_validation_urls(file, supported_content)
        if resource_content_ext_validation[0]:
            unique_key = ''.join(str(time.time()).split('.')) + '-' + str(user_id)
            key = storage_path + unique_key + resource_content_ext_validation[1]
            s3_url, status = s3_function.upload_presigned_url(key)
            time_field = int(time.time())
            doc_to_insert = {"s3_key": key,
                             "uploaded_at": time_field,
                             "user_id": ObjectId(user_id),
                             "module_name": module_name,
                             "expires_at": time_field + config.course_resource_expiry_in_sec}
            insert_resource_into_db = mongo_session.insert_doc_upload_resource(
                collection="temp_uploaded_files",
                record=doc_to_insert)['resource_id']
            resource_id = str(insert_resource_into_db)
            s3_link, status = s3_function.generate_presigned_url_from_s3(key)
            if not s3_link and status != 200:
                raise InvalidUsage("Error while communicating with s3", 500)
            response_data.append({
                "module_name": module_name,
                "resource_id": resource_id,
                "path": key,
                file: s3_url
            })
    if not response_data:
        raise InvalidUsage("Bad Request", 400)
    return response_data