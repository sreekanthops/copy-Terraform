from db_wrapper.tasks import Mongo
from routes.exception import InvalidUsage
from bson import ObjectId
from services.storage.s3_services import s3_storage
from model import Question as question
from datetime import datetime, timedelta
import model.Content as Content
from db_wrapper.fetch_functions import Fetch
s3_function = s3_storage()
mongo_session = Mongo()
fetch = Fetch()


def delete_submission_file(user_id, course_work_id, course_id, course_instance_id, file_id, report_name, report_index,
                           team_name):
    """1. Function to delete reports in course work.
       2. It will work for team as well as individual too."""
    timestamp = question.indian_standard_time()
    course_query = mongo_session.get_all_data_for_particular_condition_fields(
        collection='courses_bank',
        condition={"_id": ObjectId(course_id)})
    if course_query['status'] != 200:
        raise Exception("Something went wrong, Please try again later.")

    course_data = course_query['message'][0]
    if not course_data['active']:
        raise InvalidUsage("Oops, course is not active anymore.", 403)

    subscribers = [str(user["user_id"]) for user in course_data["subscribers"]]
    if user_id not in subscribers:
        raise InvalidUsage("You need to subscribe the course before adding the submissions.", 403)

    schedule_work_info = mongo_session.get_all_data_for_particular_condition_fields(
        collection="course_work_instances", condition={"_id": ObjectId(course_instance_id)})
    if schedule_work_info['status'] != 200:
        raise Exception("Some internal error occurred, Please try again later.")
    if not schedule_work_info['message']:
        raise InvalidUsage("Oops, This coursework is no longer available.", 404)
    schedule_data = schedule_work_info['message'][0]

    course_work_query = mongo_session.get_all_data_for_particular_condition_fields(
        collection="course_work_bank",
        condition={"_id": ObjectId(course_work_id)})
    if course_work_query['status'] != 200:
        raise Exception("Some internal error occurred, Please try again later.")
    if not course_work_query['message']:
        raise InvalidUsage("Oops, This coursework is no longer available.", 404)
    work_data = course_work_query['message'][0]

    if work_data["is_group"] and not team_name:
        raise InvalidUsage("Please specify a team name", 400)

    start_time = Content.webapp_time_to_string(schedule_data["start_date"], schedule_data["start_time"])
    start_time = datetime.strptime(start_time, "%Y:%m:%dT%H:%M")

    required_reports = work_data["submissionRequirement"]
    if not required_reports:
        raise Exception("Coursework gets modified please check.")

    active_span = int(required_reports[int(report_index)]["days_of_completion"])
    submission_end_date = start_time + timedelta(days=active_span)

    if report_name != required_reports[int(report_index)]["submission_report"]:
        raise InvalidUsage("Oops, This report does not exist.", 400)
    timestamp_obj = datetime.strptime(timestamp, "%d %b %Y, %I:%M %p")

    if timestamp_obj < start_time or timestamp_obj > submission_end_date:
        raise InvalidUsage("Sorry coursework is no longer active for modifications.", 403)

    if not file_id:
        raise InvalidUsage("Please attach the file to delete", 400)

    file_path = ""

    if team_name:
        # delete team submissions
        if not any(team["name"] == team_name for team in schedule_data["teams"]):
            raise InvalidUsage("No such team exist for this course work", 400)
        db_submissions = []
        for data in schedule_data["teams"]:
            if data["name"] == team_name:
                if not any(
                        file["file_id"] == ObjectId(file_id) for file in data["submissions"][report_name]):
                    raise InvalidUsage("File does not exist.", 400)
                if not any(user["_id"] == ObjectId(user_id) for user in data["members"]):
                    raise InvalidUsage("You can't perform this operation, you are not a member of this team.", 403)
                db_submissions = data["submissions"].get(report_name)
        updated_submissions = []
        if not db_submissions:
            raise InvalidUsage("There is nothing to delete on your pile", 409)
        if not any(file["file_id"] == ObjectId(file_id) for file in db_submissions):
            raise InvalidUsage("There is nothing to delete on your pile", 409)
        for file in db_submissions:
            if file["file_id"] == ObjectId(file_id):
                file_path = file["file_path"]
                continue
            updated_submissions.append(file)
        update_query_condition = {
            "_id": ObjectId(course_instance_id),
            "teams": {"$elemMatch":
                {
                    "name": team_name,
                    "submissions": {"$exists": True}
                }
            }
        }
        update_info = {"$set": {"teams.$.submissions." + report_name: updated_submissions}}
    else:
        # delete individual submissions
        if not any(data['user_id'] == ObjectId(user_id) for data in schedule_data["submissions"]):
            raise InvalidUsage("There is nothing to delete on your pile", 409)
        db_submissions = []
        for user in schedule_data["submissions"]:
            if user["user_id"] == ObjectId(user_id):
                db_submissions = user["submitted_files"].get(report_name)
        if not db_submissions:
            raise InvalidUsage("There is nothing to delete on your pile", 409)
        if not any(file["file_id"] == ObjectId(file_id) for file in db_submissions):
            raise InvalidUsage("There is nothing to delete on your pile", 409)

        updated_submissions = []
        for file in db_submissions:
            if file["file_id"] == ObjectId(file_id):
                file_path = file["file_path"]
                continue
            updated_submissions.append(file)

        update_query_condition = {
            "_id": ObjectId(course_instance_id),
            "submissions": {"$elemMatch":
                {
                    "user_id": ObjectId(user_id),
                    "submitted_files": {"$exists": True}
                }
            }
        }
        update_info = {"$set": {"submissions.$.submitted_files." + report_name: updated_submissions}}

    update_data = mongo_session.update_data_submissions(
        collection="course_work_instances", condition=update_query_condition,
        update_info=update_info)

    # delete file from s3
    if len(file_path) > 0:
        if s3_function.delete_s3_data(file_path):
            print("File deleted from s3 bucket")

    if update_data['status'] != 200:
        raise Exception("Internal server error, Please try again later")

    # process file
    delete_resource = ObjectId(file_id)
    insert_date_temp_delete_course_resource = mongo_session.insert_date_temp_delete_course_resource_edit_course(
        collection="course_resource_bank", temp_record="temp_uploaded_files",
        records_to_modify=[delete_resource])
    if insert_date_temp_delete_course_resource['status'] == 400:
        raise Exception("Some internal error occurred, Try again later.")
    return "File successfully deleted."
