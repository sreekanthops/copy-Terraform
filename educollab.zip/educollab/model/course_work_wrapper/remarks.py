from db_wrapper.tasks import Mongo
from routes.exception import InvalidUsage

mongo_session = Mongo()
from bson import ObjectId
from services.storage.s3_services import s3_storage
from model import Question as question
from _datetime import datetime, timedelta
import model.Content as Content

s3_function = s3_storage()

from utils.misc import is_empty


def add_remark(checker_id, schedule_id, team_name, course_work_id, course_id, remark, user_id, submission_name,
               submission_index, grade, role, peer_review_feedback=None, self_review_feedback=None):
    """
    This will allow Teachers, Teaching assistants to add remarks and grades
     on each submission requirement."""
    timestamp = question.indian_standard_time()
    course_query = mongo_session.get_all_data_for_particular_condition_fields(
        collection='courses_bank',
        condition={"_id": ObjectId(course_id)})
    
    self_peer_query = mongo_session.get_all_data_for_particular_condition_fields(
        collection='course_work_instances',
        condition={"_id": ObjectId(schedule_id)})
    self_review = self_peer_query['message'][0]['self_review'] if self_peer_query['message'][0].get('self_review') else False
    peer_review = self_peer_query['message'][0]['peer_review'] if self_peer_query['message'][0].get('peer_review') else False
    publish_sp = self_peer_query['message'][0].get('submission_publish')
    if publish_sp:
        if self_peer_query['message'][0]['submission_publish']:
            if role == 'student' and self_review_feedback and self_peer_query['message'][0]['submission_publish']:
                raise InvalidUsage("You cannot add remarks on this course work, coursework already published", 403)
            if role == 'student' and peer_review_feedback and self_peer_query['message'][0]['submission_publish']:
                raise InvalidUsage("You cannot add remarks on this course work, coursework already published", 403) 

    if course_query['status'] != 200:
        raise Exception("Something went wrong, Please try again later.")

    course_data = course_query['message'][0]
    if not course_data['active']:
        raise InvalidUsage("Oops, course is not active anymore.", 400)
    # teaching assistants on the course
    teaching_assistant = [str(user['_id']) for user in course_data["teach_assis"]]
    publish_rights = [str(user['_id']) for user in course_data["editors"]] + \
                     [str(user['_id']) for user in course_data["instructors"]] + \
                     [str(course_data["created_by"])] + teaching_assistant
    if self_review:
        teaching_assistant = teaching_assistant + [str(user_id)]
        if role == 'student':
            grade = ""
        elif role == 'super_admin' and self_review_feedback:
            grade = ""
        publish_rights = publish_rights + [str(user_id)]
    if peer_review:
        teaching_assistant = teaching_assistant + [str(checker_id)]
        if role == 'student':
            grade = ""
        elif role == 'super_admin' and peer_review_feedback:
            grade = ""
        publish_rights = publish_rights + [str(checker_id)]
    if checker_id not in publish_rights and role != 'super_admin':
        raise InvalidUsage("You cannot add remarks on this course work, Not an authorised user.", 403)
    if role == 'teacher' and peer_review_feedback or role == 'teacher' and self_review_feedback:
        raise InvalidUsage("You cannot add remarks on this course work, Not an authorised user.", 403)
    course_work_query = mongo_session.get_all_data_for_particular_condition_fields(
        collection="course_work_bank",
        condition={"_id": ObjectId(course_work_id)})
    if course_work_query['status'] != 200:
        raise Exception("Some internal error occurred, Please try again later.")
    if not course_work_query['message']:
        raise InvalidUsage("Oops, This coursework is no longer available.", 400)
    work_data = course_work_query['message'][0]

    if work_data["is_group"] and not team_name:
        raise InvalidUsage("Please specify a team name", 400)

    required_reports = work_data["submissionRequirement"]
    if not required_reports:
        raise InvalidUsage("Coursework gets modified please check.", 400)

    if submission_name != required_reports[int(submission_index)]["submission_report"]:
        raise InvalidUsage("Oops, This report does not exist.", 400)

    condition = {"_id": ObjectId(schedule_id)}
    if user_id:
        # individual course work feedback
        columns = {"_id": 1,
                   "submissions": 1,
                   "teach_assis": 1}
        return_keys = ["submissions", "teach_assis"]
    else:
        # group course work
        columns = {"_id": 1,
                   "teams": 1,
                   "teach_assis": 1
                   }
        return_keys = ["teams", "teach_assis"]

    db_data = mongo_session.check_existance_return_info(collection="course_work_instances",
                                                        condition=condition,
                                                        columns=columns,
                                                        return_keys=return_keys)
    if not db_data:
        raise InvalidUsage("Oops! course work does not exist", 400)

    # validate that teaching assistant adding remarks to their assignees only
    if self_review or peer_review:
        pass
    elif checker_id in teaching_assistant:
        assignees = []
        if not team_name:
            # if individual course work
            for assistant in course_data["teach_assis"]:
                if str(assistant["_id"]) == checker_id:
                    assignees = [str(assignee["_id"]) for assignee in assistant["assignees"]]
                    break
            if user_id not in assignees:
                raise InvalidUsage("You are not authorised person to mark this submission.", 403)
        else:
            # if group course work
            if not db_data.get("teach_assis"):
                raise InvalidUsage("You are not authorised person to mark this submission.", 403)
            for assistant in db_data["teach_assis"]:
                if str(assistant["_id"]) == checker_id:
                    assignees = [assignee["team_name"] for assignee in assistant["assignees"]]
                    break
            if team_name not in assignees:
                raise InvalidUsage("You are not authorised person to mark this submission.", 403)

    if user_id:
        # individual course work
        user_submission = db_data["submissions"]
        for data in user_submission:
            if str(data["user_id"]) == user_id:
                if checker_id in teaching_assistant or role in ["super_admin", "teacher"]:
                    data["marked_status"] = True
                if not is_empty(remark):
                    remark_obj = {"content": remark,
                                  "timestamp": timestamp,
                                  "added_by": ObjectId(checker_id)}
                    if data.get("notes") and data["notes"].get(submission_name) and data["notes"][submission_name].get(
                            "remark"):
                        data["notes"][submission_name]["remark"].append(remark_obj)
                    elif data.get("notes") and data["notes"].get(submission_name) and \
                            not data["notes"][submission_name].get("remark"):
                        data["notes"][submission_name]["remark"] = [remark_obj]
                    elif data.get("notes") and not data["notes"].get(submission_name):
                        data["notes"][submission_name] = {"remark": [remark_obj]}
                    else:
                        data["notes"] = {submission_name: {"remark": [remark_obj]}}

                if not is_empty(grade):
                    grade_obj = {"content": grade,
                                 "timestamp": timestamp,
                                 "added_by": ObjectId(checker_id)
                                 }
                    if data.get("notes") and data["notes"].get(submission_name) and data["notes"][submission_name].get(
                            "grade"):
                        data["notes"][submission_name]["grade"].append(grade_obj)
                    elif data.get("notes") and data["notes"].get(submission_name) and \
                            not data["notes"][submission_name].get("grade"):
                        data["notes"][submission_name]["grade"] = [grade_obj]
                    elif data.get("notes") and not data["notes"].get(submission_name):
                        data["notes"][submission_name] = {"grade": [grade_obj]}
                    else:
                        data["notes"] = {submission_name: {"grade": [grade_obj]}}
                if role == 'student' or 'super_admin':
                    if peer_review_feedback:
                        if data.get("notes"):
                            if not data["notes"].get(submission_name):
                                data["notes"].update({submission_name: {"peer_review": {"content": peer_review_feedback,
                                                                                        "timestamp": timestamp,
                                                                                        "added_by": ObjectId(checker_id)}}})
                            else:
                                data["notes"][submission_name]["peer_review"] = {"content": peer_review_feedback,
                                                                                 "timestamp": timestamp,
                                                                                 "added_by": ObjectId(checker_id)}
                        else:
                            data["notes"] = {submission_name: {"peer_review": {"content": peer_review_feedback,
                                                                               "timestamp": timestamp,
                                                                               "added_by": ObjectId(checker_id)}}}
                        
                    if self_review_feedback:
                        if data.get("notes"):
                            if not data["notes"].get(submission_name):
                                data["notes"].update({submission_name: {"self_review": {"content": self_review_feedback,
                                                                                        "timestamp": timestamp,
                                                                                        "added_by": ObjectId(checker_id)}}})
                            else:
                                data["notes"][submission_name]["self_review"] = {"content": self_review_feedback,
                                                                                 "timestamp": timestamp,
                                                                                 "added_by": ObjectId(checker_id)}
                        else:
                            data["notes"] = {submission_name: {"self_review": {"content": self_review_feedback,
                                                                               "timestamp": timestamp,
                                                                               "added_by": ObjectId(checker_id)}}}
        update_info = {"$set": {"submissions": user_submission}}
    else:
        # group course work
        teams = db_data["teams"]
        for data in teams:
            if data["name"] == team_name:
                if checker_id in teaching_assistant or role in ["super_admin", "teacher"]:
                    data["marked_status"] = True
                if not is_empty(remark):
                    remark_obj = {"content": remark,
                                  "timestamp": timestamp,
                                  "added_by": ObjectId(checker_id)}
                    if data.get("notes") and data["notes"].get(submission_name) and data["notes"][submission_name].get(
                            "remark"):
                        data["notes"][submission_name]["remark"].append(remark_obj)
                    elif data.get("notes") and data["notes"].get(submission_name) and \
                            not data["notes"][submission_name].get("remark"):
                        data["notes"][submission_name]["remark"] = [remark_obj]
                    elif data.get("notes") and not data["notes"].get(submission_name):
                        data["notes"][submission_name] = {"remark": [remark_obj]}
                    else:
                        data["notes"] = {submission_name: {"remark": [remark_obj]}}

                if not is_empty(grade):
                    grade_obj = {"content": grade,
                                 "timestamp": timestamp,
                                 "added_by": ObjectId(checker_id)
                                 }
                    if data.get("notes") and data["notes"].get(submission_name) and data["notes"][submission_name].get(
                            "grade"):
                        data["notes"][submission_name]["grade"].append(grade_obj)
                    elif data.get("notes") and data["notes"].get(submission_name) and \
                            not data["notes"][submission_name].get("grade"):
                        data["notes"][submission_name]["grade"] = [grade_obj]
                    elif data.get("notes") and not data["notes"].get(submission_name):
                        data["notes"][submission_name] = {"grade": [grade_obj]}
                    else:
                        data["notes"] = {submission_name: {"grade": [grade_obj]}}
        update_info = {"$set": {"teams": teams}}

    set_remark = mongo_session.update_record_into_db(
        collection="course_work_instances",
        condition=condition,
        update_info=update_info)
    if set_remark["status"] != 200:
        raise Exception("Error while updating record in DB.")
    return "Success"
