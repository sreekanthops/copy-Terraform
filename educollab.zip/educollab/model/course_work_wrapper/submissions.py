import time
import zipfile

import config
from db_wrapper.tasks import Mongo
from model.User import User_Profile, send_mail
from routes.exception import InvalidUsage

mongo_session = Mongo()
from bson import ObjectId
from services.storage.s3_services import s3_storage
from model import Question as question
from _datetime import datetime, timedelta
import model.Content as Content
import boto3
import io
from config import email_Address, email_password
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import ssl
from flask import render_template
from new_celery import celery_app
import copy

s3_function = s3_storage()
from db_wrapper.fetch_functions import Fetch
fetch = Fetch()
import random


def submit_report(user_id, course_work_id, course_id, course_instance_id, file_id, report_name, report_index,
                  team_name, autograding_id):
    """1. Function to submit reports required in course work.
       2. It will work for team as well as individual submissions too."""
    message = "Report successfully submitted."
    timestamp = question.indian_standard_time()
    course_query = mongo_session.get_all_data_for_particular_condition_fields(
        collection='courses_bank',
        condition={"_id": ObjectId(course_id)})
    if course_query['status'] != 200:
        raise Exception("Something went wrong, Please try again later.")
    course_data = course_query['message'][0]
    if not course_data['active']:
        raise InvalidUsage("Oops, course is not active anymore.", 403)
    
    # Self Paced Course
    course_class = course_data.get('course_class', None)
    if course_class:
        course_class = mongo_session.access_specific_fields(collection='course_class',
                                                            condition={'_id': ObjectId(course_class)})[0]['value']
    else:
        course_class = 'Old Structure'
    topics_completed_by_user = []
    topics_completed = False
    if course_class == 'Self Paced Course':
        check_existance = mongo_session.access_specific_fields(collection='courses_progress_tracking',
                                                            condition={"user_id": user_id})
        if check_existance:
            check_existance = check_existance[0]
            for topic in course_data['topics']:
                topic_data = mongo_session.access_specific_fields(collection='course_topics',
                                                                    condition={"_id": ObjectId(str(topic['_id'])), "course_work": {'$elemMatch':{'schedule_id': ObjectId(course_instance_id)}}})
                if topic_data:
                    topic_data = topic_data[0]
                    if str(topic_data['_id']) not in check_existance['topics_completed']:
                        raise InvalidUsage("Please complete the topic before submitting the coursework.", 403)
                if str(topic['_id']) in check_existance['topics_completed']:
                    topics_completed_by_user.append(str(topic['_id']))
            if len(topics_completed_by_user) == len(course_data['topics']):
                topics_completed = True
            if course_data['course_work']:
                for cw in course_data['course_work']:
                    if str(cw['schedule_id']) == str(course_instance_id):
                        if not topics_completed:
                            raise InvalidUsage("Please complete all of the topics before submitting the coursework.", 403)    
        else:
            raise InvalidUsage("Please start the course before submitting the coursework.", 403)
        
    subscribers = [str(user["user_id"]) for user in course_data["subscribers"]]
    if user_id not in subscribers:
        raise InvalidUsage("You need to subscribe the course before adding the submissions.", 403)

    schedule_work_info = mongo_session.get_all_data_for_particular_condition_fields(
        collection="course_work_instances", condition={"_id": ObjectId(course_instance_id)})
    if schedule_work_info['status'] != 200:
        raise Exception("Some internal error occurred, Please try again later.")
    if not schedule_work_info['message']:
        raise InvalidUsage("Oops, This coursework is no longer available.", 404)
    schedule_data = schedule_work_info['message'][0]

    course_work_query = mongo_session.get_all_data_for_particular_condition_fields(
        collection="course_work_bank",
        condition={"_id": ObjectId(course_work_id)})
    if course_work_query['status'] != 200:
        raise Exception("Some internal error occurred, Please try again later.")
    if not course_work_query['message']:
        raise InvalidUsage("Oops, This coursework is no longer available.", 404)
    work_data = course_work_query['message'][0]

    if work_data["is_group"] and not team_name:
        raise InvalidUsage("Please specify a team name", 400)

    start_time = Content.webapp_time_to_string(schedule_data["start_date"], schedule_data["start_time"])
    start_time = datetime.strptime(start_time, "%Y:%m:%dT%H:%M")

    required_reports = work_data["submissionRequirement"]
    if not required_reports:
        raise Exception("Coursework gets modified please check.")

    active_span = int(required_reports[int(report_index)]["days_of_completion"])
    submission_end_date = start_time + timedelta(days=active_span)

    if report_name != required_reports[int(report_index)]["submission_report"]:
        raise InvalidUsage("Oops, This report does not exist.", 409)
    timestamp_obj = datetime.strptime(timestamp, "%d %b %Y, %I:%M %p")

    if timestamp_obj < start_time:
        raise InvalidUsage("Course work is not active for submissions yet.", 400)

    if timestamp_obj > submission_end_date:
        message = "Thank you. As the submission have crossed the deadline, the decision for acceptance lies with the " \
                  "assessor of this course-work. Please contact them for further details. "
    if not file_id:
        raise InvalidUsage("Please attach the file to submit", 409)

    if course_class == 'Self Paced Course':
        message = "Thank you. As the submission you have given is under a self paced course. It may take some time for the " \
                    "coursework to be evaluated."
    # process file
    delete_resource = ObjectId(file_id)
    insert_resource = mongo_session.insert_files_resource_bank(
        collection="course_resource_bank",
        resource_id=ObjectId(file_id),
        temp_collection="temp_uploaded_files")

    if insert_resource["status"] == 200:
        resource_bank_resource_id = insert_resource["message"]
    else:
        raise InvalidUsage(insert_resource["message"], 400)

    s3_key_info = mongo_session.fetch_s3_key_temp_uploaded_files(
        collection="temp_uploaded_files",
        condition={"_id": ObjectId(file_id)}, columns={"s3_key": 1})
    if s3_key_info['status'] != 200:
        raise Exception("Some internal error occurred, Please try again later")

    if team_name:
        # team submissions
        submission_status = False  # whether team has submitted anything before or not
        if not any(team["name"] == team_name for team in schedule_data["teams"]):
            raise InvalidUsage("No such team exist for this course work", 409)
        for data in schedule_data["teams"]:
            if data["name"] == team_name:
                if data["submissions"]:
                    submission_status = True
                if not any(user["_id"] == ObjectId(user_id) for user in data["members"]):
                    raise InvalidUsage(
                        "You can't add submission to this coursework, you are not a member of this team.", 403)
                else:
                    for user in data["members"]:
                        if user["_id"] == ObjectId(user_id) and not user["approval_status"]:
                            raise InvalidUsage("You can't add submission to this coursework, you are not a member of "
                                               "this team.", 403)

        file_info = {
            "user_id": ObjectId(user_id),
            "file_id": resource_bank_resource_id,
            "file_path": s3_key_info['message'],
            "timestamp": timestamp
        }
        db_report_data = None
        data_to_insert = [file_info]
        for team in schedule_data["teams"]:
            if team["name"] == team_name:
                db_report_data = team["submissions"].get(report_name) if team["submissions"] else None

        if db_report_data:
            db_report_data.append(file_info)
            data_to_insert = db_report_data
        update_query_condition = {
            "_id": ObjectId(course_instance_id),
            "teams": {"$elemMatch":
                {
                    "name": team_name,
                    "submissions": {"$exists": True}
                }
            }
        }
        if submission_status:
            update_info = {"$set": {"teams.$.submissions." + report_name: data_to_insert}}
        else:
            update_info = {"$set": {"teams.$.submissions": {report_name: data_to_insert}}}

    else:
        # individual submissions
        if not any(data['user_id'] == ObjectId(user_id) for data in schedule_data["submissions"]):
            # no submission exist for this user
            update_query_condition = {
                "_id": ObjectId(course_instance_id)
            }
            data_to_insert = {"user_id": ObjectId(user_id),
                              "submitted_files": {report_name: [{"timestamp": timestamp,
                                                                 "file_id": resource_bank_resource_id,
                                                                 "file_path": s3_key_info['message']}]}}
            update_info = {"$push": {"submissions": data_to_insert}}

        else:
            # submissions already exist
            db_report_data = None
            for user in schedule_data["submissions"]:
                if user["user_id"] == ObjectId(user_id):
                    db_report_data = user["submitted_files"].get(report_name)
                    break
            file_info = {
                "file_id": resource_bank_resource_id,
                "file_path": s3_key_info['message'],
                "timestamp": timestamp
            }

            data_to_insert = [file_info]

            if db_report_data:
                db_report_data.append(file_info)
                data_to_insert = db_report_data

            update_query_condition = {
                "_id": ObjectId(course_instance_id),
                "submissions": {"$elemMatch":
                    {
                        "user_id": ObjectId(user_id),
                        "submitted_files": {"$exists": True}
                    }
                }
            }
            update_info = {"$set": {"submissions.$.submitted_files." + report_name: data_to_insert}}

    update_data = mongo_session.update_data_submissions(
        collection="course_work_instances", condition=update_query_condition,
        update_info=update_info)

    if autograding_id:
        print('Autograding')
        celery_args = [autograding_id, s3_key_info['message'], course_instance_id, user_id]
        rec_status = celery_app.send_task("tango_autograde", args=celery_args)
        print(rec_status)

    # Peer Review - Late Submission
    add_peer_reviewer(user_id=user_id, coursework_id=course_work_id, instance_id=course_instance_id)

    if update_data['status'] != 200:
        raise Exception("Internal server error, Please try again later")
    record_removed_temp = mongo_session.delete_record_temp_uploaded_files(
        collection="temp_uploaded_files", id_list=[delete_resource])

    file_link, s3_status = s3_function.generate_presigned_url_from_s3(s3_key_info['message'])
    if s3_status != 200:
        raise Exception("Error occurred while communicating with s3 server.")
    return file_link, message

def delete_report(user_id, course_work_id, course_id, course_instance_id, file_detail, report_name, report_index,
                  team_name):
    """1. Function to delete reports in course work.
       2. It will work for team as well as individual too."""
    timestamp = question.indian_standard_time()
    course_query = mongo_session.get_all_data_for_particular_condition_fields(
        collection='courses_bank',
        condition={"_id": ObjectId(course_id)})
    if course_query['status'] != 200:
        raise Exception("Something went wrong, Please try again later.")

    course_data = course_query['message'][0]
    if not course_data['active']:
        raise InvalidUsage("Oops, course is not active anymore.", 403)

    subscribers = [str(user["user_id"]) for user in course_data["subscribers"]]
    if user_id not in subscribers:
        raise InvalidUsage("You need to subscribe the course before adding the submissions.", 403)

    schedule_work_info = mongo_session.get_all_data_for_particular_condition_fields(
        collection="course_work_instances", condition={"_id": ObjectId(course_instance_id)})
    if schedule_work_info['status'] != 200:
        raise Exception("Some internal error occurred, Please try again later.")
    if not schedule_work_info['message']:
        raise InvalidUsage("Oops, This coursework is no longer available.", 404)
    schedule_data = schedule_work_info['message'][0]

    course_work_query = mongo_session.get_all_data_for_particular_condition_fields(
        collection="course_work_bank",
        condition={"_id": ObjectId(course_work_id)})
    if course_work_query['status'] != 200:
        raise Exception("Some internal error occurred, Please try again later.")
    if not course_work_query['message']:
        raise InvalidUsage("Oops, This coursework is no longer available.", 404)
    work_data = course_work_query['message'][0]

    if work_data["is_group"] and not team_name:
        raise InvalidUsage("Please specify a team name", 400)

    start_time = Content.webapp_time_to_string(schedule_data["start_date"], schedule_data["start_time"])
    start_time = datetime.strptime(start_time, "%Y:%m:%dT%H:%M")

    required_reports = work_data["submissionRequirement"]
    if not required_reports:
        raise Exception("Coursework gets modified please check.")

    active_span = int(required_reports[int(report_index)]["days_of_completion"])
    submission_end_date = start_time + timedelta(days=active_span)

    if report_name != required_reports[int(report_index)]["submission_report"]:
        raise InvalidUsage("Oops, This report does not exist.", 400)
    timestamp_obj = datetime.strptime(timestamp, "%d %b %Y, %I:%M %p")

    if timestamp_obj < start_time or timestamp_obj > submission_end_date:
        raise ("Sorry coursework is no longer active for modifications.", 403)

    if not file_detail:
        raise InvalidUsage("Please attach the file to delete", 400)

    if team_name:
        # delete team submissions
        if not any(team["name"] == team_name for team in schedule_data["teams"]):
            raise InvalidUsage("No such team exist for this course work", 400)
        db_submissions = []
        for data in schedule_data["teams"]:
            if data["name"] == team_name:
                if not any(
                        file["file_id"] == ObjectId(file_detail["_id"]) for file in data["submissions"][report_name]):
                    raise InvalidUsage("File does not exist.", 400)
                if not any(user["_id"] == ObjectId(user_id) for user in data["members"]):
                    raise InvalidUsage("You can't perform this operation, you are not a member of this team.", 403)
                db_submissions = data["submissions"].get(report_name)
        updated_submissions = []
        if not db_submissions:
            raise InvalidUsage("There is nothing to delete on your pile", 409)
        if not any(file["file_id"] == ObjectId(file_detail["_id"]) for file in db_submissions):
            raise InvalidUsage("There is nothing to delete on your pile", 409)
        for file in db_submissions:
            if file["file_id"] == ObjectId(file_detail["_id"]):
                continue
            updated_submissions.append(file)
        update_query_condition = {
            "_id": ObjectId(course_instance_id),
            "teams": {"$elemMatch":
                {
                    "name": team_name,
                    "submissions": {"$exists": True}
                }
            }
        }
        update_info = {"$set": {"teams.$.submissions." + report_name: updated_submissions}}
    else:
        # delete individual submissions
        if not any(data['user_id'] == ObjectId(user_id) for data in schedule_data["submissions"]):
            raise InvalidUsage("There is nothing to delete on your pile", 409)
        db_submissions = []
        for user in schedule_data["submissions"]:
            if user["user_id"] == ObjectId(user_id):
                db_submissions = user["submitted_files"].get(report_name)
        if not db_submissions:
            raise InvalidUsage("There is nothing to delete on your pile", 409)
        if not any(file["file_id"] == ObjectId(file_detail["_id"]) for file in db_submissions):
            raise InvalidUsage("There is nothing to delete on your pile", 409)

        updated_submissions = []
        for file in db_submissions:
            if file["file_id"] == ObjectId(file_detail["_id"]):
                continue
            updated_submissions.append(file)

        update_query_condition = {
            "_id": ObjectId(course_instance_id),
            "submissions": {"$elemMatch":
                {
                    "user_id": ObjectId(user_id),
                    "submitted_files": {"$exists": True}
                }
            }
        }
        update_info = {"$set": {"submissions.$.submitted_files." + report_name: updated_submissions}}

    update_data = mongo_session.update_data_submissions(
        collection="course_work_instances", condition=update_query_condition,
        update_info=update_info)
    if update_data['status'] != 200:
        raise Exception("Internal server error, Please try again later")

    # process file
    delete_resource = ObjectId(file_detail["_id"])
    insert_date_temp_delete_course_resource = mongo_session.insert_date_temp_delete_course_resource_edit_course(
        collection="course_resource_bank", temp_record="temp_uploaded_files",
        records_to_modify=[delete_resource])
    if insert_date_temp_delete_course_resource['status'] == 400:
        raise Exception("Some internal error occurred, Try again later.")
    return "Report successfully deleted."


def get_submissions_new(user_id, role, course_id, course_instance_id, course_work_id, team_name=None, peer_review=None,
                    self_review=None, grade_view=None, expand_view=None):
    """Function to fetch submissions done by subscribers on a particular instance. It will work both for teams and
    individuals.
    user_id: user who is accessing the submissions(it could be a student or a teacher).
    course_id: It will specify the course work related to that particular course.
    course_instance_id : It specify the schedule information of the course work.
    team_name: Specify the team whose submissions user wants to see, empty in case of individual submissions."""
    course_query = mongo_session.get_all_data_for_particular_condition_fields(
        collection='courses_bank',
        condition={"_id": ObjectId(course_id)})
    if course_query['status'] != 200:
        raise Exception("Error getting data from courses bank with {}".format(course_id))
    course_data = course_query['message'][0]

    # peer review
    course_work_peer_self = mongo_session.get_all_data_for_particular_condition_fields(
        collection='course_work_instances',
        condition={"_id": ObjectId(course_instance_id)})['message'][0]

    # if not course_data['active']:
    #     raise InvalidUsage("Oops, course is not active anymore.", 403)

    view_rights = [str(user['_id']) for user in course_data["editors"]] + \
                  [str(user['_id']) for user in course_data["instructors"]] + \
                  [str(course_data["created_by"])] + \
                  [str(user['_id']) for user in course_data["teach_assis"]]
    # peer review
    if role == 'student':
        if self_review == "true":
            view_rights = view_rights + [str(user_id)]
        if peer_review == "true":
            if course_work_peer_self.get("peer_reviewer"):
                view_rights = view_rights + [str(user['_id']) for user in course_work_peer_self["peer_reviewer"]]

    if role not in ["teacher", "super_admin"] and user_id not in view_rights:
        subscribers = [str(user["user_id"]) for user in course_data["subscribers"]]
        if user_id not in subscribers:
            raise InvalidUsage("You need to subscribe the course to see any submission.", 403)

    if role == "teacher" and user_id not in view_rights:
        raise InvalidUsage("You don't have permission to see submissions", 403)

    schedule_work_info = mongo_session.get_all_data_for_particular_condition_fields(
        collection="course_work_instances", condition={"_id": ObjectId(course_instance_id)})
    if schedule_work_info['status'] != 200:
        raise Exception("Error getting data from mongo session.")
    if not schedule_work_info['message']:
        raise ("This coursework is no longer available.", 404)
    schedule_data = schedule_work_info['message'][0]
    course_work_query = mongo_session.get_all_data_for_particular_condition_fields(
        collection="course_work_bank",
        condition={"_id": ObjectId(course_work_id)})
    if course_work_query['status'] != 200:
        raise Exception("Error in getting data from course work bank with {}".format(course_work_id))
    if not course_work_query['message']:
        raise InvalidUsage("Oops, This coursework is no longer available.", 404)
    work_data = course_work_query['message'][0]
    submissions = []
    db_submissions = []
    required_reports = [report["submission_report"] for report in work_data["submissionRequirement"]]
    total_submission = len(required_reports)
    publish = schedule_data.get("submission_publish", False)
    if role in ["teacher", "super_admin"] and user_id not in [str(user["_id"] for user in course_data["teach_assis"])]:
        publish = schedule_data.get("submission_publish", False)
    if role in ["teacher", "super_admin"] or user_id in view_rights and grade_view == 'true':
        if work_data["is_group"]:
            # team submissions
            if not schedule_data["teams"]:
                return [], publish
            for data in schedule_data["teams"]:
                team_submissions = {}
                count = 0
                db_submissions = data["submissions"]
                index = 0
                for report in required_reports:
                    if db_submissions and report in db_submissions.keys():
                        count += 1
                        for sub in db_submissions[report]:
                            sub["file_id"] = str(sub["file_id"])
                            sub["filename"] = sub["file_path"].split("/")[-1].split("-")[0]
                            file_link, s3_status = s3_function.generate_presigned_url_from_s3(sub["file_path"])
                            if s3_status != 200:
                                raise Exception("Error occurred while communicating with s3 server.")
                            sub["file_path"] = file_link
                            sub["user_id"] = str(sub["user_id"])
                            file_transcript = mongo_session.get_all_data_for_particular_condition_fields(
                                collection="course_resource_bank",
                                condition={"_id": ObjectId(str(sub["file_id"]))})['message'][0]
                            sub["file_transcript"] = file_transcript.get("transcript", "")

                        grade = data["notes"][report]["grade"][-1] if data.get("notes") and data["notes"].get(
                            report) and \
                                                                      data["notes"][report].get("grade") else {}
                        remark = data["notes"][report]["remark"][-1] if data.get("notes") and data["notes"].get(
                            report) and \
                                                                        data["notes"][report].get("remark") else {}

                        if grade:
                            grade["added_by"] = str(grade["added_by"])
                        if remark:
                            remark["added_by"] = str(remark["added_by"])

                        teach_assis = {}
                        if schedule_data.get("teach_assis"):
                            for assistant in schedule_data["teach_assis"]:
                                if any(assignees["team_name"] == data["name"] for assignees in assistant["assignees"]):
                                    teach_assis["_id"] = str(assistant["_id"])
                        if teach_assis:
                            teach_assis["username"] = mongo_session.get_particular_key_value(
                                collection="user_profile",
                                condition={
                                    "$match": {"_id": ObjectId(
                                        teach_assis["_id"])}},
                                return_info={
                                    "$project": {
                                        "username": "$username"}})["username"]
                        team_submissions["teach_assis"] = teach_assis
                        team_submissions["name"] = data["name"]
                        team_submissions["grade"] = ""
                        team_submissions["user_id"] = ""
                        team_submissions[report] = {"grade": grade,
                                                    "remark": remark,
                                                    "files": db_submissions[report],
                                                    "index": index}
                    else:
                        team_submissions[report] = {"grade": {},
                                                    "remark": {},
                                                    "files": [],
                                                    "index": index}
                    index = index + 1
                submissions.append({"submissions": team_submissions,
                                    "total_submissions": '{}/{}'.format(count, total_submission)})

        else:
            # individual submissions
            if not schedule_data["submissions"]:
                return [], publish
            for user in schedule_data["submissions"]:
                user_submissions = {}
                db_submissions = user["submitted_files"]
                index = 0
                count = 0
                for report in required_reports:
                    if db_submissions and report in db_submissions.keys():
                        count += 1
                        for sub in db_submissions[report]:
                            sub["file_id"] = str(sub["file_id"])
                            sub["filename"] = sub["file_path"].split("/")[-1].split("-")[0]
                            file_link, s3_status = s3_function.generate_presigned_url_from_s3(sub["file_path"])
                            if s3_status != 200:
                                raise Exception("Error occurred while communicating with s3 server.")
                            sub["file_path"] = file_link
                            file_transcript = mongo_session.get_all_data_for_particular_condition_fields(
                                collection="course_resource_bank",
                                condition={"_id": ObjectId(str(sub["file_id"]))})['message'][0]
                            sub["file_transcript"] = file_transcript.get("transcript", "")
                        grade = user["notes"][report]["grade"][-1] if user.get("notes") and user["notes"].get(
                            report) and \
                                                                      user["notes"][report].get("grade") else {}

                        remark = user["notes"][report]["remark"][-1] if user.get("notes") and user["notes"].get(
                            report) and user["notes"][report].get("remark") else {}

                        # peer review
                        peer_review_feedback = user["notes"][report]["peer_review"] if user.get("notes") and user[
                            "notes"].get(report) and \
                                                                                       user["notes"][report].get(
                                                                                           "peer_review") else {}
                        self_review_feedback = user["notes"][report]["self_review"] if user.get("notes") and user[
                            "notes"].get(report) and \
                                                                                       user["notes"][report].get(
                                                                                           "self_review") else {}

                        if grade:
                            grade["added_by"] = str(grade["added_by"])
                        if remark:
                            remark["added_by"] = str(remark["added_by"])
                        if peer_review_feedback:
                            peer_review_feedback["added_by"] = str(peer_review_feedback["added_by"])
                        if self_review_feedback:
                            self_review_feedback["added_by"] = str(self_review_feedback["added_by"])

                        teach_assis = {}
                        for assistant in course_data["teach_assis"]:
                            if any(assignees["_id"] == ObjectId(user["user_id"]) for assignees in assistant["assignees"]):
                                teach_assis["_id"] = str(assistant["_id"])
                        if teach_assis:
                            teach_assis["username"] = mongo_session.get_particular_key_value(
                                collection="user_profile",
                                condition={
                                    "$match": {"_id": ObjectId(
                                        teach_assis["_id"])}},
                                return_info={
                                    "$project": {
                                        "username": "$username"}})["username"]
                        username = mongo_session.get_particular_key_value(collection="user_profile",
                                                                          condition={
                                                                              "$match": {"_id": ObjectId(user["user_id"])}},
                                                                          return_info={
                                                                              "$project": {"username": "$username"}})[
                            "username"]
                        # PK Peer Review
                        if role == 'student':
                            if peer_review == 'true':
                                if course_work_peer_self.get("peer_reviewer"):
                                    teach_assis = {}
                                    for assistant in course_work_peer_self["peer_reviewer"]:
                                        if any(assignees["_id"] == ObjectId(user["user_id"]) for assignees in
                                               assistant["assignees"]):
                                            teach_assis["_id"] = str(assistant["_id"])
                                            print(teach_assis["_id"])
                                    if teach_assis:
                                        teach_assis["username"] = mongo_session.get_particular_key_value(
                                            collection="user_profile",
                                            condition={
                                                "$match": {"_id": ObjectId(
                                                    teach_assis["_id"])}},
                                            return_info={
                                                "$project": {
                                                    "username": "$username"}})["username"]


                        user_submissions[report] = {"grade": grade,
                                                    "remark": remark,
                                                    "files": db_submissions[report],
                                                    "index": index,
                                                    "peer_review": peer_review_feedback,
                                                    "self_review": self_review_feedback,
                                                    "teach_assis": teach_assis,
                                                    "name": username}
                    else:
                        user_submissions[report] = {"grade": {},
                                                    "remark": {},
                                                    "files": [],
                                                    "index": index,
                                                    "peer_review": {},
                                                    "self_review": {},
                                                    "teach_assis": {},
                                                    "name": ""}
                    index = index + 1
                teach_assis = {}
                for assistant in course_data["teach_assis"]:
                    if any(assignees["_id"] == ObjectId(user["user_id"]) for assignees in assistant["assignees"]):
                        teach_assis["_id"] = str(assistant["_id"])
                if teach_assis:
                    teach_assis["username"] = mongo_session.get_particular_key_value(
                        collection="user_profile",
                        condition={
                            "$match": {"_id": ObjectId(
                                teach_assis["_id"])}},
                        return_info={
                            "$project": {
                                "username": "$username"}})["username"]
                # PK Peer Review
                if role == 'student':
                    if peer_review == 'true':
                        if course_work_peer_self.get("peer_reviewer"):
                            teach_assis = {}
                            for assistant in course_work_peer_self["peer_reviewer"]:
                                if any(assignees["_id"] == ObjectId(user["user_id"]) for assignees in
                                       assistant["assignees"]):
                                    teach_assis["_id"] = str(assistant["_id"])
                                    print(teach_assis["_id"])
                            if teach_assis:
                                teach_assis["username"] = mongo_session.get_particular_key_value(
                                    collection="user_profile",
                                    condition={
                                        "$match": {"_id": ObjectId(
                                            teach_assis["_id"])}},
                                    return_info={
                                        "$project": {
                                            "username": "$username"}})["username"]

                submissions.append({"user_id": str(user["user_id"]),
                                    "teach_assis": teach_assis,
                                    "submissions": user_submissions
                                    })

    else:
        submissions = {}
        if work_data["is_group"] and not team_name:
            raise InvalidUsage("Please specify a team name", 400)
        if team_name:
            # view team submissions
            if not any(team["name"] == team_name for team in schedule_data["teams"]):
                raise InvalidUsage("No such team exist for this course work", 400)

            for data in schedule_data["teams"]:
                if data["name"] == team_name:
                    if not data["submissions"]:
                        # There are no submissions
                        return {}, publish
                    if not any(user["_id"] == ObjectId(user_id) for user in data["members"]):
                        raise InvalidUsage("Permission denied, you are not a member of this team.", 403)
                    db_submissions = data["submissions"]
                    db_notes = data.get("notes", [])
            index = 0
            for report in required_reports:
                if db_submissions and report in db_submissions.keys():
                    for sub in db_submissions[report]:
                        sub["file_id"] = str(sub["file_id"])
                        sub["filename"] = sub["file_path"].split("/")[-1].split("-")[0]
                        file_link, s3_status = s3_function.generate_presigned_url_from_s3(sub["file_path"])
                        if s3_status != 200:
                            raise Exception("Error occurred while communicating with s3 server.")
                        sub["file_path"] = file_link
                        sub["user_id"] = str(sub["user_id"])
                        file_transcript = mongo_session.get_all_data_for_particular_condition_fields(
                            collection="course_resource_bank",
                            condition={"_id": ObjectId(str(sub["file_id"]))})['message'][0]
                        sub["file_transcript"] = file_transcript.get("transcript", "")
                    if publish:
                        grade = db_notes[report]["grade"][-1] if db_notes and db_notes.get(report) and \
                                                                 db_notes[report].get("grade") else {}
                        remark = db_notes[report]["remark"][-1] if db_notes and db_notes.get(
                            report) and db_notes[report].get("remark") else {}
                    else:
                        grade = {}
                        remark = {}
                    if grade:
                        grade["added_by"] = str(grade["added_by"])
                    if remark:
                        remark["added_by"] = str(remark["added_by"])

                    submissions[report] = {"grade": grade,
                                           "remark": remark,
                                           "files": db_submissions[report],
                                           "index": index}
                else:
                    submissions[report] = {"grade": {},
                                           "remark": {},
                                           "files": [],
                                           "index": index}
                index = index + 1
        else:
            # show individual submissions
            submissions = {}
            if not any(data['user_id'] == ObjectId(user_id) for data in schedule_data["submissions"]):
                # There are no submissions
                return [], publish
            for user in schedule_data["submissions"]:
                if user["user_id"] == ObjectId(user_id):
                    if not user["submitted_files"]:
                        # There are no submissions
                        return [], publish
                    db_submissions = user["submitted_files"]
                    db_notes = user["notes"] if user.get("notes") else {}
            index = 0
            for report in required_reports:
                if db_submissions and report in db_submissions.keys():
                    for sub in db_submissions[report]:
                        sub["file_id"] = str(sub["file_id"])
                        sub["filename"] = sub["file_path"].split("/")[-1].split("-")[0]
                        file_link, s3_status = s3_function.generate_presigned_url_from_s3(sub["file_path"])
                        if s3_status != 200:
                            raise Exception("Error occurred while communicating with s3 server.")
                        sub["file_path"] = file_link
                        file_transcript = mongo_session.get_all_data_for_particular_condition_fields(
                            collection="course_resource_bank",
                            condition={"_id": ObjectId(str(sub["file_id"]))})['message'][0]
                        sub["file_transcript"] = file_transcript.get("transcript", "")
                    if publish:
                        grade = db_notes[report]["grade"][-1] if db_notes and db_notes.get(report) and \
                                                                 db_notes[report].get("grade") else {}
                        remark = db_notes[report]["remark"][-1] if db_notes and db_notes.get(
                            report) and db_notes[report].get("remark") else {}
                        peer_review_feedback = db_notes[report]["peer_review"] if db_notes and db_notes.get(
                            report) and db_notes[report].get("peer_review") else {}
                        self_review_feedback = db_notes[report]["self_review"] if db_notes and db_notes.get(
                            report) and db_notes[report].get("self_review") else {}
                    else:
                        grade = {}
                        remark = {}
                        peer_review_feedback = {}
                        self_review_feedback = db_notes[report]["self_review"] if db_notes and db_notes.get(
                            report) and db_notes[report].get("self_review") else {}

                    if grade:
                        grade["added_by"] = str(grade["added_by"])
                    if remark:
                        remark["added_by"] = str(remark["added_by"])
                    if peer_review_feedback:
                        peer_review_feedback["added_by"] = str(peer_review_feedback["added_by"])
                    if self_review_feedback:
                        self_review_feedback["added_by"] = str(self_review_feedback["added_by"])

                    submissions[report] = {"grade": grade,
                                           "remark": remark,
                                           "files": db_submissions[report],
                                           "index": index,
                                           "peer_review": peer_review_feedback,
                                           "self_review": self_review_feedback}
                else:
                    submissions[report] = {"grade": {},
                                           "remark": {},
                                           "files": [],
                                           "index": index,
                                           "peer_review": {},
                                           "self_review": {}}
                index = index + 1
    # peer review
    if role == 'student' and grade_view == 'true':
        submission = []
        if self_review == "true":
            if submissions:
                for data in submissions:
                    if data.get('user_id') == str(user_id):
                        temp_data = copy.deepcopy(data)
                        sr_username = mongo_session.get_particular_key_value(
                            collection="user_profile",
                            condition={
                                "$match": {"_id": ObjectId(str(user_id))}},
                            return_info={
                                "$project": {
                                    "username": "$username"}})["username"]
                        temp_data['teach_assis'] = {"_id": str(user_id), "username": sr_username}
                        temp_data['self_review_status'] = True
                        temp_data['peer_review_status'] = False
                        for x in temp_data['submissions']:
                            if not publish:
                                temp_data['submissions'][x]['peer_review'] = {}
                        submission.append(temp_data)
        if peer_review == "true":
            if submissions:
                for data in submissions:
                    if isinstance(data, dict):
                        if data.get('teach_assis'):
                            if data['teach_assis']['_id'] == str(user_id):
                                temp_data = copy.deepcopy(data)

                                temp_data['self_review_status'] = False
                                temp_data['peer_review_status'] = True
                                for x in temp_data['submissions']:
                                    if not publish:
                                        temp_data['submissions'][x]['self_review'] = {}
                                    if role == 'student':
                                        temp_data['submissions'][x]['self_review'] = {}
                                        temp_data['submissions'][x]['remark'] = {}
                                submission.append(temp_data)
        submissions = submission
    return submissions, publish


def get_submissions(user_id, role, course_id, course_instance_id, course_work_id, team_name=None, peer_review=None,
                    self_review=None, grade_view=None, expand_view=None):
    """Function to fetch submissions done by subscribers on a particular instance. It will work both for teams and
    individuals.
    user_id: user who is accessing the submissions(it could be a student or a teacher).
    course_id: It will specify the course work related to that particular course.
    course_instance_id : It specify the schedule information of the course work.
    team_name: Specify the team whose submissions user wants to see, empty in case of individual submissions."""
    course_query = mongo_session.get_all_data_for_particular_condition_fields(
        collection='courses_bank',
        condition={"_id": ObjectId(course_id)})
    if course_query['status'] != 200:
        raise Exception("Error getting data from courses bank with {}".format(course_id))
    course_data = course_query['message'][0]

    # peer review
    course_work_peer_self = mongo_session.get_all_data_for_particular_condition_fields(
        collection='course_work_instances',
        condition={"_id": ObjectId(course_instance_id)})['message'][0]

    # if not course_data['active']:
    #     raise InvalidUsage("Oops, course is not active anymore.", 403)

    view_rights = [str(user['_id']) for user in course_data["editors"]] + \
                  [str(user['_id']) for user in course_data["instructors"]] + \
                  [str(course_data["created_by"])] + \
                  [str(user['_id']) for user in course_data["teach_assis"]]
    # peer review
    if role == 'student':
        if self_review == "true":
            view_rights = view_rights + [str(user_id)]
        else:
            view_rights = view_rights + [str(user_id)]
        if peer_review == "true":
            if course_work_peer_self.get("peer_reviewer"):
                view_rights = view_rights + [str(user['_id']) for user in course_work_peer_self["peer_reviewer"]]

    if role not in ["teacher", "super_admin"] and user_id not in view_rights:
        subscribers = [str(user["user_id"]) for user in course_data["subscribers"]]
        if user_id not in subscribers:
            raise InvalidUsage("You need to subscribe the course to see any submission.", 403)

    if role == "teacher" and user_id not in view_rights:
        raise InvalidUsage("You don't have permission to see submissions", 403)

    schedule_work_info = mongo_session.get_all_data_for_particular_condition_fields(
        collection="course_work_instances", condition={"_id": ObjectId(course_instance_id)})
    if schedule_work_info['status'] != 200:
        raise Exception("Error getting data from mongo session.")
    if not schedule_work_info['message']:
        raise ("This coursework is no longer available.", 404)
    schedule_data = schedule_work_info['message'][0]
    course_work_query = mongo_session.get_all_data_for_particular_condition_fields(
        collection="course_work_bank",
        condition={"_id": ObjectId(course_work_id)})
    if course_work_query['status'] != 200:
        raise Exception("Error in getting data from course work bank with {}".format(course_work_id))
    if not course_work_query['message']:
        raise InvalidUsage("Oops, This coursework is no longer available.", 404)
    work_data = course_work_query['message'][0]
    submissions = []
    db_submissions = []
    required_reports = [report["submission_report"] for report in work_data["submissionRequirement"]]
    total_submission = len(required_reports)
    publish = schedule_data.get("submission_publish", False)
    if role in ["teacher", "super_admin"] and user_id not in [str(user["_id"] for user in course_data["teach_assis"])]:
        publish = schedule_data.get("submission_publish", False)
    if role in ["teacher", "super_admin"] or user_id in view_rights and grade_view == 'true':
        if work_data["is_group"]:
            # team submissions
            if not schedule_data["teams"]:
                return [], publish
            for data in schedule_data["teams"]:
                marked_status = data.get("marked_status", False)
                team_submissions = {}
                count = 0
                db_submissions = data["submissions"]
                index = 0
                for report in required_reports:
                    if db_submissions and report in db_submissions.keys():
                        count += 1
                        for sub in db_submissions[report]:
                            sub["file_id"] = str(sub["file_id"])
                            sub["filename"] = sub["file_path"].split("/")[-1].split("-")[0]
                            file_link, s3_status = s3_function.generate_presigned_url_from_s3(sub["file_path"])
                            if s3_status != 200:
                                raise Exception("Error occurred while communicating with s3 server.")
                            sub["file_path"] = file_link
                            sub["user_id"] = str(sub["user_id"])
                            file_transcript = mongo_session.get_all_data_for_particular_condition_fields(
                                collection="course_resource_bank",
                                condition={"_id": ObjectId(str(sub["file_id"]))})['message'][0]
                            sub["file_transcript"] = file_transcript.get("transcript", "")

                        grade = data["notes"][report]["grade"][-1] if data.get("notes") and data["notes"].get(
                            report) and \
                                                                      data["notes"][report].get("grade") else {}
                        remark = data["notes"][report]["remark"][-1] if data.get("notes") and data["notes"].get(
                            report) and \
                                                                        data["notes"][report].get("remark") else {}

                        if grade:
                            grade["added_by"] = str(grade["added_by"])
                        if remark:
                            remark["added_by"] = str(remark["added_by"])

                        team_submissions[report] = {"grade": grade,
                                                    "remark": remark,
                                                    "files": db_submissions[report],
                                                    "index": index}
                    else:
                        team_submissions[report] = {"grade": {},
                                                    "remark": {},
                                                    "files": [],
                                                    "index": index}
                    index = index + 1
                teach_assis = {}
                if schedule_data.get("teach_assis"):
                    for assistant in schedule_data["teach_assis"]:
                        if any(assignees["team_name"] == data["name"] for assignees in assistant["assignees"]):
                            teach_assis["_id"] = str(assistant["_id"])
                if teach_assis:
                    # teach_assis["username"] = mongo_session.get_particular_key_value(
                    #     collection="user_profile",
                    #     condition={
                    #         "$match": {"_id": ObjectId(
                    #             teach_assis["_id"])}},
                    #     return_info={
                    #         "$project": {
                    #             "username": "$username"}})["username"]
                    teach_assis_info = mongo_session.get_data_for_particular_columns_with_condition(
                        collection="user_profile",
                        condition={"_id": ObjectId(teach_assis["_id"])},
                        columns={"_id": 1,
                                 "username": 1,
                                 "name": 1,
                                 "last_name": 1})['message'][0]
                    teach_assis["username"] = teach_assis_info['username']
                    teach_assis["name"] = teach_assis_info['name'] + ' ' + teach_assis_info['last_name']

                submissions.append({"name": data["name"],
                                    "profile_name": data['name'],
                                    "teach_assis": teach_assis,
                                    "grade": "",
                                    "user_id": "",
                                    "submissions": team_submissions,
                                    "total_submissions": '{}/{}'.format(count, total_submission),
                                    "marked_status": marked_status})
        else:
            # individual submissions
            if not schedule_data["submissions"]:
                return [], publish
            for user in schedule_data["submissions"]:
                marked_status = user.get("marked_status", False)
                user_submissions = {}
                db_submissions = user["submitted_files"]
                index = 0
                count = 0
                for report in required_reports:
                    if db_submissions and report in db_submissions.keys():
                        count += 1
                        for sub in db_submissions[report]:
                            sub["file_id"] = str(sub["file_id"])
                            sub["filename"] = sub["file_path"].split("/")[-1].split("-")[0]
                            file_link, s3_status = s3_function.generate_presigned_url_from_s3(sub["file_path"])
                            if s3_status != 200:
                                raise Exception("Error occurred while communicating with s3 server.")
                            sub["file_path"] = file_link
                            file_transcript = mongo_session.get_all_data_for_particular_condition_fields(
                                collection="course_resource_bank",
                                condition={"_id": ObjectId(str(sub["file_id"]))})['message'][0]
                            sub["file_transcript"] = file_transcript.get("transcript", "")
                        grade = user["notes"][report]["grade"][-1] if user.get("notes") and user["notes"].get(
                            report) and \
                                                                      user["notes"][report].get("grade") else {}

                        remark = user["notes"][report]["remark"][-1] if user.get("notes") and user["notes"].get(
                            report) and user["notes"][report].get("remark") else {}

                        # peer review
                        peer_review_feedback = user["notes"][report]["peer_review"] if user.get("notes") and user[
                            "notes"].get(report) and \
                                                                                       user["notes"][report].get(
                                                                                           "peer_review") else {}
                        self_review_feedback = user["notes"][report]["self_review"] if user.get("notes") and user[
                            "notes"].get(report) and \
                                                                                       user["notes"][report].get(
                                                                                           "self_review") else {}

                        if grade:
                            grade["added_by"] = str(grade["added_by"])
                        if remark:
                            remark["added_by"] = str(remark["added_by"])
                        if peer_review_feedback:
                            peer_review_feedback["added_by"] = str(peer_review_feedback["added_by"])
                        if self_review_feedback:
                            self_review_feedback["added_by"] = str(self_review_feedback["added_by"])

                        user_submissions[report] = {"grade": grade,
                                                    "remark": remark,
                                                    "files": db_submissions[report],
                                                    "index": index,
                                                    "peer_review": peer_review_feedback,
                                                    "self_review": self_review_feedback}
                    else:
                        user_submissions[report] = {"grade": {},
                                                    "remark": {},
                                                    "files": [],
                                                    "index": index,
                                                    "peer_review": {},
                                                    "self_review": {}}
                    index = index + 1
                # username = mongo_session.get_particular_key_value(collection="user_profile",
                #                                                   condition={
                #                                                       "$match": {"_id": ObjectId(user["user_id"])}},
                #                                                   return_info={"$project": {"username": "$username"}})[
                #     "username"]
                user_info = mongo_session.get_data_for_particular_columns_with_condition(collection="user_profile",
                                                                                         condition={"_id": ObjectId(user["user_id"])},
                                                                                         columns={"_id": 1,
                                                                                                  "username": 1,
                                                                                                  "name": 1,
                                                                                                  "last_name": 1}
                                                                                         )['message'][0]
                username = user_info['username']
                user_profile_name = user_info['name'] + ' ' + user_info['last_name']
                teach_assis = {}
                for assistant in course_data["teach_assis"]:
                    if any(assignees["_id"] == ObjectId(user["user_id"]) for assignees in assistant["assignees"]):
                        teach_assis["_id"] = str(assistant["_id"])
                if teach_assis:
                    # teach_assis["username"] = mongo_session.get_particular_key_value(
                    #     collection="user_profile",
                    #     condition={
                    #         "$match": {"_id": ObjectId(
                    #             teach_assis["_id"])}},
                    #     return_info={
                    #         "$project": {
                    #             "username": "$username"}})["username"]
                    teach_assis_info = mongo_session.get_data_for_particular_columns_with_condition(
                        collection="user_profile",
                        condition={"_id": ObjectId(teach_assis["_id"])},
                        columns={"_id": 1,
                                 "username": 1,
                                 "name": 1,
                                 "last_name": 1})['message'][0]
                    teach_assis["username"] = teach_assis_info['username']
                    teach_assis["name"] = teach_assis_info['name'] + ' ' + teach_assis_info['last_name']
                # PK Peer Review
                if role == 'student':
                    if peer_review == 'true':
                        if course_work_peer_self.get("peer_reviewer"):
                            teach_assis = {}
                            for assistant in course_work_peer_self["peer_reviewer"]:
                                if any(assignees["_id"] == ObjectId(user["user_id"]) for assignees in
                                       assistant["assignees"]):
                                    teach_assis["_id"] = str(assistant["_id"])
                                    print(teach_assis["_id"])
                            if teach_assis:
                                # teach_assis["username"] = mongo_session.get_particular_key_value(
                                #     collection="user_profile",
                                #     condition={
                                #         "$match": {"_id": ObjectId(
                                #             teach_assis["_id"])}},
                                #     return_info={
                                #         "$project": {
                                #             "username": "$username"}})["username"]
                                teach_assis_info = mongo_session.get_data_for_particular_columns_with_condition(
                                    collection="user_profile",
                                    condition={"_id": ObjectId(teach_assis["_id"])},
                                    columns={"_id": 1,
                                             "username": 1,
                                             "name": 1,
                                             "last_name": 1})['message'][0]
                                teach_assis["username"] = teach_assis_info['username']
                                teach_assis["name"] = teach_assis_info['name'] + ' ' + teach_assis_info['last_name']
                submissions.append({"name": username,
                                    "profile_name": user_profile_name,
                                    "teach_assis": teach_assis,
                                    "grade": "",
                                    "user_id": str(user["user_id"]),
                                    "submissions": user_submissions,
                                    "marked_status": marked_status
                                    })

    else:
        submissions = {}
        if work_data["is_group"] and not team_name:
            raise InvalidUsage("Please specify a team name", 400)
        if team_name:
            # view team submissions
            if not any(team["name"] == team_name for team in schedule_data["teams"]):
                raise InvalidUsage("No such team exist for this course work", 400)

            for data in schedule_data["teams"]:
                if data["name"] == team_name:
                    if not data["submissions"]:
                        # There are no submissions
                        return {}, publish
                    if not any(user["_id"] == ObjectId(user_id) for user in data["members"]):
                        raise InvalidUsage("Permission denied, you are not a member of this team.", 403)
                    db_submissions = data["submissions"]
                    db_notes = data.get("notes", [])
            index = 0
            for report in required_reports:
                if db_submissions and report in db_submissions.keys():
                    for sub in db_submissions[report]:
                        sub["file_id"] = str(sub["file_id"])
                        sub["filename"] = sub["file_path"].split("/")[-1].split("-")[0]
                        file_link, s3_status = s3_function.generate_presigned_url_from_s3(sub["file_path"])
                        if s3_status != 200:
                            raise Exception("Error occurred while communicating with s3 server.")
                        sub["file_path"] = file_link
                        sub["user_id"] = str(sub["user_id"])
                        file_transcript = mongo_session.get_all_data_for_particular_condition_fields(
                            collection="course_resource_bank",
                            condition={"_id": ObjectId(str(sub["file_id"]))})['message'][0]
                        sub["file_transcript"] = file_transcript.get("transcript", "")
                    if publish:
                        grade = db_notes[report]["grade"][-1] if db_notes and db_notes.get(report) and \
                                                                 db_notes[report].get("grade") else {}
                        remark = db_notes[report]["remark"][-1] if db_notes and db_notes.get(
                            report) and db_notes[report].get("remark") else {}
                    else:
                        grade = {}
                        remark = {}
                    if grade:
                        grade["added_by"] = str(grade["added_by"])
                    if remark:
                        remark["added_by"] = str(remark["added_by"])

                    submissions[report] = {"grade": grade,
                                           "remark": remark,
                                           "files": db_submissions[report],
                                           "index": index}
                else:
                    submissions[report] = {"grade": {},
                                           "remark": {},
                                           "files": [],
                                           "index": index}
                index = index + 1
        else:
            # show individual submissions
            submissions = {}
            if not any(data['user_id'] == ObjectId(user_id) for data in schedule_data["submissions"]):
                # There are no submissions
                return [], publish
            for user in schedule_data["submissions"]:
                if user["user_id"] == ObjectId(user_id):
                    if not user["submitted_files"]:
                        # There are no submissions
                        return [], publish
                    db_submissions = user["submitted_files"]
                    db_notes = user["notes"] if user.get("notes") else {}
            index = 0
            for report in required_reports:
                if db_submissions and report in db_submissions.keys():
                    for sub in db_submissions[report]:
                        sub["file_id"] = str(sub["file_id"])
                        sub["filename"] = sub["file_path"].split("/")[-1].split("-")[0]
                        file_link, s3_status = s3_function.generate_presigned_url_from_s3(sub["file_path"])
                        if s3_status != 200:
                            raise Exception("Error occurred while communicating with s3 server.")
                        sub["file_path"] = file_link
                        file_transcript = mongo_session.get_all_data_for_particular_condition_fields(
                            collection="course_resource_bank",
                            condition={"_id": ObjectId(str(sub["file_id"]))})['message'][0]
                        sub["file_transcript"] = file_transcript.get("transcript", "")
                    if publish:
                        grade = db_notes[report]["grade"][-1] if db_notes and db_notes.get(report) and \
                                                                 db_notes[report].get("grade") else {}
                        remark = db_notes[report]["remark"][-1] if db_notes and db_notes.get(
                            report) and db_notes[report].get("remark") else {}
                        peer_review_feedback = db_notes[report]["peer_review"] if db_notes and db_notes.get(
                            report) and db_notes[report].get("peer_review") else {}
                        self_review_feedback = db_notes[report]["self_review"] if db_notes and db_notes.get(
                            report) and db_notes[report].get("self_review") else {}
                    else:
                        grade = {}
                        remark = {}
                        peer_review_feedback = {}
                        self_review_feedback = db_notes[report]["self_review"] if db_notes and db_notes.get(
                            report) and db_notes[report].get("self_review") else {}

                    if grade:
                        grade["added_by"] = str(grade["added_by"])
                    if remark:
                        remark["added_by"] = str(remark["added_by"])
                    if peer_review_feedback:
                        peer_review_feedback["added_by"] = str(peer_review_feedback["added_by"])
                    if self_review_feedback:
                        self_review_feedback["added_by"] = str(self_review_feedback["added_by"])

                    submissions[report] = {"grade": grade,
                                           "remark": remark,
                                           "files": db_submissions[report],
                                           "index": index,
                                           "peer_review": peer_review_feedback,
                                           "self_review": self_review_feedback}
                else:
                    submissions[report] = {"grade": {},
                                           "remark": {},
                                           "files": [],
                                           "index": index,
                                           "peer_review": {},
                                           "self_review": {}}
                index = index + 1
    # peer review
    if role == 'student' and grade_view == 'true':
        submission = []
        if self_review == "true":
            if submissions:
                for data in submissions:
                    if data['user_id'] == str(user_id):
                        temp_data = copy.deepcopy(data)
                        # sr_username = mongo_session.get_particular_key_value(
                        #     collection="user_profile",
                        #     condition={
                        #         "$match": {"_id": ObjectId(str(user_id))}},
                        #     return_info={
                        #         "$project": {
                        #             "username": "$username"}})["username"]
                        # sr_name = "#####"

                        teach_assis_info = mongo_session.get_data_for_particular_columns_with_condition(
                            collection="user_profile",
                            condition={"_id": ObjectId(str(user_id))},
                            columns={"_id": 1,
                                     "username": 1,
                                     "name": 1,
                                     "last_name": 1})['message'][0]
                        sr_username = teach_assis_info['username']
                        sr_name = teach_assis_info['name'] + ' ' + teach_assis_info['last_name']

                        temp_data['teach_assis'] = {"_id": str(user_id), "username": sr_username, "name": sr_name}
                        temp_data['self_review_status'] = True
                        temp_data['peer_review_status'] = False
                        for x in temp_data['submissions']:
                            if not publish:
                                temp_data['submissions'][x]['peer_review'] = {}
                        submission.append(temp_data)
        if peer_review == "true":
            if submissions:
                for data in submissions:
                    if isinstance(data, dict):
                        if data.get('teach_assis'):
                            if data['teach_assis']['_id'] == str(user_id):
                                temp_data = copy.deepcopy(data)

                                temp_data['self_review_status'] = False
                                temp_data['peer_review_status'] = True
                                for x in temp_data['submissions']:
                                    if not publish:
                                        temp_data['submissions'][x]['self_review'] = {}
                                    if role == 'student':
                                        temp_data['submissions'][x]['self_review'] = {}
                                        temp_data['submissions'][x]['remark'] = {}
                                submission.append(temp_data)

        if peer_review == "true" or self_review == "true":
            submissions = submission
        else:
            if work_data["is_group"] and not team_name:
                raise InvalidUsage("Please specify a team name", 400)
            if team_name:
                # view team submissions
                if not any(team["name"] == team_name for team in schedule_data["teams"]):
                    raise InvalidUsage("No such team exist for this course work", 400)

                for data in schedule_data["teams"]:
                    if data["name"] == team_name:
                        if not data["submissions"]:
                            # There are no submissions
                            return [], publish
                        if not any(user["_id"] == ObjectId(user_id) for user in data["members"]):
                            raise InvalidUsage("Permission denied, you are not a member of this team.", 403)
                submissions = [sub_data for sub_data in submissions if sub_data["name"] == team_name]
            else:
                submissions = [sub_data for sub_data in submissions if sub_data["user_id"] == user_id]
    return submissions, publish


def get_zip_file(course_work_id, course_instance_id, user_id, team_name, gen_mobile_link):
    condition = {"_id": ObjectId(course_instance_id),
                 "course_work_id": ObjectId(course_work_id)}

    if user_id != "":
        condition['submissions.user_id'] = ObjectId(user_id)

    course_work_info = mongo_session.check_existance_return_info(collection="course_work_instances",
                                                                 condition=condition,
                                                                 return_keys=['submissions', 'teams'])
    all_files = []

    if not course_work_info and team_name == "":
        raise InvalidUsage("No submissions present for this user", 400)

    if not course_work_info['submissions'] and team_name == "":
        raise InvalidUsage("No submissions present for this coursework", 400)

    if user_id != "":
        for data in course_work_info['submissions']:
            if str(data['user_id']) == user_id:
                for submissions in data['submitted_files']:
                    for files in data['submitted_files'][submissions]:
                        s3 = boto3.resource('s3')
                        obj = s3.Object(config.bucket, files['file_path'])
                        new_file = io.BytesIO()
                        obj.download_fileobj(new_file)
                        f = files["file_path"].split('/')[1]
                        filename = f.split("__")[0]
                        file_extn = f.split(".")[-1]
                        file_name = filename + "." + file_extn
                        file = {"filename": file_name,
                                "file_data": new_file}
                        all_files.append(file)
    else:
        if team_name != "":
            for data in course_work_info['teams']:
                if data['name'] == team_name:
                    if not data['submissions']:
                        raise InvalidUsage('No submissions present for this team', 400)
                    for submissions in data['submissions']:
                        for files in data['submissions'][submissions]:
                            s3 = boto3.resource('s3')
                            obj = s3.Object(config.bucket, files['file_path'])
                            new_file = io.BytesIO()
                            obj.download_fileobj(new_file)
                            f = files["file_path"].split('/')[1]
                            filename = f.split("__")[0]
                            file_extn = f.split(".")[-1]
                            file_name = filename + "." + file_extn
                            file = {"filename": file_name,
                                    "file_data": new_file}
                            all_files.append(file)
        else:
            for data in course_work_info['submissions']:
                for submissions in data['submitted_files']:
                    for files in data['submitted_files'][submissions]:
                        s3 = boto3.resource('s3')
                        obj = s3.Object(config.bucket, files['file_path'])
                        new_file = io.BytesIO()
                        obj.download_fileobj(new_file)
                        f = files["file_path"].split('/')[1]
                        filename = f.split("__")[0]
                        file_extn = f.split(".")[-1]
                        file_name = filename + "." + file_extn
                        file = {"filename": file_name,
                                "file_data": new_file}
                        all_files.append(file)
    memory_file = io.BytesIO()
    with zipfile.ZipFile(memory_file, 'w') as zf:
        files = all_files
        for individualFile in files:
            data = zipfile.ZipInfo(individualFile['filename'])
            data.date_time = time.localtime(time.time())[:6]
            data.compress_type = zipfile.ZIP_DEFLATED
            zf.writestr(data, individualFile['file_data'].getvalue())
    memory_file.seek(0)
    if gen_mobile_link:
        file_name = 'all_submissions-{}-{}.zip'.format(user_id, datetime.now())
        with open(file_name, "wb") as f:
            f.write(memory_file.getbuffer())
        data = s3_function.upload_file_to_s3_public('./{}'.format(file_name), individualFile['filename'][:-4], 'zip_submissions_temp/', 
                                                    '.zip', 'application/zip')
        return {"message":data['s3_link'], "status":200}
    else:
        return memory_file


def submission_publish(user_id, role, course_id, course_instance_id, course_work_id):
    """Function to publish grades on a particular course work instance. It will work both for teams and
    individuals.
    user_id: user who is accessing the submissions(it could be a student or a teacher).
    course_id: It will specify the course work related to that particular course.
    course_instance_id : It specify the schedule information of the course work.
    team_name: Specify the team whose submissions user wants to see, empty in case of individual submissions."""
    course_query = mongo_session.get_all_data_for_particular_condition_fields(
        collection='courses_bank',
        condition={"_id": ObjectId(course_id)})
    if course_query['status'] != 200:
        raise Exception("Error getting data from courses bank with {}".format(course_id))

    course_data = course_query['message'][0]
    if not course_data['active']:
        raise InvalidUsage("Oops, course is not active anymore.", 403)

    if role not in ["teacher", "super_admin"]:
        subscribers = [str(user["user_id"]) for user in course_data["subscribers"]]
        if user_id not in subscribers:
            raise InvalidUsage("You need to subscribe the course to see any submission.", 403)

    publish_rights = [str(user['_id']) for user in course_data["editors"]] + \
                     [str(user['_id']) for user in course_data["instructors"]] + [str(course_data["created_by"])]

    if role == "teacher" and user_id not in publish_rights:
        raise InvalidUsage("You don't have permission to see submissions", 403)

    schedule_work_info = mongo_session.get_all_data_for_particular_condition_fields(
        collection="course_work_instances", condition={"_id": ObjectId(course_instance_id)})
    if schedule_work_info['status'] != 200:
        raise Exception("Error getting data from mongo session.")
    course_work_query = mongo_session.get_all_data_for_particular_condition_fields(
        collection="course_work_bank",
        condition={"_id": ObjectId(course_work_id)})
    if course_work_query['status'] != 200:
        raise Exception("Error in getting data from course work bank with {}".format(course_work_id))
    if not course_work_query['message']:
        raise InvalidUsage("Oops, This coursework is no longer available.", 404)
    update_query_condition = {"_id": ObjectId(course_instance_id)}
    update_info = {"$set": {"submission_publish": True}}

    update_data = mongo_session.update_data_submissions(
        collection="course_work_instances", condition=update_query_condition,
        update_info=update_info)
    if update_data['status'] != 200:
        raise Exception("Internal server error, Please try again later")
    response = {"message": "Submissions Published successfully", "status": 200}
    return response

def send_email_to_ta(course_id, user_id, course_work_id, course_instance_id):
    course_work_instances = mongo_session.access_specific_fields(collection="course_work_instances", condition={"_id":ObjectId(str(course_instance_id))})[0]
    teaching_assistant = ""
    if course_work_instances.get('teach_assis'):
        course_info = mongo_session.access_specific_fields(collection="courses_bank", condition={"_id":ObjectId(course_id)})
        course_work = mongo_session.access_specific_fields(collection="course_work_bank", condition={"_id":ObjectId(course_work_id)})
        if course_work_instances.get('teams'):
            for member in course_work_instances['teams']:
                for user in member['members']:
                    if str(user["_id"]) == str(user_id):
                        team = member['name']
        else:
            return False
        for ta in course_work_instances['teach_assis']:
            if ta.get('assignees'):
                for data in ta['assignees']:
                    if data['team_name'] == team:
                        teaching_assistant = str(ta['_id'])
        if teaching_assistant:
            ta = User_Profile(user_id=teaching_assistant)[0]
            body = """
Dear Teaching Assistant {},

This email is a gentle reminder to evaluate your assigned courseworks on Edcuollab under the Course {}.
The Coursework to be marked is: {}
Kindly have a look at the problem statement first and then start with the marking.

Note: Assign a grade to the students assigned to you and put feedback for student performance.

For any submission which is found to be similar, please add a comment in the feedback section- "Plagiarism Detected" but assign the grade as per the submission quality only.

Best,
Team Educollab
    """.format(ta['username'], course_info[0]['subject'], course_work[0]['courseWorkTitle'])
            email_ta = User_Profile(user_id=teaching_assistant)[0]['Email']
            sm = send_mail(email=email_ta, body=body, subject="Report Submission")
            if sm == "failed to connect":
                return False
            return True
        else:
            return False    
    else:
        course_info = mongo_session.access_specific_fields(collection="courses_bank", condition={"_id":ObjectId(course_id)})
        course_work = mongo_session.access_specific_fields(collection="course_work_bank", condition={"_id":ObjectId(course_work_id)})
        teaching_assistant = ""
        for ta in course_info[0]['teach_assis']:
            for assignee in ta['assignees']:
                if user_id == str(assignee['_id']):
                    teaching_assistant = ta['_id']
        if teaching_assistant:
            ta = User_Profile(user_id=teaching_assistant)[0]
            body = """
Dear Teaching Assistant {},

This email is a gentle reminder to evaluate your assigned courseworks on Edcuollab under the Course {}.
The Coursework to be marked is: {}
Kindly have a look at the problem statement first and then start with the marking.

Note: Assign a grade to the students assigned to you and put feedback for student performance.
For any submission which is found to be similar, please add a comment in the feedback section- "Plagiarism Detected" but assign the grade as per the submission quality only.

Best,
Team Educollab
    """.format(ta['username'], course_info[0]['subject'], course_work[0]['courseWorkTitle'])
            email_ta = User_Profile(user_id=teaching_assistant)[0]['Email']
            sm = send_mail(email=email_ta, body=body, subject="Report Submission")
            if sm == "failed to connect":
                return False
            return True
        else:
            return False


def add_peer_reviewer(user_id, coursework_id, instance_id):
    coursework_instance = fetch.access_specific_fields(collection='course_work_instances',
                                                       condition={'_id': ObjectId(instance_id)})[0]

    course_work_bank = fetch.access_specific_fields(collection='course_work_bank',
                                                    condition={"_id": ObjectId(coursework_id)},
                                                    return_keys=["_id", "submissionRequirement"])
    total_days = 0
    for no_of_days in course_work_bank[0]["submissionRequirement"]:
        total_days += int(no_of_days["days_of_completion"])

    start_date = coursework_instance["start_date"]
    start_date = "{}-{}-{}".format(start_date["year"], start_date["month"], start_date["day"])
    start_time = coursework_instance["start_time"]
    start_datetime = datetime.strptime(start_date + ' ' + start_time + ":00", '%Y-%m-%d %H:%M:00')
    datetime_now = datetime.strptime(datetime.now().strftime('%Y-%m-%d %H:%M:00'), '%Y-%m-%d %H:%M:00')
    if datetime_now > start_datetime + timedelta(total_days):
        if coursework_instance["submissions"]:
            users = [user["user_id"] for user in coursework_instance["submissions"]]
            random_users = users[-1:] + users[:-1]
            if coursework_instance.get('peer_review'):
                if coursework_instance['peer_review'] and len(users) > 1:
                    if ObjectId(user_id) in users:
                        random_users.remove(ObjectId(user_id))
                        peer = random.choice(random_users)
                    else:
                        peer = random.choice(random_users)
                    if ObjectId(user_id) not in [user["assignees"][0]['_id'] for user in
                                                 coursework_instance["peer_reviewer"]]:
                        doc = {'_id': ObjectId(peer), 'created_by': 'late_submission', 'created_at': datetime_now,
                               'assignees': [{'_id': ObjectId(user_id), 'assigned_by': 'late_submission'}]}
                        mongo_session.update_data(collection='course_work_instances',
                                                  find_condition={'_id': ObjectId(instance_id)},
                                                  update_info={'$push': {'peer_reviewer': doc}},
                                                  update_condition={'_id': ObjectId(instance_id)})
                    else:
                        print('Peer reviewer already assigned')
