from routes.exception import InvalidUsage
from utils.misc import get_profile_pic

from bson import ObjectId

from db_wrapper.tasks import Mongo

mongo_session = Mongo()

from services.storage.s3_services import s3_storage

s3_function = s3_storage()


def view_course_work_instance(schedule_id, course_id):
    """To get all the information for a particular course work instance.
    :param schedule_id: mongo id for the instance of the course work.
    :type schedule_id: str (mongo).
    :param course_id: course on which the course work is scheduled.
    :type course_id: str (mongo).
    :returns dictionary object containing cw_instance information."""
    cw_teams = []
    instance_info = {"teams_info": cw_teams}

    # filter subscribers based on the course information
    course_info = mongo_session.check_existance_return_info(collection="courses_bank",
                                                            condition={"_id": ObjectId(course_id)},
                                                            columns={"subscribers": 1,
                                                                     "created_by": 1,
                                                                     "organisations": 1,
                                                                     "is_public": 1},
                                                            return_keys=["_id",
                                                                         "subscribers",
                                                                         "created_by",
                                                                         "organisations",
                                                                         "is_public"])
    if not course_info:
        raise InvalidUsage("Bad Request.", 400)

    subscribers_list = [user["user_id"] for user in course_info["subscribers"]]

    org_list = [org["_id"] for org in course_info["organisations"]]

    # if course is not public then only allowed organisation's subscribers should be included
    if course_info["is_public"]:
        user_condition = {"_id": {"$in": subscribers_list}, "role": "student"}
    else:
        user_condition = {"role": "student",
                          "$and": [{"_id": {"$in": subscribers_list}},
                                   {"organisation_id": {"$in": org_list}}]}

    fetch_subscribers = mongo_session.access_specific_fields(
        collection='user_profile',
        condition=user_condition,
        columns={"username": 1,
                 "organisation": 1,
                 "profile_pic": 1},
        return_keys=["username", "organisation", "_id", "profile_pic"])

    subscribers = []
    if fetch_subscribers:
        subscribers = [user["_id"] for user in fetch_subscribers]

    # fetch course work instance information
    cw_schedule_info = mongo_session.check_existance_return_info(collection="course_work_instances",
                                                                 condition={"_id": ObjectId(schedule_id)},
                                                                 columns={"group_type": 1,
                                                                          "teams": 1,
                                                                          "teach_assis": 1},
                                                                 return_keys=["group_type",
                                                                              "teams",
                                                                              "teach_assis"])
    if cw_schedule_info and cw_schedule_info["group_type"]:
        members_list = []
        for team in cw_schedule_info["teams"]:
            members = []
            for user in team["members"]:
                members.append({"_id": str(user["_id"]),
                                "approval_status": user["approval_status"],
                                "is_subscriber": True if user["_id"] in subscribers else False})
                members_list.append(user["_id"])
            cw_teams.append({"name": team["name"],
                             "members": members})
        # fetch all members details from user profile
        users_info = mongo_session.get_particular_key_value(collection="user_profile",
                                                            condition={"$match": {"_id": {"$in": members_list}}},
                                                            return_info={"$project": {"_id": "$_id",
                                                                                      "username": "$username",
                                                                                      "organisation": "$organisation",
                                                                                      "profile_pic": "$profile_pic"
                                                                                      }
                                                                         },
                                                            all_docs=True)
        users_dict = {}
        for data in users_info:
            data["profile_pic"] = get_profile_pic(s3_key=data["profile_pic"])
            data["_id"] = str(data["_id"])
            users_dict[str(data["_id"])] = data
        for team in cw_teams:
            for member in team["members"]:
                member.update(users_dict[member["_id"]])
    return instance_info
