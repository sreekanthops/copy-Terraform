import config
from model import Question

class Question_Bank(object):
    @staticmethod
    def close_match(question):
        return 0.8

    def __init__(self):
        qb = self.load(config.QUESTION_BANK_PATH)

    def load(self,pathname):
        self.my_questions=[]
        with open(pathname,"r") as fp:
            for line in fp:
                self.my_questions.append(Question(line))
