import datetime

from bson import ObjectId

from model.Question import indian_standard_time
from routes.exception import InvalidUsage
from model.Content import webapp_time_to_string
from services.storage.s3_services import s3_storage
from db_wrapper.tasks import Mongo

mongo_session = Mongo()
s3_function = s3_storage()


def get_teaching_assistant_progress_report(user_id, course_id, role):
    """to generate reports of Teaching assistant(TA) on some particular course.
    Includes Individual Course Work as of now.
    :param user_id: user accessing the reports.
    :param course_id: course for which report should be generated.
    :param role: role of the user who is accessing the report.
    :type user_id: str(mongo id)
    :type course_id: str(mongo id)
    :type role: str(slug)
    :returns list containing TA progress report"""
    teach_assistant = []
    course_info = mongo_session.check_existance_return_info(collection="courses_bank",
                                                            condition={"_id": ObjectId(course_id)},
                                                            columns={"teach_assis": 1,
                                                                     "editors": 1,
                                                                     "instructors": 1,
                                                                     "subscribers": 1,
                                                                     "created_by": 1,
                                                                     "topics": 1,
                                                                     "course_work": 1,
                                                                     "course_assessments": 1},
                                                            return_keys=["_id",
                                                                         "teach_assis",
                                                                         "editors",
                                                                         "instructors",
                                                                         "subscribers",
                                                                         "created_by",
                                                                         "topics",
                                                                         "course_work",
                                                                         "course_assessments"])
    if not course_info:
        raise InvalidUsage("Bad Request", 400)

    # accessor: only owner of course/editors/instructors/super-admin are allowed.
    course_info["instructors"].extend(course_info["editors"])
    accessors = [str(user["_id"]) for user in course_info["instructors"]] if course_info["instructors"] else []
    accessors.append(str(course_info["created_by"]))

    if role != "super_admin" and user_id not in accessors:
        raise InvalidUsage("You are not an authorised user to access this functionality.", 403)
    if not course_info["teach_assis"]:
        raise InvalidUsage("Please assign Teaching Assistants to check their progress report.", 400)
    # to reduce db calls
    # fetch information of assistants
    users_list = []
    assignees = {}
    for assistant in course_info["teach_assis"]:
        users_list.append(assistant["_id"])
        users_list.extend([subs["_id"] for subs in assistant["assignees"]])
        assignees[str(assistant["_id"])] = [str(subs["_id"]) for subs in assistant["assignees"]]

    # fetch users data from db
    users_info = mongo_session.get_particular_key_value(collection="user_profile",
                                                        condition={"$match": {"_id": {"$in": users_list}}},
                                                        return_info={"$project": {"_id": "$_id",
                                                                                  "username": "$username",
                                                                                  "organisation": "$organisation",
                                                                                  "profile_pic": "$profile_pic"
                                                                                  }
                                                                     },
                                                        all_docs=True)
    assistants_dict = {}
    users_dict = {}
    for data in users_info:
        if data["profile_pic"]:
            s3_url, status_code = s3_function.generate_presigned_url_from_s3(data["profile_pic"])
            data["profile_pic"] = s3_url

        if str(data["_id"]) in assignees.keys():
            data.update({"subscribers": assignees[str(data["_id"])],
                         "teams": [],
                         "marked_submissions": 0,
                         "marked_assessments": 0})
            assistants_dict[str(data["_id"])] = data
        else:
            data["_id"] = str(data["_id"])
            users_dict[str(data["_id"])] = data
    # collect course works and assessments
    # course level
    course_works = [cw for cw in course_info["course_work"]]
    assessments = [assess for assess in course_info["course_assessments"]]

    # topic level
    for topic in course_info["topics"]:
        topic_info = mongo_session.check_existance_return_info(collection="course_topics",
                                                               condition={"_id": topic["_id"]},
                                                               columns={"course_work": 1,
                                                                        "assessments": 1,
                                                                        "sessions": 1},
                                                               return_keys=["_id",
                                                                            "course_work",
                                                                            "assessments",
                                                                            "sessions"])
        if topic_info:
            course_works.extend([cw for cw in topic_info["course_work"]])
            assessments.extend([assess for assess in topic_info["assessments"]])

        # session level assessments
        for session in topic_info["sessions"]:
            session_info = mongo_session.check_existance_return_info(collection="course_sessions",
                                                                     condition={"_id": session["_id"]},
                                                                     columns={"assessments": 1},
                                                                     return_keys=["_id",
                                                                                  "assessments"])
            if session_info:
                assessments.extend([assess for assess in session_info["assessments"]])
    # consider each submission requirement on the course work as a separate parameter for progress..

    # process course works
    for cw in course_works:
        course_work_info = mongo_session.check_existance_return_info(collection="course_work_bank",
                                                                     condition={"_id": cw["_id"]},
                                                                     columns={"is_group": 1,
                                                                              "publish_status": 1,
                                                                              "courseWorkTitle": 1,
                                                                              "submissionRequirement": 1},
                                                                     return_keys=["_id",
                                                                                  "courseWorkTitle",
                                                                                  "is_group",
                                                                                  "publish_status",
                                                                                  "submissionRequirement"])
        cw_instance_info = mongo_session.check_existance_return_info(collection="course_work_instances",
                                                                     condition={"_id": cw["schedule_id"]},
                                                                     columns={"start_date": 1,
                                                                              "start_time": 1,
                                                                              "course_work_id": 1,
                                                                              "submissions": 1,
                                                                              "teams": 1,
                                                                              "teach_assis": 1},
                                                                     return_keys=["_id",
                                                                                  "start_date",
                                                                                  "start_time",
                                                                                  "course_work_id",
                                                                                  "submissions",
                                                                                  "teams",
                                                                                  "teach_assis"])
        if course_work_info:
            # validate start date time and add then add submission requirements to list.
            cw_start_time = webapp_time_to_string(cw_instance_info["start_date"], cw_instance_info["start_time"])
            cw_start_time = datetime.datetime.strptime(cw_start_time, "%Y:%m:%dT%H:%M")

            timestamp = indian_standard_time()
            datetime_now = datetime.datetime.strptime(timestamp, "%d %b %Y, %I:%M %p")
            cw["submissions"] = len(
                course_work_info["submissionRequirement"]) if cw_start_time <= datetime_now else 0
            if not course_work_info["is_group"]:
                # fetch course work submissions by students, now it is only individual course work.
                # individual
                if cw_instance_info["submissions"]:
                    for user in cw_instance_info["submissions"]:
                        if user.get("notes"):
                            for note in list(user["notes"].values()):
                                if "grade" in note:
                                    for each_note in note["grade"]:
                                        if str(each_note["added_by"]) in assistants_dict:
                                            # increase the progress of assistant by one
                                            assistants_dict[str(each_note["added_by"])]["marked_submissions"] += 1
            else:
                # when group course work
                if not cw_instance_info.get("teach_assis"):
                    continue
                for assis in cw_instance_info["teach_assis"]:
                    assign_teams = [assignee["team_name"] for assignee in assis["assignees"]]
                    for team in cw_instance_info["teams"]:
                        if team["name"] in assign_teams:
                            assistants_dict[str(assis["_id"])]["teams"].append(
                                {"name": team["name"],
                                 "members": len([member for member in team["members"] if member["approval_status"]]),
                                 "course_work": {"_id": str(course_work_info["_id"]),
                                                 "schedule_id": str(cw_instance_info["_id"]),
                                                 "title": course_work_info["courseWorkTitle"]}})

                            if team.get("notes"):
                                for note in list(team["notes"].values()):
                                    if "grade" in note:
                                        for each_note in note["grade"]:
                                            if str(each_note["added_by"]) == str(assis["_id"]):
                                                # increase the progress of assistant by one
                                                assistants_dict[str(assis["_id"])][
                                                    "marked_submissions"] += 1

    response_data = {"total_sub_per_student": sum([data.get("submissions", 0) for data in course_works]),
                     "total_assessments": len(assessments)}

    for teach_assis in assistants_dict.values():
        teach_assis["_id"] = str(teach_assis["_id"])
        teach_assis["subscribers"] = [users_dict[subs] for subs in teach_assis["subscribers"]]
        teach_assis["sub_need_to_mark"] = response_data["total_sub_per_student"] * \
                                          (len(teach_assis["subscribers"]) +
                                           len(teach_assis["teams"]))
        teach_assistant.append(teach_assis)
    response_data["teach_assistants"] = teach_assistant
    return response_data
