import datetime
import re
from itertools import zip_longest

import numpy as np
import pandas as pd
from bson import ObjectId
from config import DEFAULT_DT_FORMAT
from model.Content import webapp_time_to_string
from model.Question import indian_standard_time
from routes.exception import InvalidUsage
from utils.misc import validate_ObjectId
from db_wrapper.tasks import Mongo

mongo_session = Mongo()


def process_assessment(assess, course_id, user_data, timestamp, level, is_timed, session_title="", session_id="", topic_id=""):
    """To fetch each assessment report on course
    :param level: describes whether the assessment is course, topic, or session level.
    :param timestamp: current time
    :param assess: assessment information
    :param course_id: target course for assessment data
    :param topic_id: is it topic level assessment
    :param session_id: is it a session level assessment
    :param session_title: title of the session
    :param user_data: subscribers information on the course
    :param is_timed: whether the assessment is timed or not"""
    assess_data = {}
    db_assess = mongo_session.check_existance_return_info(
        collection="assessment",
        condition={"_id": assess["_id"],
                   "publish": True},
        columns={"assessment_name": 1, "created_date": 1, "total_time": 1},
        return_keys=["assessment_name", "created_date", "total_time"])
    if not db_assess:
        return assess_data
    assess_data["title"] = db_assess["assessment_name"]

    # start time for the assessment
    start_datetime = ""  # start time for the assessment in string format
    start_time = ""  # as date object if it is there because we don't have start time for non-calendared assessments
    end_time = ""  # as date object if it is there.
    if assess.get("schedule_id"):
        schedule_assess_info = mongo_session.check_existance_return_info(
            collection="schedule_assessment",
            condition={"_id": assess["schedule_id"]},
            whole_doc=True)
        assess_data["schedule_id"] = str(assess["schedule_id"])
        start_time = datetime.datetime.strptime(schedule_assess_info['start_time'], "%Y:%m:%dT%H:%M")
        end_time = datetime.datetime.strptime(schedule_assess_info['end_time'], "%Y:%m:%dT%H:%M")
        if start_time < timestamp:
            start_datetime = start_time.strftime(DEFAULT_DT_FORMAT)
    assess_data["datetime"] = start_datetime
    assess_data["_id"] = str(assess["_id"])
    assess_data["session_title"] = session_title
    assess_data["session_id"] = str(session_id)
    assess_data["topic_id"] = str(topic_id) if level == "topic" else ""

    # process grades and submission status of the subscribers
    """If assessment is timed then send the late hours by which the student made last submission"""
    condition = {"assessment_id": assess["_id"],
                 "course_id": ObjectId(course_id),
                 "topic_id": topic_id,
                 "course_session_id": session_id}

    if assess.get("schedule_id"):
        condition["schedule_assessment_id"] = assess["schedule_id"]

    submissions_info = mongo_session.access_specific_fields(
        collection="assessments_result",
        condition=condition,
        columns={"total_score": 1,
                 "user_id": 1,
                 "question": 1,
                 "maximum_score": 1,
                 "submitted_time": 1},
        sort_condition=("submitted_time", 1))
    info = []
    if submissions_info:
        total_grade = submissions_info[0]["maximum_score"]
        user_dict = {}
        for data in submissions_info:
            student_grade = [int(ques["grade"]["content"]) for ques in data["question"] if ques.get("grade")]
            submission_late_hours = ""
            if start_time and is_timed or start_time and assess.get('calendered'):
                # convert data["submitted_time"] to date time object
                submitted_time_object = datetime.datetime.strptime(data["submitted_time"], "%Y:%m:%dT%H:%M")
                if (submitted_time_object - end_time).total_seconds() >= 0:
                    submission_late_hours = str(submitted_time_object - end_time)
            elif assess['calendered']:
                submitted_time_object = datetime.datetime.strptime(data["submitted_time"], "%Y:%m:%dT%H:%M")
                end_dt = datetime.datetime.strptime(db_assess['created_date'][:-8], "%Y-%m-%dT%H:%M") + \
                         datetime.timedelta(minutes=float(db_assess['total_time']))
                if (submitted_time_object - end_dt).total_seconds() >= 0:
                    submission_late_hours = str(submitted_time_object - end_dt)
            user_dict[str(data["user_id"])] = {"is_marked": bool(len(student_grade)),
                                               "grade": "{}/{}".format(sum(student_grade), total_grade),
                                               "submitted_at": data["submitted_time"],
                                               "late_by": submission_late_hours
                                              }
        for subscriber in user_data:
            if str(subscriber["_id"]) in user_dict:
                data = {**subscriber,
                        **user_dict[str(subscriber["_id"])],
                        "is_submitted": True,
                        "submitted_at": user_dict[str(subscriber["_id"])]["submitted_at"],
                        "late_by": user_dict[str(subscriber["_id"])]["late_by"]}
            else:
                default = {"grade": 0,
                           "is_marked": False,
                           "is_submitted": False,
                           "submitted_at": "",
                           "late_by": ""}
                data = {**subscriber, **default}
            info.append(data)
    assess_data["content"] = info
    return assess_data


def course_report(user_id, course_id, role, max_sessions, sessions=None, notes=None, coursework=None, assessment=None,
                  attendance=None, topic_filter=None, session_offset=None):
    """
    to generate reports of the course on Notes, Course Work, Attendance, Assessments.
    :param user_id: user accessing the reports.
    :param course_id: course for which report should be generated.
    :param role: role of the user who is accessing the report.
    :type user_id: str(mongo id)
    :type course_id: str(mongo id)
    :type role: str(slug)
    :param sessions: sessions selected for information.
    :type sessions: list (contains ids).
    :param notes: notes for selected sessions
    :type notes: boolean
    :param coursework: coursework on the course required or not (topic level/course level)
    :type coursework: list (contains course/topic)
    :param assessment: assessment on the course(session level/topic level/course level)
    :type assessment: list (contains session/course/topic)
    :param attendance: attendance marked by teacher on selected sessions if any.
    :type attendance: boolean
    :param topic_filter: if search need to be on particular topic sessions
    :type topic_filter: str (object id)
    :param session_offset: index to pick which 15 sessions need to be selected.
    :type session_offset: int
    :param max_sessions: maximum sessions which can be selected in one go
    NOTE: session_offset = 1 means first max_sessions  in the selected topic.
    """
    # whether the assessment is timed or not
    is_timed = True
    timestamp = indian_standard_time()
    timestamp = datetime.datetime.strptime(timestamp, "%d %b %Y, %I:%M %p")
    notes_report = []
    attendance_report = []
    cw_report = {"topic_level": [],
                 "course_level": []}
    assessments_report = {"session_level": [],
                          "topic_level": [],
                          "course_level": []}
    # validate the user who is accessing the course report

    course_info = mongo_session.check_existance_return_info(collection="courses_bank",
                                                            condition={"_id": ObjectId(course_id)},
                                                            columns={"_id": 1,
                                                                     "created_by": 1,
                                                                     "editors": 1,
                                                                     "instructors": 1,
                                                                     "subscribers": 1,
                                                                     "is_public": 1,
                                                                     "organisations": 1,
                                                                     "topics": 1,
                                                                     "course_work": 1,
                                                                     "course_assessments": 1
                                                                     },
                                                            return_keys=["_id",
                                                                         "created_by",
                                                                         "editors",
                                                                         "instructors",
                                                                         "subscribers",
                                                                         "is_public",
                                                                         "organisations",
                                                                         "topics",
                                                                         "course_work",
                                                                         "course_assessments"])
    if not course_info:
        raise InvalidUsage("Please check request data.", 400)
    topic_info = []
    if topic_filter:
        topic_data = mongo_session.check_existance_return_info(collection="course_topics",
                                                               condition={"_id": ObjectId(topic_filter)},
                                                               columns={"course_work": 1,
                                                                        "assessments": 1,
                                                                        "sessions": 1},
                                                               return_keys=["_id",
                                                                            "course_work",
                                                                            "assessments",
                                                                            "sessions"])
        if topic_data:
            topic_info.append(topic_data)
    else:
        for topic in course_info["topics"]:
            topic_data = mongo_session.check_existance_return_info(collection="course_topics",
                                                                   condition={"_id": topic["_id"]},
                                                                   columns={"course_work": 1,
                                                                            "assessments": 1},
                                                                   return_keys=["_id",
                                                                                "course_work",
                                                                                "assessments"])
            if topic_data:
                topic_info.append(topic_data)
    if role != "super_admin":
        course_info["editors"].extend(course_info["instructors"])
        course_info["editors"].append({"_id": course_info["created_by"]})
        course_owners = [str(user['_id']) for user in course_info["editors"]]
        if user_id not in course_owners:
            raise InvalidUsage("You don't have permission to access course report.", 403)

    # process subscribers based on whether course is public or not and organisations
    if not course_info.get("subscribers") or not course_info["subscribers"]:
        raise InvalidUsage("There are no subscribers for this course, Report will be available after subscriptions "
                           "only.", 400)
    users_list = [user["user_id"] for user in course_info["subscribers"]]

    org_list = [org["_id"] for org in course_info["organisations"]]

    # if course is not public then only allowed organisation's subscribers should be visible
    if course_info["is_public"]:
        user_condition = {"_id": {"$in": users_list},
                          "role": "student"}
    else:
        user_condition = {"role": "student",
                          "$and": [{"_id": {"$in": users_list}}, {"organisation_id": {"$in": org_list}}]}

    user_query = mongo_session.access_specific_fields(
        collection='user_profile',
        condition=user_condition,
        columns={"username": 1,
                 "organisation": 1,
                 "role": 1,
                 "name": 1,
                 "last_name": 1},
        return_keys=["username", "organisation", "role", "_id", "name", "last_name"])

    if not user_query:
        return {
            "subscribers": [],
            "notes": [],
            "course_work": []
        }
    users_dict = {}
    for data in user_query:
        data["_id"] = str(data["_id"])
        users_dict[str(data["_id"])] = data

    # process assessments
    if assessment:
        if "course" in assessment:
            for assess in course_info["course_assessments"]:
                if "is_timed" in assess.keys() and not bool(assess["is_timed"]):
                    is_timed = False
                assess_data = process_assessment(assess=assess,
                                                 course_id=course_id,
                                                 user_data=user_query,
                                                 timestamp=timestamp,
                                                 level="course",
                                                 is_timed=is_timed)
                if assess_data:
                    assessments_report["course_level"].append(assess_data)
        if "topic" in assessment:
            for topic in topic_info:
                for assess in topic["assessments"]:
                    if "is_timed" in assess.keys() and not bool(assess["is_timed"]):
                        is_timed = False
                    assess_data = process_assessment(assess=assess,
                                                     course_id=course_id,
                                                     topic_id=topic["_id"],
                                                     user_data=user_query,
                                                     timestamp=timestamp,
                                                     level="topic",
                                                     is_timed=is_timed)
                    if assess_data:
                        assessments_report["topic_level"].append(assess_data)

    # process sessions
    # if topic is given construct the session list by checking the offset

    if topic_filter and topic_info:
        sessions = [sess["_id"] for sess in topic_info[0]["sessions"]]
        session_offset = int(session_offset) - 1
        sessions = sessions[session_offset * max_sessions:  (session_offset + 1) * max_sessions]
    if sessions:
        sessions = [ObjectId(session) for session in sessions if validate_ObjectId(session)]
        sessions_info = mongo_session.get_particular_key_value(
            collection="course_sessions",
            condition={"$match": {"_id": {"$in": sessions}}},
            return_info={"$project": {"_id": "$_id",
                                      "title": "$title",
                                      "assessments": "$assessments",
                                      "participants": "$participants"}},
            all_docs=True)
        # fetch session titles
        # session dict containing session id and title
        sessions_dict = {}
        for session in sessions_info:
            sessions_dict[str(session["_id"])] = session["title"]

        if notes and bool(notes):
            # fetch notes data for given course by grouping sessions
            notes_info = mongo_session.get_particular_key_value(
                collection="course_sessions_notes",
                condition={
                    "$match": {"$and": [{"course_id": ObjectId(course_id),
                                         "session_id": {"$in": sessions},
                                         "type": "note"}]}},
                return_info={"$group": {"_id": "$session_id",
                                        "data": {"$push": '$$ROOT'}},
                             },
                all_docs=True)

            if notes_info:
                # process notes on sessions
                for session in sessions:
                    user_notes = []
                    for data in notes_info:
                        if data["_id"] == session:
                            user_notes = [str(note["user_id"]) for note in data["data"]]
                    notes_report.append({"session_id": str(session),
                                         "session_title": sessions_dict[str(session)],
                                         "content": [{"username": subscriber["username"],
                                                      "id": str(subscriber["_id"]),
                                                      "is_note": True if str(
                                                          subscriber["_id"]) in user_notes else False
                                                      } for subscriber in user_query]
                                         })
        for session in sessions_info:
            if assessment and "session" in assessment:
                for assess in session["assessments"]:
                    if "is_timed" in assess.keys() and not bool(assess["is_timed"]):
                        is_timed = False
                    topic_id = mongo_session.check_existance_return_info(collection="course_topics",
                                                                         condition={"sessions._id": session["_id"]},
                                                                         columns={"_id": 1},
                                                                         return_keys=["_id"])["_id"]
                    assess_data = process_assessment(assess=assess,
                                                     topic_id=topic_id,
                                                     course_id=course_id,
                                                     user_data=user_query,
                                                     timestamp=timestamp,
                                                     level="session",
                                                     session_id=session["_id"],
                                                     session_title=sessions_dict[str(session["_id"])],
                                                     is_timed=is_timed)
                    if assess_data:
                        assessments_report["session_level"].append(assess_data)
            if attendance and type(attendance) == bool and session.get("participants") and session["participants"].get("content"):
                active_participants = [str(user["_id"]) for user in session["participants"]["content"]]
                attendance_report.append({"session_id": str(session["_id"]),
                                          "session_title": sessions_dict[str(session["_id"])],
                                          "content": [{"username": subscriber["username"],
                                                       "id": str(subscriber["_id"]),
                                                       "attended": True if str(
                                                          subscriber["_id"]) in active_participants else False
                                                     } for subscriber in user_query]
                                         })

    # process course works required and which level(course/topic or both)
    if coursework:
        course_works = []
        topic_course_works = {}  # containing course work id and corresponding topic id.
        if "course" in coursework:
            # course level
            course_works = course_info["course_work"]
        if "topic" in coursework:
            # topic level
            for topic in topic_info:
                for cw in topic["course_work"]:
                    topic_course_works[str(cw["schedule_id"])] = str(topic["_id"])

                course_works.extend(topic["course_work"])
        # process course works
        for cw in course_works:
            course_work_info = mongo_session.check_existance_return_info(collection="course_work_bank",
                                                                         condition={"_id": cw["_id"]},
                                                                         columns={"is_group": 1,
                                                                                  "publish_status": 1,
                                                                                  "submissionRequirement": 1,
                                                                                  "courseWorkTitle": 1},
                                                                         return_keys=["_id",
                                                                                      "is_group",
                                                                                      "publish_status",
                                                                                      "submissionRequirement",
                                                                                      "courseWorkTitle"])
            cw_instance_info = mongo_session.check_existance_return_info(collection="course_work_instances",
                                                                         condition={"_id": cw["schedule_id"]},
                                                                         columns={"start_date": 1,
                                                                                  "start_time": 1,
                                                                                  "course_work_id": 1,
                                                                                  "submissions": 1,
                                                                                  "teams": 1},
                                                                         return_keys=["_id",
                                                                                      "start_date",
                                                                                      "start_time",
                                                                                      "course_work_id",
                                                                                      "submissions",
                                                                                      "teams"])

            # validate start date time and add then add submission requirements to list.
            cw_start_time = webapp_time_to_string(cw_instance_info["start_date"], cw_instance_info["start_time"])
            cw_start_time = datetime.datetime.strptime(cw_start_time, "%Y:%m:%dT%H:%M")
            active_span = int(course_work_info["submissionRequirement"][-1]["days_of_completion"])
            course_work_end_time = cw_start_time + datetime.timedelta(days=active_span)

            if cw_start_time <= timestamp:
                cw_user_dict = {}
                total_submissions = len(course_work_info["submissionRequirement"])

                # fetch course work submissions by students, It could be individual course work or team course work.
                """for course work 'submitted_at' and 'late_by' is counted
                   for the last submission that student made on the course work"""
                # individual
                if cw_instance_info["submissions"]:
                    for user in cw_instance_info["submissions"]:
                        marked_submissions = 0
                        submissions_by_subs = len(user["submitted_files"]) if user.get("submitted_files") else 0
                        total_grades = 0
                        if user.get("notes"):
                            for note in list(user["notes"].values()):
                                if "grade" in note:
                                    total_grades += int(note["grade"][-1]["content"])
                                    marked_submissions += 1
                        user_total_submissions = []
                        if user.get("submitted_files"):
                            for sub_req in list(user["submitted_files"].values()):
                                for file in sub_req:
                                    user_total_submissions.append(datetime.datetime.strptime(file["timestamp"], "%d %b %Y, %I:%M %p"))
                        user_last_submission_at = max(user_total_submissions) if user_total_submissions else ""
                        late_by = ""
                        if user_last_submission_at:
                            if (user_last_submission_at - course_work_end_time).total_seconds() >= 0:
                                late_by = str(user_last_submission_at - course_work_end_time)
                        cw_user_dict[str(user["user_id"])] = {"grade": total_grades,
                                                              "team_name": "",
                                                              "submission_data": "{}/{}/{}".format(
                                                                  marked_submissions,
                                                                  submissions_by_subs,
                                                                  total_submissions),
                                                              "datetime": str(cw_start_time),
                                                              "submitted_at": user_last_submission_at.strftime("%Y:%m:%dT%H:%M") if user_last_submission_at else "",
                                                              "late_by": late_by
                                                              }

                if cw_instance_info["teams"]:
                    for team in cw_instance_info["teams"]:
                        # considering that student's submissions will be same as of team.
                        marked_submissions = 0
                        submissions_by_subs = len(team["submissions"]) if team.get("submissions") else 0
                        total_grades = 0
                        if team.get("notes"):
                            for note in list(team["notes"].values()):
                                if "grade" in note:
                                    total_grades += int(note["grade"][-1]["content"])
                                    marked_submissions += 1
                        team_total_submissions = []
                        if team.get("submissions"):
                            for sub_req in list(team["submissions"].values()):
                                for file in sub_req:
                                    team_total_submissions.append(
                                        datetime.datetime.strptime(file["timestamp"], "%d %b %Y, %I:%M %p"))
                        team_last_submission_at = max(team_total_submissions) if team_total_submissions else ""
                        late_by = ""
                        if team_last_submission_at:
                            if (team_last_submission_at - course_work_end_time).total_seconds() >= 0:
                                late_by = str(team_last_submission_at - course_work_end_time)
                        for member in team["members"]:
                            cw_user_dict[str(member["_id"])] = {"grade": total_grades,
                                                                "team_name": team["name"],
                                                                "submission_data": "{}/{}/{}".format(
                                                                    marked_submissions,
                                                                    submissions_by_subs,
                                                                    total_submissions),
                                                                "datetime": str(cw_start_time),
                                                                "submitted_at": team_last_submission_at.strftime(
                                                                    "%Y:%m:%dT%H:%M") if team_last_submission_at else "",
                                                                "late_by": late_by}
                info = []
                for subscriber in user_query:
                    if str(subscriber["_id"]) in cw_user_dict:
                        data = {**users_dict[str(subscriber["_id"])], **cw_user_dict[str(subscriber["_id"])]}
                    else:
                        default = {"grade": 0,
                                   "team_name": "",
                                   "submission_data": "{}/{}/{}".format(0, 0, total_submissions),
                                   "datetime": str(cw_start_time),
                                   "submitted_at": "",
                                   "late_by": ""}
                        data = {**users_dict[str(subscriber["_id"])], **default}
                    info.append(data)
                cw_response = {"title": course_work_info["courseWorkTitle"],
                               "topic_id": topic_course_works[str(cw["schedule_id"])] if
                               str(cw["schedule_id"]) in topic_course_works else "",
                               "is_group": course_work_info["is_group"],
                               "_id": str(course_work_info["_id"]),
                               "schedule_id": str(cw_instance_info["_id"]),
                               "content": info}
                if cw_response["topic_id"]:
                    cw_report["topic_level"].append(cw_response)
                else:
                    cw_report["course_level"].append(cw_response)
    report = {
        "subscribers": [{"_id": str(data["_id"]),
                         "username": data["username"],
                         "first_name": data["name"],
                         "last_name": data["last_name"]} for data in user_query] if user_query else [],
        "notes": notes_report,
        "course_work": cw_report,
        "assessment": assessments_report,
        "attendance": attendance_report
    }
    return report


def generate_data_for_excel(course_id, course_work, assessments, notes, attendance, role, user_id):
    """
    This function helps to generate excel for download. The excel sheet is report of each
    subscriber about what has been submitted by the user and if it is marked or not
    :param user_id: id of the current user
    :param role: role of the current user
    :param course_id: id of the course whose students' data is being observed
    :param course_work: consists ids of both course level and topic level courseworks
    :param assessments: consists ids of course level, topic level and session level assessments
    :param notes: consists session ids under the course
    :param attendance: consists session ids under the course
    :return: pandas dataframe
    """
    is_timed = False

    def bg_color_red_or_green(val):
        color = None
        if val == "Absent" or val == 'Not Submitted' or val == '0':
            color = '#ffd9d9'
        elif val == 'Present' or val == 'Submitted' or val == 'Green':
            color = '#d9ffe3'
        elif re.search(r'\d/\d/\d', str(val)):
            s = val.split('(')[1].split(')')[0]
            s = s.split('/')
            if "." in val:
                s[2] = s[2].split('.')[0]
            if s[0] == s[1] == s[2]:
                color = None
            elif int(s[1]) != 0 and int(s[2]) != 0:
                color = '#d9ffe3'
            elif int(s[0]) == 0 and int(s[1]) == 0:
                color = '#ffd9d9'
            else:
                color = '#ffd9d9'
        else:
            color = None
        return 'background-color: %s' % color

    def _color_red_or_green(val):
        color = None
        if val == 'Green':
            color = '#d9ffe3'
        elif re.search(r'\d/\d/\d', str(val)):
            if "." in val:
                color = '#FF0000'
        return 'color: %s' % color

    report = {}
    df = pd.DataFrame()
    timestamp = indian_standard_time()
    timestamp = datetime.datetime.strptime(timestamp, "%d %b %Y, %I:%M %p")
    course_info = mongo_session.check_existance_return_info(collection="courses_bank",
                                                            condition={"_id": ObjectId(course_id)},
                                                            columns={"_id": 1,
                                                                     "created_by": 1,
                                                                     "editors": 1,
                                                                     "instructors": 1,
                                                                     "subscribers": 1,
                                                                     "is_public": 1,
                                                                     "organisations": 1,
                                                                     "topics": 1,
                                                                     "course_work": 1,
                                                                     "course_assessments": 1
                                                                     },
                                                            return_keys=["_id",
                                                                         "created_by",
                                                                         "editors",
                                                                         "instructors",
                                                                         "subscribers",
                                                                         "is_public",
                                                                         "organisations",
                                                                         "topics",
                                                                         "course_work",
                                                                         "course_assessments"])
    if not course_info:
        raise InvalidUsage("Please check request data.", 400)
    users_list = [user["user_id"] for user in course_info["subscribers"]]
    org_list = [org["_id"] for org in course_info["organisations"]]

    # if course is not public then only allowed organisation's subscribers should be visible
    if course_info["is_public"]:
        user_condition = {"_id": {"$in": users_list},
                          "role": "student"}
    else:
        user_condition = {"role": "student",
                          "$and": [{"_id": {"$in": users_list}}, {"organisation_id": {"$in": org_list}}]}

    user_query = mongo_session.access_specific_fields(
        collection='user_profile',
        condition=user_condition,
        columns={"username": 1,
                 "organisation": 1,
                 "role": 1,
                 "name": 1,
                 "last_name": 1},
        return_keys=["username", "_id", "name", "last_name"])

    users_dict = {}
    for data in user_query:
        data["_id"] = str(data["_id"])
        users_dict[str(data["_id"])] = data

    if role != "super_admin":
        course_info["editors"].extend(course_info["instructors"])
        course_info["editors"].append({"_id": course_info["created_by"]})
        course_owners = [str(user['_id']) for user in course_info["editors"]]
        if user_id not in course_owners:
            raise InvalidUsage("You don't have permission to access course report.", 403)

    topic_info = []
    for topic in course_info["topics"]:
        topic_info.append(topic['_id'])
    # notes
    notes_report = []
    if notes:
        sessions = [ObjectId(session) for session in notes]
        session_info = [mongo_session.check_existance_return_info(collection='course_sessions',
                                                                  condition={
                                                                      '_id': ObjectId(session_id)
                                                                  },
                                                                  return_keys=['title', '_id']) for session_id in notes]

        notes_info = mongo_session.get_particular_key_value(
            collection="course_sessions_notes",
            condition={
                "$match": {"$and": [{"course_id": ObjectId(course_id),
                                     "session_id": {"$in": sessions},
                                     "type": "note"}]}},
            return_info={"$group": {"_id": "$session_id",
                                    "data": {"$push": '$$ROOT'}},
                         },
            all_docs=True)

        if notes_info:
            # process notes on sessions
            for session in session_info:
                user_notes = []
                for data in notes_info:
                    if data["_id"] == session['_id']:
                        user_notes = [str(note["user_id"]) for note in data["data"]]
                notes_report.append({"session_id": str(session['_id']),
                                     "title": session['title'],
                                     "content": [{"username": subscriber["username"],
                                                  "id": str(subscriber["_id"]),
                                                  "is_note": True if str(
                                                      subscriber["_id"]) in user_notes else False
                                                  } for subscriber in user_query]
                                     })
            if notes_report:
                sessions = []
                notes_data = []
                for i in range(len(notes_report)):
                    sessions.append('NT ' + str(i) + ' (' + notes_report[i]['title'] + ')')
                    each_note = []
                    for z in notes_report[i]['content']:
                        answer = 'Not Submitted'
                        if z['is_note']:
                            answer = 'Submitted'
                        each_note.append(answer)
                    notes_data.append(each_note)
                if sessions:
                    columns = pd.MultiIndex.from_product([['Notes'], sessions])
                    df_1 = pd.DataFrame(np.array(notes_data).T, columns=columns)
                    df = pd.concat([df, df_1])

    attendance_report = []
    if attendance:
        sessions = [ObjectId(session) for session in attendance if validate_ObjectId(session)]
        sessions_info = mongo_session.get_particular_key_value(
            collection="course_sessions",
            condition={"$match": {"_id": {"$in": sessions}}},
            return_info={"$project": {"_id": "$_id",
                                      "title": "$title",
                                      "assessments": "$assessments",
                                      "participants": "$participants"}},
            all_docs=True)
        # fetch session titles
        # session dict containing session id and title
        sessions_dict = {}
        for session in sessions_info:
            sessions_dict[str(session["_id"])] = session["title"]
            if session.get("participants") and session["participants"].get("content"):
                active_participants = [str(user["_id"]) for user in session["participants"]["content"]]
                attendance_report.append({"session_id": str(session["_id"]),
                                          "session_title": sessions_dict[str(session["_id"])],
                                          "content": [{"username": subscriber["username"],
                                                       "id": str(subscriber["_id"]),
                                                       "attended": True if str(
                                                           subscriber["_id"]) in active_participants else False
                                                       } for subscriber in user_query]
                                          })
        if attendance_report:
            sessions = []
            attendance_data = []
            for i in range(len(attendance_report)):
                sessions.append('ATT ' + str(i) + ' (' + attendance_report[i]['session_title'] + ')')
                each_att = []
                for z in attendance_report[i]['content']:
                    answer = 'Absent'
                    if z['attended']:
                        answer = 'Present'
                    each_att.append(answer)
                attendance_data.append(each_att)
            if sessions:
                columns = pd.MultiIndex.from_product([['Attendance'], sessions])
                df_1 = pd.DataFrame(np.array(attendance_data).T, columns=columns)
                df = pd.concat([df, df_1], axis=1)

    # course_work
    cw_report = {
        "course_level": [],
        "topic_level": []
    }
    if course_work:
        cw_levels_c, cw_levels_t, course_works = [], [], []
        topic_course_works = {}  # containing course work id and corresponding topic id.

        if "topic_level" in course_work:
            # topic level
            if course_work['topic_level']:
                cw_levels_t.append("Coursework: Topic")
            cw_report['topic_level'] = []
            for cw in course_work["topic_level"]:
                topic_course_works[str(cw["_id"])] = str(cw["_id"])
            course_works = course_work["topic_level"]

        if "course_level" in course_work:
            # course level
            if course_work['course_level']:
                cw_levels_c.append("Coursework: Course")
            cw_report['course_level'] = []
            course_works.extend(course_work["course_level"])



        # process course works
        top = 1
        course = 1
        for cw in course_works:
            course_work_info = mongo_session.check_existance_return_info(collection="course_work_bank",
                                                                         condition={"_id": ObjectId(cw["_id"])},
                                                                         columns={"is_group": 1,
                                                                                  "publish_status": 1,
                                                                                  "submissionRequirement": 1,
                                                                                  "courseWorkTitle": 1},
                                                                         return_keys=["_id",
                                                                                      "is_group",
                                                                                      "publish_status",
                                                                                      "submissionRequirement",
                                                                                      "courseWorkTitle"])
            cw_instance_info = mongo_session.check_existance_return_info(collection="course_work_instances",
                                                                         condition={"_id": ObjectId(cw["schedule_id"])},
                                                                         columns={"start_date": 1,
                                                                                  "start_time": 1,
                                                                                  "course_work_id": 1,
                                                                                  "submissions": 1,
                                                                                  "teams": 1},
                                                                         return_keys=["_id",
                                                                                      "start_date",
                                                                                      "start_time",
                                                                                      "course_work_id",
                                                                                      "submissions",
                                                                                      "teams"])

            # validate start date time and add then add submission requirements to list.
            cw_start_time = webapp_time_to_string(cw_instance_info["start_date"], cw_instance_info["start_time"])
            cw_start_time = datetime.datetime.strptime(cw_start_time, "%Y:%m:%dT%H:%M")
            active_span = int(course_work_info["submissionRequirement"][-1]["days_of_completion"])
            course_work_end_time = cw_start_time + datetime.timedelta(days=active_span)
            if cw_start_time <= timestamp:
                cw_user_dict = {}
                total_submissions = len(course_work_info["submissionRequirement"])

                # fetch course work submissions by students, It could be individual course work or team course work.
                # individual
                if cw_instance_info["submissions"]:
                    for user in cw_instance_info["submissions"]:
                        marked_submissions = 0
                        submissions_by_subs = len(user["submitted_files"]) if user.get("submitted_files") else 0
                        total_grades = 0
                        if user.get("notes"):
                            for note in list(user["notes"].values()):
                                if "grade" in note:
                                    total_grades += int(note["grade"][-1]["content"])
                                    marked_submissions += 1
                        user_total_submissions = []
                        if user.get("submitted_files"):
                            for sub_req in list(user["submitted_files"].values()):
                                for file in sub_req:
                                    user_total_submissions.append(datetime.datetime.strptime(file["timestamp"], "%d %b %Y, %I:%M %p"))
                        user_last_submission_at = max(user_total_submissions) if user_total_submissions else ""
                        late_by = ""
                        if user_last_submission_at != "":
                            if (user_last_submission_at - course_work_end_time).total_seconds() >= 0:
                                late_by = str(user_last_submission_at - course_work_end_time)
                        cw_user_dict[str(user["user_id"])] = {"grade": total_grades,
                                                              "team_name": "",
                                                              "submission_data": "{}/{}/{}".format(
                                                                  marked_submissions,
                                                                  submissions_by_subs,
                                                                  total_submissions),
                                                                  "late_by": late_by,
                                                                  "user_last_submission_at": str(user_last_submission_at) if user_last_submission_at else ""}

                if cw_instance_info["teams"]:
                    for team in cw_instance_info["teams"]:
                        # considering that student's submissions will be same as of team.
                        marked_submissions = 0
                        submissions_by_subs = len(team["submissions"]) if team.get("submissions") else 0
                        total_grades = 0
                        if team.get("notes"):
                            for note in list(team["notes"].values()):
                                if "grade" in note:
                                    total_grades += int(note["grade"][-1]["content"])
                                    marked_submissions += 1
                        team_total_submissions = []
                        if team.get("submissions"):
                            for sub_req in list(team["submissions"].values()):
                                for file in sub_req:
                                    team_total_submissions.append(
                                        datetime.datetime.strptime(file["timestamp"], "%d %b %Y, %I:%M %p"))
                        team_last_submission_at = max(team_total_submissions) if team_total_submissions else ""
                        late_by = ""
                        if team_last_submission_at != "":
                            if (team_last_submission_at - course_work_end_time).total_seconds() >= 0:
                                late_by = str(team_last_submission_at - course_work_end_time)
                        for member in team["members"]:
                            cw_user_dict[str(member["_id"])] = {"grade": total_grades,
                                                                "team_name": team["name"],
                                                                "submission_data": "{}/{}/{}".format(
                                                                    marked_submissions,
                                                                    submissions_by_subs,
                                                                    total_submissions),
                                                                    "late_by": late_by,
                                                                    "team_last_submission_at": str(team_last_submission_at) if team_last_submission_at else ""}
                info = []
                for subscriber in user_query:
                    if str(subscriber["_id"]) in cw_user_dict:
                        data = {**users_dict[str(subscriber["_id"])], **cw_user_dict[str(subscriber["_id"])]}
                    else:
                        default = {"grade": 0,
                                   "team_name": "",
                                   "submission_data": "{}/{}/{}".format(0, 0, total_submissions)}
                        data = {**users_dict[str(subscriber["_id"])], **default}
                    info.append(data)
                cw_response = {"title": course_work_info["courseWorkTitle"],
                               "topic_id": topic_course_works[str(course_work_info["_id"])] if
                               str(course_work_info["_id"]) in topic_course_works else "",
                               "is_group": course_work_info["is_group"],
                               "_id": str(course_work_info["_id"]),
                               "schedule_id": str(cw_instance_info["_id"]),
                               "content": info}
                if cw_response["topic_id"]:
                    cw_topic = []
                    cw_report["topic_level"].append(cw_response)
                    each_topic = []
                    lsa = []
                    for topic_data in cw_response['content']:
                        if topic_data.get('late_by'):
                            if not topic_data['late_by']:
                                topic_data['late_by'] = ""
                            each_topic.append(str(topic_data['grade']) + "(" + str(topic_data['submission_data']) + ")" + ".")
                        else:
                            each_topic.append(str(topic_data['grade']) + "(" + str(topic_data['submission_data']) + ")")

                        if topic_data.get('team_last_submission_at') or topic_data.get('user_last_submission_at'):
                            if topic_data.get('user_last_submission_at'):
                                lsa.append(topic_data['user_last_submission_at'])
                            if topic_data.get('team_last_submission_at'):
                                lsa.append(topic_data['team_last_submission_at'])
                        else:
                            lsa.append('')

                    cw_topic.append('CWT ' + str(top) + ' (' + cw_response['title'] + ')')
                    cw_topic.append('Last Submission '+ str(top) + ' (' + cw_response['title'] + ')')
                    column = pd.MultiIndex.from_product([cw_levels_t, cw_topic])
                    df1 = pd.DataFrame(zip(np.array(each_topic).T, np.array(lsa).T), columns=column)
                    df = pd.concat([df, df1], axis=1)
                    top += 1
                else:
                    cw_report["course_level"].append(cw_response)
                    each_course = []
                    cw_course = []
                    lsa = []
                    for course_data in cw_response['content']:
                        if course_data.get('late_by'):
                            if not course_data['late_by']:
                                course_data['late_by'] = ""
                            each_course.append(str(course_data['grade']) + "(" + str(course_data['submission_data']) + ")" + ".")
                        else:
                            each_course.append(str(course_data['grade']) + "(" + str(course_data['submission_data']) + ")")

                        if course_data.get('team_last_submission_at') or course_data.get('user_last_submission_at'):
                            if course_data.get('user_last_submission_at'):
                                lsa.append(course_data['user_last_submission_at'])
                            if course_data.get('team_last_submission_at'):
                                lsa.append(course_data['team_last_submission_at'])
                        else:
                            lsa.append('')

                    cw_course.append('CWC ' + str(course) + ' (' + cw_response['title'] + ')')
                    cw_course.append('Last Submission '+ str(top) + ' (' + cw_response['title'] + ')')
                    column = pd.MultiIndex.from_product([cw_levels_c, cw_course])
                    df1 = pd.DataFrame(zip(np.array(each_course).T, np.array(lsa).T), columns=column)
                    df = pd.concat([df, df1], axis=1)
                    course += 1

    # assessment
    assessments_report = {
        "course_level": [],
        "topic_level": [],
        "session_level": []
    }
    if assessments:
        assess_level = []
        assessments_report["topic_level"] = []
        if "topic_level" in assessments:
            if assessments['topic_level']:
                top = 1
                for assess in assessments["topic_level"]:
                    assess_level = []
                    assess_level.append("Assessment: Topic")
                    courses = []
                    assess['_id'] = ObjectId(assess['_id'])
                    topic_id = mongo_session.check_existance_return_info(collection="course_topics",
                                                                         condition={
                                                                             "_id": {"$in": topic_info},
                                                                             "assessments._id": assess["_id"]},
                                                                         columns={"_id": 1},
                                                                         return_keys=["_id"])
                    if "schedule_id" in assess:
                        assess['schedule_id'] = ObjectId(assess['schedule_id'])
                    if "is_timed" in assess.keys() and not bool(assess["is_timed"]):
                        is_timed = False
                    assess_data = process_assessment(assess=assess,
                                                     course_id=course_id,
                                                     topic_id=topic_id['_id'],
                                                     user_data=user_query,
                                                     timestamp=timestamp,
                                                     level="topic",
                                                     is_timed=is_timed)
                    sa = []
                    if assess_data['content']:
                        assessments_report["topic_level"].append(assess_data)
                        each_topic = []

                        for i in assess_data['content']:
                            if i['is_marked'] == False and i["is_submitted"] == True:
                                each_topic.append('Green')
                            elif i['is_marked'] == True and i["is_submitted"] == True:
                                each_topic.append(i['grade'])
                            elif i['is_marked'] == False and i["is_submitted"] == False:
                                each_topic.append('0')
                            if i.get('submitted_at'):
                                sa.append(i['submitted_at'])
                            else:
                                sa.append('')
                        courses.append('AT ' + str(top) + ' (' + assess_data['title'] + ')')
                        courses.append('Last Submission ' + str(top) + ' (' + assess_data['title'] + ')')
                        column = pd.MultiIndex.from_product([assess_level, courses])
                        df2 = pd.DataFrame(zip(np.array(each_topic).T, np.array(sa).T), columns=column)
                        df = pd.concat([df, df2], axis=1)
                    else:
                        courses.append('AT ' + str(top) + ' (' + assess_data['title'] + ')')
                        courses.append('Last Submission ' + str(top) + ' (' + assess_data['title'] + ')')
                        each_topic = ['' * len(user_query)]
                        sa.append('' * len(user_query))
                        column = pd.MultiIndex.from_product([assess_level, courses])
                        df2 = pd.DataFrame(zip(np.array(each_topic).T, np.array(sa).T), columns=column)
                        df = pd.concat([df, df2], axis=1)
                    top += 1

        if "session_level" in assessments:
            if assessments['session_level']:
                ses = 1
                assessments_report["session_level"] = []
                sessions = [ObjectId(session['_id']) for session in assessments['session_level']
                            if validate_ObjectId(session['_id'])]
                sessions_info = mongo_session.access_specific_fields(
                    collection="course_sessions",
                    condition={"assessments._id": {"$in": sessions}})
                sessions_dict = {}
                for session in sessions_info:
                    sessions_dict[str(session["_id"])] = session["title"]
                    for assess in session["assessments"]:
                        courses = []
                        assess_level = []
                        assess_level.append("Assessment: Session")
                        if "is_timed" in assess.keys() and not bool(assess["is_timed"]):
                            is_timed = False
                        topic_id = mongo_session.check_existance_return_info(collection="course_topics",
                                                                             condition={
                                                                                 "_id": {"$in": topic_info},
                                                                                 "sessions._id": ObjectId(
                                                                                     session["_id"])},
                                                                             columns={"_id": 1},
                                                                             return_keys=["_id"])
                        if topic_id:
                            assess_data = process_assessment(assess=assess,
                                                             topic_id=topic_id['_id'],
                                                             course_id=course_id,
                                                             user_data=user_query,
                                                             timestamp=timestamp,
                                                             level="session",
                                                             session_id=session["_id"],
                                                             session_title=sessions_dict[str(session["_id"])],
                                                             is_timed=is_timed)
                            assessments_report["session_level"].append(assess_data)
                            sa = []
                            if assess_data['content']:
                                each_session = []
                                for i in assess_data['content']:
                                    if i['is_marked'] == False and i["is_submitted"] == True:
                                        each_session.append('Green')
                                    elif i['is_marked'] == True and i["is_submitted"] == True:
                                        each_session.append(i['grade'])
                                    elif i['is_marked'] == False and i["is_submitted"] == False:
                                        each_session.append('0')
                                    if i.get('submitted_at'):
                                        sa.append(i['submitted_at'])
                                    else:
                                        sa.append('')
                                courses.append('AS ' + str(ses) + ' (' + assess_data['title'] + ')')
                                courses.append('Last Submission ' + str(ses) + ' (' + assess_data['title'] + ')')
                                column = pd.MultiIndex.from_product([assess_level, courses])
                                df3 = pd.DataFrame(zip(np.array(each_session).T, np.array(sa).T), columns=column)
                                df = pd.concat([df, df3], axis=1)
                            else:
                                courses.append('AS ' + str(ses) + ' (' + assess_data['title'] + ')')
                                courses.append('Last Submission ' + str(ses) + ' (' + assess_data['title'] + ')')
                                each_session = ['' * len(user_query)]
                                sa.append('' * len(user_query))
                                column = pd.MultiIndex.from_product([assess_level, courses])
                                df3 = pd.DataFrame(zip(np.array(each_session).T, np.array(sa).T), columns=column)
                                df = pd.concat([df, df3], axis=1)
                    ses += 1
        if "course_level" in assessments:
            course = 1
            if assessments['course_level']:
                assessments_report["course_level"] = []

                for assess in assessments["course_level"]:
                    assess_level = []
                    courses = []
                    assess_level.append("Assessment: Course")
                    if "is_timed" in assess.keys() and not bool(assess["is_timed"]):
                        is_timed = False
                    assess['_id'] = ObjectId(assess['_id'])
                    if "schedule_id" in assess:
                        assess['schedule_id'] = ObjectId(assess['schedule_id'])
                    assess_data = process_assessment(assess=assess,
                                                     course_id=course_id,
                                                     user_data=user_query,
                                                     timestamp=timestamp,
                                                     level="course",
                                                     is_timed=is_timed)
                    sa = []
                    if assess_data["content"]:
                        assessments_report["course_level"].append(assess_data)
                        each_course = []
                        for i in assess_data['content']:
                            if i['is_marked'] == False and i["is_submitted"] == True:
                                each_course.append('Green')
                            elif i['is_marked'] == True and i["is_submitted"] == True:
                                each_course.append(i['grade'])
                            elif i['is_marked'] == False and i["is_submitted"] == False:
                                each_course.append('0')
                            if i.get('submitted_at'):
                                sa.append(i['submitted_at'])
                            else:
                                sa.append('')
                        courses.append('AC ' + str(course) + ' (' + assess_data['title'] + ')')
                        courses.append('Last Submission ' + str(course) + ' (' + assess_data['title'] + ')')
                        column = pd.MultiIndex.from_product([assess_level, courses])
                        df1 = pd.DataFrame(zip(np.array(each_course).T, np.array(sa).T), columns=column)
                        df = pd.concat([df, df1], axis=1)
                    else:
                        courses.append('AC ' + str(course) + ' (' + assess_data['title'] + ')')
                        courses.append('Last Submission ' + str(course) + ' (' + assess_data['title'] + ')')
                        each_course = ['' * len(user_query)]
                        sa.append('' * len(user_query))
                        column = pd.MultiIndex.from_product([assess_level, courses])
                        df1 = pd.DataFrame(zip(np.array(each_course).T, np.array(sa).T), columns=column)
                        df = pd.concat([df, df1], axis=1)
                    course += 1

    report["subscribers"] = [{"_id": str(data["_id"]),
                              "username": data["username"],
                              "first_name": data["name"],
                              "last_name": data["last_name"]} for data in user_query] if user_query else []
    usernames = [data['username'] for data in report['subscribers']]
    student_name = [str(data['first_name'] + " " + data["last_name"]).title() for data in report['subscribers']]
    df['Student Name'] = student_name
    df['Username'] = usernames
    cols = df.columns.tolist()
    cols = cols[-2:] + cols[:-2]
    df = df[cols]
    df.index += 1
    df = df.style.applymap(bg_color_red_or_green)
    df = df.applymap(_color_red_or_green)
    return df
