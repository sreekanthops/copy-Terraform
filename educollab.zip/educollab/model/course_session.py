import json
import re

import pandas as pd
import youtube_dl

import config
from config import supported_image_content_type, supported_video_content_type, supported_content_type_with_extension, \
    s3_connection, bucket
from bson import ObjectId

from model import User
from mongo_connection import connection
import datetime
import model.Content as Content
import model.Question as Question
from routes.exception import InvalidUsage
from services.storage.s3_services import s3_storage

from utils.misc import validate_ObjectId, renew_s3_links, get_profile_pic
from utils.time_conversions import utc_datetime_now, utc_dtime_obj_to_zone_str

s3_function = s3_storage()

from db_wrapper.tasks import Mongo

mongo_session = Mongo()

import time
from utils import time_conversions, misc
from model.zoom import Zoom
from fuzzywuzzy import process
import copy
from model.courses.misc import seen_asess_feedback


def add_comment_course_session(comment, user_id, session_id):
    """to add comment on particular course session"""
    session_collection = connection.course_sessions

    condition = {"_id": ObjectId(session_id)}
    comment_update = {"_id": ObjectId(), "user_id": ObjectId(user_id), "comment": comment, "timestamp": datetime.datetime.today()}

    if not session_collection.find(condition).count() > 0:
        raise Exception("Sorry, This video does not exists.")

    session_collection.update({"_id": ObjectId(session_id)}, {"$push": {"comments": comment_update}})
    msg = "Thanks for your Comment."
    return msg


def comment_like_dislike(status, user_id, session_id, comment_id, is_true):
    """to update like dislike status in course session collection"""
    course_sessions_collection = connection.course_sessions
    comment_query = {"_id": ObjectId(str(session_id)), "comments._id": ObjectId(str(comment_id))}
    like_query = {"comments.$.Liked": str(user_id)}
    dislike_query = {"comments.$.Disliked": str(user_id)}

    if status.lower() == "liked":
        if is_true:
            course_sessions_collection.update_one(comment_query,
                                                  {"$pull": like_query})
            course_sessions_collection.update_one(comment_query,
                                                  {"$pull": dislike_query})
            like_status = False
            dislike_status = False
        else:
            course_sessions_collection.update_one(comment_query,
                                                  {"$push": like_query})
            course_sessions_collection.update_one(comment_query,
                                                  {"$pull": dislike_query})
            like_status = True
            dislike_status = False
    elif status.lower() == "disliked":
        if is_true:
            course_sessions_collection.update_one(comment_query,
                                                  {"$pull": like_query})
            course_sessions_collection.update_one(comment_query,
                                                  {"$pull": dislike_query})

            like_status = False
            dislike_status = False
        else:
            course_sessions_collection.update_one(comment_query,
                                                  {"$pull": like_query})
            course_sessions_collection.update_one(comment_query,
                                                  {"$push": dislike_query})

            like_status = False
            dislike_status = True
    else:
        raise InvalidUsage("Bad Request", 400)
    return like_status, dislike_status


def session_info(course_id, user_id, session_id, role, organisation):
    """to fetch the course session details"""
    user_collection = connection.user_profile
    course_category_collection = connection.Course_Category
    comment_count = 0
    course_category_taxonomy = ""
    view_video_time = 0
    s3_data = ""

    if role == "super_admin":
        course_condition = {
            "_id": ObjectId(course_id)
        }
    else:
        course_condition = {
            "_id": ObjectId(course_id),
            "active": True
        }
    course_query = mongo_session.get_all_data_for_particular_condition_fields(
        collection='courses_bank',
        condition=course_condition)
    if course_query['status'] != 200:
        raise InvalidUsage("Something went wrong, Please try again later.", 500)

    course_data = course_query['message'][0]
    # if not course_data['active']:
    #     raise InvalidUsage("Oops, course is not active anymore.", 500)

    publish_rights = [str(user['_id']) for user in course_data["editors"]] + \
                     [str(user['_id']) for user in course_data["instructors"]] + [str(course_data["created_by"])]
    publish_right = True
    if role != "super_admin":
        if course_data['status'] == "unpublish":
            if user_id not in publish_rights:
                raise InvalidUsage("Course is not published yet", 500)
        if course_data['status'] == "publish":
            org_list = [org["_id"] for org in course_data["organisations"]]
            organisation_query = mongo_session.get_all_data_for_particular_condition_fields(
                collection="organisations",
                condition={"name": organisation}
            )
            if organisation_query['status'] != 200:
                raise InvalidUsage("Something went wrong, please try again later.", 500)
            if (ObjectId(organisation_query['message'][0]['_id']) not in org_list) and (user_id not in publish_rights) \
                    and not course_data['is_public']:
                raise InvalidUsage("You don't have access to this course", 403)
        if user_id not in publish_rights:
            publish_right = False

    #role for user
    role = mongo_session.get_data_for_particular_columns_with_condition(
        collection="user_profile",
        condition={"_id": ObjectId(user_id)},
        columns={"role"}
    )['message'][0]['role']

    # time at which user left the video
    user_cursor = user_collection.find({"_id": ObjectId(user_id),
                                        "course_video_states": {"$elemMatch":
                                            {
                                                "course_id": ObjectId(course_id),
                                                "session_id": ObjectId(session_id)
                                            }
                                        }},
                                       {"course_video_states.$": 1})
    for item in user_cursor:
        view_video_time = item['course_video_states'][0]["video_time"]

    # content details
    session_query = mongo_session.get_all_data_for_particular_condition_fields(
        collection='course_sessions',
        condition={"_id": ObjectId(session_id)})
    if session_query["status"] != 200:
        raise Exception("Some internal server error, Please try again later.")
    session_data = session_query["message"][0]
    s3_data = session_data["url"]

    # topics
    topic_id = mongo_session.check_existance_return_info(collection="course_topics",
                                                         condition={"sessions._id": ObjectId(session_id)})
    topic_query = mongo_session.get_all_data_for_particular_condition_fields(
        collection="course_topics",
        condition={"_id": ObjectId(topic_id)})
    if topic_query['status'] != 200:
        raise InvalidUsage("Something went wrong, please try again later.", 500)
    topic_data = topic_query['message'][0]

    if session_data["type"] == "file" or session_data.get("status") == "zoom_recorded" or \
            session_data.get('status') == 'recorded':
        s3_data = session_data["url"]
        s3_link, s3_status = s3_function.generate_presigned_url_from_s3(session_data["url"])
        if s3_status != 200:
            raise Exception("Error occurred while fetching files, Please try again later.")
        session_data["url"] = s3_link
        session_data["file_id"] = str(session_data["file_id"])

    if session_data.get('instance_id'):
        session_data["instance_id"] = str(session_data["instance_id"])
    # process assessments
    for assessment in session_data["assessments"]:
        assess = assessment
        assess_query = mongo_session.get_data_for_particular_columns_with_condition(
            collection='assessment',
            condition={"_id": assessment["_id"]},
            columns={"assessment_name": 1, "total_time": 1})
        if assess_query["status"] != 200:
            raise Exception("Some internal server error, Please try again later.")
        assessment["title"] = assess_query["message"][0]["assessment_name"]

        # adding more info to sessions
        # for assess in topic_data["assessments"]:
        seen_feedback = seen_asess_feedback(user_id=user_id,
                                        role=role,
                                        course_id=course_id,
                                        topic_id=topic_id,
                                        course_session_id=session_data["_id"],
                                        assessment_id=assess["_id"],
                                        schedule_id=assess.get("schedule_id"))
        if not seen_feedback:
            seen_feedback = seen_asess_feedback(user_id=user_id,
                                        role=role,
                                        course_id=course_id,
                                        course_session_id=session_data["_id"],
                                        assessment_id=assess["_id"],
                                        schedule_id=assess.get("schedule_id"))
        user_submission = mongo_session.check_existance(collection="assessments_result",
                                                        condition={"course_id": ObjectId(course_id),
                                                                "user_id": ObjectId(user_id),
                                                                "topic_id": ObjectId(topic_id) if topic_id else "",
                                                                "course_session_id": ObjectId(session_data["_id"]) if session_data["_id"] else "",
                                                                "assessment_id": ObjectId(
                                                                    str(assess['_id']))})
        if not user_submission:
            user_submission = mongo_session.check_existance(collection="assessments_result",
                                                            condition={"course_id": ObjectId(course_id),
                                                                    "user_id": ObjectId(user_id),
                                                                    "course_session_id": ObjectId(session_data["_id"]) if session_data["_id"] else "",
                                                                    "assessment_id": ObjectId(
                                                                        str(assess['_id']))})
        if assess.get("schedule_id"):
            assess_query = mongo_session.get_all_data_for_particular_condition_fields(
                collection="schedule_assessment",
                condition={"_id": assess["schedule_id"]})
            if assess_query['status'] != 200:
                raise InvalidUsage("Something went wrong, please try again later.", 500)
            assess_data = assess_query['message'][0]
            start_obj = datetime.datetime.strptime(assess_data['start_time'], "%Y:%m:%dT%H:%M")
            assessment_start_time = start_obj.strftime("%d %b %Y, %I:%M %p")

            end_obj = datetime.datetime.strptime(assess_data['end_time'], "%Y:%m:%dT%H:%M")
            assessment_end_time = end_obj.strftime("%d %b %Y, %I:%M %p")

            timestamp = Question.indian_standard_time()
            timestamp_obj = datetime.datetime.strptime(timestamp, "%d %b %Y, %I:%M %p")

            topic_assess_status = True if timestamp_obj < end_obj else False
            assessment.update({"title": assess_data["assessment_name"],
                            "end_time": assessment_end_time,
                            "start_time": assessment_start_time,
                            "total_time": assess_data['total_time'],
                            "active": topic_assess_status,
                            "schedule_id": str(assess_data["_id"]),
                            "view_feedback": seen_feedback,
                            "one_time_assessment": assess.get('one_time_assessment', False),
                            "user_submission": True if user_submission else False,
                            "is_timed": assess.get("is_timed", True)})
        else:
            assess_query = mongo_session.get_data_for_particular_columns_with_condition(
                collection="assessment",
                condition={"_id": assess["_id"]},
                columns={"assessment_name": 1, "total_time": 1})
            if assess_query['status'] != 200:
                raise InvalidUsage("Something went wrong, please try again later.", 500)
            assess_data = assess_query['message'][0]
            assessment.update({"title": assess_data["assessment_name"],
                            "end_time": "",
                            "start_time": "",
                            "total_time": assess_data['total_time'],
                            "schedule_id": "",
                            "view_feedback": seen_feedback,
                            "one_time_assessment": assess.get('one_time_assessment', False),
                            "user_submission": True if user_submission else False,
                            "is_timed": assessment.get("is_timed", False)})

        assessment["_id"] = str(assessment["_id"])
        if session_data["key"] == "live_session":
            assessment["active"] = False
            if session_data.get("status") and session_data["status"] == "active":
                if assessment.get("activate"):
                    current_time_str = Question.indian_standard_time()
                    current_time_obj = datetime.datetime.strptime(current_time_str, "%d %b %Y, %I:%M %p")
                    start_time_str = assessment["activate"]["timestamp"]
                    start_time_obj = datetime.datetime.strptime(start_time_str, "%d %b %Y, %I:%M %p")

                    end_time_obj = start_time_obj + datetime.timedelta(
                        minutes=int(assess_query["message"][0]["total_time"]))
                    time_remaining = int((end_time_obj - current_time_obj).total_seconds())
                    if time_remaining >= 0:
                        assessment["active"] = True
                        if assessment.get("deactivate"):
                            deactive_time_str = assessment["deactivate"]["timestamp"]
                            deactive_time_obj = datetime.datetime.strptime(deactive_time_str, "%d %b %Y, %I:%M %p")
                            if deactive_time_obj > start_time_obj:
                                if int((deactive_time_obj - current_time_obj).total_seconds()) < 0:
                                    assessment["active"] = False
            if assessment.get("activate"):
                del assessment["activate"]
            if assessment.get("deactivate"):
                del assessment["deactivate"]

    if session_data.get("activate"):
        del session_data["activate"]
    if session_data.get("deactivate"):
        del session_data["deactivate"]
    if session_data.get("participants"):
        del session_data["participants"]
    # process resources
    for resource in session_data["resources"]:
        if resource["type"] == "file":
            resource['_id'] = str(resource['_id'])
            resource['url'], s3_status = s3_function.generate_presigned_url_from_s3(resource['url'])
            if resource.get('instance_id'):
                resource["instance_id"] = str(resource["instance_id"])
            if resource.get('schedule_id'):
                resource["schedule_id"] = str(resource["schedule_id"])
            if s3_status != 200:
                raise Exception("Error occurred while fetching files, Please try again later.")

    # process comments
    comments = []
    if session_data.get("comments"):
        comment_count = len(session_data["comments"])
        for comment in session_data["comments"]:
            username_query = mongo_session.get_data_for_particular_columns_with_condition(
                collection='user_profile',
                condition={"_id": comment["user_id"]},
                columns={"name": 1, "last_name": 1, "profile_pic": 1})
            if username_query["status"] != 200:
                raise Exception("Some internal server error, Please try again later.")
            comment["username"] = username_query["message"][0]["name"].capitalize() + " " + username_query["message"][0]["last_name"].capitalize()
            s3_url, status_code = s3_function.generate_presigned_url_from_s3(username_query["message"][0]['profile_pic'])
            comment['profile_pic'] = s3_url
            comment["_id"] = str(comment.get("_id"))

            comment['datetime'] = utc_dtime_obj_to_zone_str(comment['timestamp'])
            seconds = (datetime.datetime.now() - comment['timestamp']).total_seconds()
            humanreadable_format = Content.convert_time_into_humanreadable_form(seconds)
            time = humanreadable_format

            comment["user_id"] = str(comment["user_id"])
            comment["timestamp"] = time
            # process whether user liked the comment or not
            if comment.get("Liked"):
                comment["liked"] = any(user == user_id for user in comment["Liked"])
                comment['like_count'] = len(comment["Liked"])
                comment.pop("Liked")
            else:
                comment["liked"] = False
                comment['like_count'] = 0
            if comment.get("Disliked"):
                comment["disliked"] = any(user == user_id for user in comment["Disliked"])
                comment['dislike_count'] = len(comment["Disliked"])
                comment.pop("Disliked")
            else:
                comment["disliked"] = False
                comment['dislike_count'] = 0
        comments = session_data["comments"]
        comments.reverse()
    session_data["comments"] = comments
    session_data["status"] = session_data.get("status", "")

    # get taxonomy for course
    course_query = mongo_session.get_data_for_particular_columns_with_condition(
        collection='courses_bank',
        condition={"_id": ObjectId(course_id)},
        columns={"course_category_id": 1})
    if course_query["status"] != 200:
        raise Exception("Some internal server error, Please try again later.")
    category_id = course_query["message"][0]["course_category_id"]

    course_category_cursor = course_category_collection.find({"_id": ObjectId(category_id)})
    for category_for_taxonomy in course_category_cursor:
        course_category_taxonomy = Content.category_taxonomy_by_category_id(category_for_taxonomy)

    # process notes
    notes_summary_data = mongo_session.access_specific_fields(collection="course_sessions_notes",
                                                              condition={"session_id": ObjectId(session_id),
                                                                         "user_id": ObjectId(user_id)})
    session_data["notes"] = []
    session_data["summary"] = {}
    if notes_summary_data:
        for doc in notes_summary_data:
            if doc["type"] == "note" and doc["active"]:
                image_key = []
                resources_key = []
                video_path_key = []
                if doc.get('resources'):
                    for i in range(len(doc['resources'])):
                        if doc['resources'][i]:
                            resource_file_path = str(doc['resources'][i])
                            resources_key.append(resource_file_path)
                            resource_s3_path, s3_status = s3_function.generate_presigned_url_from_s3(
                                resource_file_path
                            )
                            if s3_status != 200:
                                raise Exception("Error occurred while fetching files, Please try again later.")
                            elif s3_status == 200:
                                doc['resources'][i] = resource_s3_path
                if doc.get('image_path'):
                    for i in range(len(doc['image_path'])):
                        if doc['image_path'][i]:
                            image_file_path = str(doc['image_path'][i])
                            image_key.append(image_file_path)
                            image_s3_path, s3_status = s3_function.generate_presigned_url_from_s3(
                                image_file_path
                            )
                            if s3_status != 200:
                                raise Exception("Error occurred while fetching files, Please try again later.")
                            elif s3_status == 200:
                                doc['image_path'][i] = image_s3_path
                if doc.get('video_path'):
                    for i in range(len(doc['video_path'])):
                        if doc['video_path'][i]:
                            video_path = str(doc['video_path'][i])
                            video_path_key.append(video_path)
                            video_s3_path, s3_status = s3_function.generate_presigned_url_from_s3(video_path)
                            if s3_status != 200:
                                raise Exception("Error occurred while fetching files, Please try again later.")
                            elif s3_status == 200:
                                doc['video_path'][i] = video_s3_path
                session_data["notes"].append({"_id": str(doc["_id"]),
                                              "title": doc["title"],
                                              "created_at": doc["created_at"],
                                              "content": misc.renew_s3_links(doc["content"]),
                                              "timestamp": doc['timestamp'] if doc.get('timestamp') else "",
                                              "resources": doc['resources'] if doc.get('resources') else [],
                                              "video_path": doc['video_path'] if doc.get('video_path') else [],
                                              "image_path": doc['image_path'] if doc.get('image_path') else [],
                                              "image_path_key": image_key,
                                              "resources_key": resources_key,
                                              "video_path_key": video_path_key})
            elif doc["type"] == "summary":
                session_data["summary"] = {"content": misc.renew_s3_links(doc["content"]),
                                           "_id": str(doc["_id"])}
        session_data["notes"] = sorted(session_data["notes"], key=lambda k: (k['timestamp'], k['created_at']))
    transcriptions = mongo_session.access_specific_fields(collection="video_transcriptions",
                                                          condition={"s3_key": s3_data})
    if transcriptions:
        if transcriptions[0].get('vtt'):
            vtt = transcriptions[0]['vtt'].split('/')[3:]
            key = '{}/{}'.format(vtt[0], vtt[1])
            vtt = s3_function.generate_presigned_url_from_s3(s3_key=key)[0]
        else:
            vtt = ""
    else:
        vtt = ""
    if transcriptions:
        transcriptions = transcriptions[0]['transcription']['results']
        if transcriptions['items']:
            for t in transcriptions['items']:
                t['word'] = t['alternatives'][0]['content']
                t.pop('alternatives')
        else:
            transcriptions = {'transcripts': [], 'items': []}
    else:
        transcriptions = {'transcripts': [], 'items': []}

    try:
        pattern = re.compile(
            "^((?:https?:)?\/\/)?((?:www|m)\.)?((?:youtube(-nocookie)?\.com|youtu.be))(\/(?:[\w\-]+\?v=|embed\/|v\/)?)([\w\-]+)(\S+)?$")
        if pattern.match(s3_data):
            video_query = mongo_session.get_all_data_for_particular_condition_fields(
                collection="youtube_video_duration",
                condition={"video_url": s3_data})
            if video_query['status'] != 200:
                raise InvalidUsage("Something went wrong, please try again later.", 500)
            video_data = video_query["message"]
            if video_data:
                duration = video_data[0]['duration']
            else:
                ydl_opts = {}
                with youtube_dl.YoutubeDL(ydl_opts) as ydl:
                    dictmeta = ydl.extract_info(s3_data, download=False)
                seconds = dictmeta['duration']
                seconds = seconds % (24 * 3600)
                hour = seconds // 3600
                seconds %= 3600
                minutes = seconds // 60
                seconds %= 60
                duration = "%02d:%02d:%02d" % (hour, minutes, seconds)
                video_doc_to_insert = {"video_url": s3_data, "duration": duration}
                video_duration_status = mongo_session.insert_documnet(collection="youtube_video_duration",
                                                                      doc_to_insert=video_doc_to_insert)
                if video_duration_status["status"] != 200:
                    raise Exception("Some internal error, Please try again later.")
        else:
            res = s3_connection.head_object(Bucket=bucket, Key=s3_data)
            duration = str(res['Metadata'].get('duration', '00:00:00'))
    except Exception as e:
        print("S3 duration block ", e)
        duration = "00:00:00"

    check_existance = mongo_session.access_specific_fields(collection='courses_progress_tracking',
                                                           condition={"user_id": user_id})
    topic_data = mongo_session.get_all_data_for_particular_condition_fields(collection='course_topics',condition={"_id": ObjectId(topic_id)})
    if check_existance:
        check_existance = check_existance[0]
        if check_existance.get('courses'):
            for course in check_existance['courses']:
                if str(course) == str(course_id):
                    data_copy = copy.deepcopy(check_existance)
                    course_data = data_copy['courses'][str(course_id)]
                    if str(topic_id) in list(course_data):
                        course_data[str(topic_id)].append({"session_id": session_id,
                                                           "log_time": datetime.datetime.now()})
                        if len(set([x['session_id'] for x in list(course_data[str(topic_id)])])) == len(topic_data['message'][0]['sessions']):
                            if str(topic_id) not in data_copy['topics_completed']:
                                data_copy['topics_completed'].append(str(topic_id))
                    else:
                        course_data[str(topic_id)] = [{"session_id": session_id, "log_time": datetime.datetime.now()}]
                        if len(set([x['session_id'] for x in list(course_data[str(topic_id)])])) == len(topic_data['message'][0]['sessions']):
                            if str(topic_id) not in data_copy['topics_completed']:
                                data_copy['topics_completed'].append(str(topic_id))
                    mongo_session.update_record_into_db(collection='courses_progress_tracking',
                                                        condition={'user_id': str(user_id)},
                                                        update_info=data_copy)
                else:
                    data_copy = copy.deepcopy(check_existance)
                    data_copy['courses'][str(course_id)] = {str(topic_id) if topic_id else topic_id:
                                                             [{"session_id": str(session_id),
                                                               "log_time": datetime.datetime.now()}]}
                    course_data = data_copy['courses'][str(course_id)]
                    if len(set([x['session_id'] for x in list(course_data[str(topic_id)])])) == len(topic_data['message'][0]['sessions']):
                        if str(topic_id) not in data_copy['topics_completed']:
                            data_copy['topics_completed'].append(str(topic_id))
                    mongo_session.update_record_into_db(collection='courses_progress_tracking',
                                                        condition={'user_id': str(user_id)},
                                                        update_info=data_copy)
        else:
            doc_to_insert = {"user_id": str(user_id),
                             "courses": {
                                 str(course_id): {
                                     str(topic_id) if topic_id else topic_id: [{
                                         "session_id": str(session_id),
                                         "log_time": datetime.datetime.now()
                                     }]
                                 }
                             },
                            "topics_completed": []}
            course_data = doc_to_insert['courses'][str(course_id)]
            if len(set([x['session_id'] for x in list(course_data[str(topic_id)])])) == len(topic_data['message'][0]['sessions']):
                if str(topic_id) not in doc_to_insert['topics_completed']:
                    doc_to_insert['topics_completed'].append(str(topic_id))
            mongo_session.insert_documnet(collection='courses_progress_tracking', doc_to_insert=doc_to_insert)
    else:
        doc_to_insert = {"user_id": str(user_id),
                         "courses": {
                             str(course_id): {
                                 str(topic_id) if topic_id else topic_id: [{
                                     "session_id": str(session_id),
                                     "log_time": datetime.datetime.now()
                                 }]
                             }
                         },
                         "topics_completed": []}
        course_data = doc_to_insert['courses'][str(course_id)]
        if len(set([x['session_id'] for x in list(course_data[str(topic_id)])])) == len(topic_data['message'][0]['sessions']):
            if str(topic_id) not in doc_to_insert['topics_completed']:
                doc_to_insert['topics_completed'].append(str(topic_id))
        mongo_session.insert_documnet(collection='courses_progress_tracking', doc_to_insert=doc_to_insert)
    response = {"content_detail": session_data,
                "topic_id": str(topic_id),
                "comment_count": comment_count,
                "course_category_taxonomy": course_category_taxonomy,
                "view_video_time": view_video_time,
                "transcriptions": transcriptions,
                "vtt": vtt,
                "duration": duration,
                "s3_key": s3_data,
                "publish_right": publish_right}
    return response


def get_topic_session(course_id, user_id, topic_id):
    """get info about all sessions in a topic"""
    topic_query = mongo_session.get_all_data_for_particular_condition_fields(
        collection="course_topics",
        condition={"_id": ObjectId(str(topic_id))})
    if topic_query['status'] != 200:
        raise InvalidUsage("Something went wrong, please try again later.", 500)
    topic_data = topic_query['message'][0]

    processed_sessions = []
    for session in topic_data['sessions']:
        session_query = mongo_session.get_all_data_for_particular_condition_fields(
            collection="course_sessions",
            condition={"_id": ObjectId(session["_id"])})
        if session_query['status'] != 200:
            raise InvalidUsage("Something went wrong, please try again later.", 500)
        session_data = session_query['message'][0]
        # video duration code for session
        try:
            pattern = re.compile(
                "^((?:https?:)?\/\/)?((?:www|m)\.)?((?:youtube(-nocookie)?\.com|youtu.be))(\/(?:[\w\-]+\?v=|embed\/|v\/)?)([\w\-]+)(\S+)?$")
            if pattern.match(session_data['url']):
                video_query = mongo_session.get_all_data_for_particular_condition_fields(
                    collection="youtube_video_duration",
                    condition={"video_url": session_data['url']})
                if video_query['status'] != 200:
                    raise InvalidUsage("Something went wrong, please try again later.", 500)
                video_data = video_query["message"]
                if video_data:
                    session_data['duration'] = video_data[0]['duration']
                else:
                    ydl_opts = {}
                    with youtube_dl.YoutubeDL(ydl_opts) as ydl:
                        dictmeta = ydl.extract_info(session_data['url'], download=False)
                    seconds = dictmeta['duration']
                    seconds = seconds % (24 * 3600)
                    hour = seconds // 3600
                    seconds %= 3600
                    minutes = seconds // 60
                    seconds %= 60
                    session_data['duration'] = "%02d:%02d:%02d" % (hour, minutes, seconds)
                    video_doc_to_insert = {"video_url": session_data['url'], "duration": session_data['duration']}
                    video_duration_status = mongo_session.insert_documnet(collection="youtube_video_duration",
                                                                          doc_to_insert=video_doc_to_insert)
                    if video_duration_status["status"] != 200:
                        raise Exception("Some internal error, Please try again later.")
            else:
                res = config.s3_connection.head_object(Bucket=config.bucket, Key=session_data['url'])
                session_data['duration'] = str(res['Metadata'].get('duration', "00:00:00"))
        except Exception as e:
            print("S3 duration block ", e)
            session_data['duration'] = "00:00:00"

        session_info = {"_id": str(session["_id"]),
                        "title": session_data["title"],
                        "duration": session_data['duration'],
                        "status": session_data.get("status", ""),
                        "key": session_data['key']}
        processed_sessions.append(session_info)
    response = {"topic_title": topic_data["title"], "topic_id": topic_id, "sessions": processed_sessions}
    return response


def ask_question(question, user_id, language, translated_question, coins, category_id, question_image, question_video,
                 course_id, session_id, video_time, coordinates=None):
    """to ask question on session videos and add in database"""
    timestamp = Question.indian_standard_time()
    question_image_s3_link = ""
    question_video_s3_link = ""
    question_image_s3_path = None
    question_video_s3_path = None
    available_coin = ""
    message = ""
    if question_image:
        question_image_ext_validation = Question.get_extension_validation(question_image, supported_image_content_type)
        if question_image_ext_validation[0]:
            unique_key = str(int(time.time())) + '-' + str(user_id)
            question_image_content_type = supported_content_type_with_extension[
                question_image_ext_validation[1]]
            question_image_s3_info = s3_function.upload_data_to_s3_private(question_image, unique_key=unique_key,
                                                                           folder_name="question-images/",
                                                                           file_extension=
                                                                           question_image_ext_validation[1],
                                                                           Content_Type=question_image_content_type)
            if not question_image_s3_info['status'] == 200:
                raise Exception("Some internal error occurred while serving your request, Please try again later.")

            question_image_s3_link = question_image_s3_info['s3_link']
            question_image_s3_path = question_image_s3_info['s3_key']

    if question_video:
        question_video_ext_validation = Question.get_extension_validation(question_video, supported_video_content_type)
        if question_video_ext_validation[0]:
            unique_key = str(int(time.time())) + '-' + str(user_id)
            question_video_content_type = supported_content_type_with_extension[
                question_video_ext_validation[1]]
            question_video_s3_info = s3_function.upload_data_to_s3_private(question_video, unique_key=unique_key,
                                                                           folder_name="question-videos/",
                                                                           file_extension=
                                                                           question_video_ext_validation[1],
                                                                           Content_Type=question_video_content_type)
            if not question_video_s3_info['status'] == 200:
                raise Exception("Some internal error occurred while serving your request, Please try again later.")
            question_video_s3_link = question_video_s3_info['s3_link']
            question_video_s3_path = question_video_s3_info['s3_key']

    category_name = \
        mongo_session.get_all_data_for_particular_condition_fields("Course_Category", {"_id": ObjectId(category_id)})[
            'message'][0]['name']
    insert_doc = {"user_id": user_id,
                  "questions": question,
                  "question_image_path": question_image_s3_path,
                  "question_video_path": question_video_s3_path,
                  "course_category_id": ObjectId(category_id),
                  "Course_Category": category_name,
                  "Timestamp": timestamp,
                  "status": False,
                  "answers": [],
                  "reward": coins,
                  "language": language,
                  "translated_question": translated_question,
                  "course_id": ObjectId(course_id),
                  "course_session_id": ObjectId(session_id),
                  "video_time": video_time,
                  "es_flag": False}
    if coordinates:
        insert_doc["coordinates"] = coordinates
    question_cursor_info = mongo_session.insert_data_ask_question(collection="question_bank", record=insert_doc)
    question_cursor = question_cursor_info['message']
    if question_cursor_info['status'] == 200:
        message = "question added"
        user_data_updation = mongo_session.update_user_data_ask_question(collection="user_profile",
                                                                         condition={"_id": ObjectId(user_id)},
                                                                         push_info={
                                                                             "questions": {"_id": question_cursor}},
                                                                         increment_info={"coin": -coins})

    user_cursor = user_data_updation['message']
    for data in user_cursor:
        available_coin = float(round(data['coin'], 2))
    data = str(question_cursor)
    session_query = mongo_session.get_data_for_particular_columns_with_condition(
        collection='course_sessions',
        condition={"_id": ObjectId(session_id)},
        columns={"url": 1,
                 "file_id": 1})
    if session_query["status"] != 200:
        raise Exception("Some internal server error, Please try again later.")
    session_file_id = str(session_query["message"][0]["file_id"])
    session_video_link = s3_function.generate_presigned_url_from_s3(session_query["message"][0]["url"]) if \
        session_file_id else session_query["message"][0]["url"]
    return data, available_coin, question_image_s3_link, question_video_s3_link, message, 200, session_video_link, \
           session_file_id


def activate_session_assessment(course_id, user_id, session_id, topic_id, assessment_id, role, active):
    """to make the assessments on live sessions at topic level live"""
    if role not in ["teacher", "super_admin"]:
        raise InvalidUsage("You Don't have permission to perform this action", 403)
    # check whether session is live or not
    check_live_status = mongo_session.check_existance_return_info(collection="course_sessions",
                                                                  condition={"_id": ObjectId(session_id),
                                                                             "status": "active"})
    if not check_live_status:
        raise InvalidUsage("Session is not active right now.", 400)

    # check whether an assessment exist on session level received from client in course or not.
    # session level
    if course_id and topic_id and session_id:
        # check assess exist on session level
        condition = {"_id": ObjectId(session_id),
                     "assessments._id": ObjectId(assessment_id)}
        check_assess = mongo_session.check_existance_return_info(collection="course_sessions",
                                                                 condition=condition)
        if not check_assess:
            raise InvalidUsage("Sorry, something went wrong with assessment.", 400)
    else:
        raise InvalidUsage("Bad Request", 400)
    # update the assessment in session and add timestamp, activated by information in it.
    # current timestamp
    timestamp = Question.indian_standard_time()
    if active:
        update_info = {"$set": {"assessments.$.activate":
                                    {"timestamp": timestamp,
                                     "activated_by": ObjectId(user_id)}}}
        active_assess = True
    else:
        update_info = {"$set": {"assessments.$.deactivate":
                                    {"timestamp": timestamp,
                                     "deactivated_by": ObjectId(user_id)}}}
        active_assess = False
    update_session = mongo_session.update_record_into_db(
        collection="course_sessions",
        condition={"_id": ObjectId(session_id),
                   "assessments": {"$elemMatch":
                       {
                           "_id": ObjectId(assessment_id)
                       }}
                   },
        update_info=update_info)
    if update_session["status"] != 200:
        raise Exception("Some internal error, Please try again later.")
    if update_session["update_status"]["nModified"]:
        active_assess = True
    return {"assessment_id": assessment_id,
            "active": active_assess}


def activate_live_sessions(course_id, user_id, session_id, topic_id, is_live, role):
    """to make the sessions on topic level live
    1. check if live sessions on course level exist or not, if not return error.
    2. associate the course level live session link to topic level live session.
    3. store extra information of the session like timestamp of activation and activated by in db"""
    if role not in ["teacher", "super_admin"]:
        raise InvalidUsage("You Don't have permission to perform this action", 403)
    response = ""
    delete_session_rel_data = False
    # live sessions at course level
    course_query = mongo_session.get_data_for_particular_columns_with_condition(
        collection='courses_bank',
        condition={"_id": ObjectId(course_id)},
        columns={"course_category_id": 1, "live_sessions": 1})
    if course_query["status"] != 200:
        raise Exception("Some internal server error, Please try again later.")

    live_sessions = course_query["message"][0]["live_sessions"]
    if not live_sessions:
        raise InvalidUsage("There are no live sessions present on this course to link with session", 404)

    # current timestamp
    timestamp = Question.indian_standard_time()
    # print("timestamp ", timestamp)
    current_datetime_obj = datetime.datetime.strptime(timestamp, "%d %b %Y, %I:%M %p")
    # print("current_datetime_obj ",current_datetime_obj, type(current_datetime_obj))
    current_date = current_datetime_obj.date()
    # print("current_date ",current_date)
    current_day_time = current_datetime_obj.strftime("%H:%M")
    # print("current_day_time ",current_day_time)
    first_upcomming_live_session = {"url": ""}
    for session in live_sessions:
        # print(sess)
        # print(sess["start_date"], sess["start_time"])
        db_start_time = Content.webapp_time_to_string(session["start_date"], session["start_time"])
        start_time = datetime.datetime.strptime(db_start_time, "%Y:%m:%dT%H:%M")
        # print("start_time ",start_time)
        start_time_obj = start_time - datetime.timedelta(hours=0, minutes=10)
        # print("start_time_obj ",start_time_obj)
        end_time = datetime.datetime.strptime(session["start_time"], "%H:%M") + datetime.timedelta(
            minutes=int(session["duration"]))
        # print("end_time ",end_time)
        end_time_str = end_time.strftime("%H:%M")
        # print("end_time_str ",end_time_str)
        db_end_time = Content.webapp_time_to_string(session["end_date"], end_time_str)
        # print("db_end_time ",db_end_time)
        end_time_obj = datetime.datetime.strptime(db_end_time, "%Y:%m:%dT%H:%M")
        # print("end_time_obj ",end_time_obj)
        if start_time_obj <= current_datetime_obj <= end_time_obj:
            # refresh zoom meeting host link
            if session.get("meeting_details"):
                # refresh the start_url
                # create zoom object to perform various zoom operations
                zoom_app = Zoom(jwt_api_key=session["zoom_account"]["api_key"],
                                jwt_secret_key=session["zoom_account"]["secret_key"],
                                zoom_email=session["zoom_account"]["email"])
                zoom_jwt_token = zoom_app.generate_jwt_token()

                meeting_detail_response = zoom_app.get_particular_meeting(
                    jwt_token=zoom_jwt_token,
                    meetingId=session["meeting_details"]["meeting_id"])

                if meeting_detail_response.status_code == 200:
                    meeting_detail_response = json.loads(meeting_detail_response.content)
                    session["url"] = meeting_detail_response["start_url"]
            if session["frequency"] == "daily" and current_datetime_obj < end_time_obj:
                if not first_upcomming_live_session["url"]:
                    first_upcomming_live_session["url"] = session["url"]
                    if session.get("meeting_details"):
                        first_upcomming_live_session["meeting_details"] = session["meeting_details"]

            if session["frequency"] == "weekly":
                status = False
                start_date = datetime.date(session["start_date"]["year"], session["start_date"]["month"],
                                           session["start_date"]["day"])
                end_date = datetime.date(session["end_date"]["year"], session["end_date"]["month"],
                                         session["end_date"]["day"])
                days = (end_date - start_date).days + 1
                weeks = int(days / 7) + 1
                valid_dates = [start_date + datetime.timedelta(days=7) * each_week for each_week in range(0,weeks)]

                if current_date in valid_dates and datetime.datetime.strptime(current_day_time, "%H:%M") < end_time:
                    status = True

                if status:
                    if not first_upcomming_live_session["url"]:
                        first_upcomming_live_session["url"] = session["url"]
                        if session.get("meeting_details"):
                            first_upcomming_live_session["meeting_details"] = session["meeting_details"]
        elif current_datetime_obj < start_time_obj:
            if not first_upcomming_live_session["url"]:
                # raise InvalidUsage("This live session would be available at " + str(start_time_obj), 400)
                raise InvalidUsage("Live session would be active 10 minutes before start time", 400)
        # elif end_time_obj < current_datetime_obj:
        #     if not first_upcomming_live_session["url"]:
        #         raise InvalidUsage("No more live sessions are scheduled", 400)

    # content details
    if not first_upcomming_live_session["url"]:
        raise InvalidUsage("There are no live sessions today to link with sessions", 400)
    session_query = mongo_session.get_all_data_for_particular_condition_fields(
        collection='course_sessions',
        condition={"_id": ObjectId(session_id)})
    if session_query["status"] != 200:
        raise Exception("Some internal server error, Please try again later.")
    session_data = session_query["message"][0]
    url = session_data["url"]
    if session_data["key"] == "live_session":
        if is_live and url:
            # This session has already been used once so erase questions, submissions and comments for previous session
            url = first_upcomming_live_session["url"]
            update_info = {"activate": {"timestamp": timestamp,
                                        "activated_by": ObjectId(user_id)},
                           "status": "active",
                           "url": url,
                           "comments": []}
            # add session id and topic id in meeting details collection in database
            if first_upcomming_live_session.get("meeting_details"):
                db_meeting_details = mongo_session.check_existance_return_info(
                    collection="zoom_meetings",
                    condition={"meeting_id": first_upcomming_live_session["meeting_details"]["meeting_id"]},
                    whole_doc=True)
                if not db_meeting_details:
                    raise InvalidUsage("Oops! WE don't have any meeting for live session in our records for now.", 404)
                db_occurrences = db_meeting_details["occurrences"]
                index = 0
                occurrence_id = ""
                for meet in db_occurrences:
                    if meet.get("uuid"):
                        if meet.get("session_id") and meet["session_id"] == ObjectId(session_id):
                            occurrence_id = meet["occurrence_id"]
                            break
                        index = index + 1
                    else:
                        occurrence_id = meet["occurrence_id"]
                        meet["course_id"] = ObjectId(course_id)
                        meet["session_id"] = ObjectId(session_id)
                        meet["topic_id"] = ObjectId(topic_id)
                        break
                update_info["occurrence_id"] = occurrence_id
                update_info["meeting_id"] = first_upcomming_live_session["meeting_details"]["meeting_id"]
                mongo_session.update_db_data(collection="zoom_meetings",
                                             condition=first_upcomming_live_session["meeting_details"],
                                             update_info={"$set": {"course_id": ObjectId(course_id),
                                                                   "occurrences": db_meeting_details["occurrences"]}})

            response = url
            message = "Live session is active now."
            delete_session_rel_data = True
        if is_live and not url:
            url = first_upcomming_live_session["url"]
            update_info = {"activate": {"timestamp": timestamp,
                                        "activated_by": ObjectId(user_id)},
                           "status": "active",
                           "url": url}

            # add session id and topic id in meeting details collection in database
            if first_upcomming_live_session.get("meeting_details"):
                db_meeting_details = mongo_session.check_existance_return_info(
                    collection="zoom_meetings",
                    condition={"meeting_id": first_upcomming_live_session["meeting_details"]["meeting_id"]},
                    whole_doc=True)
                if not db_meeting_details:
                    raise InvalidUsage("Oops! WE don't have any meeting for live session in our records for now.", 404)
                db_occurrences = db_meeting_details["occurrences"]
                index = 0
                occurrence_id = ""
                for meet in db_occurrences:
                    if meet.get("uuid"):
                        index = index + 1
                    else:
                        occurrence_id = meet["occurrence_id"]
                        meet["course_id"] = ObjectId(course_id)
                        meet["session_id"] = ObjectId(session_id)
                        meet["topic_id"] = ObjectId(topic_id)
                        break
                update_info["occurrence_id"] = occurrence_id
                update_info["meeting_id"] = first_upcomming_live_session["meeting_details"]["meeting_id"]
                mongo_session.update_db_data(collection="zoom_meetings",
                                             condition=first_upcomming_live_session["meeting_details"],
                                             update_info={"$set": {"course_id": ObjectId(course_id),
                                                                   "occurrences": db_meeting_details["occurrences"]}})
            response = url
            message = "Live session is active now."
        if not is_live:
            update_info = {"deactivate": {"timestamp": timestamp,
                                          "deactivated_by": ObjectId(user_id)},
                           "status": "inactive"}
            message = "Live session is over now. Thanks for conducting a live session."
        update_session = mongo_session.update_record_into_db(
            collection="course_sessions",
            condition={"_id": ObjectId(session_id)},
            update_info={"$set": update_info})

        if update_session["status"] != 200:
            raise Exception("Some internal error, Please try again later.")
        if delete_session_rel_data:
            # delete questions related to session
            del_questions = mongo_session.delete_records(collection="question_bank",
                                                         condition={"course_id": ObjectId(course_id),
                                                                    "course_session_id": ObjectId(session_id)})
            # delete submissions
            del_submissions = mongo_session.delete_records(collection="assessments_result",
                                                           condition={"course_id": ObjectId(course_id),
                                                                      "course_session_id": ObjectId(session_id)})
    return {"url": response, "message": message}


def add_notes_summary(user_id, session_id, title, content, role, note_type, resources):
    """1. If note_type is note then add a note in the session and if note_type is summary then add summary on same
    session.
    2. Collection: course_sessions_notes will contain both notes and summary can be differentiate using type.
    3. Based on the session id fetch course_id and topic_id. Check whether the course is active or not and whether user
    is entitled to add note or not."""

    if not validate_ObjectId(session_id):
        raise InvalidUsage("Bad Request.", 400)
    topic_id = mongo_session.check_existance_return_info(collection="course_topics",
                                                         condition={"sessions._id": ObjectId(session_id)},
                                                         )
    course_id = mongo_session.check_existance_return_info(collection="courses_bank",
                                                          condition={"topics._id": topic_id, "active": True},
                                                          )
    # check whether session exists or not
    if not (course_id and topic_id and session_id):
        raise InvalidUsage("Bad Request.", 400)

    check_existence = mongo_session.check_existance_return_info(collection="course_sessions",
                                                                condition={"_id": ObjectId(session_id)})
    if not check_existence:
        raise InvalidUsage("Bad Request.", 400)
    # process_content
    content = misc.replace_s3_links_with_keys(content)
    # current datetime
    utc_dtime = time_conversions.utc_datetime_now()
    if note_type == "note":
        data_to_insert = {"title": title.strip(),
                          "course_id": course_id,
                          "topic_id": topic_id,
                          "session_id": ObjectId(session_id),
                          "user_id": ObjectId(user_id),
                          "type": "note",
                          "created_at": utc_dtime,
                          "content": content,
                          "active": True,
                          "resources": resources if resources else []}
        message = "It's a good practice to make notes"
    elif note_type == "summary":
        # check if student has already made summary on this session
        note_condition = {"session_id": ObjectId(session_id),
                          "user_id": ObjectId(user_id),
                          "type": "summary"}
        check_summary_exist = mongo_session.check_existance_return_info(collection="course_sessions_notes",
                                                                        condition=note_condition)
        if check_summary_exist:
            raise InvalidUsage("Summary already exist, try to edit it.", 400)

        data_to_insert = {"course_id": course_id,
                          "topic_id": topic_id,
                          "session_id": ObjectId(session_id),
                          "user_id": ObjectId(user_id),
                          "type": "summary",
                          "created_at": utc_dtime,
                          "content": content}

        message = "It's a good practice to summarize your lectures"
    else:
        raise InvalidUsage("Please pass correct type. Available values are 'note' and 'summary'", 400)
    insert_note = mongo_session.insert_documnet(collection='course_sessions_notes',
                                                doc_to_insert=data_to_insert)
    return str(insert_note['_id'].inserted_id), message


def edit_notes_summary(course_id, user_id, session_id, topic_id, title, content, role, note_type, _id,
                       resources):
    """if note_type is note then edit a note in the session and if note_type is summary then edit summary on same
    session. """
    if not (course_id and topic_id and session_id):
        raise InvalidUsage("Bad Request.", 400)
    if not validate_ObjectId(_id):
        raise InvalidUsage("Bad Request.", 400)
    check_existence = mongo_session.access_specific_fields(collection="course_sessions_notes",
                                                           condition={"_id": ObjectId(_id),
                                                                      "course_id": ObjectId(course_id),
                                                                      "topic_id": ObjectId(topic_id),
                                                                      "session_id": ObjectId(session_id),
                                                                      "type": note_type},
                                                           columns={"user_id": 1, "_id": 1},
                                                           return_keys=["user_id", "_id"])
    if not check_existence:
        raise InvalidUsage("Bad Request", 400)
    # to validate user
    db_user = [record["user_id"] for record in check_existence if str(record["_id"]) == _id]
    if not db_user or str(db_user[0]) != user_id:
        raise InvalidUsage("Unauthorised Access", 401)
    # process_content
    content = misc.replace_s3_links_with_keys(content)
    # current datetime
    utc_dtime = time_conversions.utc_datetime_now()
    if note_type == "note":
        update_info = {"$set": {"created_at": utc_dtime,
                                "content": content,
                                "title": title,
                                "resources": resources if resources else []}}
        message = "Note updated."
    elif note_type == "summary":
        update_info = {"$set": {"created_at": utc_dtime,
                                "content": content}}
        message = "Summary updated."
    else:
        raise InvalidUsage("Please pass correct type. Available values are 'note' and 'summary'", 400)
    update_session = mongo_session.update_record_into_db(
        collection="course_sessions_notes",
        condition={"_id": ObjectId(_id),
                   "type": note_type,
                   "session_id": ObjectId(session_id)},
        update_info=update_info)
    if update_session["status"] != 200:
        raise Exception("Some internal error occurred, Please try again later.")
    return message


def delete_notes_summary(user_id, session_id, note_type, _id):
    """Purpose: soft delete a note and delete summary on session.
       Parameters:
           1. user_id : only the user who created can delete it.
           2. session_id: course session id
           3. note_type: summary/note
           4. _id: note_id/summary_id
    """
    if not validate_ObjectId(_id):
        raise InvalidUsage("Bad Request.", 400)
    topic_id = mongo_session.check_existance_return_info(collection="course_topics",
                                                         condition={"sessions._id": ObjectId(session_id)},
                                                         )
    course_id = mongo_session.check_existance_return_info(collection="courses_bank",
                                                          condition={"topics._id": topic_id, "active": True},
                                                          )
    # check whether session exists or not
    if not (course_id and topic_id and session_id):
        raise InvalidUsage("Bad Request.", 400)

    check_existence = mongo_session.check_existance_return_info(collection="course_sessions",
                                                                condition={"_id": ObjectId(session_id)})
    if not check_existence:
        raise InvalidUsage("Bad Request.", 400)

    if note_type == "note":
        # check if note exist
        condition = {"_id": ObjectId(_id),
                     "type": "note"}

        note_obj = mongo_session.check_existance_return_info(collection="course_sessions_notes",
                                                             condition=condition,
                                                             columns={"user_id": 1, "_id": 1},
                                                             return_keys=["user_id", "_id"])
        if not note_obj:
            raise InvalidUsage("Bad Request", 400)
        # to validate user
        if str(note_obj["user_id"]) != user_id:
            raise InvalidUsage("Unauthorised Access", 401)
        update_record = mongo_session.update_record_into_db(
            collection="course_sessions_notes",
            condition=condition,
            update_info={"$set": {"active": False}})
    else:
        raise InvalidUsage("Please pass correct type. Available value is 'note'", 400)
    return "Note has been deleted"


def get_notes_for_session(condition, role, organisation):
    """
    This function fetches all the notes from the db according to the condition passed and
    returns them. If no notes are present, returns an empty list.
    :param role: role of the current user
    :param condition: condition passed by the user
    :return: notes according to the condition passed
    """
    response = []
    view_rights = ['student', 'teacher', 'super_admin']
    if role not in view_rights:
        raise InvalidUsage("You are not authorized to view notes of students", 403)

    course_info = mongo_session.check_existance_return_info(collection='courses_bank',
                                                            condition={"_id": condition['course_id']},
                                                            return_keys=['topics', 'organisations', 'subscribers',
                                                                         'is_public'])
    if not course_info:
        raise InvalidUsage('Please check the request data', 400)

    users_list = [user["user_id"] for user in course_info["subscribers"]]
    organisations = [org['_id'] for org in course_info['organisations']]
    # if course is not public then only allowed organisation's subscribers should be visible
    if course_info["is_public"]:
        user_condition = {"_id": {"$in": users_list}, "role": "student"}
    else:
        user_condition = {"$and": [{"_id": {"$in": users_list}}, {"organisation_id": {"$in": organisations}}],
                          "role": "student"}

    user_query = mongo_session.access_specific_fields(
        collection='user_profile',
        condition=user_condition,
        columns={"username": 1,
                 "organisation": 1,
                 "role": 1,
                 "profile_pic": 1,
                 "name": 1,
                 "last_name": 1,
                 "email": 1},
        return_keys=["username", "organisation", "role", "_id", "profile_pic",
                     "name", "last_name", "email"])

    if not user_query:
        raise InvalidUsage("No one has subscribe this course yet", 200)

    user_dict = {}
    for user in user_query:
        user["_id"] = str(user["_id"])
        # user["profile_pic"] = get_profile_pic(s3_key=user["profile_pic"])
        user_dict[str(user["_id"])] = user

    users_list = [ObjectId(user_id) for user_id in user_dict.keys()]
    if role == 'teacher' or role == 'super_admin':
        condition['user_id'] = {"$in": users_list}
    # print(condition)
    notes_query = mongo_session.access_specific_fields(
        collection='course_sessions_notes',
        condition=condition,
        columns={"_id": 1,
                 "title": 1,
                 "content": 1,
                 "user_id": 1,
                 "topic_id": 1
                 },
        return_keys=["_id", "title", "content", "user_id", "topic_id"])

    if notes_query:
        notes_each_user = {}
        # accumulates all the notes written by a particular user and does that for
        # all users
        for notes in notes_query:
            if str(notes['user_id']) in user_dict.keys():
                note_id = str(notes['user_id'])
                notes['content'] = [renew_s3_links(notes['content'])]
                if note_id in notes_each_user:
                    notes_each_user[note_id].append({"_id": str(notes['_id']),
                                                     "title": notes['title'],
                                                     "content": notes['content']})
                else:
                    notes_each_user[note_id] = [{"_id": str(notes['_id']),
                                                 "title": notes['title'],
                                                 "content": notes['content']}]

        for each_user in notes_each_user:
            # fetches information of each user and notes for that user are put in the user_notes response
            user_info = user_dict[each_user]
            if user_info:
                user_notes = {"_id": each_user,
                              "username": user_info['username'],
                              "first_name": user_info['name'],
                              "last_name": user_info['last_name'],
                              "organisation": user_info['organisation'],
                              "role": user_info['role'],
                              "notes": notes_each_user[each_user],
                              "email": user_info['email']
                              }
                response.append(user_notes)
    return response


def get_course_sessions(user_id, course_id, role):
    """To fetch all the sessions present on the course.
    :param user_id: user accessing the sessions info.
    :type user_id: str(mongo id).
    :param course_id: course on which sessions info required.
    :type course_id: str(mongo id)."""
    course_info = mongo_session.check_existance_return_info(collection="courses_bank",
                                                            condition={"_id": ObjectId(course_id)},
                                                            columns={"topics": 1,
                                                                     "active": 1},
                                                            return_keys=["topics", "active"])
    if not course_info:
        raise InvalidUsage("Something went wrong while fetching course data", 400)

    # check if course is active or not.
    if role != "super_admin":
        if not course_info["active"]:
            raise InvalidUsage("Course is not active now.", 400)

    response_data = []

    # process topics
    topics = [topic["_id"] for topic in course_info["topics"]]
    topics_info = mongo_session.get_particular_key_value(
        collection="course_topics",
        condition={"$match": {"_id": {"$in": topics}}},
        return_info={"$project": {"_id": "$_id",
                                  "sessions": "$sessions"}},
        all_docs=True)
    topic_dict = {}
    sessions_list = []
    for topic in topics_info:
        sessions = [session["_id"] for session in topic["sessions"]]
        topic_dict[str(topic["_id"])] = sessions
        sessions_list.extend(sessions)

    sessions_data = mongo_session.get_particular_key_value(
        collection="course_sessions",
        condition={"$match": {"_id": {"$in": sessions_list}}},
        return_info={"$project": {"_id": "$_id",
                                  "title": "$title",
                                  "description": "$description",
                                  "live_session": "$key",
                                  "date_time": "$activate"
                                  }},
        all_docs=True)
    for session in sessions_data:
        session["live_session"] = True if session["live_session"] == "live_session" else False
        session["date_time"] = session["date_time"].get("timestamp", "") if session.get("date_time") else ""
        # topic_id
        for topic, topic_sessions in topic_dict.items():
            if session["_id"] in topic_sessions:
                session["topic_id"] = topic
        session["_id"] = str(session["_id"])
    return sessions_data


def fuzzy_match_participants(course_id, session_id, user_id, role, file_id=None, file_path=None):
    """
    To fuzzy match the participants from given file or list of live attendance provided by zoom
    to the course subscribers using The Levenshtein Distance.
    :param course_id: course to which the session belong.
    :type course_id: str (object id)
    :param session_id: session on which the attendance sheet is being uploaded.
    :type session_id: str (object id)
    :param file_id: attendance sheet to use for matching.
    :type file_id: str (object id)
    :param file_path: s3 path for the file
    :type file_path: str
    :param user_id: user requesting fuzzy match
    :type user_id: str (object id)
    :param role: slug for user role
    :type role: str
    :return: Subscribers info along with the matched user generated by fuzzy matching.
             match with highest score should be on top.
    """
    if file_id and file_path:
        # validate only .csv files are allowed
        if file_path.split(".")[-1] != "csv":
            raise InvalidUsage("Attendance sheet should be of .csv format only.", 400)

        # read file from s3 using file_path
        try:
            attendance_sheet = s3_connection.get_object(Bucket=bucket, Key=file_path)
            # reading file using pandas and replacing NaN values with empty string
            df = pd.read_csv(attendance_sheet['Body']).fillna("")

            # users who joined meeting more than once add up all the minutes to get the sum duration
            df = df.groupby(['Name (Original Name)'])['Duration (Minutes)'].sum().reset_index()
            zoom_participants = df['Name (Original Name)'].to_list()

        except Exception:
            raise InvalidUsage("Oops! something went wrong, Please upload the attendance sheet again.", 400)

        # validate sheet is not empty
        if not zoom_participants:
            raise InvalidUsage("Oops! Empty attendance sheet,"
                               "Please upload the attendance sheet again.", 409)
    else:
        participants_information = mongo_session.check_existance_return_info(
            collection="course_sessions",
            condition={"_id": ObjectId(session_id)},
            columns={"meeting_id": 1,
                     "occurrence_id": 1},
            return_keys=["_id", "meeting_id", "occurrence_id"])
        if not participants_information.get("meeting_id"):
            raise InvalidUsage("Live Attendance is not avaialble on this session, "
                               "Please upload the attendance sheet to mark attendance.", 400)

        # get uuid from zoom meetings
        session_uuid = mongo_session.check_existance_return_info(
            collection="zoom_meetings",
            condition={"meeting_id": int(participants_information["meeting_id"]),
                       "occurrences.occurrence_id": participants_information["occurrence_id"]},
            columns={"occurrences.$": 1},
            whole_doc=True)
        if not session_uuid or not session_uuid["occurrences"][0].get("uuid"):
            raise InvalidUsage("Live Attendance is not avaialble on this session, "
                               "Please upload the attendance sheet to mark attendance.", 400)

        # fetch attendance from participants collection
        live_participants = mongo_session.check_existance_return_info(
            collection="zoom_participants",
            condition={"meeting_id": int(participants_information["meeting_id"]),
                       "uuid": session_uuid["occurrences"][0]["uuid"]},
            return_keys=["participants", "uuid"])
        if not live_participants and not live_participants["participants"]:
            raise InvalidUsage("Live Attendance is not avaialble on this session, "
                               "Please upload the attendance sheet to mark attendance.", 400)
        zoom_participants = [user["user_name"] for user in live_participants["participants"]]
    # filter out subscribers
    course_info = mongo_session.check_existance_return_info(
        collection="courses_bank",
        condition={"_id": ObjectId(course_id), "subscribers": {"$exists": True}},
        columns={"subscribers": 1,
                 "organisations": 1,
                 "is_public": 1,
                 "editors": 1,
                 "instructors": 1,
                 "created_by": 1,
                 "teach_assis": 1},
        return_keys=["subscribers",
                     "_id",
                     "organisations",
                     "is_public",
                     "editors",
                     "instructors",
                     "created_by",
                     "teach_assis"])
    if not course_info:
        raise InvalidUsage("No one has subscribe this course yet", 400)

    # validate the user has edit rights or is teaching assistants
    attendance_rights = [str(user['_id']) for user in course_info["editors"]] + \
                  [str(user['_id']) for user in course_info["instructors"]] + \
                  [str(course_info["created_by"])] + \
                  [str(user['_id']) for user in course_info["teach_assis"]]

    if role != "super_admin" and user_id not in attendance_rights:
        raise InvalidUsage("You are an authorised user to perform this action.", 403)

    if not course_info["subscribers"]:
        raise InvalidUsage("There are no subscribers yet on this course.", 400)

    users_list = [user["user_id"] for user in course_info["subscribers"]]

    org_list = [org["_id"] for org in course_info["organisations"]]

    user_condition = {"_id": {"$in": users_list}, "role": "student"}

    # if course is not public then only allowed organisation's subscribers should be visible
    if not course_info["is_public"]:
        user_condition = {"$and": [{"_id": {"$in": users_list}, "role": "student"},
                                   {"organisation_id": {"$in": org_list}}]}

    user_query = mongo_session.access_specific_fields(
        collection="user_profile",
        condition=user_condition,
        columns={"username": 1,
                 "organisation": 1,
                 "role": 1,
                 "profile_pic": 1},
        return_keys=["username", "organisation", "role", "_id", "profile_pic"])

    if not user_query:
        raise InvalidUsage("No one has subscribe this course yet", 400)

    user_query = sorted(user_query, key=lambda i: i['username'])
    for user in user_query:
        user["_id"] = str(user["_id"])
        user["profile_pic"] = get_profile_pic(s3_key=user["profile_pic"])
        # fuzzy match users list and zoom participants based on The Levenshtein Distance
        # do simple pre-processing before calculating distance i.e. lower the strings
        fuzzy_response = process.extractOne(user["username"].lower(), zoom_participants)
        user["matched_user"] = fuzzy_response[0]
        user["matched_score"] = fuzzy_response[1]
        # df_index = df.index[df["Name (Original Name)"] == fuzzy_response[0]].to_list()
        # user["duration"] = str(df["Duration (Minutes)"][df_index[0]]) if df_index else 0

    # add information in sessions collection
    update_session = mongo_session.update_db_data(collection="course_sessions",
                                                  condition={"_id": ObjectId(session_id)},
                                                  update_info={"$set": {"participants": {"sheet": file_path,
                                                                                         "created_at": utc_datetime_now()}}})
    # delete data from temp collection
    delete_data = mongo_session.delete_records(collection="temp_uploaded_files",
                                               condition={"_id": ObjectId(file_id)})
    return {"message": "Data Retrieved successfully for attendance.",
            "response": {"subscribers_info": user_query,
                         "zoom_participants": zoom_participants}}


def save_attendance_by_teacher(course_id, session_id, participants, user_id, role):
    """
    To save attendance of course subscribers(only students for now), marked by teachers.
    ** Data in request payload should include only active users that attended the lecture according to teacher.
    :param course_id: course to which the session belong.
    :type course_id: str (object id)
    :param session_id: session on which the attendance is being marked.
    :type session_id: str (object id)
    :param participants: active participants information who is marked present by teacher.
    :type participants: list
    :param user_id: user marking attendance
    :type user_id: str (object id)
    :param role: slug for user role
    :type role: str
    """
    # filter out subscribers and check user marking attendance has publish rights
    course_info = mongo_session.check_existance_return_info(
        collection="courses_bank",
        condition={"_id": ObjectId(course_id), "subscribers": {"$exists": True}},
        columns={"editors": 1,
                 "instructors": 1,
                 "created_by": 1,
                 "teach_assis": 1},
        return_keys=["_id",
                     "editors",
                     "instructors",
                     "created_by",
                     "teach_assis"])
    if not course_info:
        raise InvalidUsage("Oops! something went wrong, Please try again later.", 500)

    # validate the user has edit rights or is teaching assistants
    attendance_rights = [str(user['_id']) for user in course_info["editors"]] + \
                        [str(user['_id']) for user in course_info["instructors"]] + \
                        [str(course_info["created_by"])] + \
                        [str(user['_id']) for user in course_info["teach_assis"]]

    if role != "super_admin" and user_id not in attendance_rights:
        raise InvalidUsage("You are an authorised user to perform this action.", 403)
    users_list = [ObjectId(user["_id"]) for user in participants]
    # check whether all participants are educollab users or not
    result = mongo_session.fetch_all_records(collection="user_profile",
                                                    condition={"_id": {"$in": users_list}},
                                                    columns={"_id": 1})
    if not result:
        InvalidUsage("Students should be Edu-Collab users only, Please try again later.", 400)

    existing_users = []
    for user in result:
        existing_users.append(user["_id"])
    if not existing_users:
        raise InvalidUsage("Please select users who are a part of Eu-Collab.", 400)
    missing_ids = list(set(users_list) - set(existing_users))

    # add only actual participants those who attended the lectures and are edu-collab users
    # add information in sessions collection
    existing_users = list(set(existing_users))
    processed_participants = []
    for user in participants:
        user["_id"] = ObjectId(user["_id"])
        if user["_id"] in existing_users:
            processed_participants.append(user)
    update_session = mongo_session.update_db_data(
        collection="course_sessions",
        condition={"_id": ObjectId(session_id)},
        update_info={"$set": {"participants.content": processed_participants}})
    return {"message": "Attendance Marked."}


def get_session_attendance(course_id, session_id, user_id, role):
    """
    To view attendance of course subscribers(only students for now), marked by teachers on sessions.
    :param course_id: course to which the session belong.
    :type course_id: str (object id)
    :param session_id: session on which the attendance is being marked.
    :type session_id: str (object id)
    :param user_id: user accessing attendance
    :type user_id: str (object id)
    :param role: slug for user role
    :type role: str
    """
    # represents if current session have live attendance from zoom.
    live_attendance = False

    # filter out subscribers
    course_info = mongo_session.check_existance_return_info(
        collection="courses_bank",
        condition={"_id": ObjectId(course_id), "subscribers": {"$exists": True}},
        columns={"subscribers": 1,
                 "organisations": 1,
                 "is_public": 1,
                 "editors": 1,
                 "instructors": 1,
                 "created_by": 1,
                 "teach_assis": 1},
        return_keys=["subscribers",
                     "_id",
                     "organisations",
                     "is_public",
                     "editors",
                     "instructors",
                     "created_by",
                     "teach_assis"])
    if not course_info:
        raise InvalidUsage("No one has subscribe this course yet", 400)

    # validate the user has edit rights or is teaching assistants
    attendance_rights = [str(user['_id']) for user in course_info["editors"]] + \
                        [str(user['_id']) for user in course_info["instructors"]] + \
                        [str(course_info["created_by"])] + \
                        [str(user['_id']) for user in course_info["teach_assis"]]

    if role != "super_admin" and user_id not in attendance_rights:
        raise InvalidUsage("You are an authorised user to perform this action.", 403)

    if not course_info["subscribers"]:
        raise InvalidUsage("There are no subscribers yet on this course.", 400)

    users_list = [user["user_id"] for user in course_info["subscribers"]]

    org_list = [org["_id"] for org in course_info["organisations"]]

    user_condition = {"_id": {"$in": users_list}, "role": "student"}

    # if course is not public then only allowed organisation's subscribers should be visible
    if not course_info["is_public"]:
        user_condition = {"$and": [{"_id": {"$in": users_list}, "role": "student"},
                                   {"organisation_id": {"$in": org_list}}]}

    user_query = mongo_session.access_specific_fields(
        collection="user_profile",
        condition=user_condition,
        columns={"username": 1,
                 "organisation": 1,
                 "role": 1,
                 "profile_pic": 1},
        return_keys=["username", "organisation", "role", "_id", "profile_pic"])

    if not user_query:
        raise InvalidUsage("No one has subscribe this course yet", 400)

    user_query = sorted(user_query, key=lambda i: i['username'])

    participants_information = mongo_session.check_existance_return_info(
        collection="course_sessions",
        condition={"_id": ObjectId(session_id)},
        columns={"participants": 1,
                 "meeting_id": 1,
                 "occurrence_id": 1},
        return_keys=["_id", "participants", "meeting_id", "occurrence_id"])

    if not participants_information:
        raise InvalidUsage("Internal Server Error.", 400)

    # fetch live attendance details
    if participants_information.get("meeting_id"):
        # get uuid from zoom meetings
        session_uuid = mongo_session.check_existance_return_info(
            collection="zoom_meetings",
            condition={"meeting_id": int(participants_information["meeting_id"]),
                       "occurrences.occurrence_id": participants_information["occurrence_id"]},
            columns={"occurrences.$": 1},
            whole_doc=True)
        if session_uuid and session_uuid["occurrences"][0].get("uuid"):
            # fetch attendance from participants collection
            live_participants = mongo_session.check_existance_return_info(
                collection="zoom_participants",
                condition={"meeting_id": int(participants_information["meeting_id"]),
                           "uuid": session_uuid["occurrences"][0]["uuid"]},
                return_keys=["participants", "uuid"])
            if live_participants and live_participants["participants"]:
                live_attendance = True

    if not participants_information["participants"] or not participants_information["participants"].get("content"):
        return {"message": "Attendance hasn't been marked yet.",
                "response":  {"attendance": [],
                              "live_attendance": live_attendance}}

    participants = [user["_id"] for user in participants_information["participants"]["content"]]

    for user in user_query:
        user["attended"] = True if user["_id"] in participants else False
        user["_id"] = str(user["_id"])
        user["profile_pic"] = get_profile_pic(s3_key=user["profile_pic"])
    return {"message": "Attendance fetched successfully.",
            "response": {"attendance": user_query,
                         "live_attendance": live_attendance}}


def get_course_topics(user_id, course_id, role):
    """To fetch all the topics present on the course.
    :param user_id: user accessing the topics info.
    :type user_id: str(mongo id).
    :param course_id: course on which topics and sessions info required.
    :type course_id: str(mongo id)."""
    course_info = mongo_session.check_existance_return_info(collection="courses_bank",
                                                            condition={"_id": ObjectId(course_id)},
                                                            columns={"topics": 1,
                                                                     "active": 1},
                                                            return_keys=["topics", "active"])
    if not course_info:
        raise InvalidUsage("Bad Request", 400)

    # check if course is active or not.
    if role != "super_admin":
        if not course_info["active"]:
            raise InvalidUsage("Course is not active now.", 400)

    # process topics
    topics = [topic["_id"] for topic in course_info["topics"]]
    topics_info = mongo_session.get_particular_key_value(
        collection="course_topics",
        condition={"$match": {"_id": {"$in": topics}}},
        return_info={"$project": {"_id": "$_id",
                                  "sessions": "$sessions",
                                  "title": "$title"}},
        all_docs=True)
    topics = []
    sessions_list = []
    for topic in topics_info:
        sessions = [session["_id"] for session in topic["sessions"]]
        topics.append({"topic_id": str(topic["_id"]),
                       "topic_title": topic["title"],
                       "sessions": sessions})
        sessions_list.extend(sessions)

    sessions_data = mongo_session.get_particular_key_value(
        collection="course_sessions",
        condition={"$match": {"_id": {"$in": sessions_list}}},
        return_info={"$project": {"_id": "$_id",
                                  "title": "$title",
                                  "description": "$description",
                                  "live_session": "$key",
                                  "date_time": "$activate"
                                  }},
        all_docs=True)

    session_dict = {}
    for session in sessions_data:
        session["live_session"] = True if session["live_session"] == "live_session" else False
        session["date_time"] = session["date_time"].get("timestamp", "") if session.get("date_time") else ""
        session["_id"] = str(session["_id"])
        session_dict[str(session["_id"])] = session
    for topic in topics:
        topic["sessions"] = [session_dict[str(sess)] for sess in topic["sessions"] if session_dict.get(str(sess))]
    return topics
