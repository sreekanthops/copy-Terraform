from __future__ import absolute_import
import time
import traceback
import config
import pandas as pd
from email import encoders, message
from email.mime.base import MIMEBase
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from model import Question as q
from model import Content
import bcrypt
from mongo_connection import connection
from bson import ObjectId
import requests
import secrets
import string
import smtplib, ssl
from flask import request, Response, json, Blueprint, jsonify
from datetime import datetime, timedelta
import config
import jwt
import requests
from bson import ObjectId
from model import Question
import model.course as course_utils
from cryptography.fernet import Fernet
import re
from flask import render_template
#from db_wrapper import chat_db
import traceback
from config import email_Address, email_password, secret_key, password_secret_key, session_token_secret_key, \
    secret_otp_key
import math
import random
from db_wrapper.tasks import Mongo
from routes.course_apis import subscribe_course, subscribers
mongo_session = Mongo()
import ast

from routes.exception import InvalidUsage
from utils.misc import is_empty
from services.storage.s3_services import s3_storage

s3_function = s3_storage()

count = 0
from utils.time_conversions import utc_datetime_now, convert_utc_to_ist
import ast


def public_profile(user_id, application_type=None):
    """return the user_profile"""
    user_detail = {}
    user_query = mongo_session.get_all_data_for_particular_condition_fields(collection="user_profile",condition={"_id": ObjectId(user_id)})['message']
    if user_query != []:
        user_data = user_query[0]
        s3_url, status_code = s3_function.generate_presigned_url_from_s3(user_data.get('profile_pic'))
        user_detail['username'] = user_data['username']
        
        user_detail = {
                            'username': user_data['username'],
                            'first_name': user_data['name'],
                            'last_name': user_data['last_name'],
                            'email': user_data['email'],
                            'organisation': user_data['organisation'],
                            'role': user_data['role'],
                            'mobile': user_data['mobile'],
                            'avatar_url': s3_url,
                            'avatar_path': user_data['profile_pic'],
                        }
        keys = ["about", "facebook_url", "linkedin_url"]
        for dict_key in keys:
            if dict_key in user_data.keys():
                user_detail[dict_key] = user_data[dict_key]
            else:
                user_detail[dict_key] = ""

        #instagram
        if user_data.get('instagram'):
            user_detail['instagram'] = user_data['instagram']
        else:
            user_detail['instagram'] = ""
        
        #twitter
        if user_data.get('twitter'):
            user_detail['twitter'] = user_data['twitter']
        else:
            user_detail['twitter'] = ""

        #student only details
        if user_data['role'] == "student":
            #subscribed_courses by student
            if user_data['subscribed_courses']:
                course_data = []
                for course in user_data['subscribed_courses']:
                    instructors = []
                    course_detail = mongo_session.get_data_for_particular_columns_with_condition(
                        collection="courses_bank",
                        condition={"_id": ObjectId(course['course_id'])},
                        columns={"instructors": 1,
                                    "banner_img": 1,
                                    "subject": 1,
                                    "learning_objectives": 1}
                    )["message"][0]
                    course_s3_url, course_status_code = s3_function.generate_presigned_url_from_s3(course_detail.get('banner_img'))
                    if course_status_code != 200:
                        raise Exception("Error occurred while communicating with s3")
                    for instructor in course_detail.get('instructors'):
                        instructor_detail = mongo_session.get_data_for_particular_columns_with_condition(
                                                                collection="user_profile",
                                                                condition={"_id": ObjectId(instructor['_id'])},
                                                                columns={"name": 1,
                                                                        "last_name": 1,
                                                                        "email": 1}
                                                            )["message"][0]
                        instructors.append({
                            "_id": str(instructor_detail.get('_id')),
                            "name": instructor_detail.get('name'),
                            "last_name": instructor_detail.get('last_name'),
                            "email": instructor_detail.get('email')
                        })
                    course_data.append({
                        "_id": str(course.get('course_id')),
                        "instructors": instructors,
                        "subject": course_detail.get('subject'),
                        "learning_objectives": course_detail.get('learning_objectives'),
                        "img_path": course_detail.get('banner_img'),
                        "img_url": course_s3_url
                    })
                user_detail['subscribed_courses']= course_data
            else:
                user_detail['subscribed_courses']= ""
            
            #student's education history
            if user_data.get('education_details'):
                user_detail['education']= user_data['education_details']
            else:
                user_detail['education']= []

            #user experience history
            if user_data.get('experience'):
                user_detail['experience']= user_data['experience']
            else:
                user_detail['experience']= []

            #total count of educollab coins availed by student
            if user_data['coin']:
                user_detail['avail_coin'] = float(round(user_data['coin'], 2))
            else:
                user_detail['avail_coin'] = 0
            
            #list of passion_projects which students are part of
            passion_projects = mongo_session.get_data_for_particular_columns_with_condition(collection="passion_project_teams",
                                                                            condition={"members": {"$in": [ObjectId(user_id)]}},
                                                                            columns={"projects":1})
            if passion_projects:
                passions = []                              
                for passion in passion_projects['message']:
                    for pass_proj in passion['projects']:
                        passion_project_details = mongo_session.get_data_for_particular_columns_with_condition(collection="passion_projects",
                                                                                                condition={"_id": ObjectId(str(pass_proj))},
                                                                                                columns={"project_title":1, "project_image":1, "project_description":1,
                                                                                                        "project_tags":1, "created_by":1, "project_mentors":1, "project_resources":1})['message'][0]
                        tags = []
                        all_question_tags = mongo_session.get_all_data("question_tags")
                        if all_question_tags["message"]:        
                            for tag in passion_project_details['project_tags']:
                                for t in all_question_tags["message"]:
                                    if str(tag) == str(t.get('_id')):
                                        tags.append({
                                            "_id": t['_id'],
                                            "tag": t['tag']
                                        })
                        passion_s3_url, passion_status_code = s3_function.generate_presigned_url_from_s3(passion_project_details.get('project_image'))
                        if passion_status_code != 200:
                            raise Exception("Error occurred while communicating with s3")
                        created_by = mongo_session.get_data_for_particular_columns_with_condition(
                                                                collection="user_profile",
                                                                condition={"_id": ObjectId(passion_project_details['created_by'])},
                                                                columns={"name": 1,
                                                                        "last_name": 1,
                                                                        "email": 1}
                                                            )["message"][0]
                        passion_doc = {
                            'project_title': passion_project_details['project_title'],
                            'project_image_path': passion_project_details['project_image'],
                            'project_image_url': passion_s3_url,
                            'project_description': passion_project_details['project_description'],
                            'project_tags': tags,
                            'created_by': created_by,
                            'project_mentors': [str(mentors) for mentors in passion_project_details['project_mentors']],
                            'project_resources': [str(resources) for resources in passion_project_details['project_resources']]
                        }
                        passions.append(passion_doc)
                user_detail['passion_project_details'] = passions
        # teacher
        if user_data['role'] == "teacher":
            total_subscribers = 0
            total_reviews = 0
            courses_query = mongo_session.get_data_for_particular_columns_with_condition(collection='courses_bank',
                condition={"status":"publish","instructors": {"$elemMatch": {"_id": ObjectId(user_id)}}},
                columns={'_id': 1, 'subject': 1, 'course_category': 1, "Rating": 1, "subscribers": 1, "learning_objectives": 1})['message']
            #print(courses_query)
            for query in courses_query:
                query["_id"] = str(query["_id"])
                query['instructor_first_name'] = user_detail['first_name']
                query['instructor_last_name'] = user_detail['last_name']
                if query.get('subscribers'):
                    total_subscribers += len(query.get('subscribers'))
                    query.pop('subscribers')
                if query.get("Rating"):
                    total_reviews += len(query.get("Rating"))
                    query.pop('Rating')
            
            #list of courses taught by teacher            
            if courses_query:
                course_data = []
                for course in courses_query:
                    #print(course)
                    instructors = []
                    course_detail = mongo_session.get_data_for_particular_columns_with_condition(
                        collection="courses_bank",
                        condition={"_id": ObjectId(course['_id'])},
                        columns={"instructors": 1,
                                    "banner_img": 1,
                                    "subject": 1}
                    )["message"][0]
                    course_s3_url, course_status_code = s3_function.generate_presigned_url_from_s3(course_detail.get('banner_img'))
                    if course_status_code != 200:
                        raise Exception("Error occurred while communicating with s3")
                    for instructor in course_detail.get('instructors'):
                        instructor_detail = mongo_session.get_data_for_particular_columns_with_condition(
                                                                collection="user_profile",
                                                                condition={"_id": ObjectId(instructor['_id'])},
                                                                columns={"name": 1,
                                                                        "last_name": 1,
                                                                        "email": 1}
                                                            )["message"][0]
                        instructors.append({
                            "_id": str(instructor_detail.get('_id')),
                            "name": instructor_detail.get('name'),
                            "last_name": instructor_detail.get('last_name'),
                            "email": instructor_detail.get('email')
                        })
                    course_data.append({
                        "_id": str(course.get('_id')),
                        "instructors": instructors,
                        "subject": course_detail.get('subject'),
                        "learning_objectives": course_detail.get('learning_objectives'),
                        "img_path": course_detail.get('banner_img'),
                        "img_url": course_s3_url
                    })
                user_detail['my_teaching_courses']= course_data
            else:
                user_detail['my_teaching_courses']= []
            
            #total number of students enrolled in the courses taught by teacher
            if total_subscribers > 0:
                user_detail['total_students_my_courses']= total_subscribers
            else:
                user_detail['total_students_my_courses']= 0
            
            #total number of reviews giving to all courses taught by teacher
            if total_reviews > 0:
                user_detail['total_reviews_count'] = total_reviews
            else:
                user_detail['total_reviews_count'] = 0
            
            #list of passion_projects which students are part of
            passion_projects = mongo_session.get_all_data_for_particular_condition_fields(collection="passion_projects",
                                                                            condition={"created_by": user_id})
            if passion_projects:
                passions = []                              
                for passion in passion_projects['message']:
                    tags = []
                    all_question_tags = mongo_session.get_all_data("question_tags")
                    if all_question_tags["message"]:        
                        for tag in passion['project_tags']:
                            for t in all_question_tags["message"]:
                                if str(tag) == str(t.get('_id')):
                                    tags.append({
                                        "_id": t['_id'],
                                        "tag": t['tag']
                                    })
                    passion_s3_url, passion_status_code = s3_function.generate_presigned_url_from_s3(passion.get('project_image'))
                    if passion_status_code != 200:
                        raise Exception("Error occurred while communicating with s3")
                    created_by = mongo_session.get_data_for_particular_columns_with_condition(
                                                                collection="user_profile",
                                                                condition={"_id": ObjectId(passion['created_by'])},
                                                                columns={"name": 1,
                                                                        "last_name": 1,
                                                                        "email": 1}
                                                            )["message"][0]                                                                                          
                    passion_doc = {
                        'project_title': passion['project_title'],
                        'project_image_path': passion['project_image'],
                        'project_image_url': passion_s3_url,
                        'project_description': passion['project_description'],
                        'project_tags': tags,
                        'created_by': created_by,
                        'project_mentors': [str(mentors) for mentors in passion['project_mentors']],
                        'project_resources': [str(resources) for resources in passion['project_resources']]
                    }
                    passions.append(passion_doc)
                user_detail['passion_project_details'] = passions
    else:
        user_detail = []
    return user_detail


def update_user_profile(user_id, name, mobile, username, profile_pic, fields_of_interest, about=None,
                        facebook=None, linkedin=None, instagram=None, twitter=None, user_type=None,
                        application_type=None):
    """edit the user profile fields"""
    collection = connection.user_profile
    user_query = {"_id": ObjectId(user_id)}
    update_data = {}
    if not is_empty(username):
        if collection.find_one({'username': username}):
            existing_user_id = list(collection.find({'username': username}, {"_id": 1}))
            if user_id == str(existing_user_id[0]['_id']):
                status, msg = username_restriction(username)
                if not status:
                    return msg, []
                update_data["username"] = username
            else:
                raise InvalidUsage(f"This username {username} already exist. Please use a different username", 400)
        else:
            status, msg = username_restriction(username)
            if not status:
                return msg, []
            update_data["username"] = username
    if not is_empty(name):
        if len(name) < 3 or len(name) > 100:
            raise InvalidUsage("Name should have at least 3 and max 99 characters.", 400)
        if not name.isalpha():
            raise InvalidUsage("Name should only contain alphabets.", 400)
        update_data["name"] = name
    if not is_empty(mobile):
        update_data["mobile"] = mobile
    if not is_empty(profile_pic):
        update_data["profile_pic"] = profile_pic
    if not is_empty(about):
        update_data["about"] = about
    if not is_empty(facebook):
        update_data["facebook_url"] = facebook
    if not is_empty(linkedin):
        update_data["linkedin_url"] = linkedin
    if not is_empty(linkedin):
        update_data["twitter_url"] = twitter
    if not is_empty(instagram):
        update_data["instagram_url"] = instagram
    if not is_empty(user_type):
        update_data["user_type"] = user_type

    update_data["fields_of_interest"] = fields_of_interest

    status = "Update Successfully"
    user_detail = []
    collection.update(user_query, {"$set": update_data})
    user_cursor = collection.find({'_id': ObjectId(user_id)})
    for data in user_cursor:
        if data:
            if application_type == "webapp":
                s3_url, status_code = s3_function.generate_presigned_url_from_s3(data['profile_pic'])
                response_dict = {'username': data['username'], 'first_name': data['name'], 'email': data['email'],
                                 'fields_of_interest': data['fields_of_interest'], 'mobile': data['mobile'],
                                 'avatar_url': s3_url, 'avatar_path': data['profile_pic'],
                                 'avail_coin': float(round(data['coin'], 2))}
                keys = ["about", "facebook_url", "linkedin_url", "instagram_url", "twitter_url", "user_type"]
                for dict_key in keys:
                    if dict_key in data.keys():
                        response_dict[dict_key] = data[dict_key]
                    else:
                        response_dict[dict_key] = ""
                return status, response_dict
            else:
                user_detail.append(
                    {'username': data['username'], 'first_name': data['name'], 'last_name': data['last_name'],
                     'Password': "xxxxxxxxx", 'email': data['email'], 'mobile': data['mobile'],
                     'fields_of_interest': data['fields_of_interest'], 'profile_pic': data['profile_pic'],
                     'avail_coin': float(round(data['coin'], 2))})
    return status, user_detail


def username_restriction(username):
    val = True
    msg = ""
    if len(username) < 3 or len(username) > 50:
        msg = 'Username length should be greater than 3.'
        val = False

    if any(char.isspace() for char in username):
        msg = 'Username should not contain white spaces.'
        val = False
    if not username.isalnum():
        msg = "Username should only contain alphanumeric values."
        val = False
    return val, msg


def update_user_education(user_id, education_details):
    """ This is the function to update user education  """

    collection = connection.user_profile
    collection.update({"_id": ObjectId(user_id)},
                      {"$set": {'education_details': education_details}}
                      )
    user_cursor = collection.find({'_id': ObjectId(user_id)})
    for data in user_cursor:
        if data:
            response_dict = {'education': data['education_details']}
    status = "Update Successfully"
    return status, response_dict


def update_user_experience(user_id, experience):
    """ This is the function to update user professional experience details  """

    collection = connection.user_profile
    collection.update({"_id": ObjectId(user_id)},
                      {"$set": {'experience': experience}}
                      )
    user_cursor = collection.find({'_id': ObjectId(user_id)})
    for data in user_cursor:
        if data:
            response_dict = {'experience': data['experience']}
    status = "Update Successfully"
    return status, response_dict


def update_password(email_address, new_password, confirm_password, old_password=None, saved_old_password=None):
    """This is the function to reset the password"""
    email_address = email_address.lower()
    email = mongo_session.get_email_forget_password_api(collection="user_profile", condition={"email": email_address},
                                                        columns={"email": 1})
    if email['status'] == 200 and len(email['message']):
        collection = connection.user_profile
        if old_password != None:
            decrypted_password = decryption_function(saved_old_password)
            if old_password == decrypted_password:
                if new_password != "":
                    status, msg = password_check(new_password)
                    if not status:
                        return msg, 400
                    else:
                        password = new_password
                        condition = {"email": email_address}
                        password = password.encode("utf-8")
                        encrypted_password = encryption_function(password)
                        update_value = {"$set": {'Password': encrypted_password}}
                        collection.update_one(condition, update_value)
                        status = "Password changed succesfully"
                        status_code = 200
                else:
                    msg = "Please enter new password"
                    return msg, 400
            else:
                status = "Old Password is not matched with saved password"
                status_code = 400
        else:
            if new_password == confirm_password:
                if new_password != "":
                    status, msg = password_check(new_password)
                    if not status:
                        return msg, 400
                password = new_password
                condition = {"email": email_address}
                password = password.encode("utf-8")
                encrypted_password = encryption_function(password)
                update_value = {"$set": {'Password': encrypted_password}}
                collection.update_one(condition, update_value)
                status = "Password changed succesfully"
                status_code = 200
            else:
                status = "Password is not matched with confirm password"
                status_code = 400
    else:
        status = "bad request"
        status_code = 400
    return status, status_code

def decryption_function(encrypted_password):
    """to decrypt the argument passed"""
    key = password_secret_key
    f = Fernet(key)
    decrypted_password = f.decrypt(encrypted_password)
    return decrypted_password.decode('utf-8')


def encryption_function(password):
    """to encrypt the  argument passed"""
    key = password_secret_key
    f = Fernet(key)
    encrypted_password = f.encrypt(password)
    return encrypted_password


def password_check(passwd):
    val = True
    msg = ""
    if len(passwd) < 8 or len(passwd) > 30 or passwd.isspace():
        if len(passwd) > 30:
            msg = "Password length should not be greater than 30"
        else:
            msg = "Password length should be greater than 8"
        val = False
    return val, msg


def submit_resume(user_id, resource_id, path):
    """This is the function to submit user resume"""
    resource_id = ObjectId(resource_id)
    temp_client = connection.temp_uploaded_files
    resume_dict = {}

    # check file resource in temporary upload files 
    temp_cursor = temp_client.find({"_id": resource_id})
    if not temp_cursor.count() > 0:
        return {"message": "File is not valid, Please check details.", "status": 400}

    resume_dict = {
        'resource_id' : resource_id,
        'path' : path,
        'updated_at' :utc_datetime_now()
    }
    
    response = mongo_session.update_field_based_on_user_id(collection="user_profile", id=user_id, field='resume', value=resume_dict)
    
    mongo_session.delete_record_temp_uploaded_files(
        collection=temp_client, id_list=[resource_id])

    if response['status'] == 200:
        return(response['message'])

    
def profile_settings(user_id, show_profile, show_username, show_organization, show_social_media, hrs_study_today,show_email, show_phone, 
                    show_courses):
    if show_profile:
        privacy_settings = {
            "show_profile" : show_profile,
            "show_username" : show_username,
            "show_organization" : show_organization,
            "show_social_media" : show_social_media,
            "hrs_study_today" : hrs_study_today,
            "show_email" : show_email,
            "show_phone" : show_phone,
            "show_courses" : show_courses
        }

    else:
        privacy_settings = {
            "show_profile" : False,
            "show_username" : False,
            "show_organization" : False,
            "show_social_media" : False,
            "hrs_study_today" : False,
            "show_email" : False,
            "show_phone" : False,
            "show_courses" : False
        }

    collection = connection.user_profile
    res = collection.update({"_id": ObjectId(user_id)},
                    {"$set": {'privacy_settings': privacy_settings}})

    if res['updatedExisting']:
        message = "Privacy settings updated successfully"
    else:
        raise Exception('Unable to update privacy settings')
        
    return message
        

def public_profile_new(user_id,check, application_type=None):
    """return the user_profile"""
    user_detail = {}
    user_query = mongo_session.get_all_data_for_particular_condition_fields(collection="user_profile",condition={"_id": ObjectId(user_id)})['message']
    if user_query != []:
        user_data = user_query[0]
        s3_url, status_code = s3_function.generate_presigned_url_from_s3(user_data.get('profile_pic'))

        #check user opening his/her profile
        if check == True:
            user_detail = user_public_profile(user_data=user_data, s3_url=s3_url,user_id=user_id)

        #check privacy setting key present
        elif user_data.get('privacy_settings'):
            if user_data['privacy_settings']['show_profile']:
                user_detail = {
                    'username': user_data['username'] if user_data['privacy_settings']['show_username'] else '*****',
                    'first_name': user_data['name'],
                    'last_name': user_data['last_name'],
                    'email': user_data['email'] if user_data['privacy_settings']['show_email'] else '*****',
                    'organisation': user_data['organisation'] if user_data['privacy_settings']['show_organization'] else '*****',
                    'role': user_data['role'],
                    'mobile': user_data['mobile'] if user_data['privacy_settings']['show_phone'] else '*****',
                    'avatar_url': s3_url,
                    'avatar_path': user_data['profile_pic'],
                }
                #about
                if user_data.get('about'):
                    user_detail['about'] = user_data['about']
                else:
                    user_detail['about'] = ''

                #facebook_url
                if user_data.get('facebook_url'):
                    if user_data['privacy_settings']['show_social_media']:
                        user_detail['facebook_url'] = user_data['facebook_url']
                    else:
                    
                        user_detail['facebook_url'] = '*************'
                else:
                    user_detail['facebook_url'] = ''

                #linkedin_url
                if user_data.get('linkedin_url'):
                    if user_data['privacy_settings']['show_social_media']:
                        user_detail['linkedin_url'] = user_data['linkedin_url']
                    else:
                        user_detail['linkedin_url'] = '*************'
                else:
                    user_detail['linkedin_url'] = ''

                #instagram
                if user_data.get('instagram'):
                    if user_data['privacy_settings']['show_social_media']:
                        user_detail['instagram'] = user_data['instagram']
                    else:
                        user_detail['instagram'] = '*************'
                else:
                    user_detail['instagram'] = ""
                
                #twitter
                if user_data.get('twitter'):
                    if user_data['privacy_settings']['show_social_media']:
                        user_detail['twitter'] = user_data['twitter']
                    else:
                        user_detail['twitter'] = '*************'
                else:
                    user_detail['twitter'] = ""

                #student only details
                if user_data['role'] == "student":
                #subscribed_courses by student
                    if user_data['subscribed_courses']:
                        course_data = []
                        for course in user_data['subscribed_courses']:
                            instructors = []
                            course_detail = mongo_session.get_data_for_particular_columns_with_condition(
                                collection="courses_bank",
                                condition={"_id": ObjectId(course['course_id'])},
                                columns={"instructors": 1,
                                            "banner_img": 1,
                                            "subject": 1,
                                            "learning_objectives": 1}
                            )["message"][0]
                            course_s3_url, course_status_code = s3_function.generate_presigned_url_from_s3(course_detail.get('banner_img'))
                            if course_status_code != 200:
                                raise Exception("Error occurred while communicating with s3")
                            for instructor in course_detail.get('instructors'):
                                instructor_detail = mongo_session.get_data_for_particular_columns_with_condition(
                                                                        collection="user_profile",
                                                                        condition={"_id": ObjectId(instructor['_id'])},
                                                                        columns={"name": 1,
                                                                                "last_name": 1,
                                                                                "email": 1}
                                                                    )["message"][0]
                                instructors.append({
                                    "_id": str(instructor_detail.get('_id')),
                                    "name": instructor_detail.get('name'),
                                    "last_name": instructor_detail.get('last_name'),
                                    "email": instructor_detail.get('email')
                                })
                            course_data.append({
                                "_id": str(course.get('course_id')),
                                "instructors": instructors,
                                "subject": course_detail.get('subject'),
                                "learning_objectives": course_detail.get('learning_objectives'),
                                "img_path": course_detail.get('banner_img'),
                                "img_url": course_s3_url
                            })
                        if user_data['privacy_settings']['show_social_media']:    
                            user_detail['subscribed_courses']= course_data
                        else:
                            user_detail['subscribed_courses']= '**********'
                    else:
                        user_detail['subscribed_courses']= ""
                    
                    #student's education history
                    if user_data.get('education_details'):
                        user_detail['education']= user_data['education_details']
                    else:
                        user_detail['education']= []

                    #user experience history
                    if user_data.get('experience'):
                        user_detail['experience']= user_data['experience']
                    else:
                        user_detail['experience']= []

                    #total count of educollab coins availed by student
                    if user_data['coin']:
                        user_detail['avail_coin'] = float(round(user_data['coin'], 2))
                    else:
                        user_detail['avail_coin'] = 0
                    
                    #list of passion_projects which students are part of
                    passion_projects = mongo_session.get_data_for_particular_columns_with_condition(collection="passion_project_teams",
                                                                                    condition={"members": {"$in": [ObjectId(user_id)]}},
                                                                                    columns={"projects":1})
                    if passion_projects:
                        passions = []                              
                        for passion in passion_projects['message']:
                            for pass_proj in passion['projects']:
                                passion_project_details = mongo_session.get_data_for_particular_columns_with_condition(collection="passion_projects",
                                                                                                        condition={"_id": ObjectId(str(pass_proj))},
                                                                                                        columns={"project_title":1, "project_image":1, "project_description":1,
                                                                                                                "project_tags":1, "created_by":1, "project_mentors":1, "project_resources":1})['message'][0]
                                tags = []
                                all_question_tags = mongo_session.get_all_data("question_tags")
                                if all_question_tags["message"]:        
                                    for tag in passion_project_details['project_tags']:
                                        for t in all_question_tags["message"]:
                                            if str(tag) == str(t.get('_id')):
                                                tags.append({
                                                    "_id": t['_id'],
                                                    "tag": t['tag']
                                                })
                                passion_s3_url, passion_status_code = s3_function.generate_presigned_url_from_s3(passion_project_details.get('project_image'))
                                if passion_status_code != 200:
                                    raise Exception("Error occurred while communicating with s3")
                                created_by = mongo_session.get_data_for_particular_columns_with_condition(
                                                                        collection="user_profile",
                                                                        condition={"_id": ObjectId(passion_project_details['created_by'])},
                                                                        columns={"name": 1,
                                                                                "last_name": 1,
                                                                                "email": 1}
                                                                    )["message"][0]
                                passion_doc = {
                                    'project_title': passion_project_details['project_title'],
                                    'project_image_path': passion_project_details['project_image'],
                                    'project_image_url': passion_s3_url,
                                    'project_description': passion_project_details['project_description'],
                                    'project_tags': tags,
                                    'created_by': created_by,
                                    'project_mentors': [str(mentors) for mentors in passion_project_details['project_mentors']],
                                    'project_resources': [str(resources) for resources in passion_project_details['project_resources']]
                                }
                                passions.append(passion_doc)
                        user_detail['passion_project_details'] = passions
            else:
                return({'message' : 'Profile hidden'})
        
        #privacy setting key not present
        else:
            user_detail = user_public_profile(user_data=user_data, s3_url=s3_url, user_id=user_id)
    else:
        user_detail = []
    return user_detail


def user_public_profile(user_data, s3_url, user_id):
    user_detail = {
        'username': user_data['username'],
        'first_name': user_data['name'],
        'last_name': user_data['last_name'],
        'email': user_data['email'],
        'organisation': user_data['organisation'],
        'role': user_data['role'],
        'mobile': user_data['mobile'],
        'avatar_url': s3_url,
        'avatar_path': user_data['profile_pic'],
    }

    keys = ["about", "facebook_url", "linkedin_url"]
    for dict_key in keys:
        if dict_key in user_data.keys():
            user_detail[dict_key] = user_data[dict_key]
        else:
            user_detail[dict_key] = ""

    #instagram
    if user_data.get('instagram'):
        user_detail['instagram'] = user_data['instagram']
    else:
        user_detail['instagram'] = ""
    
    #twitter
    if user_data.get('twitter'):
        user_detail['twitter'] = user_data['twitter']
    else:
        user_detail['twitter'] = ""

    #student only details
    if user_data['role'] == "student":
            #subscribed_courses by student
                if user_data['subscribed_courses']:
                    course_data = []
                    for course in user_data['subscribed_courses']:
                        instructors = []
                        course_detail = mongo_session.get_data_for_particular_columns_with_condition(
                            collection="courses_bank",
                            condition={"_id": ObjectId(course['course_id'])},
                            columns={"instructors": 1,
                                        "banner_img": 1,
                                        "subject": 1,
                                        "learning_objectives": 1}
                        )["message"][0]
                        course_s3_url, course_status_code = s3_function.generate_presigned_url_from_s3(course_detail.get('banner_img'))
                        if course_status_code != 200:
                            raise Exception("Error occurred while communicating with s3")
                        for instructor in course_detail.get('instructors'):
                            instructor_detail = mongo_session.get_data_for_particular_columns_with_condition(
                                                                    collection="user_profile",
                                                                    condition={"_id": ObjectId(instructor['_id'])},
                                                                    columns={"name": 1,
                                                                            "last_name": 1,
                                                                            "email": 1}
                                                                )["message"][0]
                            instructors.append({
                                "_id": str(instructor_detail.get('_id')),
                                "name": instructor_detail.get('name'),
                                "last_name": instructor_detail.get('last_name'),
                                "email": instructor_detail.get('email')
                            })
                        course_data.append({
                            "_id": str(course.get('course_id')),
                            "instructors": instructors,
                            "subject": course_detail.get('subject'),
                            "learning_objectives": course_detail.get('learning_objectives'),
                            "img_path": course_detail.get('banner_img'),
                            "img_url": course_s3_url
                        })
                   
                    user_detail['subscribed_courses']= course_data
                else:
                    user_detail['subscribed_courses']= ""
                
                #student's education history
                if user_data.get('education_details'):
                    user_detail['education']= user_data['education_details']
                else:
                    user_detail['education']= []

                #user experience history
                if user_data.get('experience'):
                    user_detail['experience']= user_data['experience']
                else:
                    user_detail['experience']= []

                #total count of educollab coins availed by student
                if user_data['coin']:
                    user_detail['avail_coin'] = float(round(user_data['coin'], 2))
                else:
                    user_detail['avail_coin'] = 0
                
                #list of passion_projects which students are part of
                passion_projects = mongo_session.get_data_for_particular_columns_with_condition(collection="passion_project_teams",
                                                                                condition={"members": {"$in": [ObjectId(user_id)]}},
                                                                                columns={"projects":1})
                if passion_projects:
                    passions = []                              
                    for passion in passion_projects['message']:
                        for pass_proj in passion['projects']:
                            passion_project_details = mongo_session.get_data_for_particular_columns_with_condition(collection="passion_projects",
                                                                                                    condition={"_id": ObjectId(str(pass_proj))},
                                                                                                    columns={"project_title":1, "project_image":1, "project_description":1,
                                                                                                            "project_tags":1, "created_by":1, "project_mentors":1, "project_resources":1})['message'][0]
                            tags = []
                            all_question_tags = mongo_session.get_all_data("question_tags")
                            if all_question_tags["message"]:        
                                for tag in passion_project_details['project_tags']:
                                    for t in all_question_tags["message"]:
                                        if str(tag) == str(t.get('_id')):
                                            tags.append({
                                                "_id": t['_id'],
                                                "tag": t['tag']
                                            })
                            passion_s3_url, passion_status_code = s3_function.generate_presigned_url_from_s3(passion_project_details.get('project_image'))
                            if passion_status_code != 200:
                                raise Exception("Error occurred while communicating with s3")
                            created_by = mongo_session.get_data_for_particular_columns_with_condition(
                                                                    collection="user_profile",
                                                                    condition={"_id": ObjectId(passion_project_details['created_by'])},
                                                                    columns={"name": 1,
                                                                            "last_name": 1,
                                                                            "email": 1}
                                                                )["message"][0]
                            passion_doc = {
                                'project_title': passion_project_details['project_title'],
                                'project_image_path': passion_project_details['project_image'],
                                'project_image_url': passion_s3_url,
                                'project_description': passion_project_details['project_description'],
                                'project_tags': tags,
                                'created_by': created_by,
                                'project_mentors': [str(mentors) for mentors in passion_project_details['project_mentors']],
                                'project_resources': [str(resources) for resources in passion_project_details['project_resources']]
                            }
                            passions.append(passion_doc)
                    user_detail['passion_project_details'] = passions
    # teacher
    if user_data['role'] == "teacher":

                total_subscribers = 0
                total_reviews = 0
                courses_query = mongo_session.get_data_for_particular_columns_with_condition(collection='courses_bank',
                    condition={"status":"publish","instructors": {"$elemMatch": {"_id": ObjectId(user_id)}}},
                    columns={'_id': 1, 'subject': 1, 'course_category': 1, "Rating": 1, "subscribers": 1, "learning_objectives": 1})['message']
                #print(courses_query)
                for query in courses_query:
                    query["_id"] = str(query["_id"])
                    query['instructor_first_name'] = user_detail['first_name']
                    query['instructor_last_name'] = user_detail['last_name']
                    if query.get('subscribers'):
                        total_subscribers += len(query.get('subscribers'))
                        query.pop('subscribers')
                    if query.get("Rating"):
                        total_reviews += len(query.get("Rating"))
                        query.pop('Rating')
                
                #list of courses taught by teacher            
                if courses_query:
                    course_data = []
                    for course in courses_query:
                        #print(course)
                        instructors = []
                        course_detail = mongo_session.get_data_for_particular_columns_with_condition(
                            collection="courses_bank",
                            condition={"_id": ObjectId(course['_id'])},
                            columns={"instructors": 1,
                                        "banner_img": 1,
                                        "subject": 1}
                        )["message"][0]
                        course_s3_url, course_status_code = s3_function.generate_presigned_url_from_s3(course_detail.get('banner_img'))
                        if course_status_code != 200:
                            raise Exception("Error occurred while communicating with s3")
                        for instructor in course_detail.get('instructors'):
                            instructor_detail = mongo_session.get_data_for_particular_columns_with_condition(
                                                                    collection="user_profile",
                                                                    condition={"_id": ObjectId(instructor['_id'])},
                                                                    columns={"name": 1,
                                                                            "last_name": 1,
                                                                            "email": 1}
                                                                )["message"][0]
                            instructors.append({
                                "_id": str(instructor_detail.get('_id')),
                                "name": instructor_detail.get('name'),
                                "last_name": instructor_detail.get('last_name'),
                                "email": instructor_detail.get('email')
                            })
                        course_data.append({
                            "_id": str(course.get('_id')),
                            "instructors": instructors,
                            "subject": course_detail.get('subject'),
                            "learning_objectives": course_detail.get('learning_objectives'),
                            "img_path": course_detail.get('banner_img'),
                            "img_url": course_s3_url
                        })
                    user_detail['my_teaching_courses']= course_data
                else:
                    user_detail['my_teaching_courses']= []
                
                #total number of students enrolled in the courses taught by teacher
                if total_subscribers > 0:
                    user_detail['total_students_my_courses']= total_subscribers
                else:
                    user_detail['total_students_my_courses']= 0
                
                #total number of reviews giving to all courses taught by teacher
                if total_reviews > 0:
                    user_detail['total_reviews_count'] = total_reviews
                else:
                    user_detail['total_reviews_count'] = 0
                
                #list of passion_projects which students are part of
                passion_projects = mongo_session.get_all_data_for_particular_condition_fields(collection="passion_projects",
                                                                                condition={"created_by": user_id})
                if passion_projects:
                    passions = []                              
                    for passion in passion_projects['message']:
                        tags = []
                        all_question_tags = mongo_session.get_all_data("question_tags")
                        if all_question_tags["message"]:        
                            for tag in passion['project_tags']:
                                for t in all_question_tags["message"]:
                                    if str(tag) == str(t.get('_id')):
                                        tags.append({
                                            "_id": t['_id'],
                                            "tag": t['tag']
                                        })
                        passion_s3_url, passion_status_code = s3_function.generate_presigned_url_from_s3(passion.get('project_image'))
                        if passion_status_code != 200:
                            raise Exception("Error occurred while communicating with s3")
                        created_by = mongo_session.get_data_for_particular_columns_with_condition(
                                                                    collection="user_profile",
                                                                    condition={"_id": ObjectId(passion['created_by'])},
                                                                    columns={"name": 1,
                                                                            "last_name": 1,
                                                                            "email": 1}
                                                                )["message"][0]                                                                                          
                        passion_doc = {
                            'project_title': passion['project_title'],
                            'project_image_path': passion['project_image'],
                            'project_image_url': passion_s3_url,
                            'project_description': passion['project_description'],
                            'project_tags': tags,
                            'created_by': created_by,
                            'project_mentors': [str(mentors) for mentors in passion['project_mentors']],
                            'project_resources': [str(resources) for resources in passion['project_resources']]
                        }
                        passions.append(passion_doc)
                    user_detail['passion_project_details'] = passions

    return user_detail