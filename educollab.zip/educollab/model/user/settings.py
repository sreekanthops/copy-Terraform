from bson import ObjectId
from model.zoom import Zoom
from db_wrapper.tasks import Mongo
from routes.exception import InvalidUsage

mongo_session = Mongo()


def validate_zoom_keys(zoom_email, jwt_api_key, jwt_secret_key, user_id, permissions, organisation):
    """
    To store JWT API and SECRET KEY for every user into the database.
    JWT App provides an api and secret key to access various features of zoom.
    :param zoom_email: email linked to the zoom account for the user.
    :type zoom_email: str.
    :param jwt_secret_key: secret key for jwt app provided by the zoom.
    :type jwt_secret_key: str.
    :param jwt_api_key: api key for jwt app provided by the zoom.
    :type jwt_api_key: str.
    :param user_id: user who is linking the zoom account.
    :type user_id: str (mongo id)
    :param permissions: user can select who can use his/her zoom account.
    :type permissions: dict object containing slugs.
    :param organisation: user's organisation.
    :type organisation: str (mongo id)
    :returns str(message)
    """
    zoom_app = Zoom(jwt_api_key=jwt_api_key,
                    jwt_secret_key=jwt_secret_key,
                    zoom_email=zoom_email)
    jwt_token = zoom_app.generate_jwt_token()
    is_valid = zoom_app.validate_api_secret_key(jwt_token=jwt_token, app_email=zoom_email)
    # 422 (not a processable Entity)
    if not is_valid:
        raise InvalidUsage("Please add correct Zoom details.", 422)

    # check if account with same email exist for the user or not
    previous_account = mongo_session.check_existance_return_info(
        collection="user_profile",
        condition={"_id": ObjectId(user_id),
                   "settings.apps.zoom": {"$elemMatch": {"email": zoom_email.lower()}}})
    if previous_account:
        raise InvalidUsage("You already have an account with {email} email, "
                           "Please delete the previous one or use different account.".format(email=zoom_email), 409)
    # add information into user profile about the secret keys.
    mongo_session.update_record_into_db(
        collection="user_profile",
        condition={"_id": ObjectId(user_id)},
        update_info={"$push":
                         {"settings.apps.zoom":
                              {"email": zoom_email.lower(),
                               "api_key": jwt_api_key,
                               "secret_key": jwt_secret_key,
                               "permissions": {"co_authors": bool(permissions["co_authors"]),
                                               "public_to_org": bool(permissions["public_to_org"]),
                                               "collaborators": bool(permissions["collaborators"])}
                               }
                          }
                     })
    # check if user selected to share his/her account with the organisation
    if bool(permissions["public_to_org"]):
        # store the account information in organisation table along with apps
        mongo_session.update_record_into_db(
            collection="organisations",
            condition={"_id": ObjectId(organisation)},
            update_info={"$push":
                             {"apps.zoom":
                                  {
                                    "user_id": ObjectId(user_id),
                                    "is_active": True,
                                    "email": zoom_email.lower(),
                                    "api_key": jwt_api_key,
                                    "secret_key": jwt_secret_key,
                                    "permissions": {"co_authors": bool(permissions["co_authors"]),
                                                   "public_to_org": bool(permissions["public_to_org"]),
                                                   "collaborators": bool(permissions["collaborators"])}

                                   }
                              }
                         }
        )
    return "Zoom linked successfully."


def get_user_zoom_accounts(user_id):
    """
    To get all the zoom accounts user has associated with the Edu-Collab.
    Also fetch the usage rights of the zoom credentials.
    :param user_id: user who is fetching the zoom account details.
    :type user_id: str (mongo id)
    :returns list containing all the zoom accounts linked to the user profile.
    """

    user_info = mongo_session.check_existance_return_info(
        collection="user_profile",
        condition={"_id": ObjectId(user_id)},
        columns={"_id": 1,
                 "username": 1,
                 "email": 1,
                 "organisation": 1,
                 "settings": 1},
        return_keys=["_id", "username", "email", "organisation", "settings"])
    if not user_info:
        raise InvalidUsage("Something went wrong, Please refresh and try again.", 400)
    response = {"user_id": str(user_id),
                "username": user_info["username"],
                "organisation": user_info["organisation"],
                "email": user_info["email"],
                "apps": {"zoom": []}}
    if not user_info.get("settings") or not user_info["settings"].get("apps") or not user_info["settings"]["apps"].get(
            "zoom"):
        return response
    response["apps"]["zoom"] = user_info["settings"]["apps"]["zoom"]
    return response


def delete_zoom_account(zoom_email, jwt_api_key, jwt_secret_key, user_id, organisation):
    """
    To delete the stored zoom account associated with the user profile.
    :param zoom_email: email linked to the zoom account for the user.
    :type zoom_email: str.
    :param jwt_secret_key: secret key for jwt app provided by the zoom.
    :type jwt_secret_key: str.
    :param jwt_api_key: api key for jwt app provided by the zoom.
    :type jwt_api_key: str.
    :param user_id: user whose account need to be deleted.
    :type user_id: str (mongo id)
    :param organisation: user's organisation.
    :type organisation: str (mongo id)
    :returns str(message)
    """
    # check and delete the account from user profile
    previous_account = mongo_session.update_db_data(
        collection="user_profile",
        condition={"_id": ObjectId(user_id)},
        update_info={"$pull": {"settings.apps.zoom": {"email": zoom_email.lower()}}})
    # delete account from organisations if added there
    previous_org_account = mongo_session.update_db_data(
        collection="organisations",
        condition={"_id": ObjectId(organisation)},
        update_info={"$pull": {"apps.zoom": {"email": zoom_email.lower()}}})
    if not previous_account["nModified"]:
        raise InvalidUsage("Please check the Account details, and try again.", 400)
    return "Zoom account deleted successfully."


def edit_zoom_account(zoom_email, jwt_api_key, jwt_secret_key, user_id, permissions, organisation):
    """
    To edit the access rights for the specific zoom account associated with the user profile.
    :param zoom_email: email linked to the zoom account for the user.
    :type zoom_email: str.
    :param jwt_secret_key: secret key for jwt app provided by the zoom.
    :type jwt_secret_key: str.
    :param jwt_api_key: api key for jwt app provided by the zoom.
    :type jwt_api_key: str.
    :param user_id: user for which the access rights need to be changed.
    :type user_id: str (mongo id)
    :param permissions: user can select who can use his/her zoom account.
    :type permissions: dict object containing slugs.
    :param organisation: user's organisation.
    :type organisation: str (mongo id)
    :returns str(message)
    """
    # check if account already exist or not
    check_account = mongo_session.check_existance_return_info(
        collection="user_profile",
        condition={"_id": ObjectId(user_id),
                   "settings.apps.zoom": {
                       "$elemMatch": {"email": zoom_email.lower(),
                                      "api_key": jwt_api_key,
                                      "secret_key": jwt_secret_key}}
                   },
    )
    if not check_account:
        raise InvalidUsage("Please select available Zoom accounts only.", 400)
    # update the account in organisation collection
    condition = {"_id": ObjectId(organisation),
                 "apps.zoom": {
                     "$elemMatch": {"email": zoom_email.lower(),
                                    "api_key": jwt_api_key,
                                    "secret_key": jwt_secret_key,
                                    "user_id": ObjectId(user_id)}}
                 }
    if bool(permissions["public_to_org"]):
        # add zoom account to organisation if not added already
        if not mongo_session.check_existance_return_info(
                collection="organisations",
                condition=condition):
            mongo_session.update_record_into_db(
                collection="organisations",
                condition={"_id": ObjectId(organisation)},
                update_info={"$push":
                                 {"apps.zoom":
                                      {"user_id": ObjectId(user_id),
                                       "email": zoom_email.lower(),
                                       "api_key": jwt_api_key,
                                       "secret_key": jwt_secret_key,
                                       "permissions": {"co_authors": bool(permissions["co_authors"]),
                                                       "public_to_org": bool(permissions["public_to_org"]),
                                                       "collaborators": bool(permissions["collaborators"])}

                                       }
                                  }
                             }
            )
    else:
        if mongo_session.check_existance_return_info(
                collection="organisations",
                condition=condition):
            previous_org_account = mongo_session.update_db_data(
                collection="organisations",
                condition={"_id": ObjectId(organisation)},
                update_info={"$pull": {"apps.zoom": {"email": zoom_email.lower()}}})

    # update the account in user profile
    user_condition = {"_id": ObjectId(user_id),
                      "settings.apps.zoom": {"$elemMatch": {"email": zoom_email.lower(),
                                                            "api_key": jwt_api_key,
                                                            "secret_key": jwt_secret_key}}}
    update_previous_account = mongo_session.update_db_data(
        collection="user_profile",
        condition=user_condition,
        update_info={"$set": {"settings.apps.zoom.$.permissions":
                                  {"co_authors": bool(permissions["co_authors"]),
                                   "public_to_org": bool(permissions["public_to_org"]),
                                   "collaborators": bool(permissions["collaborators"])}}}
        )

    if not update_previous_account["nModified"]:
        raise InvalidUsage("Please check the Account details, and try again.", 400)
    return "Access rights changed successfully."


def get_available_zoom_accounts(course_id, user_id, role, organisation):
    """
    To send all the available zoom accounts which includes:
        1. Co-authors accounts(if they have given the access)
        2. Organisation's account to which user belong
    ---------------------------
    :param course_id: course on which user is trying to generate zoom meeting.
    :type course_id: str (object id)
    :param user_id: user who is accessing the zoom accounts to create zoom meeting.
    :type user_id: str (object id)
    :param role: role of the user (slug)
    :type role: str
    :param organisation: organisation id of the user.
    :type organisation: str (object id)
    :returns zoom accounts and access rights available for them.
    """
    zoom_accounts = []
    """sample zoom account:
    {"email": "",
               "api_key": "",
               "secret_key": "",
               "permissions": {"co_authors": TRUE/FALSE,
                               "public_to_org": TRUE/FALSE,
                               "collaborators": TRUE/FALSE}"""
    # make list of all the users who have edit rights on course.
    course_info = mongo_session.check_existance_return_info(collection="courses_bank",
                                                            condition={"_id": ObjectId(course_id)},
                                                            columns={"teach_assis": 1,
                                                                     "editors": 1,
                                                                     "instructors": 1,
                                                                     "subscribers": 1,
                                                                     "created_by": 1},
                                                            return_keys=["_id",
                                                                         "teach_assis",
                                                                         "editors",
                                                                         "instructors",
                                                                         "subscribers",
                                                                         "created_by"])
    if not course_info:
        raise InvalidUsage("Bad Request.", 400)

    # accessor: only owner of course/editors/instructors/super_admin are allowed.
    course_info["instructors"].extend(course_info["editors"])
    accessors = [user["_id"] for user in course_info["instructors"]] if course_info["instructors"] else []
    accessors.append(course_info["created_by"])

    if role != "super_admin" and ObjectId(user_id) not in accessors:
        raise InvalidUsage("You are not an authorised user to access this functionality.", 403)

    # access zoom accounts for all users
    accessors_accounts = mongo_session.get_particular_key_value(
        collection="user_profile",
        condition={"$match": {"_id": {"$in": accessors}}},
        return_info={"$project": {"_id": "$_id",
                                  "zoom_accounts": "$settings.apps.zoom"}},
        all_docs=True)
    if not accessors_accounts:
        return zoom_accounts

    # filter out the accounts
    for user in accessors_accounts:
        if user.get("zoom_accounts"):
            if user["_id"] == ObjectId(user_id):
                for each_acc in user["zoom_accounts"]:
                    each_acc["user_id"] = ObjectId(user_id)
                zoom_accounts.extend(user["zoom_accounts"])
            else:
                for account in user["zoom_accounts"]:
                    if account["permissions"]["co_authors"]:
                        account.update({"user_id": user["_id"]})
                        zoom_accounts.append(account)

    # add organisation's accounts
    org_zoom_accounts = mongo_session.get_particular_key_value(collection="organisations",
                                                               condition={"$match": {"_id": ObjectId(organisation)}},
                                                               return_info={"$project": {"zoom_accounts": "$apps.zoom"}})
    if org_zoom_accounts and org_zoom_accounts.get("zoom_accounts"):
        zoom_accounts.extend(org_zoom_accounts["zoom_accounts"])

    # remove duplicate accounts and convert user id to str
    unique_accounts = []
    available_zoom_accounts = []
    for account in zoom_accounts:
        if account["email"] not in unique_accounts:
            unique_accounts.append(account["email"])
            account["user_id"] = str(account["user_id"])
            available_zoom_accounts.append(account)
    return available_zoom_accounts
