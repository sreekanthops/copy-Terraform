from bson import ObjectId
import model.Question as Question
import datetime
from routes.exception import InvalidUsage
from db_wrapper.tasks import Mongo
from model.courses.misc import seen_asess_feedback, update_schedule_assessment
import model.Content as Content

mongo_session = Mongo()


def view_course_course_assessments(course_data, user_id, role, course_id):
    """To process course assessments in view course.
        :param course_data: course data from mongo query.
        :type: dict
        :param user_id: user id
        :type: string
        :param role: role
        :type: string
        :param course_id: course id
        :type: string
    """
    processed_assessments = []
    for assessment in course_data["course_assessments"]:
        seen_feedback = seen_asess_feedback(user_id=user_id,
                                            role=role,
                                            course_id=course_id,
                                            assessment_id=assessment["_id"],
                                            schedule_id=assessment.get("schedule_id"))

        user_submission = mongo_session.check_existance(collection="assessments_result",
                                                        condition={"course_id": ObjectId(course_id),
                                                                   "user_id": ObjectId(user_id),
                                                                   "assessment_id": ObjectId(str(assessment['_id']))})
        if assessment.get("schedule_id"):
            assess_query = mongo_session.get_all_data_for_particular_condition_fields(
                collection="schedule_assessment",
                condition={"_id": assessment["schedule_id"]})
            if assess_query['status'] != 200:
                raise InvalidUsage("Something went wrong, please try again later.", 500)
            assess_data = assess_query['message'][0]
            start_obj = datetime.datetime.strptime(assess_data['start_time'], "%Y:%m:%dT%H:%M")
            assessment_start_time = start_obj.strftime("%d %b %Y, %I:%M %p")

            end_obj = datetime.datetime.strptime(assess_data['end_time'], "%Y:%m:%dT%H:%M")
            assessment_end_time = end_obj.strftime("%d %b %Y, %I:%M %p")

            timestamp = Question.indian_standard_time()
            timestamp_obj = datetime.datetime.strptime(timestamp, "%d %b %Y, %I:%M %p")

            asess_status = True if timestamp_obj < end_obj else False

            processed_assessments.append({"_id": str(assess_data["assessment_id"]),
                                          "title": assess_data["assessment_name"],
                                          "end_time": assessment_end_time,
                                          "start_time": assessment_start_time,
                                          "total_time": assess_data['total_time'],
                                          "active": asess_status,
                                          "schedule_id": str(assess_data["_id"]),
                                          "view_feedback": seen_feedback,
                                          "one_time_assessment": assessment.get('one_time_assessment', False),
                                          "user_submission": True if user_submission else False,
                                          "is_timed": assessment.get("is_timed", True)})
        else:
            assess_query = mongo_session.get_data_for_particular_columns_with_condition(
                collection="assessment",
                condition={"_id": assessment["_id"]},
                columns={"assessment_name": 1, "total_time": 1})
            if assess_query['status'] != 200:
                raise InvalidUsage("Something went wrong, please try again later.", 500)
            if len(assess_query["message"]) != 0:
                assess_data = assess_query['message'][0]
                processed_assessments.append({"_id": str(assessment["_id"]),
                                            "title": assess_data["assessment_name"],
                                            "end_time": "",
                                            "start_time": "",
                                            "total_time": assess_data['total_time'],
                                            "schedule_id": "",
                                            "view_feedback": seen_feedback,
                                            "one_time_assessment": assessment.get('one_time_assessment', False),
                                            "user_submission": True if user_submission else False,
                                            "is_timed": assessment.get("is_timed", False)})
    return processed_assessments


def edit_course_course_assessment(course_assessments, db_course_assessments, course_status,course_class):
    processed_assessments = []
    unique_assess = []
    timestamp = Question.indian_standard_time()
    timestamp_obj = datetime.datetime.strptime(timestamp, "%d %b %Y, %I:%M %p")
    for assessment in course_assessments:
        assessment["_id"] = str(assessment["_id"])
        if assessment["_id"] in unique_assess:
            raise InvalidUsage("An assessment can only be used once in a course.", 400)
        unique_assess.append(assessment["_id"])
        if assessment["calendered"] or assessment["is_timed"]:
            if course_class == "Self Paced Course":
                raise InvalidUsage("Calendered or Timed assessment not allowed in Self Paced Courses.", 406)
        if not assessment["calendered"] and not assessment["one_time_assessment"] and not assessment["is_timed"]:
            processed_assessments.append({"_id": ObjectId(assessment['_id']),
                                          "is_timed": bool(assessment["is_timed"]),
                                          "one_time_assessment": bool(assessment["one_time_assessment"]),
                                          "calendered": bool(assessment["calendered"])})

        elif not assessment["calendered"] and not assessment['one_time_assessment'] and  assessment["is_timed"] :
            processed_assessments.append({"_id": ObjectId(assessment['_id']),
                                          "is_timed": bool(assessment["is_timed"]),
                                          "one_time_assessment": bool(assessment["one_time_assessment"]),
                                          "calendered": bool(assessment["calendered"])})

        elif not assessment["calendered"] and  assessment['one_time_assessment'] and not assessment["is_timed"] :
            processed_assessments.append({"_id": ObjectId(assessment['_id']),
                                          "is_timed": bool(assessment["is_timed"]),
                                          "one_time_assessment": bool(assessment["one_time_assessment"]),
                                          "calendered": bool(assessment["calendered"])})

        elif not assessment["calendered"] and  assessment['one_time_assessment'] and  assessment["is_timed"] :
            processed_assessments.append({"_id": ObjectId(assessment['_id']),
                                          "is_timed": bool(assessment["is_timed"]),
                                          "one_time_assessment": bool(assessment["one_time_assessment"]),
                                          "calendered": bool(assessment["calendered"])})

        elif assessment['calendered'] and not assessment['one_time_assessment'] and not assessment["is_timed"]:
            schedule_id = ""
            for data in db_course_assessments:
                if str(data["_id"]) == assessment["_id"]:
                    if not data.get("schedule_id"):
                        return "Can't add same assessment twice at same level.", 409
                    schedule_id = data["schedule_id"]
            if not schedule_id:
                # schedule assessment
                schedule_assessment_id = Content.schedule_assessment(
                    assessment_data=assessment,
                    assessment_type="course")
                processed_assessments.append({"_id": ObjectId(assessment['_id']),
                                              "schedule_id": schedule_assessment_id,
                                              "is_timed": bool(assessment["is_timed"]),
                                              "one_time_assessment": bool(assessment["one_time_assessment"]),
                                              "calendered": bool(assessment["calendered"])})
            elif course_status == "publish":
                schedule_assess_info = mongo_session.get_data_for_particular_columns_with_condition(
                    collection="schedule_assessment",
                    condition={"_id": schedule_id},
                    columns={"start_time": 1})
                if schedule_assess_info["status"] != 200:
                    raise Exception("Some internal error occurred, please try again later.")
                db_assess_start_time = datetime.datetime.strptime(schedule_assess_info["message"][0]["start_time"],
                                                                  "%Y:%m:%dT%H:%M")
                new_start_time = Content.webapp_time_to_string(assessment['date'], assessment['time'])
                new_start_time = datetime.datetime.strptime(new_start_time, "%Y:%m:%dT%H:%M")

                if timestamp_obj < db_assess_start_time and timestamp_obj < new_start_time:
                    schedule_assessment_id = update_schedule_assessment(assessment, "course", schedule_id)
                    processed_assessments.append({"_id": ObjectId(assessment['_id']),
                                                  "schedule_id": schedule_assessment_id,
                                                  "is_timed": bool(assessment["is_timed"]),
                                                  "one_time_assessment": bool(assessment["one_time_assessment"]),
                                                  "calendered": bool(assessment["calendered"])})
                else:
                    schedule_assessment_id = update_schedule_assessment(assessment, "course", schedule_id)
                    processed_assessments.append({"_id": ObjectId(assessment['_id']),
                                                  "schedule_id": schedule_assessment_id,
                                                  "is_timed": bool(assessment["is_timed"]),
                                                  "one_time_assessment": bool(assessment["one_time_assessment"]),
                                                  "calendered": bool(assessment["calendered"])})
            else:  # unpublish
                schedule_assessment_id = update_schedule_assessment(assessment, "course", schedule_id)
                processed_assessments.append({"_id": ObjectId(assessment['_id']),
                                              "schedule_id": schedule_assessment_id,
                                              "is_timed": bool(assessment["is_timed"]),
                                              "one_time_assessment": bool(assessment["one_time_assessment"]),
                                              "calendered": bool(assessment["calendered"])})


        elif assessment['calendered'] and  assessment['one_time_assessment'] and not assessment["is_timed"]:

            schedule_id = ""
            for data in db_course_assessments:
                if str(data["_id"]) == assessment["_id"]:
                    if not data.get("schedule_id"):
                        return "Can't add same assessment twice at same level.", 409
                    schedule_id = data["schedule_id"]
            if not schedule_id:
                # schedule assessment
                schedule_assessment_id = Content.schedule_assessment(
                    assessment_data=assessment,
                    assessment_type="course")
                processed_assessments.append({"_id": ObjectId(assessment['_id']),
                                              "schedule_id": schedule_assessment_id,
                                              "is_timed": bool(assessment["is_timed"]),
                                              "one_time_assessment": bool(assessment["one_time_assessment"]),
                                              "calendered": bool(assessment["calendered"])})


            elif course_status == "publish":
                schedule_assess_info = mongo_session.get_data_for_particular_columns_with_condition(
                    collection="schedule_assessment",
                    condition={"_id": schedule_id},
                    columns={"start_time": 1})
                if schedule_assess_info["status"] != 200:
                    raise Exception("Some internal error occurred, please try again later.")
                db_assess_start_time = datetime.datetime.strptime(schedule_assess_info["message"][0]["start_time"],
                                                                  "%Y:%m:%dT%H:%M")
                new_start_time = Content.webapp_time_to_string(assessment['date'], assessment['time'])
                new_start_time = datetime.datetime.strptime(new_start_time, "%Y:%m:%dT%H:%M")

                if timestamp_obj < db_assess_start_time and timestamp_obj < new_start_time:
                    schedule_assessment_id = update_schedule_assessment(assessment, "course", schedule_id)
                    processed_assessments.append({"_id": ObjectId(assessment['_id']),
                                                  "schedule_id": schedule_assessment_id,
                                                  "is_timed": bool(assessment["is_timed"]),
                                                  "one_time_assessment": bool(assessment["one_time_assessment"]),
                                                  "calendered": bool(assessment["calendered"])})
                else:
                    schedule_assessment_id = update_schedule_assessment(assessment, "course", schedule_id)
                    processed_assessments.append({"_id": ObjectId(assessment['_id']),
                                                  "schedule_id": schedule_assessment_id,
                                                  "is_timed": bool(assessment["is_timed"]),
                                                  "one_time_assessment": bool(assessment["one_time_assessment"]),
                                                  "calendered": bool(assessment["calendered"])})
            else:  # unpublish
                schedule_assessment_id = update_schedule_assessment(assessment, "course", schedule_id)
                processed_assessments.append({"_id": ObjectId(assessment['_id']),
                                              "schedule_id": schedule_assessment_id,
                                              "is_timed": bool(assessment["is_timed"]),
                                              "one_time_assessment": bool(assessment["one_time_assessment"]),
                                              "calendered": bool(assessment["calendered"])})



        elif assessment['calendered'] and not assessment['one_time_assessment'] and  assessment["is_timed"]:

            schedule_id = ""
            for data in db_course_assessments:
                if str(data["_id"]) == assessment["_id"]:
                    if not data.get("schedule_id"):
                        return "Can't add same assessment twice at same level.", 409
                    schedule_id = data["schedule_id"]
            if not schedule_id:
                # schedule assessment
                schedule_assessment_id = Content.schedule_assessment(
                    assessment_data=assessment,
                    assessment_type="course")
                processed_assessments.append({"_id": ObjectId(assessment['_id']),
                                              "schedule_id": schedule_assessment_id,
                                              "is_timed": bool(assessment["is_timed"]),
                                              "one_time_assessment": bool(assessment["one_time_assessment"]),
                                              "calendered": bool(assessment["calendered"])})


            elif course_status == "publish":
                schedule_assess_info = mongo_session.get_data_for_particular_columns_with_condition(
                    collection="schedule_assessment",
                    condition={"_id": schedule_id},
                    columns={"start_time": 1})
                if schedule_assess_info["status"] != 200:
                    raise Exception("Some internal error occurred, please try again later.")
                db_assess_start_time = datetime.datetime.strptime(schedule_assess_info["message"][0]["start_time"],
                                                                  "%Y:%m:%dT%H:%M")
                new_start_time = Content.webapp_time_to_string(assessment['date'], assessment['time'])
                new_start_time = datetime.datetime.strptime(new_start_time, "%Y:%m:%dT%H:%M")

                if timestamp_obj < db_assess_start_time and timestamp_obj < new_start_time:
                    schedule_assessment_id = update_schedule_assessment(assessment, "course", schedule_id)
                    processed_assessments.append({"_id": ObjectId(assessment['_id']),
                                                  "schedule_id": schedule_assessment_id,
                                                  "is_timed": bool(assessment["is_timed"]),
                                                  "one_time_assessment": bool(assessment["one_time_assessment"]),
                                                  "calendered": bool(assessment["calendered"])})
                else:
                    schedule_assessment_id = update_schedule_assessment(assessment, "course", schedule_id)
                    processed_assessments.append({"_id": ObjectId(assessment['_id']),
                                                  "schedule_id": schedule_assessment_id,
                                                  "is_timed": bool(assessment["is_timed"]),
                                                  "one_time_assessment": bool(assessment["one_time_assessment"]),
                                                  "calendered": bool(assessment["calendered"])})
            else:  # unpublish
                schedule_assessment_id = update_schedule_assessment(assessment, "course", schedule_id)
                processed_assessments.append({"_id": ObjectId(assessment['_id']),
                                              "schedule_id": schedule_assessment_id,
                                              "is_timed": bool(assessment["is_timed"]),
                                              "one_time_assessment": bool(assessment["one_time_assessment"]),
                                              "calendered": bool(assessment["calendered"])})


        elif assessment['calendered'] and  assessment['one_time_assessment'] and  assessment["is_timed"]:

            schedule_id = ""
            for data in db_course_assessments:
                if str(data["_id"]) == assessment["_id"]:
                    if not data.get("schedule_id"):
                        return "Can't add same assessment twice at same level.", 409
                    schedule_id = data["schedule_id"]
            if not schedule_id:
                # schedule assessment
                schedule_assessment_id = Content.schedule_assessment(
                    assessment_data=assessment,
                    assessment_type="course")
                processed_assessments.append({"_id": ObjectId(assessment['_id']),
                                              "schedule_id": schedule_assessment_id,
                                              "is_timed": bool(assessment["is_timed"]),
                                              "one_time_assessment": bool(assessment["one_time_assessment"]),
                                              "calendered": bool(assessment["calendered"])})


            elif course_status == "publish":
                schedule_assess_info = mongo_session.get_data_for_particular_columns_with_condition(
                    collection="schedule_assessment",
                    condition={"_id": schedule_id},
                    columns={"start_time": 1})
                if schedule_assess_info["status"] != 200:
                    raise Exception("Some internal error occurred, please try again later.")
                db_assess_start_time = datetime.datetime.strptime(schedule_assess_info["message"][0]["start_time"],
                                                                  "%Y:%m:%dT%H:%M")
                new_start_time = Content.webapp_time_to_string(assessment['date'], assessment['time'])
                new_start_time = datetime.datetime.strptime(new_start_time, "%Y:%m:%dT%H:%M")

                if timestamp_obj < db_assess_start_time and timestamp_obj < new_start_time:
                    schedule_assessment_id = update_schedule_assessment(assessment, "course", schedule_id)
                    processed_assessments.append({"_id": ObjectId(assessment['_id']),
                                                  "schedule_id": schedule_assessment_id,
                                                  "is_timed": bool(assessment["is_timed"]),
                                                  "one_time_assessment": bool(assessment["one_time_assessment"]),
                                                  "calendered": bool(assessment["calendered"])})
                else:
                    schedule_assessment_id = update_schedule_assessment(assessment, "course", schedule_id)
                    processed_assessments.append({"_id": ObjectId(assessment['_id']),
                                                  "schedule_id": schedule_assessment_id,
                                                  "is_timed": bool(assessment["is_timed"]),
                                                  "one_time_assessment": bool(assessment["one_time_assessment"]),
                                                  "calendered": bool(assessment["calendered"])})
            else:  # unpublish
                schedule_assessment_id = update_schedule_assessment(assessment, "course", schedule_id)
                processed_assessments.append({"_id": ObjectId(assessment['_id']),
                                              "schedule_id": schedule_assessment_id,
                                              "is_timed": bool(assessment["is_timed"]),
                                              "one_time_assessment": bool(assessment["one_time_assessment"]),
                                              "calendered": bool(assessment["calendered"])})
        else:
            schedule_id = ""
            for data in db_course_assessments:
                if str(data["_id"]) == assessment["_id"]:
                    if not data.get("schedule_id"):
                        return "Can't add same assessment twice at same level.", 409
                    schedule_id = data["schedule_id"]
            if not schedule_id:
                # schedule assessment
                schedule_assessment_id = Content.schedule_assessment(
                    assessment_data=assessment,
                    assessment_type="course")
                processed_assessments.append({"_id": ObjectId(assessment['_id']),
                                              "schedule_id": schedule_assessment_id,
                                              "is_timed": bool(assessment["is_timed"]),
                                              "one_time_assessment": bool(assessment["one_time_assessment"]),
                                              "calendered": bool(assessment["calendered"])})


            elif course_status == "publish":
                schedule_assess_info = mongo_session.get_data_for_particular_columns_with_condition(
                    collection="schedule_assessment",
                    condition={"_id": schedule_id},
                    columns={"start_time": 1})
                if schedule_assess_info["status"] != 200:
                    raise Exception("Some internal error occurred, please try again later.")
                db_assess_start_time = datetime.datetime.strptime(schedule_assess_info["message"][0]["start_time"],
                                                                  "%Y:%m:%dT%H:%M")
                new_start_time = Content.webapp_time_to_string(assessment['date'], assessment['time'])
                new_start_time = datetime.datetime.strptime(new_start_time, "%Y:%m:%dT%H:%M")

                if timestamp_obj < db_assess_start_time and timestamp_obj < new_start_time:
                    schedule_assessment_id = update_schedule_assessment(assessment, "course", schedule_id)
                    processed_assessments.append({"_id": ObjectId(assessment['_id']),
                                                  "schedule_id": schedule_assessment_id,
                                                  "is_timed": bool(assessment["is_timed"]),
                                                  "one_time_assessment": bool(assessment["one_time_assessment"]),
                                                  "calendered": bool(assessment["calendered"])})
                else:
                    schedule_assessment_id = update_schedule_assessment(assessment, "course", schedule_id)
                    processed_assessments.append({"_id": ObjectId(assessment['_id']),
                                                  "schedule_id": schedule_assessment_id,
                                                  "is_timed": bool(assessment["is_timed"]),
                                                  "one_time_assessment": bool(assessment["one_time_assessment"]),
                                                  "calendered": bool(assessment["calendered"])})
            else:  # unpublish
                schedule_assessment_id = update_schedule_assessment(assessment, "course", schedule_id)
                processed_assessments.append({"_id": ObjectId(assessment['_id']),
                                              "schedule_id": schedule_assessment_id,
                                              "is_timed": bool(assessment["is_timed"]),
                                              "one_time_assessment": bool(assessment["one_time_assessment"]),
                                              "calendered": bool(assessment["calendered"])})
    return processed_assessments, unique_assess