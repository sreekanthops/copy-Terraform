from bson import ObjectId
from routes.exception import InvalidUsage
from services.storage.s3_services import s3_storage
from utils.time_conversions import utc_datetime_now, str_to_utc_datetime_obj, \
    convert_utc_to_ist
from utils.misc import renew_s3_links
from db_wrapper.tasks import Mongo

mongo_session = Mongo()
s3_function = s3_storage()


def view_course_coursework(course_data, user_id, role, course_work_id=None):
    """To process course coursework in view course.
        :param course_data: course data from mongo query.
        :type: dict
        :param user_id: user id
        :type: string
        :param role: role
        :type: string
    """
    # course work
    processed_course_work = []
    
    # Self Paced Course
    course_class = course_data.get('course_class', None)
    if course_class:
        course_class = mongo_session.access_specific_fields(collection='course_class',
                                                            condition={'_id': ObjectId(course_class)})[0]['value']
    else:
        course_class = 'Old Structure'
    
    if course_work_id:
        course_work_data = [course_work for course_work in course_data['course_work'] if str(course_work['_id']) == str(course_work_id)]
    else:
        course_work_data = course_data["course_work"]

    for work in course_work_data:
        course_work_query = mongo_session.get_all_data_for_particular_condition_fields(
            collection="course_work_bank",
            condition={"_id": ObjectId(work["_id"])})
        if course_work_query['status'] != 200:
            raise InvalidUsage("Something went wrong, please try again later.", 500)
        work_data = course_work_query['message'][0]
        schedule_work_query = mongo_session.get_all_data_for_particular_condition_fields(
            collection="course_work_instances",
            condition={"_id": ObjectId(work["schedule_id"])})
        if schedule_work_query['status'] != 200:
            raise InvalidUsage("Something went wrong, please try again later.", 500)
        schedule_data = schedule_work_query['message'][0]

        for resource in work_data["course_work_resources"]:
            if resource['resource_type'] == 'file':
                if resource.get('schedule_id'):
                    resource['schedule_id'] = str(resource['schedule_id'])
                resource['resource_id'] = str(resource['resource_id'])
                if resource.get('instance_id'):
                    resource['instance_id'] = str(resource['instance_id'])
                if resource.get('schedule_id'):
                    resource['schedule_id'] = str(resource['schedule_id'])
                if resource.get('_id'):
                    resource['_id'] = str(resource['_id'])
                resource['resource_url'], s3_status = s3_function.generate_presigned_url_from_s3(
                    resource['resource_url'])
                if s3_status != 200:
                    raise InvalidUsage("Error occurred while communicating with s3", 500)

        team_info = []
        if schedule_data.get("teams"):
            if role in ["teacher", "super_admin"]:
                for team in schedule_data["teams"]:
                    for member in team["members"]:
                        member_data = mongo_session.check_existance_return_info(collection="user_profile",
                                                                                       condition={
                                                                                           "_id": member["_id"]},
                                                                                       columns={"username": 1,
                                                                                                "_id": 1,
                                                                                                "name": 1,
                                                                                                "last_name": 1,
                                                                                                "profile_pic": 1},
                                                                                       return_keys=["username", "name", "last_name", "profile_pic"])
                        member["username"] = member_data["username"]
                        member["_id"] = str(member["_id"])
                        member["name"] = member_data.get("name","").capitalize() + " " + member_data.get("last_name","").capitalize()
                        s3_url, status_code = s3_function.generate_presigned_url_from_s3(member_data['profile_pic'])
                        member['profile_pic'] = s3_url
                    team_doc = {"name": team["name"], "members": team["members"]}
                    if team.get("room_id"):
                        current_user = "room_members." + user_id
                        current_admin = "admins.admin_id"
                        current_user_status = "room_members." + user_id + ".status"
                        condition = {"$and": [{'_id': ObjectId(team["room_id"])}, {"$or": [
                            {"$and": [{current_user: {"$exists": True}}, {current_user_status: "active"}]},
                            {"$and": [{"admins.admin_id": {"$in": [ObjectId(user_id)]}},
                                      {"admins.status": "active"}]}
                        ]}]}
                        condition_1 = {'_id': ObjectId(team["room_id"])}
                        team_doc['cw_group_chat'] = {}
                        room_info = mongo_session.check_existance_return_info(collection='chat_rooms',
                                                                              condition=condition,
                                                                              whole_doc=True)
                        room_id = mongo_session.check_existance_return_info(collection='chat_rooms',
                                                                            condition=condition_1)
                        if not room_info:
                            if room_id:
                                team_doc["room_id"] = str(room_id)
                            else:
                                team_doc["room_id"] = None
                            team_doc['cw_group_chat'] = None
                        for member in team['members']:
                            member['user_room_id'] = str(room_id)
                        if room_info:
                            team_doc["room_id"] = str(team["room_id"])
                            check_message_count = mongo_session.get_total_count(collection='messages',
                                                                                condition={
                                                                                    'room_id': str(
                                                                                        room_info['_id']),
                                                                                    "receiver_status":
                                                                                        {"$elemMatch": {"$and": [
                                                                                            {"_id": ObjectId(
                                                                                                user_id)},
                                                                                            {"status": False}
                                                                                        ]}
                                                                                        }})
                            if check_message_count:
                                room_info['total_unread_messages'] = check_message_count
                            else:
                                room_info['total_unread_messages'] = 0

                            message_info = mongo_session.check_existance_return_info(collection='messages',
                                                                                     condition={'room_id': str(
                                                                                         room_info['_id'])},
                                                                                     return_keys=['message',
                                                                                                  'created_at',
                                                                                                  'sender_id',
                                                                                                  'content'])
                            if message_info:
                                message_info['sender_id'] = str(message_info['sender_id'])
                                date = message_info['created_at']
                                message_info['created_at'] = convert_utc_to_ist(date).replace(
                                    tzinfo=None).isoformat(' ')
                                room_info['messages'] = [message_info]
                            else:
                                room_info['messages'] = []

                            room_members = []
                            members = [ObjectId(member) for member in room_info['room_members']]
                            room_members.extend(members)
                            admins = [member['admin_id'] for member in room_info['admins'] if
                                      member['status'] == "active"]
                            room_members.extend(admins)
                            admins = [str(member['admin_id']) for member in room_info['admins'] if
                                      member['status'] == "active"]

                            user_info = mongo_session.access_specific_fields(collection='user_profile',
                                                                             condition={
                                                                                 "_id": {"$in": room_members}
                                                                             },
                                                                             return_keys=['_id', 'name',
                                                                                          'last_name', 'email',
                                                                                          'username',
                                                                                          'profile_pic'])
                            user_details = {}
                            for user in user_info:
                                user_details[str(user['_id'])] = user
                                user['_id'] = str(user['_id'])
                                user['user_id'] = user['_id']
                                user['avatar_url'] = user['profile_pic']
                                # print(user['profile_pic'])
                                user['color'] = ""
                                if user['avatar_url'] is None:
                                    user['avatar_url'] = ""
                                del user['_id']

                            room_info['_id'] = str(room_info['_id'])
                            room_info['room_id'] = room_info['_id']
                            del room_info['_id']
                            room_info['created_by'] = str(room_info['created_by'])
                            room_info['created_at'] = convert_utc_to_ist(room_info['created_at']).replace(
                                tzinfo=None)
                            if room_info.get('type'):
                                admin_list = []
                                for admin in room_info['admins']:
                                    admin['admin_id'] = str(admin['admin_id'])
                                    if admin['admin_id'] == user_id and admin['status'] == 'active':
                                        room_info['current_user_admin'] = True
                                    else:
                                        room_info['current_user_admin'] = False
                                    admin['added_by'] = str(admin['added_by'])
                                    if room_info['room_members']:
                                        room_info['room_members'][admin['admin_id']] = {"status": admin['status']}
                                    else:
                                        dict_1 = {admin['admin_id']: {"status": admin['status']}}
                                        room_info['room_members'] = dict_1

                            member_list = []
                            for member in room_info['room_members']:
                                if member in user_details:
                                    s3_url, status_code = s3_function.generate_presigned_url_from_s3(
                                        user_details[member]['profile_pic'])
                                    user_details[member]['avatar_url'] = s3_url
                                    if room_info['name'] == "" and not room_info.get('type'):
                                        if member != user_id:
                                            room_info['name'] = user_details[member]['username']
                                            room_info['avatar_url'] = s3_url
                                    if room_info.get('type'):
                                        if member in admins:
                                            user_details[member]['is_admin'] = True
                                        else:
                                            user_details[member]['is_admin'] = False
                                        if member == user_id:
                                            room_info['user_status'] = room_info['room_members'][member]['status']
                                        user_details[member]['user_status'] = room_info['room_members'][member][
                                            'status']
                                    else:
                                        if member == user_id:
                                            room_info['user_status'] = "active"
                                        user_details[member]['user_status'] = "active"
                                    d = {key: value for key, value in user_details[member].items() if
                                         key not in 'profile_pic'}
                                    if user_details[member].get('user_status'):
                                        del user_details[member]['user_status']
                                    if user_details[member].get('is_admin'):
                                        del user_details[member]['is_admin']
                                    member_list.append(d)
                            room_info['room_members'] = member_list
                            if room_info.get('group_photo'):
                                room_info['avatar_url'], status = s3_function.generate_presigned_url_from_s3(
                                    room_info['group_photo']['avatar_url'])
                                del room_info['group_photo']

                            if room_info.get('group_description'):
                                room_info['description'] = str(room_info['group_description']['description'])
                                del room_info['group_description']

                            if room_info.get('course_work_id'):
                                room_info['course_work_id'] = str(room_info['course_work_id'])

                            if room_info.get('cw_instance_id'):
                                room_info['cw_instance_id'] = str(room_info['cw_instance_id'])
                            del room_info['admins']
                            team_doc['cw_group_chat'] = room_info
                            if len(room_info['room_members']) == 1:
                                team_doc['cw_group_chat'] = None
                    team_info.append(team_doc)
            else:
                for team in schedule_data["teams"]:
                    if any(member["_id"] == ObjectId(user_id) for member in team["members"]):
                        for member in team["members"]:
                            member["username"] = mongo_session.check_existance_return_info(collection="user_profile",
                                                                                           condition={
                                                                                               "_id": member["_id"]},
                                                                                           columns={"username": 1,
                                                                                                    "_id": 1},
                                                                                           return_keys=["username"])[
                                "username"]
                            member["_id"] = str(member["_id"])
                        team_doc = {"name": team["name"], "members": team["members"]}
                        if team.get("room_id"):
                            current_user = "room_members." + user_id
                            current_admin = "admins.admin_id"
                            current_user_status = "room_members." + user_id + ".status"
                            condition = {"$and": [{'_id': ObjectId(team["room_id"])}, {"$or": [
                                {"$and": [{current_user: {"$exists": True}}, {current_user_status: "active"}]},
                                {"$and": [{"admins.admin_id": {"$in": [ObjectId(user_id)]}},
                                          {"admins.status": "active"}]}
                            ]}]}
                            team_doc['cw_group_chat'] = {}
                            room_info = mongo_session.check_existance_return_info(collection='chat_rooms',
                                                                                  condition=condition,
                                                                                  whole_doc=True)
                            if not room_info:
                                team_doc["room_id"] = None
                                team_doc['cw_group_chat'] = None
                            if room_info:
                                team_doc["room_id"] = str(team["room_id"])
                                for member in team['members']:
                                    member['user_room_id'] = str(room_info['_id'])
                                check_message_count = mongo_session.get_total_count(collection='messages',
                                                                                    condition={
                                                                                        'room_id': str(
                                                                                            room_info['_id']),
                                                                                        "receiver_status":
                                                                                            {"$elemMatch": {"$and": [
                                                                                                {"_id": ObjectId(
                                                                                                    user_id)},
                                                                                                {"status": False}
                                                                                            ]}
                                                                                            }})
                                if check_message_count:
                                    room_info['total_unread_messages'] = check_message_count
                                else:
                                    room_info['total_unread_messages'] = 0

                                message_info = mongo_session.check_existance_return_info(collection='messages',
                                                                                         condition={'room_id': str(
                                                                                             room_info['_id'])},
                                                                                         return_keys=['message',
                                                                                                      'created_at',
                                                                                                      'sender_id',
                                                                                                      'content'])
                                if message_info:
                                    message_info['sender_id'] = str(message_info['sender_id'])
                                    date = message_info['created_at']
                                    message_info['created_at'] = convert_utc_to_ist(date).replace(
                                        tzinfo=None).isoformat(' ')
                                    room_info['messages'] = [message_info]
                                else:
                                    room_info['messages'] = []

                                room_members = []
                                members = [ObjectId(member) for member in room_info['room_members']]
                                room_members.extend(members)
                                admins = [member['admin_id'] for member in room_info['admins'] if
                                          member['status'] == "active"]
                                room_members.extend(admins)
                                admins = [str(member['admin_id']) for member in room_info['admins'] if
                                          member['status'] == "active"]

                                user_info = mongo_session.access_specific_fields(collection='user_profile',
                                                                                 condition={
                                                                                     "_id": {"$in": room_members}
                                                                                 },
                                                                                 return_keys=['_id', 'name',
                                                                                              'last_name', 'email',
                                                                                              'username',
                                                                                              'profile_pic'])
                                user_details = {}
                                for user in user_info:
                                    user_details[str(user['_id'])] = user
                                    user['_id'] = str(user['_id'])
                                    user['user_id'] = user['_id']
                                    user['avatar_url'] = user['profile_pic']
                                    # print(user['profile_pic'])
                                    user['color'] = ""
                                    if user['avatar_url'] is None:
                                        user['avatar_url'] = ""
                                    del user['_id']

                                room_info['_id'] = str(room_info['_id'])
                                room_info['room_id'] = room_info['_id']
                                del room_info['_id']
                                room_info['created_by'] = str(room_info['created_by'])
                                room_info['created_at'] = convert_utc_to_ist(room_info['created_at']).replace(
                                    tzinfo=None)
                                if room_info.get('type'):
                                    admin_list = []
                                    for admin in room_info['admins']:
                                        admin['admin_id'] = str(admin['admin_id'])
                                        if admin['admin_id'] == user_id and admin['status'] == 'active':
                                            room_info['current_user_admin'] = True
                                        else:
                                            room_info['current_user_admin'] = False
                                        admin['added_by'] = str(admin['added_by'])
                                        if room_info['room_members']:
                                            room_info['room_members'][admin['admin_id']] = {"status": admin['status']}
                                        else:
                                            dict_1 = {admin['admin_id']: {"status": admin['status']}}
                                            room_info['room_members'] = dict_1

                                member_list = []
                                for member in room_info['room_members']:
                                    if member in user_details:
                                        s3_url, status_code = s3_function.generate_presigned_url_from_s3(
                                            user_details[member]['profile_pic'])
                                        user_details[member]['avatar_url'] = s3_url
                                        if room_info['name'] == "" and not room_info.get('type'):
                                            if member != user_id:
                                                room_info['name'] = user_details[member]['username']
                                                room_info['avatar_url'] = s3_url
                                        if room_info.get('type'):
                                            if member in admins:
                                                user_details[member]['is_admin'] = True
                                            else:
                                                user_details[member]['is_admin'] = False
                                            if member == user_id:
                                                room_info['user_status'] = room_info['room_members'][member]['status']
                                            user_details[member]['user_status'] = room_info['room_members'][member][
                                                'status']
                                        else:
                                            if member == user_id:
                                                room_info['user_status'] = "active"
                                            user_details[member]['user_status'] = "active"
                                        d = {key: value for key, value in user_details[member].items() if
                                             key not in 'profile_pic'}
                                        if user_details[member].get('user_status'):
                                            del user_details[member]['user_status']
                                        if user_details[member].get('is_admin'):
                                            del user_details[member]['is_admin']
                                        member_list.append(d)
                                room_info['room_members'] = member_list
                                if room_info.get('group_photo'):
                                    room_info['avatar_url'], status = s3_function.generate_presigned_url_from_s3(
                                        room_info['group_photo']['avatar_url'])
                                    del room_info['group_photo']

                                if room_info.get('group_description'):
                                    room_info['description'] = str(room_info['group_description']['description'])
                                    del room_info['group_description']

                                if room_info.get('course_work_id'):
                                    room_info['course_work_id'] = str(room_info['course_work_id'])

                                if room_info.get('cw_instance_id'):
                                    room_info['cw_instance_id'] = str(room_info['cw_instance_id'])
                                del room_info['admins']
                                team_doc['cw_group_chat'] = room_info
                                if len(room_info['room_members']) == 1:
                                    team_doc['cw_group_chat'] = None
                        team_info.append(team_doc)

        course_work_resources = work_data["course_work_resources"]
        current_date = str(utc_datetime_now().date()).split('-')
        data = {"_id": str(work['_id']),
                "course_work_resources": course_work_resources,
                "title": work_data['courseWorkTitle'],
                "group_type": schedule_data["group_type"],
                "group_size": work_data["group_size"],
                "is_group": work_data["is_group"],
                "course_work_description": renew_s3_links(work_data["course_work_description"]),
                "submission_requirement": work_data["submissionRequirement"],
                "date": schedule_data["start_date"] if course_class != 'Self Paced Course' else {'year': int(current_date[0]),'month': int(current_date[1]),'day': int(current_date[2])},
                "time": schedule_data["start_time"] if course_class != 'Self Paced Course' else "00:00",
                "schedule_id": str(work["schedule_id"]),
                "team_info": team_info,
                "publish": schedule_data.get("submission_publish", False)}

        # PK - Added code for peer review and self review
        if schedule_data.get('peer_review'):
            if schedule_data['peer_review'] == True and not schedule_data["group_type"]:
                data['peer_review'] = True
            else:
                data['peer_review'] = False
        else:
            data['peer_review'] = False

        if schedule_data.get('self_review'):
            if schedule_data['self_review'] == True and not schedule_data["group_type"]:
                data['self_review'] = True
            else:
                data['self_review'] = False
        else:
            data['self_review'] = False

        processed_course_work.append(data)
    return processed_course_work
    