from db_wrapper.tasks import Mongo
from bson import ObjectId
from services.storage.s3_services import s3_storage
from utils.time_conversions import utc_datetime_now, str_to_utc_datetime_obj, \
    convert_utc_to_ist
import re
import time
from model.courses.misc import manage_course_s3_resources
from utils.elasticsearch.resource_bank import insert_resource_elastic
s3_function = s3_storage()
mongo_session = Mongo()


def edit_course_resources(course_data, course_resources, user_id, delete_list_temp_files, existing_resources,
                          delete_resource_list):
    instance_ids = []
    db_course_resources = course_data["resources"]
    for course_resource in course_resources:
        if course_resource['type'] == 'file':
            if not any(
                    data['_id'] == ObjectId(course_resource['_id']) for data in db_course_resources):
                resource_id = course_resource['_id']
                check_resource = mongo_session.check_existance_return_info(collection='global_resource_bank',
                                                                           condition={'_id': ObjectId(resource_id)},
                                                                           whole_doc=True)
                if check_resource:
                    doc_to_insert = {
                        "resource_id": ObjectId(resource_id),
                        "tags": [],
                        "description": "",
                        "title": course_resource['title'],
                        "module": "course",
                        "used_at": "",
                        "updated_at": utc_datetime_now(),
                        "updated_by": ObjectId(user_id),
                    }
                    course_resource['url'] = check_resource['s3_key']
                    course_resource['_id'] = ObjectId(resource_id)
                    resp_id = mongo_session.insert_documnet(collection="resource_bank_instance",
                                                            doc_to_insert=doc_to_insert)
                    course_resource['instance_id'] = resp_id['_id'].inserted_id
                    instance_ids.append(course_resource['instance_id'])

                elif check_resource is None:
                    course_bank_find = mongo_session.check_existance_return_info(collection='course_resource_bank',
                                                                                 condition={
                                                                                     "_id": ObjectId(resource_id)
                                                                                 },
                                                                                 whole_doc=True)
                    if course_bank_find:
                        some = mongo_session.transfer_docs_another_collection(from_collection='course_resource_bank',
                                                                              to_collection='global_resource_bank',
                                                                              condition={"_id": ObjectId(resource_id)})
                        course_resource['url'] = course_bank_find['s3_key']
                        course_resource['_id'] = ObjectId(resource_id)
                    passion_project_find = mongo_session.check_existance_return_info(collection='resources',
                                                                                     condition={
                                                                                         "_id": ObjectId(resource_id)
                                                                                     },
                                                                                     whole_doc=True)
                    if passion_project_find:
                        some = mongo_session.transfer_docs_another_collection(from_collection='resources',
                                                                              to_collection='global_resource_bank',
                                                                              condition={"_id": ObjectId(resource_id)})
                        course_resource['url'] = passion_project_find['s3_key']
                        course_resource['_id'] = ObjectId(resource_id)
                    if passion_project_find or course_bank_find:
                        doc_to_insert = {
                            "resource_id": ObjectId(resource_id),
                            "tags": [],
                            "description": "",
                            "title": course_resource['title'],
                            "module": "course",
                            "used_at": "",
                            "updated_at": utc_datetime_now(),
                            "updated_by": ObjectId(user_id),
                        }
                        resp_id = mongo_session.insert_documnet(collection="resource_bank_instance",
                                                                doc_to_insert=doc_to_insert)
                        course_resource['instance_id'] = resp_id['_id'].inserted_id
                        instance_ids.append(course_resource['instance_id'])
                    else:
                        delete_list_temp_files.append(ObjectId(resource_id))
                        resource_bank_resource_id, s3_key_info = manage_course_s3_resources(resource_id)
                        course_resource['_id'] = resource_bank_resource_id
                        course_resource['url'] = s3_key_info['message']
                        if s3_key_info['status'] != 200:
                            raise Exception("Some internal error occurred, Please try again later.")
                        resource_info = mongo_session.check_existance_return_info(collection='global_resource_bank',
                                                                                  condition={
                                                                                      '_id': ObjectId(
                                                                                          resource_bank_resource_id)},
                                                                                  return_keys=['uploaded_at',
                                                                                               'user_id'])
                        doc_to_insert = {
                            "resource_id": ObjectId(resource_id),
                            "tags": [],
                            "description": "",
                            "title": course_resource['title'],
                            "module": "course",
                            "used_at": "",
                            "updated_at": utc_datetime_now(),
                            "updated_by": ObjectId(user_id),
                        }
                        resp_id = mongo_session.insert_documnet(collection="resource_bank_instance",
                                                                doc_to_insert=doc_to_insert)
                        course_resource['instance_id'] = resp_id['_id'].inserted_id
                        instance_ids.append(course_resource['instance_id'])
                        created_at = time.strftime('%Y-%m-%d %H:%M', time.localtime(int(resource_info['uploaded_at'])))
                        item_type = ""
                        if re.findall('\.mp4', course_resource['url']):
                            item_type = "video"
                        if re.findall('\.png|\.jpg|\.jpeg', course_resource['url']):
                            item_type = "image"
                        if re.findall('\.pdf|\.zip|\.doc|\.docx|\.ppt|\.pptx|\.txt|\.xml|\.rar|\.csv|\.mp3|\.xlsx',
                                      course_resource['url']):
                            item_type = "file"
                        if re.findall('\.py|\.ipynb', course_resource['url']):
                            item_type = "python"

                        data_resource = {'url': course_resource['url'], '_id': resource_bank_resource_id,
                                         'title': course_resource['title'], 'description': "", 'module_name': 'course',
                                         'mongo_collection': 'course_resource_bank', 'tags': [],
                                         'created_by': resource_info['user_id'], 'created_at': created_at,
                                         'file_type': item_type}
                        insert_resource_elastic(data_resource)
            else:
                for data in db_course_resources:
                    if data['_id'] == ObjectId(course_resource['_id']):
                        course_resource['url'] = data['url']
                        course_resource['_id'] = data['_id']
                        existing_resources.append(data['_id'])
    delete_resource_list = delete_resource_list + [data['_id'] for data in db_course_resources if
                                                   '_id' in data and (data['_id'] not in existing_resources) and data[
                                                       '_id'] != ""]
    delete_course_resource_instances = [data.get('instance_id', '') for data in db_course_resources if
                                        '_id' in data and (data['_id'] not in existing_resources) and data[
                                            '_id'] != ""]
    for ids in delete_course_resource_instances:
        if ids != '':
            mongo_session.delete_data(collection='resource_bank_instance', condition={'_id': ObjectId(ids)})
    return instance_ids, delete_list_temp_files, existing_resources, delete_resource_list


def upload_course_resources(course_resources, delete_record_list, user_id):
    instance_ids = []
    for resource in course_resources:
        if resource['type'] == 'file':
            resource_id = resource['_id']
            delete_record_list.append(ObjectId(resource_id))
            check_resource = mongo_session.check_existance_return_info(collection='global_resource_bank',
                                                                       condition={'_id': ObjectId(resource_id)},
                                                                       whole_doc=True)
            if check_resource:
                doc_to_insert = {
                    "resource_id": ObjectId(resource_id),
                    "tags": [],
                    "description": "",
                    "title": resource['title'],
                    "module": "course",
                    "used_at": "",
                    "updated_at": utc_datetime_now(),
                    "updated_by": ObjectId(user_id),
                }
                resource['url'] = check_resource['s3_key']
                resource['_id'] = ObjectId(resource_id)
                resp_id = mongo_session.insert_documnet(collection="resource_bank_instance",
                                                        doc_to_insert=doc_to_insert)
                resource['instance_id'] = resp_id['_id'].inserted_id
                instance_ids.append(resource['instance_id'])

            elif check_resource is None:
                course_bank_find = mongo_session.check_existance_return_info(collection='course_resource_bank',
                                                                             condition={
                                                                                 "_id": ObjectId(resource_id)
                                                                             },
                                                                             whole_doc=True)
                if course_bank_find:
                    some = mongo_session.transfer_docs_another_collection(from_collection='course_resource_bank',
                                                                          to_collection='global_resource_bank',
                                                                          condition={"_id": ObjectId(resource_id)})
                    resource['url'] = course_bank_find['s3_key']
                    resource['_id'] = ObjectId(resource_id)
                passion_project_find = mongo_session.check_existance_return_info(collection='resources',
                                                                                 condition={
                                                                                     "_id": ObjectId(resource_id)
                                                                                 },
                                                                                 whole_doc=True)
                if passion_project_find:
                    some = mongo_session.transfer_docs_another_collection(from_collection='resources',
                                                                          to_collection='global_resource_bank',
                                                                          condition={"_id": ObjectId(resource_id)})
                    resource['url'] = passion_project_find['s3_key']
                    resource['_id'] = ObjectId(resource_id)
                if passion_project_find or course_bank_find:
                    doc_to_insert = {
                        "resource_id": ObjectId(resource_id),
                        "tags": [],
                        "description": "",
                        "title": resource['title'],
                        "module": "course",
                        "used_at": "",
                        "updated_at": utc_datetime_now(),
                        "updated_by": ObjectId(user_id),
                    }
                    resp_id = mongo_session.insert_documnet(collection="resource_bank_instance",
                                                            doc_to_insert=doc_to_insert)
                    resource['instance_id'] = resp_id['_id'].inserted_id
                    instance_ids.append(resource['instance_id'])
                else:
                    resource_bank_resource_id, s3_key_info = manage_course_s3_resources(resource_id)
                    resource['_id'] = resource_bank_resource_id
                    if s3_key_info['status'] != 200:
                        raise Exception("Error occurred while adding resources")
                    resource['url'] = s3_key_info['message']
                    resource_info = mongo_session.check_existance_return_info(collection='global_resource_bank',
                                                                              condition={
                                                                                  '_id': ObjectId(
                                                                                      resource_bank_resource_id)},
                                                                              return_keys=['uploaded_at', 'user_id'])
                    doc_to_insert = {
                        "resource_id": ObjectId(resource_bank_resource_id),
                        "tags": [],
                        "description": "",
                        "title": resource['title'],
                        "module": "course",
                        "used_at": "",
                        "updated_at": utc_datetime_now(),
                        "updated_by": ObjectId(user_id),
                    }
                    resp_id = mongo_session.insert_documnet(collection="resource_bank_instance",
                                                            doc_to_insert=doc_to_insert)
                    resource['instance_id'] = resp_id['_id'].inserted_id
                    instance_ids.append(resource['instance_id'])
                    created_at = time.strftime('%Y-%m-%d %H:%M', time.localtime(int(resource_info['uploaded_at'])))
                    item_type = ""
                    if re.findall('\.mp4', resource['url']):
                        item_type = "video"
                    if re.findall('\.png|\.jpg|\.jpeg', resource['url']):
                        item_type = "image"
                    if re.findall('\.pdf|\.zip|\.doc|\.docx|\.ppt|\.pptx|\.txt|\.xml|\.rar|\.csv|\.mp3|\.xlsx',
                                  resource['url']):
                        item_type = "file"
                    if re.findall('\.py|\.ipynb', resource['url']):
                        item_type = "python"

                    data_resource = {'url': resource['url'], '_id': resource_bank_resource_id,
                                     'title': resource['title'],
                                     'description': "", 'module_name': 'course',
                                     'mongo_collection': 'course_resource_bank',
                                     'tags': [], 'created_by': resource_info['user_id'], 'created_at': created_at,
                                     'file_type': item_type}
                    insert_resource_elastic(data_resource)
    return instance_ids, delete_record_list
