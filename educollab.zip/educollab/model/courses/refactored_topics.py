from utils.misc import renew_s3_links
from db_wrapper.tasks import Mongo
from bson import ObjectId
from routes.exception import InvalidUsage
from services.storage.s3_services import s3_storage
from utils.time_conversions import utc_datetime_now, str_to_utc_datetime_obj, \
    convert_utc_to_ist
import youtube_dl
import re
import config
import model.Question as Question
import datetime
import time
from model.courses.misc import seen_asess_feedback, upload_course_topic, update_schedule_course_work, \
    update_schedule_assessment, upload_course_session, manage_course_s3_resources, schedule_course_work
from utils.elasticsearch.resource_bank import insert_resource_elastic
import model.Content as Content
s3_function = s3_storage()
mongo_session = Mongo()


def view_course_topics(course_data, user_id, role, course_id, topic_list = None):
    """To process course coursework in view course.
        :param course_data: course data from mongo query.
        :type: dict
        :param user_id: user id
        :type: string
        :param role: role
        :type: string
        :param course_id: course id
        :type: string
    """
    # topics
    processed_topics = []
    for topic in course_data["topics"]:
        topic_query = mongo_session.get_all_data_for_particular_condition_fields(
            collection="course_topics",
            condition={"_id": ObjectId(topic["_id"])})
        if topic_query['status'] != 200:
            raise InvalidUsage("Something went wrong, please try again later.", 500)
        topic_data = topic_query['message'][0]
        topic_duration = []
        total_live_sessions = 0
        for session in topic_data['sessions']:
            session_query = mongo_session.get_all_data_for_particular_condition_fields(
                collection="course_sessions",
                condition={"_id": ObjectId(session["_id"])})
            if session_query['status'] != 200:
                raise InvalidUsage("Something went wrong, please try again later.", 500)
            session_data = session_query['message'][0]
            s3_url = session_data['url']
            session_data["file_id"] = str(session_data["file_id"])
            if session_data["key"] == "live_session":
                total_live_sessions = total_live_sessions + 1
            # video duration code for session
            try:
                pattern = re.compile(
                    "^((?:https?:)?\/\/)?((?:www|m)\.)?((?:youtube(-nocookie)?\.com|youtu.be))(\/(?:[\w\-]+\?v=|embed\/|v\/)?)([\w\-]+)(\S+)?$")
                if pattern.match(session_data['url']):
                    video_query = mongo_session.get_all_data_for_particular_condition_fields(
                        collection="youtube_video_duration",
                        condition={"video_url": session_data['url']})
                    if video_query['status'] != 200:
                        raise InvalidUsage("Something went wrong, please try again later.", 500)
                    video_data = video_query["message"]
                    if video_data:
                        session_data['duration'] = video_data[0]['duration']
                    else:
                        ydl_opts = {}
                        with youtube_dl.YoutubeDL(ydl_opts) as ydl:
                            dictmeta = ydl.extract_info(session_data['url'], download=False)
                        seconds = dictmeta['duration']
                        seconds = seconds % (24 * 3600)
                        hour = seconds // 3600
                        seconds %= 3600
                        minutes = seconds // 60
                        seconds %= 60
                        session_data['duration'] = "%02d:%02d:%02d" % (hour, minutes, seconds)
                        video_doc_to_insert = {"video_url": session_data['url'], "duration": session_data['duration']}
                        video_duration_status = mongo_session.insert_documnet(collection="youtube_video_duration",
                                                                              doc_to_insert=video_doc_to_insert)
                        if video_duration_status["status"] != 200:
                            raise Exception("Some internal error, Please try again later.")
                else:
                    res = config.s3_connection.head_object(Bucket=config.bucket, Key=session_data['url'])
                    session_data['duration'] = str(res['Metadata'].get('duration', "00:00:00"))
            except Exception as e:
                print("S3 duration block ", e)
                session_data['duration'] = "00:00:00"
            topic_duration.append(session_data['duration'])
        # calculating time duration of topic
        tp_duration = []
        for time_str in topic_duration:
            h, m, s = time_str.split(':')
            tp_duration.append(int(h) * 3600 + int(m) * 60 + int(s))
        seconds = sum(tp_duration)
        seconds = seconds % (24 * 3600)
        hours = seconds // 3600
        seconds %= 3600
        minutes = seconds // 60
        seconds %= 60
        topic_dur = "%02d:%02d:%02d" % (hours, minutes, seconds)
        if not topic_data['sessions'] and not topic_data['course_work'] and not topic_data['assessments'] and not topic_data['resources'] \
                and role == 'student':
            continue
        else:
            if topic_list:
                topic_info = {"_id": str(topic["_id"]),
                          "title": topic_data['title'],
                          "duration": topic_dur,
                          "total_resources": len(topic_data['resources']),
                          "total_sessions": len(topic_data['sessions']),
                          "total_live_sessions": total_live_sessions}
            else:
                topic_info = {"_id": str(topic["_id"]),
                            "title": topic_data['title'],
                            "description": topic_data['description'],
                            "duration": topic_dur,
                            "total_resources": len(topic_data['resources']),
                            "total_assessments": len(topic_data['assessments']),
                            "total_coursework": len(topic_data['course_work']),
                            "total_sessions": len(topic_data['sessions']),
                            "total_live_sessions": total_live_sessions}
            processed_topics.append(topic_info)
    return processed_topics


def edit_course_topics(topics, unique_assess, user_id, course_status, delete_list_temp_files, timestamp_obj,
                       delete_resource_list, course_class):
    processed_topics = []
    instance_ids_topics = []
    for topic in topics:
        if not topic["_id"]:
            processed_topic, delete_resources, unique_assess = upload_course_topic(topic, unique_assess, user_id, course_class)
            processed_topics.append(processed_topic)
            delete_list_temp_files = delete_list_temp_files + delete_resources
        else:
            # existed topic
            # topic resources
            topic_query = mongo_session.get_all_data_for_particular_condition_fields(
                collection='course_topics',
                condition={"_id": ObjectId(topic["_id"])})
            if topic_query['status'] != 200:
                raise Exception("Something went wrong, Please try again later.")
            topic_data = topic_query['message'][0]

            existing_resources = []
            db_topic_resources = topic_data["resources"]
            for topic_resource in topic["resources"]:
                if topic_resource['type'] == 'file':
                    if not any(
                            data['_id'] == ObjectId(topic_resource['_id']) for data in db_topic_resources):
                        resource_id = topic_resource['_id']
                        check_resource = mongo_session.check_existance_return_info(collection='global_resource_bank',
                                                                                   condition={
                                                                                       '_id': ObjectId(resource_id)},
                                                                                   whole_doc=True)
                        if check_resource:
                            doc_to_insert = {
                                "resource_id": ObjectId(resource_id),
                                "tags": [],
                                "description": "",
                                "title": topic_resource['title'],
                                "module": "course",
                                "used_at": "",
                                "updated_at": utc_datetime_now(),
                                "updated_by": ObjectId(user_id),
                            }
                            topic_resource['url'] = check_resource['s3_key']
                            topic_resource['_id'] = ObjectId(resource_id)
                            resp_id = mongo_session.insert_documnet(collection="resource_bank_instance",
                                                                    doc_to_insert=doc_to_insert)
                            topic_resource['instance_id'] = resp_id['_id'].inserted_id
                            instance_ids_topics.append(topic_resource['instance_id'])

                        elif check_resource is None:
                            course_bank_find = mongo_session.check_existance_return_info(
                                collection='course_resource_bank',
                                condition={
                                    "_id": ObjectId(resource_id)
                                },
                                whole_doc=True)
                            if course_bank_find:
                                some = mongo_session.transfer_docs_another_collection(
                                    from_collection='course_resource_bank',
                                    to_collection='global_resource_bank',
                                    condition={"_id": ObjectId(resource_id)})
                                topic_resource['url'] = course_bank_find['s3_key']
                                topic_resource['_id'] = ObjectId(resource_id)
                            passion_project_find = mongo_session.check_existance_return_info(collection='resources',
                                                                                             condition={
                                                                                                 "_id": ObjectId(
                                                                                                     resource_id)
                                                                                             },
                                                                                             whole_doc=True)
                            if passion_project_find:
                                some = mongo_session.transfer_docs_another_collection(from_collection='resources',
                                                                                      to_collection='global_resource_bank',
                                                                                      condition={
                                                                                          "_id": ObjectId(resource_id)})
                                topic_resource['url'] = passion_project_find['s3_key']
                                topic_resource['_id'] = ObjectId(resource_id)
                            if passion_project_find or course_bank_find:
                                doc_to_insert = {
                                    "resource_id": ObjectId(resource_id),
                                    "tags": [],
                                    "description": "",
                                    "title": topic_resource['title'],
                                    "module": "course",
                                    "used_at": "",
                                    "updated_at": utc_datetime_now(),
                                    "updated_by": ObjectId(user_id),
                                }
                                resp_id = mongo_session.insert_documnet(collection="resource_bank_instance",
                                                                        doc_to_insert=doc_to_insert)
                                topic_resource['instance_id'] = resp_id['_id'].inserted_id
                                instance_ids_topics.append(topic_resource['instance_id'])
                            else:
                                delete_list_temp_files.append(ObjectId(resource_id))
                                resource_bank_resource_id, s3_key_info = manage_course_s3_resources(resource_id)
                                topic_resource['_id'] = resource_bank_resource_id
                                topic_resource['url'] = s3_key_info['message']
                                if s3_key_info['status'] != 200:
                                    raise Exception("Some internal error occurred, Please try again later.")
                                resource_info = mongo_session.check_existance_return_info(
                                    collection='global_resource_bank',
                                    condition={
                                        '_id': ObjectId(
                                            resource_bank_resource_id)},
                                    return_keys=['uploaded_at',
                                                 'user_id'])
                                doc_to_insert = {
                                    "resource_id": ObjectId(resource_id),
                                    "tags": [],
                                    "description": "",
                                    "title": topic_resource['title'],
                                    "module": "course",
                                    "used_at": "",
                                    "updated_at": utc_datetime_now(),
                                    "updated_by": ObjectId(user_id),
                                }
                                resp_id = mongo_session.insert_documnet(collection="resource_bank_instance",
                                                                        doc_to_insert=doc_to_insert)
                                topic['instance_id'] = resp_id['_id'].inserted_id
                                instance_ids_topics.append(topic_resource['instance_id'])
                                created_at = time.strftime('%Y-%m-%d %H:%M',
                                                           time.localtime(int(resource_info['uploaded_at'])))
                                item_type = ""
                                if re.findall('\.mp4', topic_resource['url']):
                                    item_type = "video"
                                if re.findall('\.png|\.jpg|\.jpeg', topic_resource['url']):
                                    item_type = "image"
                                if re.findall(
                                        '\.pdf|\.zip|\.doc|\.docx|\.ppt|\.pptx|\.txt|\.xml|\.rar|\.csv|\.mp3|\.xlsx',
                                        topic_resource['url']):
                                    item_type = "file"
                                if re.findall('\.py|\.ipynb', topic_resource['url']):
                                    item_type = "python"

                                data_resource = {'url': topic_resource['url'], '_id': resource_bank_resource_id,
                                                 'title': topic_resource['title'],
                                                 'description': "", 'module_name': 'course',
                                                 'mongo_collection': 'course_resource_bank',
                                                 'tags': [], 'created_by': resource_info['user_id'],
                                                 'created_at': created_at,
                                                 'file_type': item_type}
                                insert_resource_elastic(data_resource)
                    else:
                        for data in db_topic_resources:
                            if data['_id'] == ObjectId(topic_resource['_id']):
                                topic_resource['url'] = data['url']
                                topic_resource['_id'] = data['_id']
                                existing_resources.append(data['_id'])
            delete_resource_list = delete_resource_list + [data['_id'] for data in db_topic_resources if
                                                           '_id' in data and (data['_id'] not in existing_resources) and
                                                           data['_id'] != ""]
            delete_course_resource_instances = [data.get('instance_id', '') for data in db_topic_resources if
                                                '_id' in data and (data['_id'] not in existing_resources) and data[
                                                    '_id'] != ""]
            for ids in delete_course_resource_instances:
                if ids != '':
                    mongo_session.delete_data(collection='resource_bank_instance', condition={'_id': ObjectId(ids)})
            # topic course work
            topic_course_work = []
            db_topic_course_work = topic_data["course_work"]
            for work in topic["course_work"]:
                work["_id"] = str(work["_id"])
                schedule_id = ""
                for data in db_topic_course_work:
                    if str(data["_id"]) == work["_id"]:
                        schedule_id = data["schedule_id"]
                tcw_st_dt_str = Content.webapp_time_to_string(work["date"], work["time"])  # topic level course work
                fields_to_update = {
                    "start_date": work["date"],
                    "start_time": work["time"],
                    "start_datetime": str_to_utc_datetime_obj(time_string=tcw_st_dt_str,
                                                              date_format="%Y:%m:%dT%H:%M")
                }
                if not schedule_id:
                    # schedule course work
                    schedule_course_work_id = schedule_course_work(
                        course_work_data=work,
                        course_work_type="course")
                    topic_course_work.append({"_id": ObjectId(work['_id']),
                                              "schedule_id": schedule_course_work_id})
                elif course_status == "publish":
                    schedule_work_info = mongo_session.get_data_for_particular_columns_with_condition(
                        collection="course_work_instances",
                        condition={"_id": schedule_id},
                        columns={"start_time": 1, "start_date": 1})
                    if schedule_work_info["status"] != 200:
                        raise Exception("Some internal error occurred, please try again later.")
                    db_work_start_time = Content.webapp_time_to_string(
                        schedule_work_info["message"][0]["start_date"], schedule_work_info["message"][0]["start_time"])
                    db_work_start_time = datetime.datetime.strptime(db_work_start_time, "%Y:%m:%dT%H:%M")

                    new_start_time = Content.webapp_time_to_string(work['date'], work['time'])
                    new_start_time = datetime.datetime.strptime(new_start_time, "%Y:%m:%dT%H:%M")

                    if timestamp_obj < db_work_start_time and timestamp_obj < new_start_time:
                        schedule_course_work_id = update_schedule_course_work(fields_to_update, "course", schedule_id)
                        topic_course_work.append({"_id": ObjectId(work['_id']),
                                                  "schedule_id": schedule_course_work_id})

                    else:
                        topic_course_work.append({"_id": ObjectId(work['_id']),
                                                  "schedule_id": schedule_id})
                else:  # unpublish
                    schedule_course_work_id = update_schedule_course_work(fields_to_update, "course", schedule_id)
                    topic_course_work.append({"_id": ObjectId(work['_id']),
                                              "schedule_id": schedule_course_work_id})
            # topic assessments
            db_topic_assessments = topic_data["assessments"]
            topic_assessments = []
            for assessment in topic["assessments"]:
                assessment["_id"] = str(assessment["_id"])
                if assessment["_id"] in unique_assess:
                    raise InvalidUsage("An assessment can only be used once in a course.", 400)
                unique_assess.append(assessment["_id"])
                if assessment["calendered"] or assessment["is_timed"]:
                    if course_class == "Self Paced Course":
                        raise InvalidUsage("Calendered or Timed assessment not allowed in Self Paced Courses.", 406)
                if not assessment["calendered"] and not assessment["one_time_assessment"] and not assessment[
                    "is_timed"]:  # not calendered , not one time and not is_timed
                    topic_assessments.append({"_id": ObjectId(assessment['_id']),
                                                  "is_timed": bool(assessment["is_timed"]),
                                                  "one_time_assessment": bool(assessment["one_time_assessment"]),
                                                  "calendered": bool(assessment["calendered"])})

                elif not assessment["calendered"] and not assessment['one_time_assessment'] and assessment[
                    "is_timed"]:  # not calendered , not one time and  is_timed
                    topic_assessments.append({"_id": ObjectId(assessment['_id']),
                                                  "is_timed": bool(assessment["is_timed"]),
                                                  "one_time_assessment": bool(assessment["one_time_assessment"]),
                                                  "calendered": bool(assessment["calendered"])})


                elif not assessment["calendered"] and assessment['one_time_assessment'] and not assessment[
                    "is_timed"]:  # not calendered ,  one time and not is_timed
                    topic_assessments.append({"_id": ObjectId(assessment['_id']),
                                                  "is_timed": bool(assessment["is_timed"]),
                                                  "one_time_assessment": bool(assessment["one_time_assessment"]),
                                                  "calendered": bool(assessment["calendered"])})

                elif not assessment["calendered"] and assessment['one_time_assessment'] and assessment[
                    "is_timed"]:  # not calendered ,  one time and  is_timed
                    topic_assessments.append({"_id": ObjectId(assessment['_id']),
                                              "is_timed": bool(assessment["is_timed"]),
                                              "one_time_assessment": bool(assessment["one_time_assessment"]),
                                              "calendered": bool(assessment["calendered"])})



                elif assessment['calendered'] and assessment['one_time_assessment'] and not assessment["is_timed"]:
                    schedule_id = ""
                    for data in db_topic_assessments:
                        if str(data["_id"]) == assessment["_id"]:
                            if not data.get("schedule_id"):
                                return "Can't add same assessment twice at same level.", 409
                            schedule_id = data["schedule_id"]

                    if not schedule_id:
                        # schedule assessment
                        schedule_assessment_id = Content.schedule_assessment(
                            assessment_data=assessment,
                            assessment_type="course")
                        topic_assessments.append({"_id": ObjectId(assessment['_id']),
                                                  "schedule_id": schedule_assessment_id,
                                                  "is_timed": bool(assessment["is_timed"]),
                                                  "one_time_assessment": bool(assessment["one_time_assessment"]),
                                                  "calendered": bool(assessment["calendered"])})
                    elif course_status == "publish":
                        schedule_assess_info = mongo_session.get_data_for_particular_columns_with_condition(
                            collection="schedule_assessment",
                            condition={"_id": schedule_id},
                            columns={"start_time": 1})
                        if schedule_assess_info["status"] != 200:
                            raise Exception("Some internal error occurred, please try again later.")
                        db_assess_start_time = datetime.datetime.strptime(
                            schedule_assess_info["message"][0]["start_time"],
                            "%Y:%m:%dT%H:%M")
                        new_start_time = Content.webapp_time_to_string(assessment['date'], assessment['time'])
                        new_start_time = datetime.datetime.strptime(new_start_time, "%Y:%m:%dT%H:%M")

                        if timestamp_obj < db_assess_start_time and timestamp_obj < new_start_time:
                            schedule_assessment_id = update_schedule_assessment(assessment, "course", schedule_id)
                            topic_assessments.append({"_id": ObjectId(assessment['_id']),
                                                      "schedule_id": schedule_assessment_id,
                                                      "is_timed": bool(assessment["is_timed"]),
                                                      "one_time_assessment": bool(assessment["one_time_assessment"]),
                                                      "calendered": bool(assessment["calendered"])})
                        else:
                            topic_assessments.append({"_id": ObjectId(assessment['_id']),
                                                      "schedule_id": schedule_id,
                                                      "is_timed": bool(assessment["is_timed"]),
                                                      "one_time_assessment": bool(assessment["one_time_assessment"]),
                                                      "calendered": bool(assessment["calendered"])})
                    else:  # unpublish
                        schedule_assessment_id = update_schedule_assessment(assessment, "course", schedule_id)
                        topic_assessments.append({"_id": ObjectId(assessment['_id']),
                                                  "schedule_id": schedule_assessment_id,
                                                  "is_timed": bool(assessment["is_timed"]),
                                                  "one_time_assessment": bool(assessment["one_time_assessment"]),
                                                  "calendered": bool(assessment["calendered"])})

                elif assessment['calendered'] and not assessment['one_time_assessment'] and not assessment["is_timed"]:

                    schedule_id = ""
                    for data in db_topic_assessments:
                        if str(data["_id"]) == assessment["_id"]:
                            if not data.get("schedule_id"):
                                return "Can't add same assessment twice at same level.", 409
                            schedule_id = data["schedule_id"]

                    if not schedule_id:
                        # schedule assessment
                        schedule_assessment_id = Content.schedule_assessment(
                            assessment_data=assessment,
                            assessment_type="course")
                        topic_assessments.append({"_id": ObjectId(assessment['_id']),
                                                  "schedule_id": schedule_assessment_id,
                                                  "is_timed": bool(assessment["is_timed"]),
                                                  "one_time_assessment": bool(assessment["one_time_assessment"]),
                                                  "calendered": bool(assessment["calendered"])})
                    elif course_status == "publish":
                        schedule_assess_info = mongo_session.get_data_for_particular_columns_with_condition(
                            collection="schedule_assessment",
                            condition={"_id": schedule_id},
                            columns={"start_time": 1})
                        if schedule_assess_info["status"] != 200:
                            raise Exception("Some internal error occurred, please try again later.")
                        db_assess_start_time = datetime.datetime.strptime(
                            schedule_assess_info["message"][0]["start_time"],
                            "%Y:%m:%dT%H:%M")
                        new_start_time = Content.webapp_time_to_string(assessment['date'], assessment['time'])
                        new_start_time = datetime.datetime.strptime(new_start_time, "%Y:%m:%dT%H:%M")

                        if timestamp_obj < db_assess_start_time and timestamp_obj < new_start_time:
                            schedule_assessment_id = update_schedule_assessment(assessment, "course", schedule_id)
                            topic_assessments.append({"_id": ObjectId(assessment['_id']),
                                                      "schedule_id": schedule_assessment_id,
                                                      "is_timed": bool(assessment["is_timed"]),
                                                      "one_time_assessment": bool(assessment["one_time_assessment"]),
                                                      "calendered": bool(assessment["calendered"])})
                        else:
                            topic_assessments.append({"_id": ObjectId(assessment['_id']),
                                                      "schedule_id": schedule_id,
                                                      "is_timed": bool(assessment["is_timed"]),
                                                      "one_time_assessment": bool(assessment["one_time_assessment"]),
                                                      "calendered": bool(assessment["calendered"])})
                    else:  # unpublish
                        schedule_assessment_id = update_schedule_assessment(assessment, "course", schedule_id)
                        topic_assessments.append({"_id": ObjectId(assessment['_id']),
                                                  "schedule_id": schedule_assessment_id,
                                                  "is_timed": bool(assessment["is_timed"]),
                                                  "one_time_assessment": bool(assessment["one_time_assessment"]),
                                                  "calendered": bool(assessment["calendered"])})


                elif assessment['calendered'] and not assessment['one_time_assessment'] and assessment["is_timed"]:

                    schedule_id = ""
                    for data in db_topic_assessments:
                        if str(data["_id"]) == assessment["_id"]:
                            if not data.get("schedule_id"):
                                return "Can't add same assessment twice at same level.", 409
                            schedule_id = data["schedule_id"]

                    if not schedule_id:
                        # schedule assessment
                        schedule_assessment_id = Content.schedule_assessment(
                            assessment_data=assessment,
                            assessment_type="course")
                        topic_assessments.append({"_id": ObjectId(assessment['_id']),
                                                  "schedule_id": schedule_assessment_id,
                                                  "is_timed": bool(assessment["is_timed"]),
                                                  "one_time_assessment": bool(assessment["one_time_assessment"]),
                                                  "calendered": bool(assessment["calendered"])})
                    elif course_status == "publish":
                        schedule_assess_info = mongo_session.get_data_for_particular_columns_with_condition(
                            collection="schedule_assessment",
                            condition={"_id": schedule_id},
                            columns={"start_time": 1})
                        if schedule_assess_info["status"] != 200:
                            raise Exception("Some internal error occurred, please try again later.")
                        db_assess_start_time = datetime.datetime.strptime(
                            schedule_assess_info["message"][0]["start_time"],
                            "%Y:%m:%dT%H:%M")
                        new_start_time = Content.webapp_time_to_string(assessment['date'], assessment['time'])
                        new_start_time = datetime.datetime.strptime(new_start_time, "%Y:%m:%dT%H:%M")

                        if timestamp_obj < db_assess_start_time and timestamp_obj < new_start_time:
                            schedule_assessment_id = update_schedule_assessment(assessment, "course", schedule_id)
                            topic_assessments.append({"_id": ObjectId(assessment['_id']),
                                                      "schedule_id": schedule_assessment_id,
                                                      "is_timed": bool(assessment["is_timed"]),
                                                      "one_time_assessment": bool(assessment["one_time_assessment"]),
                                                      "calendered": bool(assessment["calendered"])})
                        else:
                            topic_assessments.append({"_id": ObjectId(assessment['_id']),
                                                      "schedule_id": schedule_id,
                                                      "is_timed": bool(assessment["is_timed"]),
                                                      "one_time_assessment": bool(assessment["one_time_assessment"]),
                                                      "calendered": bool(assessment["calendered"])})
                    else:  # unpublish
                        schedule_assessment_id = update_schedule_assessment(assessment, "course", schedule_id)
                        topic_assessments.append({"_id": ObjectId(assessment['_id']),
                                                  "schedule_id": schedule_assessment_id,
                                                  "is_timed": bool(assessment["is_timed"]),
                                                  "one_time_assessment": bool(assessment["one_time_assessment"]),
                                                  "calendered": bool(assessment["calendered"])})


                elif assessment['calendered'] and assessment['one_time_assessment'] and assessment["is_timed"]:

                    schedule_id = ""
                    for data in db_topic_assessments:
                        if str(data["_id"]) == assessment["_id"]:
                            if not data.get("schedule_id"):
                                return "Can't add same assessment twice at same level.", 409
                            schedule_id = data["schedule_id"]

                    if not schedule_id:
                        # schedule assessment
                        schedule_assessment_id = Content.schedule_assessment(
                            assessment_data=assessment,
                            assessment_type="course")
                        topic_assessments.append({"_id": ObjectId(assessment['_id']),
                                                  "schedule_id": schedule_assessment_id,
                                                  "is_timed": bool(assessment["is_timed"]),
                                                  "one_time_assessment": bool(assessment["one_time_assessment"]),
                                                  "calendered": bool(assessment["calendered"])})
                    elif course_status == "publish":
                        schedule_assess_info = mongo_session.get_data_for_particular_columns_with_condition(
                            collection="schedule_assessment",
                            condition={"_id": schedule_id},
                            columns={"start_time": 1})
                        if schedule_assess_info["status"] != 200:
                            raise Exception("Some internal error occurred, please try again later.")
                        db_assess_start_time = datetime.datetime.strptime(
                            schedule_assess_info["message"][0]["start_time"],
                            "%Y:%m:%dT%H:%M")
                        new_start_time = Content.webapp_time_to_string(assessment['date'], assessment['time'])
                        new_start_time = datetime.datetime.strptime(new_start_time, "%Y:%m:%dT%H:%M")

                        if timestamp_obj < db_assess_start_time and timestamp_obj < new_start_time:
                            schedule_assessment_id = update_schedule_assessment(assessment, "course", schedule_id)
                            topic_assessments.append({"_id": ObjectId(assessment['_id']),
                                                      "schedule_id": schedule_assessment_id,
                                                      "is_timed": bool(assessment["is_timed"]),
                                                      "one_time_assessment": bool(assessment["one_time_assessment"]),
                                                      "calendered": bool(assessment["calendered"])})
                        else:
                            topic_assessments.append({"_id": ObjectId(assessment['_id']),
                                                      "schedule_id": schedule_id,
                                                      "is_timed": bool(assessment["is_timed"]),
                                                      "one_time_assessment": bool(assessment["one_time_assessment"]),
                                                      "calendered": bool(assessment["calendered"])})
                    else:  # unpublish
                        schedule_assessment_id = update_schedule_assessment(assessment, "course", schedule_id)
                        topic_assessments.append({"_id": ObjectId(assessment['_id']),
                                                  "schedule_id": schedule_assessment_id,
                                                  "is_timed": bool(assessment["is_timed"]),
                                                  "one_time_assessment": bool(assessment["one_time_assessment"]),
                                                  "calendered": bool(assessment["calendered"])})
                else:
                    schedule_id = ""
                    for data in db_topic_assessments:
                        if str(data["_id"]) == assessment["_id"]:
                            if not data.get("schedule_id"):
                                return "Can't add same assessment twice at same level.", 409
                            schedule_id = data["schedule_id"]

                    if not schedule_id:
                        # schedule assessment
                        schedule_assessment_id = Content.schedule_assessment(
                            assessment_data=assessment,
                            assessment_type="course")
                        topic_assessments.append({"_id": ObjectId(assessment['_id']),
                                                  "schedule_id": schedule_assessment_id,
                                                  "is_timed": bool(assessment["is_timed"]),
                                                  "one_time_assessment": bool(assessment["one_time_assessment"]),
                                                  "calendered": bool(assessment["calendered"])})
                    elif course_status == "publish":
                        schedule_assess_info = mongo_session.get_data_for_particular_columns_with_condition(
                            collection="schedule_assessment",
                            condition={"_id": schedule_id},
                            columns={"start_time": 1})
                        if schedule_assess_info["status"] != 200:
                            raise Exception("Some internal error occurred, please try again later.")
                        db_assess_start_time = datetime.datetime.strptime(
                            schedule_assess_info["message"][0]["start_time"],
                            "%Y:%m:%dT%H:%M")
                        new_start_time = Content.webapp_time_to_string(assessment['date'], assessment['time'])
                        new_start_time = datetime.datetime.strptime(new_start_time, "%Y:%m:%dT%H:%M")

                        if timestamp_obj < db_assess_start_time and timestamp_obj < new_start_time:
                            schedule_assessment_id = update_schedule_assessment(assessment, "course", schedule_id)
                            topic_assessments.append({"_id": ObjectId(assessment['_id']),
                                                      "schedule_id": schedule_assessment_id,
                                                      "is_timed": bool(assessment["is_timed"]),
                                                      "one_time_assessment": bool(assessment["one_time_assessment"]),
                                                      "calendered": bool(assessment["calendered"])})
                        else:
                            topic_assessments.append({"_id": ObjectId(assessment['_id']),
                                                      "schedule_id": schedule_id,
                                                      "is_timed": bool(assessment["is_timed"]),
                                                      "one_time_assessment": bool(assessment["one_time_assessment"]),
                                                      "calendered": bool(assessment["calendered"])})
                    else:  # unpublish
                        schedule_assessment_id = update_schedule_assessment(assessment, "course", schedule_id)
                        topic_assessments.append({"_id": ObjectId(assessment['_id']),
                                                  "schedule_id": schedule_assessment_id,
                                                  "is_timed": bool(assessment["is_timed"]),
                                                  "one_time_assessment": bool(assessment["one_time_assessment"]),
                                                  "calendered": bool(assessment["calendered"])})
            # topic sessions
            processed_sessions = []
            instance_ids_sessions = []
            for session in topic["sessions"]:
                if not session["_id"]:
                    # new
                    processed_session, delete_resources, unique_assess = upload_course_session(session, unique_assess,
                                                                                               user_id)
                    processed_sessions.append(processed_session)
                    delete_list_temp_files = delete_list_temp_files + delete_resources
                else:
                    is_recording = False
                    # existing session
                    session_query = mongo_session.get_all_data_for_particular_condition_fields(
                        collection='course_sessions',
                        condition={"_id": ObjectId(session["_id"])})
                    if session_query['status'] != 200:
                        raise Exception("Something went wrong, Please try again later.")
                    session_data = session_query['message'][0]
                    url = ""
                    file_id = ""
                    type_of_doc = ""
                    delete_record_list = []
                    if session['key'] == "session":
                        type_of_doc = session['type']
                        if session['type'] == "file" and session["url"]:
                            # no change in session video
                            file_id = ObjectId(session["file_id"])
                            url = session_data["url"]
                        elif session['type'] == "file" and not session["url"]:
                            # new file uploaded
                            resource_id = session['file_id']
                            file_id = ObjectId(session["file_id"])
                            check_resource = mongo_session.check_existance_return_info(
                                collection='global_resource_bank',
                                condition={'_id': ObjectId(resource_id)},
                                whole_doc=True)
                            if check_resource:
                                doc_to_insert = {
                                    "resource_id": ObjectId(resource_id),
                                    "tags": [],
                                    "description": "",
                                    "title": session['title'],
                                    "module": "course",
                                    "used_at": "",
                                    "updated_at": utc_datetime_now(),
                                    "updated_by": ObjectId(user_id),
                                }
                                url = check_resource['s3_key']
                                resp_id = mongo_session.insert_documnet(collection="resource_bank_instance",
                                                                        doc_to_insert=doc_to_insert)
                                instance_id = resp_id['_id'].inserted_id
                                instance_ids_sessions.append(instance_id)

                            elif check_resource is None:
                                course_bank_find = mongo_session.check_existance_return_info(
                                    collection='course_resource_bank',
                                    condition={
                                        "_id": ObjectId(resource_id)
                                    },
                                    whole_doc=True)
                                if course_bank_find:
                                    some = mongo_session.transfer_docs_another_collection(
                                        from_collection='course_resource_bank',
                                        to_collection='global_resource_bank',
                                        condition={"_id": ObjectId(resource_id)})
                                    url = course_bank_find['s3_key']
                                passion_project_find = mongo_session.check_existance_return_info(collection='resources',
                                                                                                 condition={
                                                                                                     "_id": ObjectId(
                                                                                                         resource_id)
                                                                                                 },
                                                                                                 whole_doc=True)
                                if passion_project_find:
                                    some = mongo_session.transfer_docs_another_collection(from_collection='resources',
                                                                                          to_collection='global_resource_bank',
                                                                                          condition={"_id": ObjectId(
                                                                                              resource_id)})
                                    url = passion_project_find['s3_key']
                                if passion_project_find or course_bank_find:
                                    doc_to_insert = {
                                        "resource_id": ObjectId(resource_id),
                                        "tags": [],
                                        "description": "",
                                        "title": session['title'],
                                        "module": "course",
                                        "used_at": "",
                                        "updated_at": utc_datetime_now(),
                                        "updated_by": ObjectId(user_id),
                                    }
                                    resp_id = mongo_session.insert_documnet(collection="resource_bank_instance",
                                                                            doc_to_insert=doc_to_insert)
                                    instance_id = resp_id['_id'].inserted_id
                                    instance_ids_sessions.append(instance_id)
                                else:
                                    delete_record_list.append(ObjectId(resource_id))
                                    resource_bank_resource_id, s3_key_info = manage_course_s3_resources(resource_id)
                                    file_id = resource_bank_resource_id
                                    if s3_key_info['status'] != 200:
                                        raise Exception("Some internal error, Please try again later.")
                                    url = s3_key_info['message']
                                    resource_info = mongo_session.check_existance_return_info(
                                        collection='global_resource_bank',
                                        condition={
                                            '_id': ObjectId(
                                                resource_bank_resource_id)},
                                        return_keys=['uploaded_at',
                                                     'user_id'])
                                    doc_to_insert = {
                                        "resource_id": ObjectId(resource_id),
                                        "tags": [],
                                        "description": "",
                                        "title": session['title'],
                                        "module": "course",
                                        "used_at": "",
                                        "updated_at": utc_datetime_now(),
                                        "updated_by": ObjectId(user_id),
                                    }
                                    resp_id = mongo_session.insert_documnet(collection="resource_bank_instance",
                                                                            doc_to_insert=doc_to_insert)
                                    session['instance_id'] = resp_id['_id'].inserted_id
                                    instance_ids_sessions.append(session['instance_id'])
                                    created_at = time.strftime('%Y-%m-%d %H:%M',
                                                               time.localtime(int(resource_info['uploaded_at'])))
                                    item_type = ""
                                    if re.findall('\.mp4', url):
                                        item_type = "video"
                                    if re.findall('\.png|\.jpg|\.jpeg', url):
                                        item_type = "image"
                                    if re.findall(
                                            '\.pdf|\.zip|\.doc|\.docx|\.ppt|\.pptx|\.txt|\.xml|\.rar|\.csv|\.mp3|\.xlsx',
                                            url):
                                        item_type = "file"
                                    if re.findall('\.py|\.ipynb', url):
                                        item_type = "python"

                                    data_resource = {'url': url, '_id': resource_bank_resource_id,
                                                     'title': session['title'],
                                                     'description': session['description'], 'module_name': 'course',
                                                     'mongo_collection': 'course_resource_bank',
                                                     'tags': [], 'created_by': resource_info['user_id'],
                                                     'created_at': created_at,
                                                     'file_type': item_type}
                                    insert_resource_elastic(data_resource)
                        else:
                            url = session['url']
                        for assessment in session['assessments']:
                            assessment["_id"] = ObjectId(assessment['_id'])
                            if str(assessment["_id"]) in unique_assess:
                                raise InvalidUsage("An assessment can only be used once in a course.", 400)
                            unique_assess.append(str(assessment["_id"]))
                    if session['key'] == "live_session":
                        if session['type'] == "file" and session["url"]:
                            # no change in session video
                            file_id = ObjectId(session["file_id"])
                            url = session_data["url"]
                            is_recording = True
                            type_of_doc = session.get('type', "")
                        elif session['type'] == "file" and not session["url"]:
                            # new file uploaded
                            resource_id = session['file_id']
                            file_id = ObjectId(session['file_id'])
                            check_resource = mongo_session.check_existance_return_info(
                                collection='global_resource_bank',
                                condition={'_id': ObjectId(resource_id)},
                                whole_doc=True)
                            if check_resource:
                                doc_to_insert = {
                                    "resource_id": ObjectId(resource_id),
                                    "tags": [],
                                    "description": "",
                                    "title": session['title'],
                                    "module": "course",
                                    "used_at": "",
                                    "updated_at": utc_datetime_now(),
                                    "updated_by": ObjectId(user_id),
                                }
                                url = check_resource['s3_key']
                                resp_id = mongo_session.insert_documnet(collection="resource_bank_instance",
                                                                        doc_to_insert=doc_to_insert)
                                instance_id = resp_id['_id'].inserted_id
                                instance_ids_sessions.append(instance_id)

                            elif check_resource is None:
                                course_bank_find = mongo_session.check_existance_return_info(
                                    collection='course_resource_bank',
                                    condition={
                                        "_id": ObjectId(resource_id)
                                    },
                                    whole_doc=True)
                                if course_bank_find:
                                    some = mongo_session.transfer_docs_another_collection(
                                        from_collection='course_resource_bank',
                                        to_collection='global_resource_bank',
                                        condition={"_id": ObjectId(resource_id)})
                                    url = course_bank_find['s3_key']
                                passion_project_find = mongo_session.check_existance_return_info(collection='resources',
                                                                                                 condition={
                                                                                                     "_id": ObjectId(
                                                                                                         resource_id)
                                                                                                 },
                                                                                                 whole_doc=True)
                                if passion_project_find:
                                    some = mongo_session.transfer_docs_another_collection(from_collection='resources',
                                                                                          to_collection='global_resource_bank',
                                                                                          condition={"_id": ObjectId(
                                                                                              resource_id)})
                                    url = passion_project_find['s3_key']
                                if passion_project_find or course_bank_find:
                                    doc_to_insert = {
                                        "resource_id": ObjectId(resource_id),
                                        "tags": [],
                                        "description": "",
                                        "title": session['title'],
                                        "module": "course",
                                        "used_at": "",
                                        "updated_at": utc_datetime_now(),
                                        "updated_by": ObjectId(user_id),
                                    }
                                    resp_id = mongo_session.insert_documnet(collection="resource_bank_instance",
                                                                            doc_to_insert=doc_to_insert)
                                    instance_id = resp_id['_id'].inserted_id
                                    instance_ids_sessions.append(instance_id)
                            url = url
                            is_recording = True
                            type_of_doc = session.get('type', "")
                        elif session.get("status") == "zoom_recorded":
                            url = session_data["url"]
                        else:
                            url = session['url']
                        for assessment in session['assessments']:
                            assessment["_id"] = ObjectId(assessment['_id'])
                            if str(assessment["_id"]) in unique_assess:
                                raise InvalidUsage("An assessment can only be used once in a course.", 400)
                            unique_assess.append(str(assessment["_id"]))

                    # session resources
                    existing_resources = []
                    db_session_resources = session_data["resources"]
                    for session_resource in session["resources"]:
                        if session_resource['type'] == 'file':
                            if not any(
                                    data['_id'] == ObjectId(session_resource['_id']) for data in
                                    db_session_resources):
                                resource_id = session_resource['_id']
                                check_resource = mongo_session.check_existance_return_info(
                                    collection='global_resource_bank',
                                    condition={'_id': ObjectId(resource_id)},
                                    whole_doc=True)
                                if check_resource:
                                    doc_to_insert = {
                                        "resource_id": ObjectId(resource_id),
                                        "tags": [],
                                        "description": "",
                                        "title": session_resource['title'],
                                        "module": "course",
                                        "used_at": "",
                                        "updated_at": utc_datetime_now(),
                                        "updated_by": ObjectId(user_id),
                                    }
                                    session_resource['url'] = check_resource['s3_key']
                                    session_resource['_id'] = ObjectId(resource_id)
                                    resp_id = mongo_session.insert_documnet(collection="resource_bank_instance",
                                                                            doc_to_insert=doc_to_insert)
                                    session_resource['instance_id'] = resp_id['_id'].inserted_id
                                    instance_ids_sessions.append(session_resource['instance_id'])

                                elif check_resource is None:
                                    course_bank_find = mongo_session.check_existance_return_info(
                                        collection='course_resource_bank',
                                        condition={
                                            "_id": ObjectId(resource_id)
                                        },
                                        whole_doc=True)
                                    if course_bank_find:
                                        some = mongo_session.transfer_docs_another_collection(
                                            from_collection='course_resource_bank',
                                            to_collection='global_resource_bank',
                                            condition={"_id": ObjectId(resource_id)})
                                        session_resource['url'] = course_bank_find['s3_key']
                                        session_resource['_id'] = ObjectId(resource_id)
                                    passion_project_find = mongo_session.check_existance_return_info(
                                        collection='resources',
                                        condition={
                                            "_id": ObjectId(resource_id)
                                        },
                                        whole_doc=True)
                                    if passion_project_find:
                                        some = mongo_session.transfer_docs_another_collection(
                                            from_collection='resources',
                                            to_collection='global_resource_bank',
                                            condition={"_id": ObjectId(resource_id)})
                                        session_resource['url'] = passion_project_find['s3_key']
                                        session_resource['_id'] = ObjectId(resource_id)
                                    if passion_project_find or course_bank_find:
                                        doc_to_insert = {
                                            "resource_id": ObjectId(resource_id),
                                            "tags": [],
                                            "description": "",
                                            "title": session_resource['title'],
                                            "module": "course",
                                            "used_at": "",
                                            "updated_at": utc_datetime_now(),
                                            "updated_by": ObjectId(user_id),
                                        }
                                        resp_id = mongo_session.insert_documnet(collection="resource_bank_instance",
                                                                                doc_to_insert=doc_to_insert)
                                        session_resource['instance_id'] = resp_id['_id'].inserted_id
                                        instance_ids_sessions.append(session_resource['instance_id'])
                                    else:
                                        delete_list_temp_files.append(ObjectId(resource_id))
                                        resource_bank_resource_id, s3_key_info = manage_course_s3_resources(resource_id)
                                        session_resource['_id'] = resource_bank_resource_id
                                        session_resource['url'] = s3_key_info['message']
                                        if s3_key_info['status'] != 200:
                                            raise Exception("Some internal error occurred, Please try again later.")
                                        resource_info = mongo_session.check_existance_return_info(
                                            collection='global_resource_bank',
                                            condition={
                                                '_id': ObjectId(resource_bank_resource_id)},
                                            return_keys=['uploaded_at', 'user_id'])
                                        doc_to_insert = {
                                            "resource_id": ObjectId(resource_id),
                                            "tags": [],
                                            "description": "",
                                            "title": session_resource['title'],
                                            "module": "course",
                                            "used_at": "",
                                            "updated_at": utc_datetime_now(),
                                            "updated_by": ObjectId(user_id),
                                        }
                                        resp_id = mongo_session.insert_documnet(collection="resource_bank_instance",
                                                                                doc_to_insert=doc_to_insert)
                                        session_resource['instance_id'] = resp_id['_id'].inserted_id
                                        instance_ids_sessions.append(session_resource['instance_id'])
                                        created_at = time.strftime('%Y-%m-%d %H:%M',
                                                                   time.localtime(int(resource_info['uploaded_at'])))
                                        item_type = ""
                                        if re.findall('\.mp4', session_resource['url']):
                                            item_type = "video"
                                        if re.findall('\.png|\.jpg|\.jpeg', session_resource['url']):
                                            item_type = "image"
                                        if re.findall(
                                                '\.pdf|\.zip|\.doc|\.docx|\.ppt|\.pptx|\.txt|\.xml|\.rar|\.csv|\.mp3|\.xlsx',
                                                session_resource['url']):
                                            item_type = "file"
                                        if re.findall('\.py|\.ipynb', session_resource['url']):
                                            item_type = "python"

                                        data_resource = {'url': session_resource['url'],
                                                         '_id': resource_bank_resource_id,
                                                         'title': session_resource['title'],
                                                         'description': "", 'module_name': 'course',
                                                         'mongo_collection': 'course_resource_bank',
                                                         'tags': [], 'created_by': resource_info['user_id'],
                                                         'created_at': created_at,
                                                         'file_type': item_type}
                                        insert_resource_elastic(data_resource)
                            else:
                                for data in db_session_resources:
                                    if data['_id'] == ObjectId(session_resource['_id']):
                                        session_resource['url'] = data['url']
                                        session_resource['_id'] = data['_id']
                                        existing_resources.append(data['_id'])
                    delete_resource_list = delete_resource_list + [data['_id'] for data in db_session_resources if
                                                                   '_id' in data and (data[
                                                                                          '_id'] not in existing_resources) and
                                                                   data[
                                                                       '_id'] != ""]

                    session_data = {"title": session["title"],
                                    "description": session["description"],
                                    "key": session['key'],
                                    "url": url,
                                    "file_id": file_id,
                                    "type": type_of_doc,
                                    "assessments": session['assessments'],
                                    "resources": session['resources'],
                                    "status": "recorded" if is_recording else session_data.get("status", "")}
                    update_session = mongo_session.update_record_into_db(
                        collection="course_sessions",
                        condition={"_id": ObjectId(session["_id"])},
                        update_info={"$set": session_data})
                    used_at = {"$set": {"used_at": {'session_id': ObjectId(session['_id'])}}}
                    condition = {"_id": {"$in": instance_ids_sessions}}
                    updation = mongo_session.update_db_data(collection='resource_bank_instance', condition=condition,
                                                            update_info=used_at, multi=True)
                    if update_session["status"] != 200:
                        raise Exception("Some internal error, Please try again later.")
                    processed_sessions.append({"_id": ObjectId(session["_id"])})
            topic_data = {"title": topic['title'],
                          "description": topic['description'],
                          "sessions": processed_sessions,
                          "resources": topic['resources'],
                          "course_work": topic_course_work,
                          "assessments": topic_assessments}
            update_topic = mongo_session.update_record_into_db(
                collection="course_topics",
                condition={"_id": ObjectId(topic["_id"])},
                update_info={"$set": topic_data})
            if update_topic["status"] != 200:
                raise Exception("Some internal error, Please try again later.")
            processed_topics.append({"_id": ObjectId(topic["_id"])})
            used_at = {"$set": {"used_at": {'topic_id': ObjectId(topic['_id'])}}}
            condition = {"_id": {"$in": instance_ids_topics}}
            updation = mongo_session.update_db_data(collection='resource_bank_instance', condition=condition,
                                                    update_info=used_at, multi=True)
    return processed_topics, instance_ids_topics, delete_list_temp_files, delete_resource_list


def view_course_topics_new(topic_id, user_id, role, course_id):
    """To process topics in view course.
        :param topic_id: topic id of topic.
        :type: string
    """
    # topics
    topic_query = mongo_session.get_all_data_for_particular_condition_fields(
        collection="course_topics",
        condition={"_id": ObjectId(topic_id)})
    if topic_query['status'] != 200:
        raise InvalidUsage("Something went wrong, please try again later.", 500)
    topic_data = topic_query['message'][0]

    user_progress_query = mongo_session.access_specific_fields(collection='courses_progress_tracking',
                                                               condition={'user_id': str(user_id)})
    viewed_sessions = []
    total_completed_topics_by_user = []
    if user_progress_query:
        user_progress_query = user_progress_query[0]
        total_completed_topics_by_user = user_progress_query['topics_completed']
        if str(course_id) in list(user_progress_query['courses']):
            if str(topic_id) in list(user_progress_query['courses'][str(course_id)]):
                viewed_sessions = set([session['session_id'] for session in user_progress_query['courses'][str(course_id)][str(topic_id)]])
    if role == 'student':
        topics_complete = True if len(viewed_sessions) == len(topic_data['sessions']) else False
    elif role == 'teacher' or role =='super_admin':
        topics_complete = True
    course_data =  mongo_session.access_specific_fields(collection='courses_bank',
                                                        condition={'_id': ObjectId(course_id)})[0]
    processed_topics = [str(topic['_id']) for topic in course_data["topics"]]
    course_class = course_data.get('course_class', None)
    if course_class:
        course_class = mongo_session.access_specific_fields(collection='course_class',
                                                            condition={'_id': ObjectId(course_class)})[0]['value']
    else:
        course_class = 'Old Structure'
    processed_topics_user = []
    for x in processed_topics:
        if x in total_completed_topics_by_user:
            processed_topics_user.append(x)
    activate_validations = False
    if course_class == 'Self Paced Course':
        if len(processed_topics) > 1:
            if topic_id in processed_topics_user:
                activate_validations = True
            if processed_topics_user:
                if processed_topics.index(processed_topics_user[-1]) == (processed_topics.index(topic_id) - 1):
                    activate_validations = True
            if processed_topics.index(topic_id) == 0:
                activate_validations = True
        else:
            activate_validations = True
    processed_sessions = []
    topic_duration = []
    for session in topic_data['sessions']:
        session_query = mongo_session.get_all_data_for_particular_condition_fields(
            collection="course_sessions",
            condition={"_id": ObjectId(session["_id"])})
        if session_query['status'] != 200:
            raise InvalidUsage("Something went wrong, please try again later.", 500)
        session_data = session_query['message'][0]
        s3_url = session_data['url']
        s3_path = ""
        session_data["file_id"] = str(session_data["file_id"])
        if session_data.get('instance_id'):
            session_data['instance_id'] = str(session_data['instance_id'])
        if session_data.get('schedule_id'):
            session_data['schedule_id'] = str(session_data['schedule_id'])
        if session_data['type'] == "file":
            session_data["file_id"] = str(session_data["file_id"])
            if session_data.get('instance_id'):
                session_data['instance_id'] = str(session_data['instance_id'])
            if session_data.get('schedule_id'):
                session_data['schedule_id'] = str(session_data['schedule_id'])
            s3_path, s3_status = s3_function.generate_presigned_url_from_s3(session_data['url'])
            if s3_status != 200:
                raise InvalidUsage("Error occurred while communicating with s3, unable to generate file s3 url", 500)

        # if we get 
        # res = config.s3_connection.head_object(Bucket=config.bucket, Key=session_data['url'])
        # before generating presigned url we get empty dict res['Metadata']
        # but if we get "res" after generating presigned url we get dict res['Metadata'].get('duration') as key value pair
        if session_data.get('status') == "zoom_recorded":
            session_data["file_id"] = str(session_data["file_id"])
            s3_path, s3_status = s3_function.generate_presigned_url_from_s3(session_data['url'])
            if s3_status != 200:
                raise InvalidUsage("Error occurred while communicating with s3, unable to produce zoom live session recorded video", 500)

        # video duration code for session
        try:
            pattern = re.compile(
                "^((?:https?:)?\/\/)?((?:www|m)\.)?((?:youtube(-nocookie)?\.com|youtu.be))(\/(?:[\w\-]+\?v=|embed\/|v\/)?)([\w\-]+)(\S+)?$")
            if pattern.match(session_data['url']):
                video_query = mongo_session.get_all_data_for_particular_condition_fields(
                    collection="youtube_video_duration",
                    condition={"video_url": session_data['url']})
                if video_query['status'] != 200:
                    raise InvalidUsage("Something went wrong, please try again later.", 500)
                video_data = video_query["message"]
                if video_data:
                    session_data['duration'] = video_data[0]['duration']
                else:
                    ydl_opts = {}
                    with youtube_dl.YoutubeDL(ydl_opts) as ydl:
                        dictmeta = ydl.extract_info(session_data['url'], download=False)
                    seconds = dictmeta['duration']
                    seconds = seconds % (24 * 3600)
                    hour = seconds // 3600
                    seconds %= 3600
                    minutes = seconds // 60
                    seconds %= 60
                    session_data['duration'] = "%02d:%02d:%02d" % (hour, minutes, seconds)
                    video_doc_to_insert = {"video_url": session_data['url'], "duration": session_data['duration']}
                    video_duration_status = mongo_session.insert_documnet(collection="youtube_video_duration",
                                                                          doc_to_insert=video_doc_to_insert)
                    if video_duration_status["status"] != 200:
                        raise Exception("Some internal error, Please try again later.")
            else:
                res = config.s3_connection.head_object(Bucket=config.bucket, Key=session_data['url'])
                session_data['duration'] = str(res['Metadata'].get('duration', "00:00:00"))
        except Exception as e:
            print("S3 duration block ", e)
            session_data['duration'] = "00:00:00"
        topic_duration.append(session_data['duration'])
        if len(s3_path) > 0:
            session_data['url'] = s3_path
        
        # session resources
        for resource in session_data['resources']:
            if resource.get('_id'):
                resource['_id'] = str(resource['_id'])
            if resource['type'] == 'file':
                if resource.get('schedule_id'):
                    resource['schedule_id'] = str(resource['schedule_id'])
                if resource.get('instance_id'):
                    resource['instance_id'] = str(resource['instance_id'])
                resource['_id'] = str(resource['_id'])
                if resource.get('instance_id'):
                    resource['instance_id'] = str(resource['instance_id'])
                if resource.get('schedule_id'):
                    resource['schedule_id'] = str(resource['schedule_id'])
                resource['url'], s3_status = s3_function.generate_presigned_url_from_s3(resource['url'])
                if s3_status != 200:
                    raise InvalidUsage("Error occurred while communicating with s3", 500)
        # session assessments
        processed_session_assess = []
        for assess in session_data["assessments"]:
            assess["_id"] = str(assess["_id"])
            # to check whether user has seen the feedback or not
            seen_feedback = seen_asess_feedback(user_id=user_id,
                                                role=role,
                                                course_id=course_id,
                                                topic_id=topic_id,
                                                course_session_id=session_data['_id'],
                                                assessment_id=ObjectId(assess["_id"]))
            assess["view_feedback"] = seen_feedback
            if assess.get("activate"):
                del assess["activate"]
            if assess.get("deactivate"):
                del assess["deactivate"]
            processed_session_assess.append(assess)

        status = session_data.get("status", "")
        # transcriptions
        transcriptions = mongo_session.access_specific_fields(collection="video_transcriptions",
                                                              condition={"s3_key": s3_url})
        if transcriptions:
            transcriptions = transcriptions[0]['transcription']['results']
            for t in transcriptions['items']:
                t['text'] = t['alternatives'][0]['content']
                t.pop('alternatives')
        else:
            transcriptions = {'transcripts': [], 'items': []}
        if course_class == 'Self Paced Course' and role == 'student':
            session_status = False
        elif course_class == 'Self Paced Course' and role == 'teacher' or course_class == 'Self Paced Course' and role == 'super_admin':
            session_status = True
        elif course_class == 'Old Structure':
            session_status = True
        session_info = {"_id": str(session["_id"]),
                        "title": session_data["title"],
                        "description": session_data["description"],
                        "key": session_data['key'],
                        "url": session_data['url'],
                        "file_id": session_data['file_id'],
                        "type": session_data['type'],
                        "assessments": processed_session_assess,
                        "resources": session_data['resources'],
                        "duration": session_data['duration'],
                        "status": status,
                        "transcriptions": transcriptions,
                        "seen_by_user": True if str(session["_id"]) in viewed_sessions else False,
                        "session_status": session_status}
        processed_sessions.append(session_info)
    if activate_validations:
        for sess in range(len(processed_sessions)):
            if sess == 0:
                processed_sessions[sess]['session_status'] = True
            if processed_sessions[sess]['seen_by_user']:
                if sess + 1 != len(processed_sessions):
                    processed_sessions[sess + 1]['session_status'] = True
    # topic resources
    for resource in topic_data['resources']:
        if resource.get('_id'):
            resource['_id'] = str(resource['_id'])
        if resource['type'] == 'file':
            if resource.get('schedule_id'):
                resource['schedule_id'] = str(resource['schedule_id'])
            if resource.get('instance_id'):
                resource['instance_id'] = str(resource['instance_id'])
            resource['_id'] = str(resource['_id'])
            if resource.get('instance_id'):
                resource['instance_id'] = str(resource['instance_id'])
            if resource.get('schedule_id'):
                resource['schedule_id'] = str(resource['schedule_id'])
            resource['url'], s3_status = s3_function.generate_presigned_url_from_s3(resource['url'])
            if s3_status != 200:
                raise InvalidUsage("Error occurred while communicating with s3", 500)

    # topic course work
    topic_course_work = []
    for work in topic_data["course_work"]:
        course_work_query = mongo_session.get_all_data_for_particular_condition_fields(
            collection="course_work_bank",
            condition={"_id": ObjectId(work["_id"])})
        if course_work_query['status'] != 200:
            raise InvalidUsage("Something went wrong, please try again later.", 500)
        work_data = course_work_query['message'][0]

        schedule_work_query = mongo_session.get_all_data_for_particular_condition_fields(
            collection="course_work_instances",
            condition={"_id": ObjectId(work["schedule_id"])})
        if schedule_work_query['status'] != 200:
            raise InvalidUsage("Something went wrong, please try again later.", 500)
        schedule_data = schedule_work_query['message'][0]
        for resource in work_data["course_work_resources"]:
            if resource.get('_id'):
                resource['_id'] = str(resource['_id'])
            if resource['resource_type'] == 'file':
                resource['resource_id'] = str(resource['resource_id'])
                if resource.get('schedule_id'):
                    resource['schedule_id'] = str(resource['schedule_id'])
                if resource.get('instance_id'):
                    resource['instance_id'] = str(resource['instance_id'])
                resource['resource_url'], s3_status = s3_function.generate_presigned_url_from_s3(
                    resource['resource_url'])
                if s3_status != 200:
                    raise InvalidUsage("Error occurred while communicating with s3", 500)
        team_info = []
        if schedule_data.get("teams"):
            if role in ["teacher", "super_admin"]:
                for team in schedule_data["teams"]:
                    for member in team["members"]:
                        member_data = mongo_session.check_existance_return_info(collection="user_profile",
                                                                                       condition={
                                                                                           "_id": member["_id"]},
                                                                                       columns={"username": 1,
                                                                                                "_id": 1,
                                                                                                "name": 1,
                                                                                                "last_name": 1,
                                                                                                "profile_pic": 1},
                                                                                       return_keys=["username", "name", "last_name", "profile_pic"])
                        member["username"] = member_data["username"]
                        member["_id"] = str(member["_id"])
                        member["name"] = member_data.get("name","").capitalize() + " " + member_data.get("last_name","").capitalize()
                        s3_url, status_code = s3_function.generate_presigned_url_from_s3(member_data['profile_pic'])
                        member['profile_pic'] = s3_url
                    team_doc = {"name": team["name"], "members": team["members"]}
                    if team.get("room_id"):
                        current_user = "room_members." + user_id
                        current_admin = "admins.admin_id"
                        current_user_status = "room_members." + user_id + ".status"
                        condition = {"$and": [{'_id': ObjectId(team["room_id"])}, {"$or": [
                            {"$and": [{current_user: {"$exists": True}}, {current_user_status: "active"}]},
                            {"$and": [{"admins.admin_id": {"$in": [ObjectId(user_id)]}},
                                      {"admins.status": "active"}]}
                        ]}]}

                        condition_1 = {'_id': ObjectId(team["room_id"])}
                        team_doc['cw_group_chat'] = {}
                        room_info = mongo_session.check_existance_return_info(collection='chat_rooms',
                                                                              condition=condition,
                                                                              whole_doc=True)
                        room_id = mongo_session.check_existance_return_info(collection='chat_rooms',
                                                                            condition=condition_1)
                        if not room_info:
                            if room_id:
                                team_doc["room_id"] = str(room_id)
                            else:
                                team_doc["room_id"] = None
                            team_doc['cw_group_chat'] = None
                        for member in team['members']:
                            member['user_room_id'] = str(room_id)
                        if room_info:
                            team_doc["room_id"] = str(team["room_id"])
                            check_message_count = mongo_session.get_total_count(collection='messages',
                                                                                condition={
                                                                                    'room_id': str(
                                                                                        room_info['_id']),
                                                                                    "receiver_status":
                                                                                        {"$elemMatch": {"$and": [
                                                                                            {"_id": ObjectId(
                                                                                                user_id)},
                                                                                            {"status": False}
                                                                                        ]}
                                                                                        }})
                            if check_message_count:
                                room_info['total_unread_messages'] = check_message_count
                            else:
                                room_info['total_unread_messages'] = 0

                            message_info = mongo_session.check_existance_return_info(collection='messages',
                                                                                     condition={'room_id': str(
                                                                                         room_info['_id'])},
                                                                                     return_keys=['message',
                                                                                                  'created_at',
                                                                                                  'sender_id',
                                                                                                  'content'])
                            if message_info:
                                message_info['sender_id'] = str(message_info['sender_id'])
                                date = message_info['created_at']
                                message_info['created_at'] = convert_utc_to_ist(date).replace(
                                    tzinfo=None).isoformat(' ')
                                room_info['messages'] = [message_info]
                            else:
                                room_info['messages'] = []

                            room_members = []
                            members = [ObjectId(member) for member in room_info['room_members']]
                            room_members.extend(members)
                            admins = [member['admin_id'] for member in room_info['admins'] if
                                      member['status'] == "active"]
                            room_members.extend(admins)
                            admins = [str(member['admin_id']) for member in room_info['admins'] if
                                      member['status'] == "active"]

                            user_info = mongo_session.access_specific_fields(collection='user_profile',
                                                                             condition={
                                                                                 "_id": {"$in": room_members}
                                                                             },
                                                                             return_keys=['_id', 'name',
                                                                                          'last_name', 'email',
                                                                                          'username',
                                                                                          'profile_pic'])
                            user_details = {}
                            for user in user_info:
                                user_details[str(user['_id'])] = user
                                user['_id'] = str(user['_id'])
                                user['user_id'] = user['_id']
                                user['avatar_url'] = user['profile_pic']
                                # print(user['profile_pic'])
                                user['color'] = ""
                                if user['avatar_url'] is None:
                                    user['avatar_url'] = ""
                                del user['_id']

                            room_info['_id'] = str(room_info['_id'])
                            room_info['room_id'] = room_info['_id']
                            del room_info['_id']
                            room_info['created_by'] = str(room_info['created_by'])
                            room_info['created_at'] = convert_utc_to_ist(room_info['created_at']).replace(
                                tzinfo=None)
                            if room_info.get('type'):
                                admin_list = []
                                for admin in room_info['admins']:
                                    admin['admin_id'] = str(admin['admin_id'])
                                    if admin['admin_id'] == user_id and admin['status'] == 'active':
                                        room_info['current_user_admin'] = True
                                    else:
                                        room_info['current_user_admin'] = False
                                    admin['added_by'] = str(admin['added_by'])
                                    if room_info['room_members']:
                                        room_info['room_members'][admin['admin_id']] = {"status": admin['status']}
                                    else:
                                        dict_1 = {admin['admin_id']: {"status": admin['status']}}
                                        room_info['room_members'] = dict_1

                            member_list = []
                            for member in room_info['room_members']:
                                if member in user_details:
                                    s3_url, status_code = s3_function.generate_presigned_url_from_s3(
                                        user_details[member]['profile_pic'])
                                    user_details[member]['avatar_url'] = s3_url
                                    if room_info['name'] == "" and not room_info.get('type'):
                                        if member != user_id:
                                            room_info['name'] = user_details[member]['username']
                                            room_info['avatar_url'] = s3_url
                                    if room_info.get('type'):
                                        if member in admins:
                                            user_details[member]['is_admin'] = True
                                        else:
                                            user_details[member]['is_admin'] = False
                                        if member == user_id:
                                            room_info['user_status'] = room_info['room_members'][member]['status']
                                        user_details[member]['user_status'] = room_info['room_members'][member][
                                            'status']
                                    else:
                                        if member == user_id:
                                            room_info['user_status'] = "active"
                                        user_details[member]['user_status'] = "active"
                                    d = {key: value for key, value in user_details[member].items() if
                                         key not in 'profile_pic'}
                                    if user_details[member].get('user_status'):
                                        del user_details[member]['user_status']
                                    if user_details[member].get('is_admin'):
                                        del user_details[member]['is_admin']
                                    member_list.append(d)
                            room_info['room_members'] = member_list
                            if room_info.get('group_photo'):
                                room_info['avatar_url'], status = s3_function.generate_presigned_url_from_s3(
                                    room_info['group_photo']['avatar_url'])
                                del room_info['group_photo']

                            if room_info.get('group_description'):
                                room_info['description'] = str(room_info['group_description']['description'])
                                del room_info['group_description']

                            if room_info.get('course_work_id'):
                                room_info['course_work_id'] = str(room_info['course_work_id'])

                            if room_info.get('cw_instance_id'):
                                room_info['cw_instance_id'] = str(room_info['cw_instance_id'])
                            del room_info['admins']
                            team_doc['cw_group_chat'] = room_info
                            if len(room_info['room_members']) == 1:
                                team_doc['cw_group_chat'] = None
                    team_info.append(team_doc)
            else:
                for team in schedule_data["teams"]:
                    if any(member["_id"] == ObjectId(user_id) for member in team["members"]):
                        for member in team["members"]:
                            member["username"] = \
                                mongo_session.check_existance_return_info(collection="user_profile",
                                                                          condition={"_id": member["_id"]},
                                                                          columns={"username": 1, "_id": 1},
                                                                          return_keys=["username"])["username"]
                            member["_id"] = str(member["_id"])
                        team_doc = {"name": team["name"], "members": team["members"]}
                        if team.get("room_id"):
                            current_user = "room_members." + user_id
                            current_admin = "admins.admin_id"
                            current_user_status = "room_members." + user_id + ".status"
                            condition = {"$and": [{'_id': ObjectId(team["room_id"])}, {"$or": [
                                {"$and": [{current_user: {"$exists": True}}, {current_user_status: "active"}]},
                                {"$and": [{"admins.admin_id": {"$in": [ObjectId(user_id)]}},
                                          {"admins.status": "active"}]}
                            ]}]}
                            team_doc['cw_group_chat'] = {}
                            room_info = mongo_session.check_existance_return_info(collection='chat_rooms',
                                                                                  condition=condition,
                                                                                  whole_doc=True)
                            if not room_info:
                                team_doc["room_id"] = None
                                team_doc['cw_group_chat'] = None
                            if room_info:
                                team_doc["room_id"] = str(team["room_id"])
                                for member in team['members']:
                                    member['user_room_id'] = str(room_info['_id'])
                                check_message_count = mongo_session.get_total_count(collection='messages',
                                                                                    condition={
                                                                                        'room_id': str(
                                                                                            room_info['_id']),
                                                                                        "receiver_status":
                                                                                            {"$elemMatch": {
                                                                                                "$and": [
                                                                                                    {
                                                                                                        "_id": ObjectId(
                                                                                                            user_id)},
                                                                                                    {
                                                                                                        "status": False}
                                                                                                ]}
                                                                                            }})
                                if check_message_count:
                                    room_info['total_unread_messages'] = check_message_count
                                else:
                                    room_info['total_unread_messages'] = 0

                                message_info = mongo_session.check_existance_return_info(collection='messages',
                                                                                         condition={'room_id': str(
                                                                                             room_info['_id'])},
                                                                                         return_keys=['message',
                                                                                                      'created_at',
                                                                                                      'sender_id',
                                                                                                      'content'])
                                if message_info:
                                    message_info['sender_id'] = str(message_info['sender_id'])
                                    date = message_info['created_at']
                                    message_info['created_at'] = convert_utc_to_ist(date).replace(
                                        tzinfo=None).isoformat(' ')
                                    room_info['messages'] = [message_info]
                                else:
                                    room_info['messages'] = []

                                room_members = []
                                members = [ObjectId(member) for member in room_info['room_members']]
                                room_members.extend(members)
                                admins = [member['admin_id'] for member in room_info['admins'] if
                                          member['status'] == "active"]
                                room_members.extend(admins)
                                admins = [str(member['admin_id']) for member in room_info['admins'] if
                                          member['status'] == "active"]

                                user_info = mongo_session.access_specific_fields(collection='user_profile',
                                                                                 condition={
                                                                                     "_id": {"$in": room_members}
                                                                                 },
                                                                                 return_keys=['_id', 'name',
                                                                                              'last_name', 'email',
                                                                                              'username',
                                                                                              'profile_pic'])
                                user_details = {}
                                for user in user_info:
                                    user_details[str(user['_id'])] = user
                                    user['_id'] = str(user['_id'])
                                    user['user_id'] = user['_id']
                                    user['avatar_url'] = user['profile_pic']
                                    # print(user['profile_pic'])
                                    user['color'] = ""
                                    if user['avatar_url'] is None:
                                        user['avatar_url'] = ""
                                    del user['_id']

                                room_info['_id'] = str(room_info['_id'])
                                room_info['room_id'] = room_info['_id']
                                del room_info['_id']
                                room_info['created_by'] = str(room_info['created_by'])
                                room_info['created_at'] = convert_utc_to_ist(room_info['created_at']).replace(
                                    tzinfo=None)
                                if room_info.get('type'):
                                    admin_list = []
                                    for admin in room_info['admins']:
                                        admin['admin_id'] = str(admin['admin_id'])
                                        if admin['admin_id'] == user_id and admin['status'] == 'active':
                                            room_info['current_user_admin'] = True
                                        else:
                                            room_info['current_user_admin'] = False
                                        admin['added_by'] = str(admin['added_by'])
                                        if room_info['room_members']:
                                            room_info['room_members'][admin['admin_id']] = {
                                                "status": admin['status']}
                                        else:
                                            dict_1 = {admin['admin_id']: {"status": admin['status']}}
                                            room_info['room_members'] = dict_1

                                member_list = []
                                for member in room_info['room_members']:
                                    if member in user_details:
                                        s3_url, status_code = s3_function.generate_presigned_url_from_s3(
                                            user_details[member]['profile_pic'])
                                        user_details[member]['avatar_url'] = s3_url
                                        if room_info['name'] == "" and not room_info.get('type'):
                                            if member != user_id:
                                                room_info['name'] = user_details[member]['username']
                                                room_info['avatar_url'] = s3_url
                                        if room_info.get('type'):
                                            if member in admins:
                                                user_details[member]['is_admin'] = True
                                            else:
                                                user_details[member]['is_admin'] = False
                                            if member == user_id:
                                                room_info['user_status'] = room_info['room_members'][member][
                                                    'status']
                                            user_details[member]['user_status'] = room_info['room_members'][member][
                                                'status']
                                        else:
                                            if member == user_id:
                                                room_info['user_status'] = "active"
                                            user_details[member]['user_status'] = "active"
                                        d = {key: value for key, value in user_details[member].items() if
                                             key not in 'profile_pic'}
                                        if user_details[member].get('user_status'):
                                            del user_details[member]['user_status']
                                        if user_details[member].get('is_admin'):
                                            del user_details[member]['is_admin']
                                        member_list.append(d)
                                room_info['room_members'] = member_list
                                if room_info.get('group_photo'):
                                    room_info['avatar_url'], status = s3_function.generate_presigned_url_from_s3(
                                        room_info['group_photo']['avatar_url'])
                                    del room_info['group_photo']

                                if room_info.get('group_description'):
                                    room_info['description'] = str(room_info['group_description']['description'])
                                    del room_info['group_description']

                                if room_info.get('course_work_id'):
                                    room_info['course_work_id'] = str(room_info['course_work_id'])

                                if room_info.get('cw_instance_id'):
                                    room_info['cw_instance_id'] = str(room_info['cw_instance_id'])
                                del room_info['admins']
                                team_doc['cw_group_chat'] = room_info
                                if len(room_info['room_members']) == 1:
                                    team_doc['cw_group_chat'] = None
                        team_info.append(team_doc)

        course_work_resources = work_data["course_work_resources"]
        current_date = str(utc_datetime_now().date()).split('-')
        data = {"_id": str(work['_id']),
                "course_work_resources": course_work_resources,
                "title": work_data['courseWorkTitle'],
                "group_type": schedule_data["group_type"],
                "group_size": work_data["group_size"],
                "is_group": work_data["is_group"],
                "course_work_description": renew_s3_links(work_data["course_work_description"]),
                "submission_requirement": work_data["submissionRequirement"],
                "date": schedule_data["start_date"] if course_class != 'Self Paced Course' else {'year': int(current_date[0]),'month': int(current_date[1]),'day': int(current_date[2])},
                "time": schedule_data["start_time"] if course_class != 'Self Paced Course' else "00:00",
                "schedule_id": str(work["schedule_id"]),
                "team_info": team_info}

        # PK - Added code for peer review and self review
        if schedule_data.get('peer_review'):
            if schedule_data['peer_review'] == True:
                data['peer_review'] = True
            else:
                data['peer_review'] = False
        else:
            data['peer_review'] = False

        if schedule_data.get('self_review'):
            if schedule_data['self_review'] == True:
                data['self_review'] = True
            else:
                data['self_review'] = False
        else:
            data['self_review'] = False
        topic_course_work.append(data)

    # topic assessments
    topic_assessments = []
    for assessment in topic_data["assessments"]:
        seen_feedback = seen_asess_feedback(user_id=user_id,
                                            role=role,
                                            course_id=course_id,
                                            topic_id=topic_id,
                                            assessment_id=assessment["_id"],
                                            schedule_id=assessment.get("schedule_id"))
        user_submission = mongo_session.check_existance(collection="assessments_result",
                                                        condition={"course_id": ObjectId(course_id),
                                                                   "user_id": ObjectId(user_id),
                                                                   "topic_id": ObjectId(topic_id),
                                                                   "assessment_id": ObjectId(
                                                                       str(assessment['_id']))})
        if assessment.get("schedule_id"):
            assess_query = mongo_session.get_all_data_for_particular_condition_fields(
                collection="schedule_assessment",
                condition={"_id": assessment["schedule_id"]})
            if assess_query['status'] != 200:
                raise InvalidUsage("Something went wrong, please try again later.", 500)
            assess_data = assess_query['message'][0]
            start_obj = datetime.datetime.strptime(assess_data['start_time'], "%Y:%m:%dT%H:%M")
            assessment_start_time = start_obj.strftime("%d %b %Y, %I:%M %p")

            end_obj = datetime.datetime.strptime(assess_data['end_time'], "%Y:%m:%dT%H:%M")
            assessment_end_time = end_obj.strftime("%d %b %Y, %I:%M %p")

            timestamp = Question.indian_standard_time()
            timestamp_obj = datetime.datetime.strptime(timestamp, "%d %b %Y, %I:%M %p")

            topic_assess_status = True if timestamp_obj < end_obj else False
            topic_assessments.append({"_id": str(assess_data["assessment_id"]),
                                      "title": assess_data["assessment_name"],
                                      "end_time": assessment_end_time,
                                      "start_time": assessment_start_time,
                                      "total_time": assess_data['total_time'],
                                      "active": topic_assess_status,
                                      "schedule_id": str(assess_data["_id"]),
                                      "view_feedback": seen_feedback,
                                      "one_time_assessment": assessment.get('one_time_assessment', False),
                                      "user_submission": True if user_submission else False,
                                      "is_timed": assessment.get("is_timed", True)})
        else:
            assess_query = mongo_session.get_data_for_particular_columns_with_condition(
                collection="assessment",
                condition={"_id": assessment["_id"]},
                columns={"assessment_name": 1, "total_time": 1})
            if assess_query['status'] != 200:
                raise InvalidUsage("Something went wrong, please try again later.", 500)
            assess_data = assess_query['message'][0]
            topic_assessments.append({"_id": str(assessment["_id"]),
                                      "title": assess_data["assessment_name"],
                                      "end_time": "",
                                      "start_time": "",
                                      "total_time": assess_data['total_time'],
                                      "schedule_id": "",
                                      "view_feedback": seen_feedback,
                                      "one_time_assessment": assessment.get('one_time_assessment', False),
                                      "user_submission": True if user_submission else False,
                                      "is_timed": assessment.get("is_timed", False)})
    # calculating time duration of topic
    tp_duration = []
    for time_str in topic_duration:
        h, m, s = time_str.split(':')
        tp_duration.append(int(h) * 3600 + int(m) * 60 + int(s))
    seconds = sum(tp_duration)
    seconds = seconds % (24 * 3600)
    hours = seconds // 3600
    seconds %= 3600
    minutes = seconds // 60
    seconds %= 60
    topic_dur = "%02d:%02d:%02d" % (hours, minutes, seconds)
    if not processed_sessions and not topic_course_work and not topic_assessments and not topic_data['resources'] \
            and role == 'student':
        pass
    else:
        topic_info = {"_id": str(topic_id),
                      "title": topic_data['title'],
                      "description": topic_data['description'],
                      "sessions": processed_sessions,
                      "resources": topic_data['resources'],
                      "course_work": topic_course_work,
                      "duration": topic_dur,
                      "assessments": topic_assessments,
                      "topic_complete": topics_complete}
    return topic_info
