from utils.time_conversions import utc_datetime_now, str_to_utc_datetime_obj, \
    convert_utc_to_ist
import datetime
# from datetime import datetime, timedelta
import json
from model.zoom import Zoom
from db_wrapper.tasks import Mongo
from routes.exception import InvalidUsage

mongo_session = Mongo()

def view_course_live_sessions(course_data, user_id, publish_rights, role):
    """To process live sessions in view course.
        :param course_data: course data from mongo query.
        :type: dict
        :param user_id: user id
        :type: string
        :param publish_rights: list of users that have the right to publish
        :type: list
        :param role: role
        :type: string
    """
    
    processed_live_sessions = []
    prossessing_video = "False"
    session_over = ""
    if course_data["live_sessions"]:
        ist_date = ""
        if user_id in publish_rights or role == "super_admin":
            # refresh the url with start url
            for sess in course_data["live_sessions"]:
                start_date_time = str(sess['start_date']['year']) + '-' + str(sess['start_date']['month']) + '-' + \
                                  str(sess['start_date']['day']) + ' ' + sess['start_time']
                date_time_obj = str_to_utc_datetime_obj(start_date_time, '%Y-%m-%d %H:%M')
                start_date_time = str_to_utc_datetime_obj(start_date_time, '%Y-%m-%d %H:%M')
                current_date = str(utc_datetime_now())
                end_date_time = str(sess['end_date']['year']) + '-' + str(sess['end_date']['month']) + '-' + \
                                str(sess['end_date']['day']) + ' ' + sess['start_time']
                end_date_time = str_to_utc_datetime_obj(end_date_time, '%Y-%m-%d %H:%M')
                end_date_time = end_date_time + datetime.timedelta(minutes=int(sess["duration"]))
                date = current_date.split(' ')[0] + " " + sess['start_time']
                current_date = str_to_utc_datetime_obj(date, '%Y-%m-%d %H:%M')
                if end_date_time >= current_date >= date_time_obj:
                    if sess["frequency"] == "daily":
                        ist_date = str(convert_utc_to_ist(current_date))

                    if sess["frequency"] == "weekly":
                        days = abs(current_date - date_time_obj).days
                        if days % 7 != 0:
                            day_diff = 7 - days % 7
                            current_date = current_date + datetime.timedelta(days=day_diff)
                            ist_date = str(convert_utc_to_ist(current_date))
                        else:
                            ist_date = str(convert_utc_to_ist(current_date))
                elif end_date_time >= current_date and current_date <= date_time_obj:
                    ist_date = str(convert_utc_to_ist(date_time_obj))
                else:
                    ist_date = str(convert_utc_to_ist(end_date_time))

                if sess.get("meeting_details") and sess["meeting_details"]:
                    url = sess["meeting_details"]["start_url"]
                    # refresh the start_url
                    # create zoom object to perform various zoom operations
                    zoom_app = Zoom(jwt_api_key=sess["zoom_account"]["api_key"],
                                    jwt_secret_key=sess["zoom_account"]["secret_key"],
                                    zoom_email=sess["zoom_account"]["email"])
                    zoom_jwt_token = zoom_app.generate_jwt_token()

                    meeting_detail_response = zoom_app.get_particular_meeting(
                        jwt_token=zoom_jwt_token,
                        meetingId=sess["meeting_details"]["meeting_id"])

                    if meeting_detail_response.status_code == 200:
                        meeting_detail_response = json.loads(meeting_detail_response.content)
                        url = meeting_detail_response["start_url"]
                        if sess.get('subscriber_url'):
                            if str(user_id) in sess['subscriber_url'].keys():
                                url = sess['subscriber_url'][str(user_id)]['url']
                    x = datetime.datetime.utcnow()
                    now = x.strftime("%Y-%m-%d %H:%M")
                    start_datetime_object = start_date_time.strftime("%Y-%m-%d %H:%M")
                    end_datetime_object = end_date_time.strftime("%Y-%m-%d %H:%M")
                    if "zoom" in url or "recorded-sessions" in url:
                        meeting_id = ""
                        if "zoom" in url:
                            meeting_id = url.split('?')[0].split('/')[-1]
                        elif "recorded-sessions" in url:
                            meeting_id = url.split('.mp4')[0].split('-')[-1]
                        meet_details = mongo_session.get_all_data_for_particular_condition_fields(
                                    collection="course_sessions",
                                    condition={
                                        "key": "live_session",
                                        "url": {"$regex": str(meeting_id)}
                                        }
                                )
                        if len(meet_details["message"]) > 0:
                            session_over = ""
                            if meet_details["message"][0]["status"] == "active":
                                session_over = "False"
                            elif meet_details["message"][0]["status"] == "inactive" or meet_details["message"][0]["status"] == "zoom_recorded":
                                session_over = "True"
                        else:
                            session_over =  ""
                            if end_datetime_object < now:
                                session_over = "True"

                        meet_recordings_url = ""
                        if meet_details["message"]:
                            participants_information = mongo_session.check_existance_return_info(
                                collection="course_sessions",
                                condition={
                                    "key": "live_session",
                                    "url": {"$regex": str(meeting_id)}
                                    },
                                columns={"meeting_id": 1,
                                        "occurrence_id": 1},
                                return_keys=["_id", "meeting_id", "occurrence_id"])
                            if not participants_information.get("meeting_id"):
                                print("Live Attendance is not avaialble on this session, "
                                                "Please upload the attendance sheet to mark attendance.")
                            else:
                                meet_recordings = mongo_session.check_existance_return_info(
                                    collection="zoom_meetings",
                                    condition={"meeting_id": int(participants_information["meeting_id"]),
                                            "total_recordings.occurrence_id": participants_information["occurrence_id"]},
                                    columns={"total_recordings.$": 1},
                                    whole_doc=True)
                                if not meet_recordings or not meet_recordings["total_recordings"]:
                                    print("Live Attendance is not avaialble on this session, "
                                                    "Please upload the attendance sheet to mark attendance.")
                                else:
                                    meet_recordings_url = meet_recordings["total_recordings"][0]["recording_s3_key"]
                        # threshold time is maximum we allow processing video option to be true
                        threshold_time = (end_date_time + datetime.timedelta(minutes=20)).strftime("%Y-%m-%d %H:%M")
                        if len(meet_details["message"]) > 0:
                            if session_over == "True" and threshold_time > now and not meet_details["message"][0]["status"] == "zoom_recorded":
                                prossessing_video = "True"
                            elif session_over == "True" and (threshold_time < now or meet_details["message"][0]["status"] == "zoom_recorded"):
                                prossessing_video = "False"
                            else:
                                prossessing_video = "False"
                        else:
                            prossessing_video = "False"
                    meeting_detail = {"duration": sess["duration"],
                                      "end_date": sess["end_date"],
                                      "frequency": sess["frequency"],
                                      "start_date": sess["start_date"],
                                      "start_time": sess["start_time"],
                                      "ist_date": ist_date,
                                      "time_format": "IST",
                                      "url": url,
                                      "prossessing_video": prossessing_video,
                                      "meet_recordings_url": meet_recordings_url,
                                      "password": sess["password"] if sess.get("password") else "",
                                      "meeting_details": sess["meeting_details"],
                                      "confFld": sess["confFld"],
                                      'liveSession_title': sess['liveSession_title'] if sess.get('liveSession_title') else 'Live Session',
                                      'session_over': session_over
                                      }
                    try:
                        meeting_detail["waiting_room"] = sess["waiting_room"]
                    except:
                        meeting_detail["waiting_room"] = True

                    processed_live_sessions.append(meeting_detail)
                else:
                    url = sess['url']
                    meet_recordings_url = ""
                    x = datetime.datetime.utcnow()
                    now = x.strftime("%Y-%m-%d %H:%M")
                    start_datetime_object = start_date_time.strftime("%Y-%m-%d %H:%M")
                    end_datetime_object = end_date_time.strftime("%Y-%m-%d %H:%M")
                    if "zoom" in url or "recorded-sessions" in url:
                        meeting_id = ""
                        if "zoom" in url:
                            meeting_id = url.split('?')[0].split('/')[-1]
                        elif "recorded-sessions" in url:
                            meeting_id = url.split('.mp4')[0].split('-')[-1]
                        meet_details = mongo_session.get_all_data_for_particular_condition_fields(
                            collection="course_sessions",
                            condition={
                                "key": "live_session",
                                "url": {"$regex": str(meeting_id)}
                                }
                        )
                        meet_recordings_url = ""
                        if meet_details["message"]:
                            participants_information = mongo_session.check_existance_return_info(
                                collection="course_sessions",
                                condition={
                                    "key": "live_session",
                                    "url": {"$regex": str(meeting_id)}
                                    },
                                columns={"meeting_id": 1,
                                        "occurrence_id": 1},
                                return_keys=["_id", "meeting_id", "occurrence_id"])
                            if not participants_information.get("meeting_id"):
                                print("Live Attendance is not avaialble on this session, "
                                                "Please upload the attendance sheet to mark attendance.")
                            else:
                                meet_recordings = mongo_session.check_existance_return_info(
                                    collection="zoom_meetings",
                                    condition={"meeting_id": int(participants_information["meeting_id"]),
                                            "total_recordings.occurrence_id": participants_information["occurrence_id"]},
                                    columns={"total_recordings.$": 1},
                                    whole_doc=True)
                                if not meet_recordings or not meet_recordings["total_recordings"]:
                                    print("Live Attendance is not avaialble on this session, "
                                                    "Please upload the attendance sheet to mark attendance.")
                                else:
                                    meet_recordings_url = meet_recordings["total_recordings"][0]["recording_s3_key"]
                            if len(meet_details["message"]) > 0:
                                session_over = ""
                                if meet_details["message"][0]["status"] == "active":
                                    session_over = "False"
                                elif meet_details["message"][0]["status"] == "inactive" or meet_details["message"][0]["status"] == "zoom_recorded":
                                    session_over = "True"
                            else:
                                session_over =  ""
                                if end_datetime_object < now:
                                    session_over = "True"
                        # threshold time is maximum we allow processing video option to be true
                        threshold_time = (end_date_time + datetime.timedelta(minutes=20)).strftime("%Y-%m-%d %H:%M")
                        if len(meet_details["message"]) > 0:
                            if session_over == "True" and threshold_time > now and not meet_details["message"][0]["status"] == "zoom_recorded":
                                prossessing_video = "True"
                            elif session_over == "True" and (threshold_time < now or meet_details["message"][0]["status"] == "zoom_recorded"):
                                prossessing_video = "False"
                            else:
                                prossessing_video = "False"
                        else:
                            prossessing_video = "False"
                    sess['session_over'] = session_over
                    sess['prossessing_video'] = prossessing_video
                    sess["meet_recordings_url"] = meet_recordings_url
                    sess["ist_date"] = ist_date
                    sess["time_format"] = "IST"
                    sess['liveSession_title'] = sess['liveSession_title'] if sess.get(
                        'liveSession_title') else 'Live Session'
                    processed_live_sessions.append(sess)
        else:
            # replace the url with joining url from the meeting
            for sess in course_data["live_sessions"]:
                start_date_time = str(sess['start_date']['year']) + '-' + str(sess['start_date']['month']) + '-' + \
                                  str(sess['start_date']['day']) + ' ' + sess['start_time']
                date_time_obj = str_to_utc_datetime_obj(start_date_time, '%Y-%m-%d %H:%M')
                start_date_time = str_to_utc_datetime_obj(start_date_time, '%Y-%m-%d %H:%M')
                current_date = str(utc_datetime_now())
                end_date_time = str(sess['end_date']['year']) + '-' + str(sess['end_date']['month']) + '-' + \
                                str(sess['end_date']['day']) + ' ' + sess['start_time']
                end_date_time = str_to_utc_datetime_obj(end_date_time, '%Y-%m-%d %H:%M')
                end_date_time = end_date_time + datetime.timedelta(minutes=int(sess["duration"]))
                date = current_date.split(' ')[0] + " " + sess['start_time']
                current_date = str_to_utc_datetime_obj(date, '%Y-%m-%d %H:%M')
                if end_date_time >= current_date >= date_time_obj:
                    if sess["frequency"] == "daily":
                        ist_date = str(convert_utc_to_ist(current_date))

                    if sess["frequency"] == "weekly":
                        days = abs(current_date - date_time_obj).days
                        if days % 7 != 0:
                            day_diff = 7 - days % 7
                            current_date = current_date + datetime.timedelta(days=day_diff)
                            ist_date = str(convert_utc_to_ist(current_date))
                        else:
                            ist_date = str(convert_utc_to_ist(current_date))
                elif end_date_time >= current_date and current_date <= date_time_obj:
                    ist_date = str(convert_utc_to_ist(date_time_obj))
                else:
                    ist_date = str(convert_utc_to_ist(end_date_time))
                if sess.get("meeting_details") and sess["meeting_details"]:
                    url = sess["meeting_details"]["join_url"]
                    if sess.get('subscriber_url'):
                        if str(user_id) in sess['subscriber_url'].keys():
                            url = sess['subscriber_url'][str(user_id)]['url']
                    x = datetime.datetime.utcnow()
                    now = x.strftime("%Y-%m-%d %H:%M")
                    start_datetime_object = start_date_time.strftime("%Y-%m-%d %H:%M")
                    end_datetime_object = end_date_time.strftime("%Y-%m-%d %H:%M")
                    if "zoom" in url or "recorded-sessions" in url:
                        meeting_id = ""
                        if "zoom" in url:
                            meeting_id = url.split('?')[0].split('/')[-1]
                        elif "recorded-sessions" in url:
                            meeting_id = url.split('.mp4')[0].split('-')[-1]
                        meet_details = mongo_session.get_all_data_for_particular_condition_fields(
                            collection="course_sessions",
                            condition={
                                "key": "live_session",
                                "url": {"$regex": str(meeting_id)}
                                }
                        )
                        meet_recordings_url = ""
                        if meet_details["message"]:
                            participants_information = mongo_session.check_existance_return_info(
                                collection="course_sessions",
                                condition={
                                    "key": "live_session",
                                    "url": {"$regex": str(meeting_id)}
                                    },
                                columns={"meeting_id": 1,
                                        "occurrence_id": 1},
                                return_keys=["_id", "meeting_id", "occurrence_id"])
                            if not participants_information.get("meeting_id"):
                                print("Live Attendance is not avaialble on this session, "
                                                "Please upload the attendance sheet to mark attendance.")
                            else:
                                meet_recordings = mongo_session.check_existance_return_info(
                                    collection="zoom_meetings",
                                    condition={"meeting_id": int(participants_information["meeting_id"]),
                                            "total_recordings.occurrence_id": participants_information["occurrence_id"]},
                                    columns={"total_recordings.$": 1},
                                    whole_doc=True)
                                if not meet_recordings or not meet_recordings["total_recordings"]:
                                    print("Live Attendance is not avaialble on this session, "
                                                    "Please upload the attendance sheet to mark attendance.")
                                else:
                                    meet_recordings_url = meet_recordings["total_recordings"][0]["recording_s3_key"]
                        if len(meet_details["message"]) > 0:
                            session_over = ""
                            if meet_details["message"][0]["status"] == "active":
                                session_over = "False"
                            elif meet_details["message"][0]["status"] == "inactive" or meet_details["message"][0]["status"] == "zoom_recorded":
                                session_over = "True"
                        else:
                            session_over =  ""
                            if end_datetime_object < now:
                                session_over = "True"
                        threshold_time = (end_date_time + datetime.timedelta(minutes=20)).strftime("%Y-%m-%d %H:%M")
                        if len(meet_details["message"]) > 0:
                            if session_over == "True" and threshold_time > now and not meet_details["message"][0]["status"] == "zoom_recorded":
                                prossessing_video = "True"
                            elif session_over == "True" and (threshold_time < now or meet_details["message"][0]["status"] == "zoom_recorded"):
                                prossessing_video = "False"
                            else:
                                prossessing_video = "False"
                        else:
                            prossessing_video = "False"
                    meeting_detail = {"duration": sess["duration"],
                                      "end_date": sess["end_date"],
                                      "frequency": sess["frequency"],
                                      "start_date": sess["start_date"],
                                      "start_time": sess["start_time"],
                                      "url": url,
                                      "prossessing_video": prossessing_video,
                                      "meet_recordings_url": meet_recordings_url,
                                      "meeting_details": sess["meeting_details"],
                                      "confFld": sess["confFld"],
                                      "ist_date": ist_date,
                                      "time_format": "IST",
                                      'liveSession_title': sess['liveSession_title'] if sess.get('liveSession_title') else 'Live Session',
                                      'session_over': session_over
                                      }
                    processed_live_sessions.append(meeting_detail)
                else:
                    url = sess["url"]
                    meet_recordings_url = ""
                    x = datetime.datetime.utcnow()
                    now = x.strftime("%Y-%m-%d %H:%M")
                    start_datetime_object = start_date_time.strftime("%Y-%m-%d %H:%M")
                    end_datetime_object = end_date_time.strftime("%Y-%m-%d %H:%M")
                    if "zoom" in url or "recorded-sessions" in url:
                        meeting_id = ""
                        if "zoom" in url:
                            meeting_id = url.split('?')[0].split('/')[-1]
                        elif "recorded-sessions" in url:
                            meeting_id = url.split('.mp4')[0].split('-')[-1]
                        meet_details = mongo_session.get_all_data_for_particular_condition_fields(
                            collection="course_sessions",
                            condition={
                                "key": "live_session",
                                "url": {"$regex": str(meeting_id)}
                                }
                        )
                        if meet_details["message"]:
                            participants_information = mongo_session.check_existance_return_info(
                                collection="course_sessions",
                                condition={
                                    "key": "live_session",
                                    "url": {"$regex": str(meeting_id)}
                                    },
                                columns={"meeting_id": 1,
                                        "occurrence_id": 1},
                                return_keys=["_id", "meeting_id", "occurrence_id"])
                            if not participants_information.get("meeting_id"):
                                print("Live Attendance is not avaialble on this session, "
                                                "Please upload the attendance sheet to mark attendance.")
                            else:
                                meet_recordings = mongo_session.check_existance_return_info(
                                    collection="zoom_meetings",
                                    condition={"meeting_id": int(participants_information["meeting_id"]),
                                            "total_recordings.occurrence_id": participants_information["occurrence_id"]},
                                    columns={"total_recordings.$": 1},
                                    whole_doc=True)
                                if not meet_recordings or not meet_recordings["total_recordings"]:
                                    print("Live Attendance is not avaialble on this session, "
                                                    "Please upload the attendance sheet to mark attendance.")
                                else:
                                    meet_recordings_url = meet_recordings["total_recordings"][0]["recording_s3_key"]
                        if len(meet_details["message"]) > 0:
                            session_over = ""
                            if meet_details["message"][0]["status"] == "active":
                                session_over = "False"
                            elif meet_details["message"][0]["status"] == "inactive" or meet_details["message"][0]["status"] == "zoom_recorded":
                                session_over = "True"
                        else:
                            session_over =  ""
                            if end_datetime_object < now:
                                session_over = "True"
                        threshold_time = (end_date_time + datetime.timedelta(minutes=20)).strftime("%Y-%m-%d %H:%M")
                        if len(meet_details["message"]) > 0:
                            if session_over == "True" and threshold_time > now and not meet_details["message"][0]["status"] == "zoom_recorded":
                                prossessing_video = "True"
                            elif session_over == "True" and (threshold_time < now or meet_details["message"][0]["status"] == "zoom_recorded"):
                                prossessing_video = "False"
                            else:
                                prossessing_video = "False"
                        else:
                            prossessing_video = "False"
                    sess['session_over'] = session_over
                    sess['prossessing_video'] = prossessing_video
                    sess["meet_recordings_url"] = meet_recordings_url
                    sess["ist_date"] = ist_date
                    sess["time_format"] = "IST"
                    sess['liveSession_title'] = sess['liveSession_title'] if sess.get(
                        'liveSession_title') else 'Live Session'
                    processed_live_sessions.append(sess)
    return processed_live_sessions
