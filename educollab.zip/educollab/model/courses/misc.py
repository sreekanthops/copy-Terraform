import re
import time
from bson import ObjectId
from model import Content as Content
from db_wrapper.tasks import Mongo
mongo_session = Mongo()
import datetime

from routes.exception import InvalidUsage
from utils.elasticsearch.resource_bank import insert_resource_elastic
from utils.time_conversions import utc_datetime_now


def schedule_course_work(course_work_data,
                         course_work_type):
    if course_work_type == "course":
        if not mongo_session.check_existance_return_info(collection="course_work_bank",
                                                         condition={"_id": ObjectId(course_work_data["_id"]),
                                                                    "publish": True}):
            raise InvalidUsage("Please use published course works only.", 400)
        doc_to_insert = {"course_work_id": ObjectId(course_work_data["_id"]),
                         "group_type": course_work_data["group_type"],
                         "start_date": course_work_data["date"],
                         "start_time": course_work_data["time"],
                         "submissions": [],
                         "reviews": {
                             "peer": {
                                 "required": False,
                                 "min_count": 0,
                                 "data": []
                             },
                             "user": {
                                 "required": False
                             }
                         },
                         "teams": []
                         }
        # PK - Added code for peer review and self review
        if course_work_data.get('peer_review'):
            if course_work_data['peer_review'] == True:
                doc_to_insert['peer_review'] = True
            else:
                doc_to_insert['peer_review'] = False

        if course_work_data.get('self_review'):
            if course_work_data['self_review'] == True:
                doc_to_insert['self_review'] = True
            else:
                doc_to_insert['self_review'] = False
        insert_doc = mongo_session.insert_documnet(collection='course_work_instances', doc_to_insert=doc_to_insert)
    return insert_doc['_id'].inserted_id


def manage_course_s3_resources(resource_id):
    check_resource = mongo_session.check_existance_return_info(collection='global_resource_bank',
                                                               condition={'_id': ObjectId(resource_id)},
                                                               whole_doc=True)
    if not check_resource:
        resource_bank_resource_id = mongo_session.insert_files_resource_bank(
            collection="global_resource_bank",
            resource_id=ObjectId(resource_id),
            temp_collection="temp_uploaded_files")['message']
    else:
        resource_bank_resource_id = resource_id
    s3_key_info = mongo_session.fetch_s3_key_temp_uploaded_files(
        collection="temp_uploaded_files",
        condition={
            "_id": ObjectId(resource_id)},
        columns={"s3_key": 1})
    return resource_bank_resource_id, s3_key_info


def seen_asess_feedback(user_id, role, assessment_id, course_id, topic_id=None, course_session_id=None,
                        schedule_id=None):
    # This is to check whether user can submit assessment or not on the basis of whether user has seen the feedback or
    # not.
    seen_status = False
    if role != "super_admin":
        condition = {"user_id": ObjectId(user_id),
                     "assessment_id": ObjectId(assessment_id),
                     "course_id": ObjectId(course_id),
                     "topic_id": ObjectId(topic_id) if topic_id else "",
                     "course_session_id": ObjectId(course_session_id) if course_session_id else ""}
        if schedule_id:
            condition["schedule_assessment_id"] = ObjectId(schedule_id)

        user_submission = mongo_session.check_existance_return_info(collection="assessments_result",
                                                                    condition=condition,
                                                                    columns={'_id': 1,
                                                                             'feedback_seen': 1},
                                                                    return_keys=['_id', 'feedback_seen'])
        if user_submission:
            if user_submission["feedback_seen"] and user_submission["feedback_seen"]["status"]:
                seen_status = True
    return seen_status


def update_schedule_assessment(assessment_data, assessment_type, schedule_id):
    assessment_collection = mongo_session.get_all_data_for_particular_condition_fields("assessment",
                                                                                       {"_id": ObjectId(
                                                                                           assessment_data['_id'])})[
        'message'][0]

    total_time = int(assessment_collection['total_time'])
    if assessment_type == "course":
        start_time_str = Content.webapp_time_to_string(assessment_data['date'], assessment_data['time'])

        start_time_obj = datetime.datetime.strptime(start_time_str, "%Y:%m:%dT%H:%M")

        end_time = start_time_obj + datetime.timedelta(minutes=total_time)
        end_time_str = end_time.strftime("%Y:%m:%dT%H:%M")

        update_schedule_assess = mongo_session.update_record_into_db(
            collection="schedule_assessment",
            condition={"_id": schedule_id},
            update_info={"$set": {"start_time": start_time_str, "end_time": end_time_str}})
        if update_schedule_assess["status"] != 200:
            raise Exception("Some internal error, Please try again later.")
    return schedule_id


def upload_course_topic(topic, unique_assess, user_id, course_class):
    """Purpose: To upload a topic which is a part of the course into db under course_topics. It involves processing of
                sessions, resources, assessments and course work attached to that particular topic.
       Parameters:
           1. topic: it contains all the information related to topic like resources, assessments and course works.
           2. unique_assess: it is an array which contains the assessment ids which has already been used in the course.
    """
    processed_sessions = []
    delete_record_list = []
    for session in topic['sessions']:
        processed_session, delete_resources, unique_assess = upload_course_session(session, unique_assess, user_id)
        processed_sessions.append(processed_session)
        delete_record_list = delete_record_list + delete_resources
    # topic resources
    instance_ids = []
    if topic.get('resources'):
        for resource in topic['resources']:
            if resource['type'] == 'file':
                resource_id = resource['_id']
                check_resource = mongo_session.check_existance_return_info(collection='global_resource_bank',
                                                                           condition={'_id': ObjectId(resource_id)},
                                                                           whole_doc=True)
                if check_resource:
                    doc_to_insert = {
                        "resource_id": ObjectId(resource_id),
                        "tags": [],
                        "description": "",
                        "title": resource['title'],
                        "module": "course",
                        "used_at": "",
                        "updated_at": utc_datetime_now(),
                        "updated_by": ObjectId(user_id),
                    }
                    resource['url'] = check_resource['s3_key']
                    resource['_id'] = ObjectId(resource_id)
                    resp_id = mongo_session.insert_documnet(collection="resource_bank_instance",
                                                            doc_to_insert=doc_to_insert)
                    resource['instance_id'] = resp_id['_id'].inserted_id
                    instance_ids.append(resource['instance_id'])

                elif check_resource is None:
                    course_bank_find = mongo_session.check_existance_return_info(collection='course_resource_bank',
                                                                                 condition={
                                                                                     "_id": ObjectId(resource_id)
                                                                                 },
                                                                                 whole_doc=True)
                    if course_bank_find:
                        some = mongo_session.transfer_docs_another_collection(from_collection='course_resource_bank',
                                                                              to_collection='global_resource_bank',
                                                                              condition={"_id": ObjectId(resource_id)})
                        resource['url'] = course_bank_find['s3_key']
                        resource['_id'] = ObjectId(resource_id)
                    passion_project_find = mongo_session.check_existance_return_info(collection='resources',
                                                                                     condition={
                                                                                         "_id": ObjectId(resource_id)
                                                                                     },
                                                                                     whole_doc=True)
                    if passion_project_find:
                        some = mongo_session.transfer_docs_another_collection(from_collection='resources',
                                                                              to_collection='global_resource_bank',
                                                                              condition={"_id": ObjectId(resource_id)})
                        resource['url'] = passion_project_find['s3_key']
                        resource['_id'] = ObjectId(resource_id)
                    if passion_project_find or course_bank_find:
                        doc_to_insert = {
                            "resource_id": ObjectId(resource_id),
                            "tags": [],
                            "description": "",
                            "title": resource['title'],
                            "module": "course",
                            "used_at": "",
                            "updated_at": utc_datetime_now(),
                            "updated_by": ObjectId(user_id),
                        }
                        resp_id = mongo_session.insert_documnet(collection="resource_bank_instance",
                                                                doc_to_insert=doc_to_insert)
                        resource['instance_id'] = resp_id['_id'].inserted_id
                        instance_ids.append(resource['instance_id'])
                    else:
                        delete_record_list.append(ObjectId(resource_id))
                        resource_bank_resource_id, s3_key_info = manage_course_s3_resources(resource_id)
                        resource['_id'] = resource_bank_resource_id
                        if s3_key_info['status'] != 200:
                            return {}, "Error occurred while adding resources", 500
                        resource['url'] = s3_key_info['message']
                        doc_to_insert = {
                            "resource_id": ObjectId(resource_bank_resource_id),
                            "tags": [],
                            "description": "",
                            "title": resource['title'],
                            "module": "course",
                            "used_at": "",
                            "updated_at": utc_datetime_now(),
                            "updated_by": ObjectId(user_id),
                        }
                        resp_id = mongo_session.insert_documnet(collection="resource_bank_instance",
                                                                doc_to_insert=doc_to_insert)
                        resource['instance_id'] = resp_id['_id'].inserted_id
                        instance_ids.append(resource['instance_id'])
                        resource_info = mongo_session.check_existance_return_info(collection='global_resource_bank',
                                                                                  condition={
                                                                                      '_id': ObjectId(
                                                                                          resource_bank_resource_id)},
                                                                                  return_keys=['uploaded_at',
                                                                                               'user_id'])
                        created_at = time.strftime('%Y-%m-%d %H:%M', time.localtime(int(resource_info['uploaded_at'])))
                        item_type = ""
                        if re.findall('\.mp4', resource['url']):
                            item_type = "video"
                        if re.findall('\.png|\.jpg|\.jpeg', resource['url']):
                            item_type = "image"
                        if re.findall('\.pdf|\.zip|\.doc|\.docx|\.ppt|\.pptx|\.txt|\.xml|\.rar|\.csv|\.mp3|\.xlsx',
                                      resource['url']):
                            item_type = "file"
                        if re.findall('\.py|\.ipynb', resource['url']):
                            item_type = "python"

                        data_resource = {'url': resource['url'], '_id': resource_bank_resource_id,
                                         'title': resource['title'],
                                         'description': "", 'module_name': 'course',
                                         'mongo_collection': 'course_resource_bank', 'tags': [],
                                         'created_by': resource_info['user_id'], 'created_at': created_at,
                                         'file_type': item_type}
                        insert_resource_elastic(data_resource)
    # topic course work
    topic_course_work = []
    if topic.get('course_work'):
        for work in topic['course_work']:
            schedule_course_work_id = schedule_course_work(
                course_work_data=work,
                course_work_type="course")
            topic_course_work.append({"_id": ObjectId(work['_id']),
                                      "schedule_id": schedule_course_work_id})
    # topic assessments
    topic_assessments = []
    if topic.get('assessments'):
        for assessment in topic['assessments']:
            if str(assessment["_id"]) in unique_assess:
                raise InvalidUsage("An assessment can only be used once in a course.", 400)
            unique_assess.append(str(assessment["_id"]))
            if assessment["calendered"] or assessment["is_timed"]:
                if course_class == "Self Paced Course":
                    raise InvalidUsage("Calendered or Timed assessment not allowed in Self Paced Courses.", 406)
            if not assessment['calendered']:
                topic_assessments.append({"_id": ObjectId(assessment['_id']),
                                          "is_timed": bool(assessment["is_timed"]),
                                          "one_time_assessment": bool(assessment["one_time_assessment"])})
            if assessment['calendered']:
                schedule_assessment_id = Content.schedule_assessment(
                    assessment_data=assessment,
                    assessment_type="course")
                topic_assessments.append({"_id": ObjectId(assessment['_id']),
                                          "schedule_id": schedule_assessment_id,
                                          "is_timed": bool(assessment["is_timed"]),
                                          "one_time_assessment": bool(assessment["one_time_assessment"])})

    topic_data = {"title": topic['title'],
                  "description": topic['description'],
                  "sessions": processed_sessions,
                  "resources": topic['resources'],
                  "course_work": topic_course_work,
                  "assessments": topic_assessments}
    insert_topic = mongo_session.insert_documnet(collection='course_topics',
                                                 doc_to_insert=topic_data)
    used_at = {"$set": {"used_at": {'topic_id': ObjectId(insert_topic['_id'].inserted_id)}}}
    condition = {"_id": {"$in": instance_ids}}
    updation = mongo_session.update_db_data(collection='resource_bank_instance', condition=condition,
                                            update_info=used_at, multi=True)
    return {"_id": ObjectId(insert_topic['_id'].inserted_id)}, delete_record_list, unique_assess


def update_schedule_course_work(course_work_data, course_work_type, schedule_id):
    if course_work_type == "course":
        update_schedule_work = mongo_session.update_record_into_db(
            collection="course_work_instances",
            condition={"_id": schedule_id},
            update_info={"$set": course_work_data})
        if update_schedule_work["status"] != 200:
            raise Exception("Some internal error, Please try again later.")
    return schedule_id


def upload_course_session(session, unique_assess, user_id):
    """Purpose: To upload a session which is a part of a topic in the course into db under course_sessions. It involves
                processing of resources, assessments and videos attached to that particular session.
       Parameters:
               1. session: it contains all the information related to session like resources, assessments and video.
               2. unique_assess: it is an array which contains the assessment ids which has already been used in the course.
    """
    url = ""
    file_id = ""
    type_of_doc = ""
    delete_record_list = []
    instance_ids = []
    instance_id = ""
    if session['key'] == "session":
        type_of_doc = session['type']
        if session['type'] == "file":
            resource_id = session['file_id']
            check_resource = mongo_session.check_existance_return_info(collection='global_resource_bank',
                                                                       condition={'_id': ObjectId(resource_id)},
                                                                       whole_doc=True)
            if check_resource:
                doc_to_insert = {
                    "resource_id": ObjectId(resource_id),
                    "tags": [],
                    "description": "",
                    "title": session['title'],
                    "module": "course",
                    "used_at": "",
                    "updated_at": utc_datetime_now(),
                    "updated_by": ObjectId(user_id),
                }
                url = check_resource['s3_key']
                resp_id = mongo_session.insert_documnet(collection="resource_bank_instance",
                                                        doc_to_insert=doc_to_insert)
                instance_id = resp_id['_id'].inserted_id
                instance_ids.append(instance_id)
                file_id = session['file_id']

            elif check_resource is None:
                course_bank_find = mongo_session.check_existance_return_info(collection='course_resource_bank',
                                                                             condition={
                                                                                 "_id": ObjectId(resource_id)
                                                                             },
                                                                             whole_doc=True)
                if course_bank_find:
                    some = mongo_session.transfer_docs_another_collection(from_collection='course_resource_bank',
                                                                          to_collection='global_resource_bank',
                                                                          condition={"_id": ObjectId(resource_id)})
                    url = course_bank_find['s3_key']
                    file_id = session['file_id']
                passion_project_find = mongo_session.check_existance_return_info(collection='resources',
                                                                                 condition={
                                                                                     "_id": ObjectId(resource_id)
                                                                                 },
                                                                                 whole_doc=True)
                if passion_project_find:
                    some = mongo_session.transfer_docs_another_collection(from_collection='resources',
                                                                          to_collection='global_resource_bank',
                                                                          condition={"_id": ObjectId(resource_id)})
                    url = passion_project_find['s3_key']
                    file_id = session['file_id']
                if passion_project_find or course_bank_find:
                    doc_to_insert = {
                        "resource_id": ObjectId(resource_id),
                        "tags": [],
                        "description": "",
                        "title": session['title'],
                        "module": "course",
                        "used_at": "",
                        "updated_at": utc_datetime_now(),
                        "updated_by": ObjectId(user_id),
                    }
                    resp_id = mongo_session.insert_documnet(collection="resource_bank_instance",
                                                            doc_to_insert=doc_to_insert)
                    instance_id = resp_id['_id'].inserted_id
                    instance_ids.append(instance_id)
                else:
                    delete_record_list.append(ObjectId(resource_id))
                    resource_bank_resource_id, s3_key_info = manage_course_s3_resources(resource_id)
                    file_id = resource_bank_resource_id
                    if s3_key_info['status'] != 200:
                        return {}, "Error occurred while adding resources", 500
                    url = s3_key_info['message']
                    doc_to_insert = {
                        "resource_id": ObjectId(resource_bank_resource_id),
                        "tags": [],
                        "description": "",
                        "title": session['title'],
                        "module": "course",
                        "used_at": "",
                        "updated_at": utc_datetime_now(),
                        "updated_by": ObjectId(user_id),
                    }
                    resp_id = mongo_session.insert_documnet(collection="resource_bank_instance",
                                                            doc_to_insert=doc_to_insert)
                    instance_id = resp_id['_id'].inserted_id
                    instance_ids.append(instance_id)
                    resource_info = mongo_session.check_existance_return_info(collection='global_resource_bank',
                                                                              condition={
                                                                                  '_id': ObjectId(
                                                                                      resource_bank_resource_id)},
                                                                              return_keys=['uploaded_at', 'user_id'])
                    created_at = time.strftime('%Y-%m-%d %H:%M', time.localtime(int(resource_info['uploaded_at'])))
                    item_type = ""
                    if re.findall('\.mp4', url):
                        item_type = "video"
                    if re.findall('\.png|\.jpg|\.jpeg', url):
                        item_type = "image"
                    if re.findall('\.pdf|\.zip|\.doc|\.docx|\.ppt|\.pptx|\.txt|\.xml|\.rar|\.csv|\.mp3|\.xlsx', url):
                        item_type = "file"
                    if re.findall('\.py|\.ipynb', url):
                        item_type = "python"

                    data_resource = {'url': url, '_id': resource_bank_resource_id, 'title': session['title'],
                                     'description': session['description'], 'module_name': 'course',
                                     'mongo_collection': 'course_resource_bank',
                                     'tags': [], 'created_by': resource_info['user_id'], 'created_at': created_at,
                                     'file_type': item_type}
                    insert_resource_elastic(data_resource)
        else:
            url = session['url']
        for assessment in session['assessments']:
            assessment["_id"] = ObjectId(assessment['_id'])
            if str(assessment["_id"]) in unique_assess:
                raise InvalidUsage("An assessment can only be used once in a course", 400)
            unique_assess.append(str(assessment["_id"]))
    if session['key'] == "live_session":
        for assessment in session['assessments']:
            assessment["_id"] = ObjectId(assessment['_id'])
            if str(assessment["_id"]) in unique_assess:
                raise InvalidUsage("An assessment can only be used once in a course", 400)
            unique_assess.append(str(assessment["_id"]))
    # session resources
    if session.get('resources'):
        for resource in session['resources']:
            if resource['type'] == 'file':
                resource_id = resource['_id']
                check_resource = mongo_session.check_existance_return_info(collection='global_resource_bank',
                                                                           condition={'_id': ObjectId(resource_id)},
                                                                           whole_doc=True)
                if check_resource:
                    doc_to_insert = {
                        "resource_id": ObjectId(resource_id),
                        "tags": [],
                        "description": "",
                        "title": resource['title'],
                        "module": "course",
                        "used_at": "",
                        "updated_at": utc_datetime_now(),
                        "updated_by": ObjectId(user_id),
                    }
                    resource['url'] = check_resource['s3_key']
                    resource['_id'] = ObjectId(resource_id)
                    resp_id = mongo_session.insert_documnet(collection="resource_bank_instance",
                                                            doc_to_insert=doc_to_insert)
                    resource['instance_id'] = resp_id['_id'].inserted_id
                    instance_ids.append(resource['instance_id'])

                elif check_resource is None:
                    course_bank_find = mongo_session.check_existance_return_info(collection='course_resource_bank',
                                                                                 condition={
                                                                                     "_id": ObjectId(resource_id)
                                                                                 },
                                                                                 whole_doc=True)
                    if course_bank_find:
                        some = mongo_session.transfer_docs_another_collection(from_collection='course_resource_bank',
                                                                              to_collection='global_resource_bank',
                                                                              condition={"_id": ObjectId(resource_id)})
                        resource['url'] = course_bank_find['s3_key']
                        resource['_id'] = ObjectId(resource_id)
                    passion_project_find = mongo_session.check_existance_return_info(collection='resources',
                                                                                     condition={
                                                                                         "_id": ObjectId(resource_id)
                                                                                     },
                                                                                     whole_doc=True)
                    if passion_project_find:
                        some = mongo_session.transfer_docs_another_collection(from_collection='resources',
                                                                              to_collection='global_resource_bank',
                                                                              condition={"_id": ObjectId(resource_id)})
                        resource['url'] = passion_project_find['s3_key']
                        resource['_id'] = ObjectId(resource_id)
                    if passion_project_find or course_bank_find:
                        doc_to_insert = {
                            "resource_id": ObjectId(resource_id),
                            "tags": [],
                            "description": "",
                            "title": resource['title'],
                            "module": "course",
                            "used_at": "",
                            "updated_at": utc_datetime_now(),
                            "updated_by": ObjectId(user_id),
                        }
                        resp_id = mongo_session.insert_documnet(collection="resource_bank_instance",
                                                                doc_to_insert=doc_to_insert)
                        resource['instance_id'] = resp_id['_id'].inserted_id
                        instance_ids.append(resource['instance_id'])
                    else:
                        delete_record_list.append(ObjectId(resource_id))
                        resource_bank_resource_id, s3_key_info = manage_course_s3_resources(resource_id)
                        resource['_id'] = resource_bank_resource_id
                        if s3_key_info['status'] != 200:
                            return {}, "Error occurred while adding resources", 500
                        resource['url'] = s3_key_info['message']
                        doc_to_insert = {
                            "resource_id": ObjectId(resource_bank_resource_id),
                            "tags": [],
                            "description": "",
                            "title": resource['title'],
                            "module": "course",
                            "used_at": "",
                            "updated_at": utc_datetime_now(),
                            "updated_by": ObjectId(user_id),
                        }
                        resp_id = mongo_session.insert_documnet(collection="resource_bank_instance",
                                                                doc_to_insert=doc_to_insert)
                        resource['instance_id'] = resp_id['_id'].inserted_id
                        instance_ids.append(resource['instance_id'])
                        resource_info = mongo_session.check_existance_return_info(collection='global_resource_bank',
                                                                                  condition={
                                                                                      '_id': ObjectId(
                                                                                          resource_bank_resource_id)},
                                                                                  return_keys=['uploaded_at',
                                                                                               'user_id'])
                        created_at = time.strftime('%Y-%m-%d %H:%M', time.localtime(int(resource_info['uploaded_at'])))
                        item_type = ""
                        if re.findall('\.mp4', resource['url']):
                            item_type = "video"
                        if re.findall('\.png|\.jpg|\.jpeg', resource['url']):
                            item_type = "image"
                        if re.findall('\.pdf|\.zip|\.doc|\.docx|\.ppt|\.pptx|\.txt|\.xml|\.rar|\.csv|\.mp3|\.xlsx',
                                      resource['url']):
                            item_type = "file"
                        if re.findall('\.py|\.ipynb', resource['url']):
                            item_type = "python"

                        data_resource = {'url': resource['url'], '_id': resource_bank_resource_id,
                                         'title': resource['title'],
                                         'description': "", 'module_name': 'course',
                                         'mongo_collection': 'course_resource_bank', 'tags': [],
                                         'created_by': resource_info['user_id'], 'created_at': created_at,
                                         'file_type': item_type}
                        insert_resource_elastic(data_resource)
    if len(url) > 0:
        pattern = re.compile(
                    "^((?:https?:)?\/\/)?((?:www|m)\.)?((?:youtube(-nocookie)?\.com|youtu.be))(\/(?:[\w\-]+\?v=|embed\/|v\/)?)([\w\-]+)(\S+)?$")
        if pattern.match(url):
            if "&list=" in url:
                url = url.split("&list=")[0]
    session_data = {"title": session["title"],
                    "description": session["description"],
                    "key": session['key'],
                    "url": url,
                    "file_id": file_id,
                    "type": type_of_doc,
                    "assessments": session['assessments'],
                    "resources": session['resources'],
                    "instance_id": ObjectId(instance_id) if instance_id else ""}
    insert_session = mongo_session.insert_documnet(collection='course_sessions',
                                                   doc_to_insert=session_data)
    used_at = {"$set": {"used_at": {'session_id': ObjectId(insert_session['_id'].inserted_id)}}}
    condition = {"_id": {"$in": instance_ids}}
    updation = mongo_session.update_db_data(collection='resource_bank_instance', condition=condition,
                                            update_info=used_at, multi=True)
    return {"_id": insert_session['_id'].inserted_id}, delete_record_list, unique_assess
