from bson import ObjectId

from db_wrapper.tasks import Mongo
from routes.exception import InvalidUsage
from slugify import slugify
from utils.time_conversions import utc_datetime_now
import regex

mongo_session = Mongo()


def fetch_organisations():
    """ To fetch details of the organisations we have in Educollab."""
    organisations = []
    query = mongo_session.access_specific_fields(
        collection="organisations",
        columns={"_id": 1, "name": 1, "slug": 1, "organisation_type": 1})
    if query == []:
        raise Exception("Unable to retrieve organisations.")
    for org in query:
        new_type_id = org.get("organisation_type", "")
        if new_type_id != "":
            org_type_data = mongo_session.access_specific_fields(
                collection="organisations_type",
                condition={"_id": ObjectId(new_type_id)},
                columns={"_id": 1, "slug": 1, "name": 1})
            org_type_data = org_type_data[0]
            org_type_data["_id"] = str(org_type_data["_id"])

        else:
            org_type_data = {}
        organisations.append({
            "_id": str(org['_id']),
            "name": org['name'],
            "slug": org['slug'],
            "organisation_type": org_type_data
        })
    return organisations



def add_organisation(role, user_id, new_org,organisation_type_id):
    """
    This is to add new organisation into the database. Only Super Admin can add any organisation.
    """
    if role != "super_admin":
        raise InvalidUsage(message="You don't have permission to add organisation", status_code=403)
    org_check = validate_organisation_name(new_org)
    if not org_check:
        raise InvalidUsage(message="Organisation name  should only contain alphabets.", status_code=409)
    slug = slugify(new_org)
    find_query = mongo_session.find_data_in_db(collection="organisations", condition={"slug": slug}, columns={})

    if find_query['status'] != 200:
        raise Exception("Error while searching for existing organisation name")

    if find_query['message']:
        raise InvalidUsage(message="An organisation with same name already exists", status_code=409)

    doc_to_insert = {"slug": slug, "name": new_org,"created_at":utc_datetime_now(),"organisation_type":ObjectId(organisation_type_id)}
    add_query = mongo_session.insert_documnet(collection='organisations', doc_to_insert=doc_to_insert)
    if add_query['status'] != 200:
        raise Exception("Error while inserting data in database")

    query = mongo_session.get_data_for_particular_columns_with_condition(
                                collection="organisations",
                                condition={"_id": ObjectId(add_query['_id'].inserted_id)},
                                columns={"_id": 1, "slug": 1, "name": 1})
    if query['status'] != 200:
        raise Exception("Error while communicating with database")
    org_info = query['message'][0]
    data = {"_id": org_info['_id'], "name": org_info['name'], "slug": org_info['slug']}
    return data

def validate_organisation_name(org_name):
    """to validate organisation name"""
    check_string="^[a-zA-Z]+(\s[a-zA-Z]+)?$"
    match=regex.search(check_string,org_name)
    return match




def edit_organisation(role, user_id, new_org,organisation_id,new_type):
    """
    This is to edit organisation name into the database. Only Super Admin can edit any organisation.
    param role: role of registering user.
    param user_id:user_id of registered user
    paarm organisation_id:organisation_id
    param new_org: new_org is the updated name of the organisation
    param new_type: new_org is the updated type of the organisation
    type role: str
    type user_id:str
    type new_org:str
    type organisation_id:str
    """
    if role != "super_admin":
        raise InvalidUsage(message="You don't have permission to add organisation", status_code=403)
    if new_org != "":
        org_check = validate_organisation_name(new_org)
        if not org_check:
            raise InvalidUsage(message="Organisation name  should only contain alphabets.", status_code=409)
        slug = slugify(new_org)
        find_query = mongo_session.check_existance(collection="organisations", condition={"slug": slug})
        if find_query == True:
            raise InvalidUsage(message="An organisation with same name already exists", status_code=409)
    else:
        organisation_query = mongo_session.access_specific_fields(
            collection="organisations", condition={"_id": ObjectId(organisation_id)})
        if not organisation_query:
            raise Exception("Error while searching for existing organisation name")
        new_org_data = organisation_query[0]
        slug = new_org_data.get("slug", "")
        new_org = new_org_data.get("name", "")

    if new_type != "":
        new_type_id = new_type
    else:
        organisation_type_query = mongo_session.access_specific_fields(
            collection="organisations", condition={"_id": ObjectId(organisation_id)})
        if not organisation_type_query:
            raise Exception("Error while searching for existing organisation name")
        new_type_data = organisation_type_query[0]
        new_type_id = new_type_data.get("organisation_type", "")

    condition_query = {"_id": ObjectId(organisation_id)}
    updated_data = {"slug": slug, "name": new_org, "updated_by": ObjectId(user_id), "updated_at": utc_datetime_now(),
                    "organisation_type": ObjectId(new_type_id)}
    add_query = mongo_session.update_multiple_fields(collection='organisations', condition=condition_query,
                                                     set_columns=updated_data)
    if add_query['status'] != 200:
        raise Exception("Error while updating data in database")

    query = mongo_session.access_specific_fields(
        collection="organisations",
        condition={"_id": ObjectId(organisation_id)},
        columns={"_id": 1, "slug": 1, "name": 1, "organisation_type": 1})
    user_response = mongo_session.access_specific_fields(collection="user_profile",
                                                         condition={"organisation_id": ObjectId(organisation_id)},
                                                         columns={"_id": 1, "organisation": 1})
    if user_response:
        for user_profile in user_response:
            result = mongo_session.update_field_based_on_user_id(collection="user_profile", id=user_profile['_id'],
                                                                 field="organisation", value=new_org)
    if query == []:
        raise Exception("Error while communicating with database")
    org_info = query[0]
    data = {"_id": str(org_info['_id']), "name": org_info['name'], "slug": org_info['slug'],
            "organisation_type": str(org_info['organisation_type'])}
    return data


def fetch_organisations_type():
    """ To fetch details of the types of organisations we have in Educollab."""
    org_types = mongo_session.access_specific_fields(collection="organisations_type")
    for org in org_types:
        org["_id"] = str(org["_id"])
    return org_types

