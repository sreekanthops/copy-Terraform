from db_wrapper.tasks import Mongo
from db_wrapper.fetch_functions import Fetch
import traceback
from bson import ObjectId
from datetime import datetime, timedelta

from model.Question import indian_standard_time, filtered_html_tags, convert_utc_ist
from services.storage.s3_services import s3_storage
from model.Content import category_taxonomy_by_category_id
from routes.exception import InvalidUsage
from config import ASSESSMENT_VIEW_COMPONENTS as components_dict
from model.general import get_img_in_question
from config import EMPTY_STRING

from utils.misc import renew_s3_links, is_empty, replace_s3_links_with_keys, validate_ObjectId

s3_function = s3_storage()
mongo_session = Mongo()
fetch_session = Fetch()
from bs4 import BeautifulSoup

from config import email_Address, email_password
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from mongo_connection import connection
from io import StringIO
import pandas as pd
from flask import render_template
import ssl
import re
from bs4 import BeautifulSoup


def view_assessment(assessment_id, components, user_id):
    """
    This gives components of assessment for a corresponding assessment_id
    1. Only the Selected Components of the assessment are returned.
    2. For Comprehension sub_question are displayed only with the components selected.
    """
    if set(components) | set(components_dict.keys()) != set(components_dict.keys()):
        raise InvalidUsage(message="Selected Component is not present in assessment.", status_code=400)

    components_tuple = [(comp, list(components_dict.keys()).index(comp)) for comp in components]
    components = [i[0] for i in sorted(components_tuple, key=lambda tup: tup[1])]

    tags_collection = mongo_session.get_all_data("question_tags")['message']
    tags_dict = dict(map(lambda x: (str(x['_id']), x['tag']), tags_collection))

    global_tags_collection = mongo_session.get_all_data("global_tags")['message']
    global_tags_dict = dict(map(lambda x: (str(x['_id']), x['tag']), global_tags_collection))
    tags_dict.update((global_tags_dict))

    type_collection = mongo_session.get_all_data("question_type")['message']
    type_dict = dict(map(lambda x: (str(x['_id']), x['value']), type_collection))

    complexity_collection = mongo_session.get_all_data("question_complexity")['message']
    complexity_dict = dict(map(lambda x: (str(x['_id']), x['name']), complexity_collection))

    assessment = display_assessment(user_id=user_id, assessment_id=assessment_id)['assessment']
    assessment_obj = {
        'assessment_name': assessment['assessment_name'],
        'questions': [],
    }
    for question in assessment['questions']:
        options = question['option']
        question['options'] = [opt['option_value'] for opt in options]
        question_id = question['question_id']
        question_data = mongo_session.get_all_data_for_particular_condition_fields("add_questions",
                                                                                   {"_id": ObjectId(question_id)}
                                                                                   )['message'][0]
        complexity_id = question_data['complexity']
        ques_type_id = question_data['questype']
        tags = question_data['tags']

        question_obj = {
            "_id": question_id,
            'question_text': question['question_text'],
            'question_html': question['question_html'],
            'marks': question.get('marks', 1)
        }
        # non comprehension
        question_obj['tags'] = [tags_dict[str(t)] for t in tags]
        question_obj['complexity'] = complexity_dict[str(complexity_id)]
        question['type'] = type_dict[str(ques_type_id)]
        question_obj['type'] = type_dict[str(ques_type_id)]
        question_obj['options'] = {"values": [opt['option_value'] for opt in options],
                               "type": question['type']}
        if question['type'] != 'comprehension':
            meta_data = question_data['meta_data']

            if question['type'] == 'multianswermcq' or question['type'] == 'singleanswermcq' or question[
                'type'] == 'bool':
                if meta_data:
                    question_obj['correct_answer'] = [renew_s3_links(m['option']) for m in meta_data if m['answer']]
                else:
                    question_obj['correct_answer'] = []

            if question['type'] == 'fib' or question['type'] == "text":
                question_obj['answer'] = [renew_s3_links(m['answer']) for m in meta_data]

        # Comprehension
        else:
            sub_qus_list = []
            sub_qus = question_data['sub_qus']
            for each_question in sub_qus:
                sub_qus_obj = {
                    'question_text': filtered_html_tags(each_question['question']),
                    'question_html': renew_s3_links(each_question['question'])
                }
                sub_qus_meta_data = each_question['meta_data']

                sub_qus_type = type_dict[str(each_question['type'])]
                meta_data_obj = {"options": [], "answer": [], "type": sub_qus_type}
                for meta_data_dict in sub_qus_meta_data:
                    if sub_qus_type == 'multianswermcq' or sub_qus_type == 'singleanswermcq' or sub_qus_type \
                            == 'bool':
                        if meta_data_dict['answer']:
                            meta_data_obj['answer'].append(renew_s3_links(meta_data_dict['option']))

                        meta_data_obj['options'].append(renew_s3_links(meta_data_dict['option']))

                    if sub_qus_type == 'fib':
                        meta_data_obj['answer'] = renew_s3_links(meta_data_dict['answer'])

                for sub_qus_com in components:
                    if sub_qus_com != "Marks" and sub_qus_com != "Complexity" and sub_qus_com != "Tags":
                        sub_qus_obj[sub_qus_com.lower()] = meta_data_obj[components_dict[sub_qus_com]]
                sub_qus_list.append(sub_qus_obj)
            question_obj['sub_qus'] = sub_qus_list

        for c in components:
            question_obj[c.lower()] = question[components_dict[c]]

        assessment_obj['questions'].append(question_obj)

    assessment_obj['question_header'] = ['question'] + components
    return assessment_obj


def create_table_for_assessment(assessment_id, components, user_id):
    assessment_object = view_assessment(assessment_id, components, user_id)
    df = pd.DataFrame(columns=['Sr.', 'Question'])
    question_list = []
    dict_1 = {}
    headers = assessment_object['question_header']

    if len(headers) == 1 or len(headers) == 2 or len(headers) == 3:
        size = 200
    elif len(headers) == 4:
        size = 130
    else:
        size = 80

    def format_options(options):
        value = ''.join(options)
        return f'<ul style="margin: 5px; padding: 5px;">{value}</ul>'

    def format_questions(question):
        return f'<div style="margin:10px;padding-top: 10px;text-align:justify;">{question}</div>'

    def image_size(x):
        return x.group(1) + str(size)

    index = []
    count = 1
    for question in assessment_object['questions']:
        ind = "<p style='margin: 50%;'>" + str(count) + "</p>"
        index.append(ind)
        if "<img" not in question['question_html']:
            question['question_html'] = BeautifulSoup(question['question_html']).text
            quest = "<p>" + question['question_html'] + "</p>"
        else:
            ss = re.sub(r"(?i)(<img[^>]*?width\s*=\s*[\"'])(\d*)", image_size, question['question_html'])
            quest = re.sub(r"(?i)(<img[^>]*?height\s*=\s*[\"'])(\d*)", image_size, ss)
            quest = "<div>" + quest + "</div>"
        question_list.append(quest)
        count += 1
    df['Sr.'] = index
    df['Question'] = question_list
    dict_1['Question'] = format_questions

    if 'Option' in assessment_object['question_header']:
        options_list = []
        for question in assessment_object['questions']:
            value = question['option']['values']
            if value:
                for i in range(len(value)):
                    type = question['option']['type']
                    if type == 'singleanswermcq' or type == 'bool':
                        if '<img' not in value[i]:
                            if i == 0:
                                value[i] = BeautifulSoup(value[i]).text
                                value[i] = f'<li style="margin:10px; padding:10px 5px;">&nbsp;{value[i]}</li>'
                            else:
                                value[i] = BeautifulSoup(value[i]).text
                                value[i] = f'<li style="margin:10px; padding:10px 5px;">&nbsp;{value[i]}</li>'
                        else:
                            ss = re.sub(r"(?i)(<img[^>]*?width\s*=\s*[\"'])(\d*)", image_size, value[i])
                            value[i] = re.sub(r"(?i)(<img[^>]*?height\s*=\s*[\"'])(\d*)", image_size, ss)
                            value[i] = "<li style='margin:10px;'>" + value[i] + "</li>"
                    elif type == 'multianswermcq':
                        if '<img' not in value[i]:
                            if i == 0:
                                value[i] = BeautifulSoup(value[i]).text
                                value[i] = f'<p style="margin: 10px; padding:10px 5px;">&#9633;&nbsp;{value[i]}</p>'
                            else:
                                value[i] = BeautifulSoup(value[i]).text
                                value[i] = f'<p style="margin: 10px; padding:10px 5px;">&#9633;&nbsp;{value[i]}</p>'
                        else:
                            ss = re.sub(r"(?i)(<img[^>]*?width\s*=\s*[\"'])(\d*)", image_size, value[i])
                            value[i] = re.sub(r"(?i)(<img[^>]*?height\s*=\s*[\"'])(\d*)", image_size, ss)
                            value[i] = "<p style='margin:10px; padding:10px 5px;'>&#9633;&nbsp;" + value[i] + "</p>"
            options_list.append(value)
        df_1 = pd.DataFrame(columns=['Option'])
        df_1['Option'] = options_list
        dict_1['Question'] = format_options
        df = pd.concat([df, df_1], axis=1)

    if 'Answer' in assessment_object['question_header']:
        answer_list = []
        for question in assessment_object['questions']:
            for i in range(len(question['answer'])):
                if '<img' not in question['answer'][i]:
                    answer = BeautifulSoup(question['answer'][i]).text
                    question['answer'][i] = f'<li style="margin:10px; padding:10px 5px; text-align:justify">{answer}</li>'
                else:
                    answer = question['answer'][i]
                    ss = re.sub(r"(?i)(<img[^>]*?width\s*=\s*[\"'])(\d*)", image_size, answer)
                    answer = re.sub(r"(?i)(<img[^>]*?height\s*=\s*[\"'])(\d*)", image_size, ss)
                    question['answer'][i] = f'<li style="margin:10px; padding:10px 5px;text-align:justify">{answer}</li>'
            answer_list.append(question['answer'])
        df_1 = pd.DataFrame(columns=['Answer'])
        df_1['Answer'] = answer_list
        dict_1['Answer'] = format_options
        df = pd.concat([df, df_1], axis=1)

    if 'Type' in assessment_object['question_header']:
        type_list = []
        for question in assessment_object['questions']:
            question['type'] = "<p>&nbsp;" + str(question['type']) + "</p>"
            type_list.append(question['type'])
        df_1 = pd.DataFrame(columns=['Type'])
        df_1['Type'] = type_list
        df = pd.concat([df, df_1], axis=1)

    if 'Tags' in assessment_object['question_header']:
        tags_list = []
        for question in assessment_object['questions']:
            all_tags = [tag for tag in question['tags']]
            tags = "<p>" + ', '.join(all_tags) + "</p>"
            for i in range(len(question['tags'])):
                question['tags'][i] = "<ul><li>" + question['tags'][i] + "</li></ul>"
            tags_list.append(tags)
        df_1 = pd.DataFrame(columns=['Tags'])
        df_1['Tags'] = tags_list
        df = pd.concat([df, df_1], axis=1)

    if 'Marks' in assessment_object['question_header']:
        marks_list = []
        for question in assessment_object['questions']:
            question['marks'] = "<pre style='padding: 10px;'>   " + str(question['marks']) + "</pre>"
            marks_list.append(question['marks'])
        df_1 = pd.DataFrame(columns=['Marks'])
        df_1['Marks'] = marks_list
        df = pd.concat([df, df_1], axis=1)

    if 'Complexity' in assessment_object['question_header']:
        complexity_list = []
        for question in assessment_object['questions']:
            question['complexity'] = "<pre style='padding: 10px;'>   " + str(question['complexity']) + "</pre>"
            complexity_list.append(question['complexity'])
        df_1 = pd.DataFrame(columns=['Complexity'])
        df_1['Complexity'] = complexity_list
        df = pd.concat([df, df_1], axis=1)

    output = StringIO()
    df.to_html(output, formatters={'Answer': format_options,
                                   'Option': format_options,
                                   'Question': format_questions,
                                   'Tags': format_options,
                                   'Marks': format_questions}, escape=False,
               classes=['table table-hover'], justify='left', index=False)
    response = {"message": "File created successfully"}
    return response, output


def get_assessment_submission_student(required_user, user_id, assessment_id, course_id, topic_id, course_session_id,assessment_result_id,
                                      role, device, schedule_id=None):
    """
    This function provide the answer submitted by the student
    """
    # check whether an assessment exist on particular level received from client in course or not.
    # session level
    if course_id and topic_id and course_session_id:
        # check assess exist on session level
        condition = {"_id": ObjectId(course_session_id),
                     "assessments._id": ObjectId(assessment_id)}
        check_assess = mongo_session.check_existance_return_info(collection="course_sessions",
                                                                 condition=condition)
        if not check_assess:
            raise InvalidUsage("Sorry, something went wrong with session assessment.", 400)

    # topic level
    if course_id and topic_id and not course_session_id:
        condition = {"_id": ObjectId(assessment_id)}
        if schedule_id:
            condition["schedule_id"] = ObjectId(schedule_id)
        check_assess = mongo_session.check_existance_return_info(collection="course_topics",
                                                                 condition={"_id": ObjectId(topic_id),
                                                                            "assessments": {"$elemMatch": condition}})
        if not check_assess:
            raise InvalidUsage("Sorry, something went wrong with topic assessment.", 400)
    # course level
    if course_id and not (topic_id or course_session_id):
        condition = {"_id": ObjectId(assessment_id)}
        if schedule_id:
            condition["schedule_id"] = ObjectId(schedule_id)
        check_assess = mongo_session.check_existance_return_info(collection="courses_bank",
                                                                 condition={"_id": ObjectId(course_id),
                                                                            "course_assessments": {
                                                                                "$elemMatch": condition}})
        if not check_assess:
            raise InvalidUsage("Sorry, something went wrong with course assessment.", 400)

    course_query = mongo_session.get_all_data_for_particular_condition_fields(
        collection='courses_bank',
        condition={"_id": ObjectId(course_id)})
    if course_query['status'] != 200:
        raise InvalidUsage("Something went wrong, Please try again later.", 500)
    course_data = course_query['message'][0]

    # if not course_data['active']:
    #     raise InvalidUsage("Oops, course is not active anymore.", 500)

    publish_rights = [str(user['_id']) for user in course_data["editors"]] + \
                     [str(user['_id']) for user in course_data["instructors"]] + [str(course_data["created_by"])]

    condition = {"assessment_id": ObjectId(assessment_id),
                 'course_id': ObjectId(course_id),
                 'topic_id': ObjectId(topic_id) if validate_ObjectId(topic_id) else "",
                 'course_session_id': ObjectId(course_session_id) if validate_ObjectId(course_session_id) else ""}

    if user_id in publish_rights or role == "super_admin" or role == "teacher":  # check if role is teacher or super admin
        condition['user_id'] = ObjectId(required_user)
        condition['_id'] = ObjectId(assessment_result_id)
    else:
        condition['user_id'] = ObjectId(user_id)
    if schedule_id:
        condition['schedule_assessment_id'] = ObjectId(schedule_id)
    assessment_submission_data = \
        mongo_session.get_all_data_for_particular_condition_fields(collection="assessments_result",
                                                                   condition=condition
                                                                   )['message']
    if not assessment_submission_data:
        raise InvalidUsage(message="You have not submitted this assessment yet.", status_code=400)

    assess_info = mongo_session.get_all_data_for_particular_condition_fields(collection="assessment",
                                                                             condition={"_id": ObjectId(assessment_id)}
                                                                            )['message'][0]
    assessment_name = assess_info['assessment_name']
    type_collection = mongo_session.get_all_data("question_type")['message']
    type_dict = dict(map(lambda x: (str(x['_id']), x['value']), type_collection))

    # teaching assistants on the course
    teach_assis = [str(user['_id']) for user in course_data["teach_assis"]]
    publish_rights = [str(user['_id']) for user in course_data["editors"]] + \
                     [str(user['_id']) for user in course_data["instructors"]] + \
                     [str(course_data["created_by"])] + \
                     teach_assis
    # validate that current user in publish rights ie instructor or editor or a super admin
    if user_id in publish_rights or role == "super_admin":
        current_user_check = True
    # validate that teaching assistant adding remarks and grades to their assignees only
    elif user_id in teach_assis:
        assignees = []
        for assistant in course_data["teach_assis"]:
            if str(assistant["_id"]) == user_id:
                for assignee in assistant["assignees"]:
                    if assignee == ObjectId(required_user):
                        current_user_check = True
    else:
        current_user_check = False

    assessment_submission_obj = {
        'current_user_remark': current_user_check,
        'assessmentName': assessment_name,
        'questions': []
    }
    user_score = 0
    total_marks = 0
    user_percentage = 0
    review_completed = False

    for question in assessment_submission_data[-1]['question']:
        question_review_completed = False
        question_id = question['question_id']
        marks = \
            [data.get('marks', 1) for data in assess_info['questions'] if
             data['question_id'] == ObjectId(question_id)][0]
        total_marks += marks
        try:
            question_data = mongo_session.get_all_data_for_particular_condition_fields(collection="add_questions",
                                                                                       condition={"_id":
                                                                                                      ObjectId(question_id)
                                                                                                    })['message'][0]
            question_type = type_dict[str(question_data['questype'])]
            question_text = question['question_text']
            if question_type == 'multianswermcq' or question_type == 'fib':
                student_answer = [{"text": renew_s3_links(i)} for i in question['submitted_answer']]
                model_answer = [{"text": renew_s3_links(i)} for i in question['correct_answer']]

            elif question_type == 'singleanswermcq' or question_type == 'bool':
                student_answer = [{"text": renew_s3_links(question['submitted_answer'])}]
                model_answer = [{"text": renew_s3_links(question['correct_answer'])}]

            elif question_type == "text":
                student_answer = [{"text": renew_s3_links(question['submitted_answer'])}]
                if question.get('correct_answer'):
                    model_answer = [{"text": renew_s3_links(question['correct_answer'])}]
                else:
                    model_answer = []
            else:
                student_answer = [{"text": renew_s3_links(question['submitted_answer'])}]
                model_answer = []
            # remarks if given
            remarks = {}
            if question.get("remark"):
                remarks = question['remark']
                remarks["added_by"] = str(remarks["added_by"])
                question_review_completed = True

            grades = {}
            if question.get("grade"):
                grades = question['grade']
                grades["added_by"] = str(grades["added_by"])
                question_review_completed = True

            is_question_correct = "Review Pending"

            if question_type == 'multianswermcq' or question_type == 'singleanswermcq' or question_type == 'bool':

                question_obj = {
                    '_id': question_id,
                    'question_type': question_type,
                    'question_text': question_text,
                    'question_html': renew_s3_links(question_data['question']),
                    'model_answer': model_answer,
                    'student_answer': student_answer,
                    'remarks': remarks,
                    'grades': grades,
                    'max_marks': marks,
                    "options": question_data["meta_data"],
                    "question_review_completed": question_review_completed,
                    "is_question_correct": is_question_correct
                }
            # ignoring any options for such questions
            elif question_type == 'text' or question_type == 'fib' or question_type == 'comprehension':
                question_obj = {
                    '_id': question_id,
                    'question_type': question_type,
                    'question_text': question_text,
                    'question_html': renew_s3_links(question_data['question']),
                    'model_answer': model_answer,
                    'student_answer': student_answer,
                    'remarks': remarks,
                    'grades': grades,
                    'max_marks': marks,
                    "question_review_completed": question_review_completed,
                    "is_question_correct": is_question_correct
                }
                
            if question_obj.get('options'):
                for option in question_obj['options']:
                    option.update({"student_answer": ""})
                    option.update({"is_option_student_answer": False})
            if question_obj.get('options') and (question_type == "singleanswermcq" or question_type == "bool"):
                if len(question_obj.get("model_answer", "")) == 0:
                    is_question_correct = "Review Pending"
                    if len(question_obj["grades"]) == 0:
                        is_question_correct = "Review Pending"
                    elif len(question_obj["grades"]) > 0:
                        if grades["content"] == 0:
                            is_question_correct = "False"
                        elif grades["content"] > 0:
                            is_question_correct = "True"
                if len(question_obj.get("student_answer", "")) == 0 or len(BeautifulSoup(question_obj["student_answer"][0].get("text")).text) == 0:
                    is_question_correct = "False"
                    for option in question_obj['options']:
                        option.update({"student_answer": ""})
                        option.update({"is_option_student_answer": False})
                elif len(question_obj.get("student_answer", "")) > 0 and len(question_obj.get("model_answer", "")) > 0:
                    for option in question_obj["options"]:
                        option.update({"key": ""})
                        if option.get("is_option_student_answer") == True:
                            continue
                        for stu_answer in question_obj["student_answer"]:
                            if BeautifulSoup(stu_answer['text']).text == BeautifulSoup(option["option"]).text:
                                option.update({"student_answer": stu_answer["text"]})
                                option.update({"is_option_student_answer": True})
                            else:
                                option.update({"student_answer": ""})
                                option.update({"is_option_student_answer": False})
                        for mod_answer in question_obj["model_answer"]:
                            if BeautifulSoup(mod_answer['text']).text == BeautifulSoup(option["option"]).text:
                                if not option["answer"]:
                                    option.update({"answer": True})
                        if option["is_option_student_answer"]:
                            if option["answer"]:
                                option.update({"key": "green"})
                                is_question_correct = "True"   
                            elif not option["answer"]:
                                option.update({"key": "red"})
                                is_question_correct = "False"
                        if option["answer"]:
                            if option["is_option_student_answer"]:
                                option.update({"key": "green"})
                                is_question_correct = "True"
                            elif not option["is_option_student_answer"]:
                                option.update({"key": "red"})
                if is_question_correct == "True":
                    if question_obj.get("grades"):
                        if int(question_obj["grades"]["content"]) > 0:
                            user_score += int(question_obj["grades"]["content"])
                    else:
                        question_obj["grades"]["content"] = str(question_obj["max_marks"])
                        user_score += int(question_obj["grades"]["content"])
                elif is_question_correct == "False":
                    if assess_info["negative_marking"]:
                        question_obj["grades"]["content"] = str(-1 * abs(int(assess_info["negative_value"])))
                        user_score += (-1 * abs(int(question_obj["grades"]["content"])))
            elif question_obj.get('options') and question_type == "multianswermcq":
                if len(question_obj.get("model_answer")) == 0:
                    is_question_correct = "Review Pending"
                    if len(question_obj["grades"]) == 0:
                            is_question_correct = "Review Pending"
                    elif len(question_obj["grades"]) > 0:
                        if grades["content"] == 0:
                            is_question_correct = "False"
                        elif grades["content"] > 0:
                            is_question_correct = "True"
                if len(question_obj.get("student_answer", "")) == 0:
                    is_question_correct = "False"
                    for option in question_obj['options']:
                        option.update({"student_answer": ""})
                        option.update({"is_option_student_answer": False})
                elif len(question_obj.get("student_answer", "")) > 0 and len(question_obj.get("model_answer", "")) > 0:
                    for option in question_obj["options"]:
                        option.update({"key": ""})
                        if option.get("is_option_student_answer") == True:
                            continue
                        for stu_answer in question_obj["student_answer"]:
                            if BeautifulSoup(stu_answer['text']).text == BeautifulSoup(option["option"]).text:
                                option.update({"student_answer": stu_answer["text"]})
                                option.update({"is_option_student_answer": True})
                                break
                            else:
                                option.update({"student_answer": ""})
                                option.update({"is_option_student_answer": False})
                        for mod_answer in question_obj["model_answer"]:
                            if BeautifulSoup(mod_answer['text']).text == BeautifulSoup(option["option"]).text:
                                if not option["answer"]:
                                    option.update({"answer": True})
                        if option["is_option_student_answer"]:
                            if option["answer"]:
                                option.update({"key": "green"})      
                            elif not option["answer"]:
                                option.update({"key": "red"})
                        if option["answer"]:
                            if option["is_option_student_answer"]:
                                option.update({"key": "green"})      
                            elif not option["is_option_student_answer"]:
                                option.update({"key": "red"})
                if len(question_obj.get("student_answer", "")) == len(question_obj.get("model_answer", "")):
                    is_question_correct =  "True"
                    for option in question_obj['options']:
                        if option['answer']:
                            if option["is_option_student_answer"] == False:
                                is_question_correct = "False"
                                break
                else:
                    is_question_correct = "False"
                if is_question_correct == "True":
                    if question_obj.get("grades"):
                        if int(question_obj["grades"]["content"]) > 0:
                            user_score += int(question_obj["grades"]["content"])
                    else:
                        question_obj["grades"]["content"] = str(question_obj["max_marks"])
                        user_score += int(question_obj["grades"]["content"])
                elif is_question_correct == "False":
                    if assess_info["negative_marking"]:
                        question_obj["grades"]["content"] = str(-1 * abs(int(assess_info["negative_value"])))
                        user_score += (-1 * abs(int(question_obj["grades"]["content"])))
            elif question_type == "text" or question_type == "fib" or question_type == "comprehension":
                if question_type == "text" or question_type == "fib":
                    # catering request from frontend to send string of student_answer in case of text and fib
                    if device == "web":
                        if len(question_obj['student_answer']) > 0:
                            question_obj["student_answer"] = question_obj['student_answer'][0]["text"]
                        elif len(question_obj['student_answer']) == 0:
                            question_obj["student_answer"] = ""
                    if device == "mobile":
                        if len(question_obj['student_answer']) > 0:
                            question_obj["student_answer"] = question_obj['student_answer']
                        elif len(question_obj['student_answer']) == 0:
                            question_obj["student_answer"] = [{
                                "text": ""
                            }]
                if question_review_completed:
                    if int(question_obj["grades"]["content"]) == 0:
                        is_question_correct = "False"
                    elif int(question_obj["grades"]["content"]) > 0:
                        is_question_correct = "True"
                else:
                    is_question_correct = "Review Pending"
                if is_question_correct == "True":
                    if question_obj.get("grades"):
                        if int(question_obj["grades"]["content"]) > 0:
                            user_score += int(question_obj["grades"]["content"])
                    else:
                        question_obj["grades"]["content"] = str(question_obj["max_marks"])
                        user_score += int(question_obj["grades"]["content"])
                elif is_question_correct == "False":
                    if assess_info["negative_marking"]:
                        question_obj["grades"]["content"] = str(-1 * abs(int(assess_info["negative_value"])))
                        user_score += (-1 * abs(int(question_obj["grades"]["content"])))

            question_obj["is_question_correct"] = is_question_correct
            assessment_submission_obj['questions'].append(question_obj)
        except:
            continue
    if len(assessment_submission_obj['questions']) == 0:
        raise InvalidUsage("Dear User, this assessment is no longer active.", 406)
    # This is to add a key in last submission made my user, so that as he has seen the feedback he cannot submit his
    # assessments again. This restriction is for every user except those who have publish rights or super admins,
    # but then also we are storing the key for every user and can change the decision accordingly.
    add_view_key = mongo_session.update_record_into_db(
        collection="assessments_result",
        condition={"_id": ObjectId(assessment_submission_data[-1]["_id"])},
        update_info={"$set": {"feedback_seen": {"status": True,
                                                "timestamp": indian_standard_time()}}})
    if add_view_key["status"] != 200:
        raise InvalidUsage("Some internal error, Please try again later.", 500)
    # adding username to response
    if required_user:
        username = mongo_session.check_existance_return_info(collection="user_profile",
                                                             condition={"_id": ObjectId(str(required_user))},
                                                             columns={"username": 1},
                                                             return_keys=["username"])
        assessment_submission_obj['username'] = username['username']
    if total_marks > 0:
        user_percentage = round((user_score/total_marks) * 100,2)
    else:
        user_percentage = 0.00
    for question in assessment_submission_obj['questions']:
        if question.get("question_review_completed"):
            review_completed = True
        elif question.get("question_review_completed") == False:
            review_completed = False
            break
    assessment_submission_obj['user_score'] = user_score
    assessment_submission_obj['total_marks'] = total_marks
    assessment_submission_obj['user_percentage'] = user_percentage
    assessment_submission_obj['review_completed'] = review_completed
    return assessment_submission_obj


def get_upcoming_assessments(user_id, subscribed_courses):
    """
    This gives all the assessments of courses subscribed by the students
    1. course_name and course_category are fetched from course_id
    2. assessment is fetched from the assessment id
    """
    assessment_records = []
    user_data = mongo_session.get_all_data_for_particular_condition_fields(collection="user_profile",
                                                                           condition={
                                                                                "_id": ObjectId(user_id)}
                                                                           )['message']
    user_last_seen = user_data[0].get("upcoming_assess_last_seen")
    if not subscribed_courses:
        return {"message": "No courses have been subscribed by the user."}
    for sub_course in subscribed_courses:
        course_id = sub_course['course_id']
        course = mongo_session.get_all_data_for_particular_condition_fields(collection="courses_bank",
                                                                            condition={
                                                                                "_id": ObjectId(course_id)}
                                                                            )['message']
        if not course:
            continue
        if user_last_seen and course[0].get("updated_at"):
            last_seen = datetime.strptime(user_last_seen, "%d %b %Y, %I:%M %p")
            course_updated_at = datetime.strptime(course[0]["updated_at"], "%d %b %Y, %I:%M %p")
            if last_seen > course_updated_at:
                continue
        course_name = course[0]['subject']
        course_category_id = course[0]['course_category_id']
        course_category = mongo_session.get_all_data_for_particular_condition_fields(collection="Course_Category",
                                                                                     condition={
                                                                                         "_id": course_category_id}
                                                                                     )['message'][0]
        course_category_taxonomy = category_taxonomy_by_category_id(course_category)
        # whether an assessment is timed or not.
        timed_status = {}
        assessments = []
        user_assessments = {}
        one_time_assess = dict()
        for a in course[0]['course_assessments']:
            if "schedule_id" in a:
                assessments.append(str(a['schedule_id']))
                timed_status[str(a['schedule_id'])] = a.get("is_timed", True)
                if a.get("one_time_assessment") and a.get("calendared"):
                    user_assessments[str(a["schedule_id"])] = True
                    one_time_assess[str(a["schedule_id"])] = a.get("one_time_assessment")
                elif not a.get("one_time_assessment") and a.get("calendared"):
                    user_assessments[str(a["schedule_id"])] = True
                    one_time_assess[str(a["schedule_id"])] = a.get("one_time_assessment")
                else:
                    user_assessments[str(a["schedule_id"])] = True
                    one_time_assess[str(a["schedule_id"])] = a.get("one_time_assessment")

        topic_id_dict = dict()
        count = len(assessments)
        for t in course[0]['topics']:
            topic_assessments = mongo_session.get_all_data_for_particular_condition_fields(collection="course_topics",
                                                                                           condition={
                                                                                               "_id": ObjectId(t['_id'])
                                                                                           }
                                                                                           )['message'][0]['assessments']
            for each_topic_assessment in topic_assessments:
                if "schedule_id" in each_topic_assessment.keys():
                    assessments.append(str(each_topic_assessment['schedule_id']))
                    timed_status[str(each_topic_assessment['schedule_id'])] = each_topic_assessment.get("is_timed",
                                                                                                        True)
                    topic_id_dict[count] = str(t['_id'])
                    count += 1
        for assessment_index, schedule_id in enumerate(assessments):
            assessment = mongo_session.get_all_data_for_particular_condition_fields("schedule_assessment",
                                                                                    {"_id": ObjectId(schedule_id)}
                                                                                    )['message'][0]
            assessment_id = assessment['assessment_id']
            start_time = datetime.strptime(assessment['start_time'], "%Y:%m:%dT%H:%M")
            end_time = datetime.strptime(assessment['end_time'], "%Y:%m:%dT%H:%M")
            timestamp = indian_standard_time()
            current_time = datetime.strptime(timestamp, "%d %b %Y, %I:%M %p")
            if current_time < end_time:
                assessment_obj = offline_display_assessment(user_id=user_id,
                                                            assessment_id=assessment_id)['assessment']

                assessment_obj['_id'] = str(assessment_id)
                assessment_obj['schedule_assessment_id'] = str(schedule_id)
                assessment_obj['is_timed'] = bool(timed_status[str(schedule_id)])
                assessment_obj['user_asssessment'] = bool(user_assessments[str(schedule_id)])
                assessment_obj['one_time_assessment'] = bool(one_time_assess[str(schedule_id)])
                assessment_obj['topic_id'] = topic_id_dict[
                    assessment_index] if assessment_index in topic_id_dict else ""
                assessment_obj['user_id'] = user_id
                assessment_obj['course_id'] = str(course_id)
                assessment_obj['course_name'] = course_name
                assessment_obj['course_category_taxonomy'] = course_category_taxonomy
                assessment_obj['start_time'] = start_time.strftime("%Y-%m-%d %H:%M")
                assessment_obj['end_time'] = end_time.strftime("%Y-%m-%d %H:%M")
                assessment_obj['total_time'] = assessment['total_time']
                if assessment_obj['topic_id'] != "":
                    assessment_obj['topic_title'] = mongo_session.get_all_data_for_particular_condition_fields(
                        collection='course_topics', condition={'_id': ObjectId(assessment_obj['topic_id'])}
                    )['message'][0]['title']
                assessment_records.append(assessment_obj)
    update_assessment_status = mongo_session.update_record_into_db(
        collection="user_profile",
        condition={"_id": ObjectId(user_id)},
        update_info={"$set": {'upcoming_assess_last_seen': indian_standard_time()}})
    if not assessment_records:
        return {'message': 'No upcoming assessment found'}
    print("1-->", assessment_records)
    return {"assessments": assessment_records}


def get_assessments_in_time_period(user_id, time_period):
    """
    This function gives all the assessments submitted by a given user
    in a given time period.
    """
    submitted_assessments = mongo_session.get_all_data_for_particular_condition_fields(collection="assessments_result",
                                                                                       condition=
                                                                                       {"user_id": ObjectId(user_id)}
                                                                                       )['message']
    assessment_list = []
    unique_key_info = {}
    for assess in submitted_assessments:
        unique_key = str(assess['course_id']) + str(assess['assessment_id']) + str(assess['topic_id']) + \
                     str(assess['course_session_id'])
        unique_key_info[unique_key] = assess["_id"]

    for assessment in submitted_assessments:
        if assessment["_id"] not in unique_key_info.values():
            continue
        submission_time = datetime.strptime(assessment['submitted_time'], "%Y:%m:%dT%H:%M")
        if time_period[0] <= submission_time <= time_period[1]:
            _id = str(assessment['assessment_id'])
            status = assessment['status']

            assessment_data = mongo_session.get_all_data_for_particular_condition_fields(collection="assessment",
                                                                                         condition={"_id": ObjectId(_id)
                                                                                                    })['message'][0]
            _type = assessment_data['assessment_type']
            name = assessment_data['assessment_name']
            course_id = str(assessment['course_id'])
            course_data = mongo_session.get_all_data_for_particular_condition_fields(collection="courses_bank",
                                                                                     condition={
                                                                                         "_id": ObjectId(course_id)
                                                                                     }
                                                                                     )['message'][0]
            course_name = course_data['subject']
            course_category_id = course_data['course_category_id']
            course_category = mongo_session.get_all_data_for_particular_condition_fields(collection="Course_Category",
                                                                                         condition=
                                                                                         {"_id": course_category_id}
                                                                                         )['message'][0]
            course_category_taxonomy = category_taxonomy_by_category_id(course_category)
            if assessment['topic_id']:
                topic_title = mongo_session.get_all_data_for_particular_condition_fields(
                    collection='course_topics', condition={'_id': ObjectId(assessment['topic_id'])}
                )['message'][0]['title']
            else:
                topic_title = ""
            assessment_obj = {
                'assessment_id': _id,
                'assessment_name': name,
                'assessment_type': _type,
                'assessment_status': status,
                'course_id': course_id,
                'course_name': course_name,
                'course_category_taxonomy': course_category_taxonomy,
                'topic_id': str(assessment['topic_id']),
                'topic_title': topic_title,
                'course_session_id': str(assessment['course_session_id']),
                'start_time': '',
                'end_time': '',
                'is_timed': assessment.get('is_timed', False),
                'total_time': assessment_data['total_time'],
                'submitted_time': datetime.strptime(assessment['submitted_time'],
                                                    "%Y:%m:%dT%H:%M").strftime("%Y-%m-%d %H:%M")
            }
            # calendared assessment
            if "schedule_assessment_id" in assessment.keys():
                assessment_obj['is_timed'] = assessment.get('is_timed', True)
                schedule_id = assessment['schedule_assessment_id']
                schedule_data = \
                    mongo_session.get_all_data_for_particular_condition_fields(collection="schedule_assessment",
                                                                               condition=
                                                                               {"_id": ObjectId(schedule_id)
                                                                                })['message'][0]
                start_time_obj = datetime.strptime(schedule_data['start_time'], "%Y:%m:%dT%H:%M")
                assessment_obj['start_time'] = start_time_obj.strftime("%Y-%m-%d %H:%M")
                end_time_obj = datetime.strptime(schedule_data['end_time'], "%Y:%m:%dT%H:%M")
                assessment_obj['end_time'] = end_time_obj.strftime("%Y-%m-%d %H:%M")

            assessment_list.append(assessment_obj)
    return assessment_list


def add_remark(grade, question_id, remark, checker_id, user_id, assessment_id, course_id, topic_id, session_id, role, assessment_result_id, 
               schedule_id=None):
    """
    It will submit a remark given by a teacher or a teaching assistant to the assessment submission made by a subscriber.
    """
    # Fetch valid user submission
    if course_id and not (topic_id or len(topic_id) > 0) and not (session_id and len(session_id) > 0):
        condition = {"user_id": ObjectId(user_id),
                "assessment_id": ObjectId(assessment_id),
                "course_id": ObjectId(course_id),
                "_id": ObjectId(assessment_result_id)}
    elif course_id and topic_id and not (session_id and len(session_id) > 0):
        condition = {"user_id": ObjectId(user_id),
                "assessment_id": ObjectId(assessment_id),
                "course_id": ObjectId(course_id),
                "topic_id": ObjectId(topic_id) if topic_id else "",
                "_id": ObjectId(assessment_result_id)}
    elif course_id and topic_id and session_id:
        condition = {"user_id": ObjectId(user_id),
                "assessment_id": ObjectId(assessment_id),
                "course_id": ObjectId(course_id),
                "_id": ObjectId(assessment_result_id),
                "topic_id": ObjectId(topic_id) if topic_id else "",
                "course_session_id": ObjectId(session_id) if session_id else ""}

    if schedule_id:
        condition["schedule_assessment_id"] = ObjectId(schedule_id)

    user_submission = mongo_session.check_existance_return_info(collection="assessments_result",
                                                                condition=condition,
                                                                columns={'_id': 1,
                                                                         'question': 1},
                                                                return_keys=[
                                                                    '_id',
                                                                    'question'
                                                                ])
    if not user_submission:
        raise InvalidUsage("This assessment does not exist anymore.", 400)

    condition['_id'] = ObjectId(user_submission["_id"])
    course_query = mongo_session.get_all_data_for_particular_condition_fields(
        collection='courses_bank',
        condition={"_id": ObjectId(course_id)})
    if course_query['status'] != 200:
        raise InvalidUsage("Something went wrong, Please try again later.", 500)
    course_data = course_query['message'][0]

    if not course_data['active']:
        raise InvalidUsage("Oops, course is not active anymore.", 400)

    # teaching assistants on the course
    teach_assis = [str(user['_id']) for user in course_data["teach_assis"]]
    publish_rights = [str(user['_id']) for user in course_data["editors"]] + \
                     [str(user['_id']) for user in course_data["instructors"]] + \
                     [str(course_data["created_by"])] + \
                     teach_assis
    # validate that teaching assistant adding remarks and grades to their assignees only
    if checker_id in teach_assis:
        assignees = []
        for assistant in course_data["teach_assis"]:
            if str(assistant["_id"]) == checker_id:
                assignees = [str(assignee["_id"]) for assignee in assistant["assignees"]]
                break
        if role == "super_admin":
            assignees = [str(checker_id)]
        if role == "teacher" and str(checker_id) in [str(user['_id']) for user in course_data["instructors"]]:
                assignees = [str(user_id)]
        if user_id not in assignees:
            raise InvalidUsage("You are not authorised person to mark this submission.", 403)

    if checker_id not in publish_rights and role != "super_admin":
        raise InvalidUsage("You cannot add remarks on this assessment, Not an authorised user.", 403)
    for data in user_submission["question"]:
        if data["question_id"] == question_id:
            timestamp = indian_standard_time()
            if not is_empty(remark):
                data["remark"] = {"content": remark,
                                  "timestamp": timestamp,
                                  "added_by": ObjectId(checker_id)}
            if not is_empty(grade):
                data["grade"] = {"content": str(int(grade)),
                                 "timestamp": timestamp,
                                 "added_by": ObjectId(checker_id)
                                 }

    set_remark = mongo_session.update_record_into_db(
        collection="assessments_result",
        condition=condition,
        update_info={"$set": {"question": user_submission["question"]}})
    if set_remark["status"] != 200:
        raise Exception("Error while updating record in DB.")
    return "Success"


def submit_assess_user_info(role, assessment_id, course_id, schedule_id=None):
    """
    This function provide the answer submitted by the student
    """
    response = []
    if role not in ["teacher", "super_admin"]:
        raise InvalidUsage("You don't have access to view user's information.", 403)

    condition = {'assessment_id': ObjectId(assessment_id),
                 'course_id': ObjectId(course_id)}
    if schedule_id:
        condition['schedule_assessment_id'] = ObjectId(schedule_id)
    assessment_submission_data = mongo_session.get_all_data_for_particular_condition_fields(
        collection="assessments_result",
        condition=condition
    )
    if assessment_submission_data["status"] != 200:
        raise InvalidUsage("Internal server error, Please try again later.", 500)
    assessment_submission_data = assessment_submission_data["message"]

    if not assessment_submission_data:
        return response

    for submission in assessment_submission_data:
        marked = False
        if submission:
            for question in submission['question']:
                correct_answer = question.get('answer_correct', "")
                #False
                question_data = mongo_session.get_all_data_for_particular_condition_fields(collection="add_questions",
                                                                                                condition={
                                                                                                    "_id": ObjectId(str(question['question_id']))
                                                                                                })['message'][0]
                check_questype = fetch_session.access_specific_fields(collection='question_type',
                                                                            condition={
                                                                                "_id": ObjectId(str(question_data['questype']))
                                                                            })[0]
                
                if correct_answer in [True, False] and (check_questype['value'] == 'bool' or check_questype['value'] == 'multianswermcq' or check_questype['value'] == 'singleanswermcq'):
                    marked = True
                elif check_questype['value'] == 'text' or check_questype['value'] == 'fib':
                    if len(question.get('grade', "")) > 0:
                        marked = True
                    elif len(question.get('remarks',"")) > 0:
                        marked = True
                    else:
                        marked = False
                        break    
                    # print(check_questype)
                    # print("question",question)
                else:
                    marked = False
                    break
        username = mongo_session.check_existance_return_info(collection="user_profile",
                                                             condition={"_id": ObjectId(submission["user_id"])},
                                                             columns={
                                                                "username": 1,
                                                                "name": 1,
                                                                "last_name": 1
                                                             },
                                                             return_keys=[
                                                                "username",
                                                                "name",
                                                                "last_name"
                                                                ])
        if not username:
            continue
        submitted_at = submission["submitted_time"].split('T')
        submitted_time = str(submitted_at[0]).replace(':', '-') + "T" + str(submitted_at[1])
        user_data = {"_id": str(submission["user_id"]),
                     "username": username["username"],
                     "name": username["name"] + username["last_name"],
                     "submitted_time": submitted_time,
                     "assessment_result_id": submission['_id'],
                     "marked": marked
                     }
        response.append(user_data)
    return response


def assessment_questions_detail(role, assessment_id, schedule_id, course_id, topic_id, course_session_id):
    """ This function will provide all the information related to a question in an assessment"""
    response = []
    assess_info = mongo_session.check_existance_return_info(collection="assessment",
                                                            condition={"_id": ObjectId(assessment_id)},
                                                            columns={'_id': 1,
                                                                     'questions': 1},
                                                            return_keys=['questions', '_id'])
    if not assess_info:
        raise InvalidUsage("Bad Request.", 400)

    condition = {"assessment_id": ObjectId(assessment_id),
                 "course_id": ObjectId(course_id),
                 "topic_id": ObjectId(topic_id) if topic_id else "",
                 "course_session_id": ObjectId(course_session_id) if course_session_id else ""}
    # if schedule_id != "":
    #     condition["schedule_assessment_id"] = ObjectId(schedule_id)
    columns = {"question": 1, "user_id": 1}
    assess_submissions = mongo_session.get_data_for_particular_columns_with_condition(collection="assessments_result",
                                                                                      condition=condition,
                                                                                      columns=columns)
    if not assess_submissions["message"]:
        return response

    assess_submissions["message"].reverse()
    ques_type = ["singleanswermcq", "multianswermcq", "bool"]  # multiple mcq, single ans mcq, binary
    ques_type_ids = mongo_session.access_specific_fields(collection="question_type",
                                                         condition={"value": {"$in": ques_type}},
                                                         columns={"_id": 1},
                                                         return_keys=["_id"])
    ques_type_id = [record["_id"] for record in ques_type_ids]
    quest_type_ids_str = [str(record["_id"]) for record in ques_type_ids]
    processed_users = []
    for user in assess_submissions["message"]:
        if not any(str(data['user_id']) == str(user["user_id"]) for data in processed_users):
            processed_users.append(user)
    for question in assess_info['questions']:
        # fetch question info
        ques_record = {}
        question_data = mongo_session.check_existance_return_info(collection="add_questions",
                                                                  condition={"_id": ObjectId(question['question_id']),
                                                                             "$or": [
                                                                                 {"questype": {"$in": ques_type_id}},
                                                                                 {"questype": {
                                                                                     "$in": quest_type_ids_str}}
                                                                             ]},
                                                                  columns={"meta_data": 1, "question": 1},
                                                                  return_keys=["meta_data", "question", "_id"])

        if not question_data:
            continue

        ques_record["question"] = renew_s3_links(question_data["question"])
        ques_record["question_id"] = str(question_data["_id"])
        ques_record["options"] = []
        ques_record["graph_data"] = []

        option_alias = 65
        for option in question_data["meta_data"]:
            students = []
            for user in processed_users:
                # checking the submissions of students with respect to the particular option of the question
                for ques in user["question"]:
                    if ques["question_id"] == str(question['question_id']):
                        answer_corrected = False
                        # check whether the correct answer is in the submitted answers or not.
                        if type(ques["submitted_answer"]) == list:
                            c_process = BeautifulSoup(option["option"]).text.replace("\n", "").replace(" ", "")
                            for s_opt in ques["submitted_answer"]:
                                s_process = BeautifulSoup(s_opt).text.replace("\n", "").replace(" ", "")
                                if c_process == s_process:
                                    answer_corrected = True
                        else:
                            c_process = BeautifulSoup(option["option"]).text.replace("\n", "").replace(" ", "")
                            s_process = BeautifulSoup(ques["submitted_answer"]).text.replace("\n", "").replace(" ", "")
                            answer_corrected = c_process == s_process
                        if answer_corrected:
                            student_data = mongo_session.check_existance_return_info(collection="user_profile",
                                                                                     condition={"_id": ObjectId(
                                                                                         user["user_id"])},
                                                                                     columns={"name": 1, "last_name": 1,
                                                                                              "username": 1, "_id": 1},
                                                                                     return_keys=["name", "last_name",
                                                                                                  "username", "_id"])
                            if not student_data:
                                continue
                            if student_data["name"] and student_data["last_name"]:
                                short_name = student_data["name"][0] + student_data["last_name"][0]
                            else:
                                short_name = student_data["name"][0:2]
                            students.append({"first_name": student_data["name"],
                                             "last_name": student_data["last_name"],
                                             "short_name": short_name,
                                             "_id": str(student_data["_id"])})

            option_data = {"value": renew_s3_links(option["option"]),
                           "answer": option["answer"],
                           "students": students}
            ques_record["options"].append(option_data)
            ques_record["graph_data"].append({"name": chr(option_alias),
                                              "value": len(students)})
            option_alias = option_alias + 1
        response.append(ques_record)
    return response


def display_assessment(user_id, assessment_id, schedule_assessment_id=None):
    """
    It is used to display assessments
    1. questions and options are fetched from the db of corresponding assessment
    2. it is formatted in the desired format and send in response body
    """

    current_time = convert_utc_ist(format="%Y:%m:%dT%H:%M", time_obj=datetime.now())
    assessment_collection = mongo_session.get_all_data_for_particular_condition_fields("assessment",
                                                                                       {"_id": ObjectId(assessment_id)})
    assessment_name = assessment_collection['message'][0]['assessment_name']
    question_id_lis = assessment_collection['message'][0]['questions']
    assessment_obj = {
        "assessment_name": assessment_name,
        "questions": []
    }
    if schedule_assessment_id:
        schedule_collection = mongo_session.get_all_data_for_particular_condition_fields("schedule_assessment",
                                                                                         {"_id": ObjectId(
                                                                                             schedule_assessment_id)
                                                                                         })["message"][0]
        start_time = datetime.strptime(schedule_collection['start_time'], "%Y:%m:%dT%H:%M")
        end_time = datetime.strptime(schedule_collection['end_time'], "%Y:%m:%dT%H:%M")
        time_remaining = int((start_time - current_time).total_seconds() / 60)
        if time_remaining > 0:
            return {"message": "{} minutes remaining for assessment".format(time_remaining)}
        total_time = int(abs((end_time - start_time).total_seconds() / 60))
        assessment_obj['start_time'] = start_time
        assessment_obj['end_time'] = end_time
        assessment_obj['total_time'] = total_time

    questype_collection = mongo_session.get_all_data("question_type")['message']
    questype_dict = dict(map(lambda x: (x['_id'], x['value']), questype_collection))
    for i in question_id_lis:
        try:
            id = i['question_id'].__str__()
            docs = mongo_session.get_all_data_for_particular_condition_fields("add_questions",
                                                                              {"_id": ObjectId(id)}
                                                                              )['message'][0]
            questype = questype_dict[str(docs['questype'])]

            if "marks" in i.keys():
                marks = i['marks']
            else:
                marks = 0

            question_obj = {
                'question_id': id,
                'question_type': questype,
                'marks': marks,
                'question_text': filtered_html_tags(docs['question']),
                'question_html': renew_s3_links(docs['question']),
                'option': [],
                'answer': []
            }
            if questype != "comprehension":
                for i in docs['meta_data']:
                    if i['option'] != "":
                        option_obj = {
                            'option_value': renew_s3_links(i['option']),
                            'checked': False
                        }
                        question_obj['option'].append(option_obj)
            assessment_obj['questions'].append(question_obj)
        except:
            continue
    if len(assessment_obj['questions']) == 0:
        raise InvalidUsage('Dear User, this assessment is no longer active.', 406)
    assessment_res = {"assessment": assessment_obj}

    return assessment_res


def submit_assessment(user_id, questions, assessment_id, status, course_id, topic_id, course_session_id, submitted_time,
                      role, schedule_id=None):
    """
    It is used to submit the assessment in db
    1. question and its answers are fetched according to the question id
    2. total_score , maximum_score is calculated stored
    3. For text ony questions new field speech_text is added
    """
    submitted_time = datetime.strptime(submitted_time, "%Y-%m-%d %H:%M")
    is_timed = None
    assessment_data = mongo_session.get_all_data_for_particular_condition_fields(collection="assessment",
                                                                                 condition=
                                                                                 {"_id": ObjectId(assessment_id)}
                                                                                 )['message'][0]

    # check whether an assessment exist on particular level received from client in course or not.
    # session level
    if course_id and topic_id and course_session_id:
        print('[INFO Submit Assessment]: Inside Session Condition: course id - {}, topic id - {}, course session id - {}'
            ', assessment id - {}'.format(course_id, topic_id, course_session_id, assessment_id))
        # check assess exist on session level
        condition = {"_id": ObjectId(course_session_id),
                     "assessments._id": ObjectId(assessment_id)}
        check_assess = mongo_session.check_existance_return_info(collection="course_sessions",
                                                                 condition=condition)
        print(check_assess)
        print('[INFO Submit Assessment]: check_assess {}'.format(check_assess))
        if not check_assess:
            raise InvalidUsage("Sorry, something went wrong with assessment.", 400)
        live_session_condition = {"_id": ObjectId(assessment_id),
                                  "activate": {"$exists": True}}
        live_session = mongo_session.check_existance_return_info(collection="course_sessions",
                                                                 condition={"_id": ObjectId(course_session_id),
                                                                            "key": "live_session",
                                                                            "assessments": {
                                                                                "$elemMatch": live_session_condition}},
                                                                 columns={"assessments.$.timestamp": 1, "_id": 1,
                                                                          "status": 1},
                                                                 return_keys=["assessments", "_id", "status"])
        print('[INFO Submit Assessment]: Live session - {}'.format(live_session))
        # if not live_session:
        #     raise InvalidUsage("Sorry, something went wrong with assessment.", 400)
        if live_session and live_session["assessments"]:
            if live_session["status"] == "active":
                start_time_str = live_session["assessments"][0]["activate"]["timestamp"]
                start_time_obj = datetime.strptime(start_time_str, "%d %b %Y, %I:%M %p")

                end_time_obj = start_time_obj + timedelta(minutes=int(assessment_data["total_time"]))
                time_remaining = int((end_time_obj - submitted_time).total_seconds())
                if time_remaining >= 0:
                    status = "done"
                    if live_session["assessments"][0].get("deactivate"):
                        deactive_time_str = live_session["assessments"][0]["deactivate"]["timestamp"]
                        deactive_time_obj = datetime.strptime(deactive_time_str, "%d %b %Y, %I:%M %p")
                        if deactive_time_obj > start_time_obj:
                            if int((deactive_time_obj - submitted_time).total_seconds()) < 0:
                                status = "deactivated"
                else:
                    status = "timeout"
            elif live_session["status"] == "inactive":
                status = "deactivated"
            elif live_session["status"] == "recorded":
                pass
            else:
                raise InvalidUsage("Live session is not active, Please contact the assessor", 400)

    # topic level
    if course_id and topic_id and not course_session_id:
        print('[INFO Submit Assessment]:  Inside Topic Condition: course id - {}, topic id - {}, assessment id - '
              '{}'.format(course_id, topic_id, assessment_id))
        condition = {"_id": ObjectId(assessment_id)}
        if schedule_id:
            condition["schedule_id"] = ObjectId(schedule_id)
        check_assess = mongo_session.check_existance_return_info(collection="course_topics",
                                                                 condition={"_id": ObjectId(topic_id),
                                                                            "assessments": {"$elemMatch": condition}},
                                                                 columns={"assessments": 1,
                                                                          "_id": 1},
                                                                 return_keys=["assessments", "_id"])
        print('[INFO Submit Assessment]: check_assess {}'.format(check_assess))
        if not check_assess:
            raise InvalidUsage("Sorry, something went wrong with assessment.", 400)
        for assess in check_assess["assessments"]:
            if assess["_id"] == ObjectId(assessment_id):
                if assess.get("schedule_id"):
                    is_timed = assess.get("is_timed", True)
                else:
                    is_timed = assess.get("is_timed", False)
    # course level
    if course_id and not (topic_id or course_session_id):
        print('[INFO Submit Assessment]: Inside Topic Condition: course id - {}, assessment id - '
              '{}'.format(course_id, assessment_id))
        condition = {"_id": ObjectId(assessment_id)}
        if schedule_id:
            condition["schedule_id"] = ObjectId(schedule_id)
        check_assess = mongo_session.check_existance_return_info(collection="courses_bank",
                                                                 condition={"_id": ObjectId(course_id),
                                                                            "course_assessments": {
                                                                                "$elemMatch": condition}},
                                                                 columns={"_id": 1,
                                                                          "course_assessments": 1},
                                                                 return_keys=["_id", "course_assessments"])
        print('[INFO Submit Assessment]: check_assess {}'.format(check_assess))
        if not check_assess:
            raise InvalidUsage("Sorry, something went wrong with assessment.", 400)
        for assess in check_assess["course_assessments"]:
            if assess["_id"] == ObjectId(assessment_id):
                if assess.get("schedule_id"):
                    is_timed = assess.get("is_timed", True)
                else:
                    is_timed = assess.get("is_timed", False)
    # This is to check whether user can submit assessment or not on the basis of whether user has seen the feedback or
    # not.
    if role != "super_admin":
        condition = {"user_id": ObjectId(user_id),
                     "assessment_id": ObjectId(assessment_id),
                     "course_id": ObjectId(course_id),
                     "topic_id": ObjectId(topic_id) if topic_id else "",
                     "course_session_id": ObjectId(course_session_id) if course_session_id else ""}
        if schedule_id:
            condition["schedule_assessment_id"] = ObjectId(schedule_id)

        user_submission = mongo_session.check_existance_return_info(collection="assessments_result",
                                                                    condition=condition,
                                                                    columns={'_id': 1,
                                                                             'feedback_seen': 1},
                                                                    return_keys=['feedback_seen', '_id'])
        print(['[INFO Submit Assessment]: User Submission {}'.format(user_submission)])
        # print(user_submission['_id'])
        if user_submission:
            if user_submission["feedback_seen"] and user_submission["feedback_seen"]["status"]:
                raise InvalidUsage("You cannot submit again, your submission is already seen.", 403)

    # schedule assessment id validation
    if schedule_id:
        schedule_id_exits = mongo_session.find_one_in_db(collection="schedule_assessment",
                                                         condition={"_id": ObjectId(schedule_id)},
                                                         columns=['_id'])['message']
        if not schedule_id_exits:
            raise Exception("Following schedule assessment id is not present in db.")

    # topic id validation
    if not is_empty(topic_id):
        topic_id_exits = mongo_session.find_one_in_db(collection="course_topics",
                                                      condition={"_id": ObjectId(topic_id)},
                                                      columns=['_id'])['message']
        if not topic_id_exits:
            raise Exception("Following topic id is not present in db.")

    current_time = convert_utc_ist(format="%Y:%m:%dT%H:%M", time_obj=datetime.now())
    maximum_score = 0
    total_score = 0
    submitted_question = []
    if schedule_id:
        print(['[INFO Submit Assessment]: Schedule Id {}'.format(schedule_id)])
        schedule_collection = mongo_session.get_all_data_for_particular_condition_fields("schedule_assessment",
                                                                                         {"_id": ObjectId(schedule_id)}
                                                                                         )['message'][0]
        if not schedule_collection:
            raise Exception("Following schedule assessment id is not present in db.")
        end_time = datetime.strptime(schedule_collection['end_time'], "%Y:%m:%dT%H:%M")
        time_remaining = int((end_time - submitted_time).total_seconds())
        if time_remaining >= 0:
            status = "done"
        else:
            status = "timeout"
    if status != "failed":
        maximum_score = assessment_data['total_marks']
        questype_collection = mongo_session.get_all_data("question_type")['message']
        questype_dict = dict(map(lambda x: (str(x['_id']), x['value']), questype_collection))
        negative_marking = assessment_data['negative_marking']
        negative_marks = float(assessment_data['negative_value'])
        for index, q in enumerate(questions):
            question_id = q['question_id']
            question_collection = mongo_session.get_all_data_for_particular_condition_fields("add_questions",
                                                                                             {"_id": ObjectId(
                                                                                                 question_id)})[
                'message'][0]
            meta_data = question_collection['meta_data']
            questype = questype_dict[str(question_collection['questype'])]

            question_obj = {
                'question_id': question_id,
                'question_text': question_collection["filtered_question"],
                'question_html': replace_s3_links_with_keys(question_collection["question"])
            }
            # single answer mcq and bool questions
            if questype == "singleanswermcq" or questype == "bool":
                if len(q['answer']) > 1:
                    raise InvalidUsage(message="{} question has more than one answer".format(questype),
                                       status_code=400)
                marked_answer = replace_s3_links_with_keys(q['answer'][0]['value']) if q['answer'] else ""
                question_obj['correct_answer'] = [i['option'] for i in meta_data if i['answer']][0]
            # text questions
            elif questype == 'text':
                marked_answer = replace_s3_links_with_keys(q['answer'][0]['value']) if q['answer'] else ""
                question_obj['correct_answer'] = meta_data[0]['answer'] if meta_data else ""
                question_obj['speech_text'] = q['answer'][0]['speech_text'] if q['answer'] else ""
            # fill in the blanks and multiple answer mcq
            else:
                marked_answer = [replace_s3_links_with_keys(ans['value']) for ans in q['answer']] if q['answer'] else ""
                if questype == 'fib':
                    question_obj['correct_answer'] = [i['answer'] for i in meta_data]
                    if set(question_obj['correct_answer']) == set(marked_answer):
                        answer_correct = True
                        score = assessment_data['questions'][index]['marks']
                    else:
                        answer_correct = False
                        score = 0
                        if negative_marking and not question_obj.get('submitted_answer'):
                            score = -int(assessment_data['questions'][index]['marks'] * negative_marks)
                    total_score += score
                    question_obj['answer_correct'] = answer_correct
                    question_obj['score'] = score
                else:
                    question_obj['correct_answer'] = [i['option'] for i in meta_data if i['answer']]

            question_obj['submitted_answer'] = marked_answer
            if questype != "text" and questype != "fib":
                if questype == "multianswermcq":
                    correct_answer_list = [BeautifulSoup(ans).text for ans in question_obj['correct_answer']]
                    submitted_answer_list = [BeautifulSoup(ans).text for ans in question_obj['submitted_answer']]
                else:
                    correct_answer_list = [BeautifulSoup(question_obj['correct_answer']).text]
                    submitted_answer_list = [BeautifulSoup(question_obj['submitted_answer']).text]
                timestamp = indian_standard_time()
                if set(correct_answer_list) == set(submitted_answer_list) and len(correct_answer_list) > 0:
                    question_obj["grade"] = {"content": assessment_data['questions'][index]['marks'],
                                             "timestamp": timestamp,
                                             "added_by": ""
                                             }
                    answer_correct = True
                    score = assessment_data['questions'][index]['marks']
                else:
                    question_obj["grade"] = {"content": 0,
                                             "timestamp": timestamp,
                                             "added_by": ""
                                             }
                    answer_correct = False
                    score = 0
                    if negative_marking and not question_obj['submitted_answer']:
                        score = -int(assessment_data['questions'][index]['marks'] * negative_marks)
                total_score += score
                question_obj['answer_correct'] = answer_correct
                question_obj['score'] = score
            submitted_question.append(question_obj)
    docs = {
        "module_name": "Assessment",
        "user_id": ObjectId(user_id),
        "assessment_id": ObjectId(assessment_id),
        "question": submitted_question,
        'total_score': total_score,
        'maximum_score': maximum_score,
        'submitted_time': submitted_time.strftime("%Y:%m:%dT%H:%M"),
        'status': status,
        'course_id': ObjectId(course_id)
    }
    if type(is_timed) == bool:
        docs["is_timed"] = is_timed
    if schedule_id:
        docs['schedule_assessment_id'] = ObjectId(schedule_id)
    docs['topic_id'] = ObjectId(topic_id) if not is_empty(topic_id) else topic_id
    docs['course_session_id'] = ObjectId(course_session_id) if not is_empty(course_session_id) else course_session_id

    id = connection.assessments_result.insert(docs)
    # message depends on status
    message = {"done": "Your Assessment Submitted Successfully",
               "timeout": "Thank you for your submission. However as the submission was after the deadline, "
                          "the decision on whether or not the submission will be considered lies with the assessor of "
                          "this assessment. Please contact them for further details",
               "deactivated": "As the assessor of this assessment has deactivated the assessment, no submissions are "
                              "entertained right now."}
    # print(message[status])
    assessment_res = {
                        "message": message[status],
                        "status": status,
                        "assessment_name": assessment_data["assessment_name"],
                        "submisstion_id": str(id)
                    }
    # print(assessment_res)
    return assessment_res


def offline_display_assessment(user_id, assessment_id, schedule_assessment_id=None):
    """
    It is used to display assessment on app
    1. questions and options are fetched from the db of corresponding assessment
    2. it is formatted in the desired format and send in response body
    """

    current_time = convert_utc_ist(format="%Y:%m:%dT%H:%M", time_obj=datetime.now())
    assessment_collection = mongo_session.get_all_data_for_particular_condition_fields("assessment",
                                                                                       {"_id": ObjectId(assessment_id)})
    assessment_name = assessment_collection['message'][0]['assessment_name']
    question_id_lis = assessment_collection['message'][0]['questions']
    assessment_obj = {
        "assessment_name": assessment_name,
        "questions": []
    }
    if schedule_assessment_id:
        schedule_collection = mongo_session.get_all_data_for_particular_condition_fields("schedule_assessment",
                                                                                         {"_id": ObjectId(
                                                                                             schedule_assessment_id)
                                                                                         })["message"][0]
        start_time = datetime.strptime(schedule_collection['start_time'], "%Y:%m:%dT%H:%M")
        end_time = datetime.strptime(schedule_collection['end_time'], "%Y:%m:%dT%H:%M")
        time_remaining = int((start_time - current_time).total_seconds() / 60)
        if time_remaining > 0:
            return {"message": "{} minutes remaining for assessment".format(time_remaining)}
        total_time = int(abs((end_time - start_time).total_seconds() / 60))
        assessment_obj['start_time'] = start_time
        assessment_obj['end_time'] = end_time
        assessment_obj['total_time'] = total_time

    questype_collection = mongo_session.get_all_data("question_type")['message']
    questype_dict = dict(map(lambda x: (x['_id'], x['value']), questype_collection))
    for i in question_id_lis:
        id = i['question_id'].__str__()
        docs = mongo_session.get_all_data_for_particular_condition_fields("add_questions",
                                                                          {"_id": ObjectId(id)}
                                                                          )['message'][0]
        questype = questype_dict[str(docs['questype'])]
        image_urls_question = get_img_in_question(docs['question'])
        if "marks" in i.keys():
            marks = i['marks']
        else:
            marks = 0

        question_obj = {
            'question_id': id,
            'question_type': questype,
            'image': image_urls_question,
            'marks': marks,
            'question_text': filtered_html_tags(docs['question']),
            'question_html': replace_s3_links_with_keys(docs['question'], "offline-assess"),
            'option': [],
            'answer': []
        }
        if questype != "comprehension":
            for i in docs['meta_data']:
                if i['option'] != "":
                    image_urls_option = get_img_in_question(i['option'])
                    option_obj = {
                        'option_value': replace_s3_links_with_keys(i['option'], "offline-assess"),
                        "image": image_urls_option,
                        'checked': False
                    }
                    question_obj['option'].append(option_obj)
        assessment_obj['questions'].append(question_obj)
    assessment_res = {"assessment": assessment_obj}

    return assessment_res


def send_confirmation_email(login_user_other_details, data):
    """Send a confirmation email that the report is submitted."""
    password = email_password
    sender_email = email_Address

    receiver_email = login_user_other_details["email"]

    msg = MIMEMultipart('alternative')
    msg['Subject'] = data["status"]
    msg['From'] = sender_email
    msg['To'] = receiver_email

    name = login_user_other_details['name'] + " " + login_user_other_details['last_name']
    template_path = "assessement_submission"
    confirmation_message = render_template(template_path + ".txt",
                                           name=name,
                                           report_name=data["message"])
    email_text = MIMEText(confirmation_message, 'plain')
    msg.attach(email_text)

    text = msg.as_string()
    # context = ssl.create_default_context()
    # with smtplib.SMTP_SSL("smtp.gmail.com", 465, context=context) as server:
    #     server.login(sender_email, password)
    #     server.sendmail(sender_email, receiver_email, text)

    # PK - Email Service Migration
    smtp = smtplib.SMTP(host="172.31.6.215", port=25)
    smtp.sendmail(sender_email, receiver_email, text)
    smtp.close()
    return True
    