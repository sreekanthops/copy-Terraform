from logging import exception
import traceback

import config
import pandas as pd
from email import encoders
from email.mime.base import MIMEBase
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from model import Question as q
from model import Content
import bcrypt
from mongo_connection import connection
from bson import ObjectId
import requests
import secrets
import string
import smtplib, ssl
# import datetime
from flask import request, Response, json, Blueprint, jsonify
from datetime import datetime, timedelta
import jwt
from config import email_Address, email_password, secret_key, password_secret_key, session_token_secret_key, \
    secret_otp_key
import math
import random
from db_wrapper.tasks import Mongo
from cryptography.fernet import Fernet
import re
from flask import render_template
import traceback

mongo_session = Mongo()
from routes.exception import InvalidUsage
from utils.misc import is_empty
from utils.time_conversions import utc_datetime_now
import ast
from services.storage.s3_services import s3_storage

s3_function = s3_storage()


class User(object):

    def __init__(self, user):
        bits = user.split(",")
        self.user_name = bits[0]
        if len(bits) == 1:
            bits = self.load_user().split(",")
        self.grade = bits[1]
        self.questions_asked = self.load_questions(bits[2])
        self.content_authored = self.load_content(bits[3])
        self.comments = self.load_comments(bits[4])
        self.ratings = self.load_ratings(bits[5])
        self.wallet = int(bits[6])

    # def serialize(self):
    #     return {
    #         'name': self.user_name,
    #         'grade': self.grade,
    #         # 'questions': self.questions_asked,
    #         # 'content': self.content_authored,
    #         # 'comments': self.comments,
    #         # 'ratings': self.ratings,
    #         'wallet': self.wallet,
    #     }

    # def __repr__(self):
    #     return json.dumps(self.__dict__)

    def load_user(self):
        with open(config.USER_BASE_PATH, "r") as fp:
            for line in fp:
                if line[0] == self.user_name:
                    return line

    def load_questions(self, questions):
        quests = []
        ids = questions.split(";")
        for id in ids:
            quests.append(q.Question(id))
        return quests

    def load_content(self, content):
        return content.split(";")

    def load_comments(self, comments):
        return comments.split(";")

    def load_ratings(self, ratings):
        return ratings.split(";")


class MongoSession():
    def find_where(self, key, value, collection):
        """to find the items in db"""
        user_profile = []
        collection = connection[collection]
        cursor = collection.find({key: value})
        for data in cursor:
            data["_id"] = str(data["_id"])
            user_profile.append(data)
        return user_profile

    def Insert_One(self, post, collection):
        """to insert the items in db"""
        collection = connection[collection]
        collection.insert(post)
        return True

    def update_by_id(self, collection, id, field, value):
        """to update the collections items"""
        collection = connection[collection]
        condition = {"_id": ObjectId(id)}
        update_value = {"$set": {field: value}}
        collection.update_one(condition, update_value)
        return True


def encode_otp(otp, email):
    """ encode oto"""
    try:
        payload = {
            'exp': datetime.utcnow() + timedelta(minutes=config.otp_exp_limit_reset_min),
            'iat': datetime.utcnow(),
            'sub': [otp, email]
        }
        otp = jwt.encode(payload, secret_otp_key, algorithm=config.jwt_encoding_algorithm)
        return otp.decode('utf-8')
    except Exception as e:
        return e.__str__()


def decode_otp(encoded_OTP):
    """
    Decodes otp
    """
    try:
        encoded_OTP = encoded_OTP.encode('utf-8')
        payload = jwt.decode(encoded_OTP, secret_otp_key)
        return payload['sub']
    except jwt.ExpiredSignatureError:
        return 'Signature expired. Please log in again.'
    except jwt.InvalidTokenError:
        return 'Invalid token. Please log in again.'


class OAuth_login():
    """login with facebook and google"""

    def __init__(self, provider, access_token):
        self.provider = provider
        self.access_token = access_token

    def facebook(self):
        entity = []
        data = requests.get(
            "https://graph.facebook.com/me?fields=email,name&access_token={}".format(self.access_token)).json()

        try:
            email = data['email']
        except Exception as e:
            print(e)
            # logger.exception("exception in calling FB graph api ")
            email = None
        if email:
            query_data = MongoSession().find_where(key='email', value=email, collection='user_profile')
            if len(query_data) == 0:  # means this email does not exist in user db yet,  so go ahead
                name = data['name']
                post = {"name": name, "Password": None, "email": email, "questions": [],
                        "answers": [], "score": int(), "coin": int(50), "organisation": None,
                        "user_creation_type": "Oauth",
                        "access_token": self.access_token
                        }
                response = MongoSession().Insert_One(post=post, collection='user_profile')
                token = encode_auth_token(str(post["_id"]))
                condition = {"name": post['name']}
                update_value = {"$set": {"session_token": token}}
                connection.user_profile.update_one(condition, update_value)
                mongo_cursor = connection.user_profile.find({'name': post['name']})
                for data in mongo_cursor:
                    data["_id"] = str(data["_id"])
                    data['session_token'] = str(decode_auth_token(data['session_token']))
                    entity.append(data)
                login_data = entity[0]
                response_message = "Login Succesfully"
                return response_message, login_data
            elif len(query_data) == 1:  # means this email is already registered, now update existing access-token
                MongoSession().update_by_id(collection="user_profile", id=str(query_data[0]["_id"]),
                                            field="access_token",
                                            value=self.access_token)

                mongo_cursor = connection.user_profile.find({'name': query_data[0]['name']})
                for data in mongo_cursor:
                    data["_id"] = str(data["_id"])
                    data['session_token'] = str(decode_auth_token(data['session_token']))
                    entity.append(data)

                response = entity[0]
                response_message = "Login Succesfully"
                return response_message, response
        else:
            response_data = None
            response_message = "Could not login"
            return response_message, response_data

    def google(self):
        """        we need id_token for google instead of access token, but in login api,
                   key name is access_token for all providers,
         """
        entity = []
        id_token = self.access_token
        data = requests.get("https://www.googleapis.com/oauth2/v3/tokeninfo?id_token={}".format(id_token)).json()
        try:
            email = data['email']
        except Exception as e:
            print(e)
            # logger.exception("exception in calling Google Oauth api for new user,no email in user profile")
            email = None
        if email:
            query_data = MongoSession().find_where(key='email', value=email, collection='user_profile')
            if len(query_data) == 0:
                name = data['name']
                post = {"name": name, "Password": None, "email": email, "questions": [],
                        "answers": [], "score": int(), "coin": int(50), "organisation": None,
                        "user_creation_type": "Oauth",
                        "access_token": self.access_token,
                        }
                response = MongoSession().Insert_One(post=post, collection='user_profile')
                token = encode_auth_token(str(post["_id"]))
                condition = {"name": post['name']}
                update_value = {"$set": {"session_token": token}}
                connection.user_profile.update_one(condition, update_value)
                mongo_cursor = connection.user_profile.find({'name': post['name']})
                for data in mongo_cursor:
                    data["_id"] = str(data["_id"])
                    data['session_token'] = str(decode_auth_token(data['session_token']))
                    entity.append(data)
                login_data = entity[0]
                response_message = "Login Succesfully"
                return response_message, login_data
            elif len(query_data) == 1:
                MongoSession().update_by_id(collection="user_profile", id=str(query_data[0]["_id"]),
                                            field="access_token",
                                            value=self.access_token)

                response = query_data[0]
                response_message = "Login Succesfully"
                return response_message, response
        else:
            response_data = None
            response_message = "Could not login"
            return response_message, response_data


def encryption_function(password):
    """to encrypt the  argument passed"""
    key = password_secret_key
    f = Fernet(key)
    encrypted_password = f.encrypt(password)
    return encrypted_password


def decryption_function(encrypted_password):
    """to decrypt the argument passed"""
    key = password_secret_key
    f = Fernet(key)
    decrypted_password = f.decrypt(encrypted_password)
    return decrypted_password.decode('utf-8')


# login decorator to validate session token
def login(func):
    def inner():
        try:
            session_token = request.headers['session-token']
            session_status = get_user_data_decrypt_session_token(session_token)
            if session_status.get("status") and session_status["status"] == 401:
                res = {"message": "Session Expired",
                       "status": 401}
                return Response(json.dumps(res),
                                mimetype='application/json',
                                status=401)
            role = session_status['role']
            organisation = session_status['organisation']
            login_user_other_details = session_status
            login_user_other_details["_id"] = str(session_status["_id"])
            permissions_array_data = mongo_session.get_data_for_particular_columns_with_condition(
                collection='roles',
                condition={"name": role},
                columns={"permissions": 1})
            permissions = permissions_array_data['message'][0]['permissions']
            return func(role=role,
                        organisation=organisation,
                        permissions=permissions,
                        login_user_other_details=login_user_other_details)
        except Exception as e:
            traceback.print_exc()
            res = {"detail": e.__str__(),
                   "message": "Something went wrong, Please try again later."}
            return Response(json.dumps(res), mimetype='application/json', status=500)

    inner.__name__ = func.__name__
    return inner


def generate_session_token(user_id):
    """ generate session_token"""
    JWT_EXP_DELTA_DAYS = config.jwt_session_token_expiry_limit_in_days
    payload = {
        'user_id': user_id,
        'iat': datetime.utcnow(),
        'exp': datetime.utcnow() + timedelta(days=JWT_EXP_DELTA_DAYS)
    }
    jwt_session_token = jwt.encode(payload, session_token_secret_key, algorithm=config.jwt_encoding_algorithm)

    return jwt_session_token.decode('utf-8')


# return json_response({'token': jwt_token.decode('utf-8')})


def decrypt_session_token(jwt_session_token):
    """returns whether the session_token is valid or not"""
    try:
        jwt_session_token = jwt_session_token.encode("utf-8")
        payload = jwt.decode(jwt_session_token, session_token_secret_key, verify=True)
        user_id = payload['user_id']
        user_id = ObjectId(user_id)
        session_status = connection.user_profile.find({'_id': user_id}).count() > 0
        return session_status

    except (jwt.DecodeError, jwt.ExpiredSignatureError):
        return 'Token is invalid'


def get_expiry_jwt_session_token(jwt_session_token):
    """returns whether the session_token is valid or not"""
    try:
        payload = ""
        jwt_session_token = jwt_session_token.encode("utf-8")
        payload = jwt.decode(jwt_session_token, session_token_secret_key, verify=True)
        user_id = payload['user_id']
        user_id = ObjectId(user_id)
        session_status = connection.user_profile.find({'_id': user_id}).count() > 0
        return session_status, payload
    except (jwt.DecodeError, jwt.ExpiredSignatureError):
        return 'Token is invalid', payload


def get_user_data_decrypt_session_token(jwt_session_token):
    """method which validates whether the session_token is valid or not.
       :param jwt_session_token: jwt token to validate user.
       :type jwt_session_token: token str
       :returns: token is valid or not."""
    try:
        jwt_session_token = jwt_session_token.encode("utf-8")
        jwt_options = {'verify_exp': True}
        payload = jwt.decode(jwt_session_token, session_token_secret_key, verify=True, options=jwt_options)
        user_id = payload['user_id']
        user_id = ObjectId(user_id)
        condition = {"_id": user_id}
        session_status = mongo_session.check_existance_return_info(collection='user_profile',
                                                                   condition=condition,
                                                                   whole_doc=True)
        return session_status

    except (jwt.DecodeError, jwt.ExpiredSignatureError):
        return {"message": 'Unauthorised Access.', "status": 401}


def login_user(useremail=None, password=None):
    """
    This function checks the existence of user in the database according to the information
    provided by the user through login form. If information is correct it logins the user to
    the website else informs user that either email or password entered is incorrect.
    :param useremail: email entered by the user
    :param password: password entered by the user
    :return: response message and user information
    """
    entity = {}
    user_info = mongo_session.check_existance_return_info(collection="user_profile",
                                                          condition={"email": useremail},
                                                          columns={"_id": 1, "username": 1, "name": 1, "last_name": 1,
                                                                   "Password": 1, "email": 1, "coin": 1, "active": 1,
                                                                   "role": 1, "profile_pic": 1},
                                                          return_keys=["_id", "username", "name", "last_name",
                                                                       "Password", "email", "coin", "active", "role",
                                                                       "profile_pic"])
    if not user_info:
        raise InvalidUsage("Incorrect password or username", 401)

    user_id = str(user_info["_id"])
    token = generate_session_token(user_id)
    if type(user_info['active']) == bool and not user_info['active']:
        raise InvalidUsage("This account is inactive !! you can't login", 401)

    stored_password = decryption_function(user_info["Password"])

    if stored_password == password:
        user_info["_id"] = str(user_info["_id"])
        response_message = ['Login Successfully', str(token)]
        return response_message, user_info
    else:
        raise InvalidUsage("Incorrect password. Login failed", 401)


def get_user_profile_image(user_id):
    """
    This function checks the existence of user in the database according to user_id. If user exits then
    it will return profle image url with expiration time
    :param user_id: user_id generated by session token of user
    :return: response message and user profle pic with expiration time
    """
    user_info = mongo_session.check_existance_return_info(collection="user_profile",
                                                          condition={"_id": ObjectId(user_id)},
                                                          columns={"_id": 1, "profile_pic": 1},
                                                          return_keys=["_id", "profile_pic"])
    if not user_info:
        raise InvalidUsage("Invalid access", 401)

    x = datetime.now()
    threshold_time = (x + timedelta(hours=6)).strftime("%Y-%m-%d %H:%M:%S")

    if user_info["profile_pic"]:
        user_info["_id"] = str(user_info["_id"])
        user_info["profile_pic"], status_code = s3_function.generate_presigned_url_from_s3(user_info["profile_pic"])
        user_info["expire_time"] = threshold_time
        return user_info
    else:
        raise InvalidUsage("Profile image not found.", 400)


def add_user(email_address, first_name, last_name, organisation, organisation_id, grade, org_type, role,
             default_courses=[],
             password=None, username=None):
    """This method add the new user into database. Works for bulk upload too.
    :param email_address: email of user to register, should be valid and unique.
    :param first_name: first name of the user to register.
    :param last_name: last name of the user to register, it is optional.
    :param organisation: org slug of user to register,validate if org is registered.
    :param grade: grade of user to register.
    :param org_type: type of the organisation, college or school.
    :param role: slug defining role of registering user.
    :param default_courses: the courses user should be subscribe to while we register user.
    :param password: optional.
    :param username: optional.
    :type email_address: str
    :type first_name: str
    :type last_name: str
    :type organisation: slug
    :type grade: str
    :type org_type: slug
    :type role: slug
    :type password: str
    :type username: str
    """
    collection = connection.user_profile
    entity = []

    if not email_address_validation(email_address):
        raise InvalidUsage("Enter a valid Email Address.", 409)

    if len(first_name) < 3 or len(first_name) > 100:
        raise InvalidUsage("first name should have at least 3 and max 99 characters.", 409)

    if not first_name.isalpha():
        raise InvalidUsage("First name should only contain alphabets.", 409)

    if password:
        if len(password) < 8 or len(password) > 30 or password.isspace():
            raise InvalidUsage("Password length should be greater than 8.", 409)

    if last_name:
        if len(last_name) < 3 or len(last_name) > 100:
            raise InvalidUsage("Last name should have at least 3 and max 99 characters.", 409)
        if not last_name.isalpha():
            raise InvalidUsage("Last name should only contain alphabets.", 409)

    if mongo_session.check_existance(collection="user_profile",
                                     condition={"email": email_address}):
        msg = "Email %s already exist. Try with different email." % (email_address)
        raise InvalidUsage(msg, 409)

    if username:
        status, msg = username_restriction(username)
        if not status:
            raise InvalidUsage(msg, 409)
        if mongo_session.check_existance(collection="user_profile",
                                         condition={"username": username}):
            msg = "Username %s already exist. Try with different Username" % (username)
            raise InvalidUsage(msg, 409)
    if not password:
        alphabet = string.ascii_letters + string.digits
        password = ''.join(secrets.choice(alphabet) for i in range(20))
    if not username:
        username = generate_username(first_name, last_name)

    encoded_password = password.encode("utf-8")
    encrypted_password = encryption_function(encoded_password)

    user_id = collection.insert({"name": first_name,
                                 "last_name": last_name,
                                 "Password": encrypted_password,
                                 "email": email_address,
                                 "questions": [],
                                 "username": username,
                                 "grade": int(grade),
                                 "answers": [],
                                 "score": int(),
                                 "coin": config.coins_given_on_signup,
                                 "organisation": organisation,
                                 "institute_type": org_type,
                                 "user_creation_type": "SignUp",
                                 "access_token": None,
                                 "subscribed_courses": [],
                                 "mobile": None,
                                 "profile_pic": None,
                                 "Verified_Email": None,
                                 "role": role,
                                 "active": True,
                                 "organisation_id": organisation_id,
                                 "registered_at": utc_datetime_now()})
    # subscribe to courses if there are courses in Default courses list

    if default_courses and ast.literal_eval(default_courses):
        default_courses = ast.literal_eval(default_courses)
        for course_id in default_courses:
            msg, status = Content.subscribe_course(user_id=user_id,
                                                   course_id=course_id,
                                                   subscribe=True)
            err_msg = "We ran into some problem while subscribing the course."
            if status != 200:
                InvalidUsage(err_msg, 500)

    # send email to user
    subject = "Welcome to Educollab"
    template_path = "welcome_email"
    body = render_template(template_path + ".txt",
                           username=username,
                           email=email_address,
                           password=password)
    send_mail(email=email_address,
              body=body,
              subject=subject)
    mongo_cursor = collection.find({'email': email_address})
    for data in mongo_cursor:
        data["_id"] = str(data["_id"])
        entity.append(data)
        response_message = "User %s Signup Successfully." % (username)
        return response_message, entity[0]

def add_bulk_user(usersdetails,organisation, organisation_id, org_type,role,default_courses=[],password=None, username=None):
    """This method add the new user into database. Works for bulk upload too.
    :param org_type: type of the organisation, college or school.
    :param role: slug defining role of registering user.
    :param default_courses: the courses user should be subscribe to while we register user.
    :param password: optional.
    :param username: optional.
    :type organisation: slug
    :type org_type: slug
    :type role: slug
    :type password: str
    :type username: str
    """
    collection = connection.user_profile
    user_ids = []
    entities = []
    response_messages = []
    userdetails = []
    errorlist=[]   
    for details in usersdetails:
        username = None
        entity = []
        try:
            if not email_address_validation(details["Email"]):
                raise InvalidUsage("Enter a valid Email Address.", 409)
            if len(details["First_Name"]) < 3 or len(details["First_Name"]) > 100:
                raise InvalidUsage("first name should have at least 3 and max 99 characters.", 409)
                
            if not details["First_Name"]:
                details["First_Name"].strip()
                raise InvalidUsage("First name should only contain alphabets.", 409)
            if password:
                if len(password) < 8 or len(password) > 30 or password.isspace():
                    raise InvalidUsage("Password length should be greater than 8.", 409)

            if details["Last_Name"]:
                if len(details["Last_Name"]) < 3 or len(details["Last_Name"]) > 100:
                    raise InvalidUsage("Last name should have at least 3 and max 99 characters.", 409)
                if not details["Last_Name"]:
                    details["Last_Name"].strip()
                    raise InvalidUsage("Last name should only contain alphabets.", 409)

            if mongo_session.check_existance(collection="user_profile",
                                            condition={"email": details["Email"]}):

                msg = "Email %s already exist. Try with different email." % (details["Email"])
                raise InvalidUsage(msg, 409)

            if username:
                status, msg = username_restriction(username)

                if not status:
                    raise InvalidUsage(msg, 409)
                if mongo_session.check_existance(collection="user_profile",
                                                condition={"username": username}):
                    msg = "Username %s already exist. Try with different Username" % (username)
                    raise InvalidUsage(msg, 409)

            if not password:
                alphabet = string.ascii_letters + string.digits
                password = ''.join(secrets.choice(alphabet) for i in range(20))
            if not username:
                username = generate_username(details["First_Name"], details["Last_Name"])

            encoded_password = password.encode("utf-8")
            encrypted_password = encryption_function(encoded_password)

            userdetails.append({"name": details["First_Name"],
                                        "last_name": details["Last_Name"],
                                        "Password": encrypted_password,
                                        "email": details["Email"].lower(),
                                        "questions": [],
                                        "username": username,
                                        "grade": int(details["Grade"]),
                                        "answers": [],
                                        "score": int(),
                                        "coin": config.coins_given_on_signup,
                                        "organisation": organisation,
                                        "institute_type": org_type,
                                        "user_creation_type": "SignUp",
                                        "access_token": None,
                                        "subscribed_courses": [],
                                        "mobile": None,
                                        "profile_pic": None,
                                        "Verified_Email": None,
                                        "role": role,
                                        "active": True,
                                        "organisation_id": organisation_id,
                                        "registered_at": utc_datetime_now()})
        except InvalidUsage as e:
            message = e.message + " for %s" % (details["First_Name"] + " " + details["Last_Name"] + ".")
            errorlist.append(message)
            continue
    if userdetails != []:
        user_id = collection.insert_many(userdetails)
        user_ids = user_id.inserted_ids
        for user_id, details in zip(user_ids, userdetails):
            # user_ids.append(user_id)
            # # subscribe to courses if there are courses in Default courses list
            if default_courses and isinstance(default_courses, list):
                #default_courses = isinstance(default_courses, list)
                for course_id in default_courses:
                    msg, status = Content.subscribe_course(user_id=user_id,
                                                        course_id=course_id,
                                                        subscribe=True)
                    err_msg = "We ran into some problem while subscribing the course."
                    if status != 200:
                        InvalidUsage(err_msg, 500)

            # send email to user
            subject = "Welcome to Educollab"
            template_path = "welcome_email"
            body = render_template(template_path + ".txt",
                                username=details["username"],
                                email=details["email"],
                                password=password)
            send_mail(email=details["email"],
                    body=body,
                    subject=subject)
            user_emails = [user["email"] for user in userdetails]
            mongo_cursor = collection.find({'_id':{"$in":list(user_ids)}})
            for data in mongo_cursor:
                data["_id"] = str(data["_id"])
                entity.append(data)
                response_message = "User %s Signup Successfully." % (data["username"])
                response_messages.append(response_message)
            entities.append(entity[0])
        return [response_messages, entities, user_ids]
    else:
        return [errorlist]


def generateOTP():
    """method to genearte OTP"""
    digits = "0123456789"
    OTP = ""
    for i in range(4):
        OTP += digits[math.floor(random.random() * 10)]
    return OTP


def forget_password(email_address):
    """
    This function checks whether the email id user provided is valid or not. If it is valid
    it sends an email to the user consisting of url to reset the password.
    :param email_address: email address entered by the user
    :return: otp generated for the user
    """
    email_address = email_address.lower()
    email = mongo_session.get_email_forget_password_api(collection="user_profile",
                                                        condition={"email": email_address},
                                                        columns={"email": 1})

    if not email['status'] == 200:
        if not email['message']:
            raise InvalidUsage("That address is either invalid or not a registered email address", 401)
        else:
            raise Exception(email['message'])

    OTP = generateOTP()
    encoded_otp = encode_otp(OTP, email['message'])
    subject = 'Reset Password'
    body = """\
        This is the OTP to reset your Password %s """ % (OTP)
    #fetching all docs in which email is stored as provided by the user
    fetch = mongo_session.fetch_all_records(collection = "Otp",
                                            condition = {"email_id": email_address},
                                            columns= {"tries" : 1})
    created_at = datetime.utcnow()
    initial_time= created_at - timedelta(minutes = 15)
    count = 0
    if fetch:
        for ent in fetch:
            tries = ent["tries"]
            for _try in tries:
                if _try["created_at"] > initial_time:
                    count += 1

        if count < 3:
            send_mail(email=email['message'], body=body, subject=subject)
            currentvalues = { "otp" : encoded_otp, "created_at": created_at}
            tries.append(currentvalues)
            otpupdatedata = {"tries": tries}
            otp = mongo_session.update_multiple_fields(collection='Otp',
                                                       condition={"email_id": email_address},
                                                       set_columns = otpupdatedata)
        else:
            raise InvalidUsage("You have reached maximum limit for next 15 minutes", 500)
    else:
        send_mail(email=email['message'], body=body, subject=subject)
        otp = mongo_session.insert_docs_to_db(collection='Otp', 
                                              docs=[{"email_id": email["message"],
                                                     "tries" : [{"otp": encoded_otp,
                                                    "created_at": created_at}]}])
    return encoded_otp


def match_otp(user_email, otp, encoded_otp):
    """to verify OTP"""
    response = decode_otp(encoded_otp)
    user_email = user_email.lower()
    if response[1] == user_email:
        if response[0] == otp:
            return "OTP Matched", 200
        elif response[0] != otp:
            return "Incorrect OTP", 400
        else:
            return "Not a registred User", 400
    else:
        return "bad request", 400


def reset_password(email_address, new_password, confirm_password, old_password=None, saved_old_password=None):
    """module to reset the password"""
    email_address = email_address.lower()
    email = mongo_session.get_email_forget_password_api(collection="user_profile", condition={"email": email_address},
                                                        columns={"email": 1})
    if email['status'] == 200 and len(email['message']):
        collection = connection.user_profile
        if old_password != None:
            decrypted_password = decryption_function(saved_old_password)
            if old_password == decrypted_password:
                if new_password != "":
                    status, msg = password_check(new_password)
                    if not status:
                        return msg, 400
                    else:
                        password = new_password
                        condition = {"email": email_address}
                        password = password.encode("utf-8")
                        encrypted_password = encryption_function(password)
                        update_value = {"$set": {'Password': encrypted_password}}
                        collection.update_one(condition, update_value)
                        status = "Password changed succesfully"
                        status_code = 200
                else:
                    msg = "Please enter new password"
                    return msg, 400
            else:
                status = "Old Password is not matched with saved password"
                status_code = 400
        else:
            if new_password == confirm_password:
                if new_password != "":
                    status, msg = password_check(new_password)
                    if not status:
                        return msg, 400
                password = new_password
                condition = {"email": email_address}
                password = password.encode("utf-8")
                encrypted_password = encryption_function(password)
                update_value = {"$set": {'Password': encrypted_password}}
                collection.update_one(condition, update_value)
                status = "Password changed succesfully"
                status_code = 200
            else:
                status = "Password is not matched with confirm password"
                status_code = 400
    else:
        status = "bad request"
        status_code = 400
    return status, status_code


def send_mail(email, body, subject):
    """this module send the mail to registered user"""
    password = email_password

    sender_email = email_Address
    receiver_email = email

    # Create a multipart message and set headers
    message = MIMEMultipart()
    message["From"] = sender_email
    message["To"] = receiver_email
    message["Subject"] = subject

    # Add body to email
    message.attach(MIMEText(body, 'plain'))

    text = message.as_string()

    # Log in to server using secure context and send email
    # try:
    #     context = ssl.create_default_context()
    #     with smtplib.SMTP_SSL("smtp.gmail.com", 465, context=context) as server:
    #         server.login(sender_email, password)
    #         server.sendmail(sender_email, receiver_email, text)
    # except:
    #     return "failed to connect"
    try:
        smtp = smtplib.SMTP(host="172.31.6.215", port=25)
        smtp.sendmail(sender_email, receiver_email, text)
        smtp.close()
    except:
        return "failed to connect"


def generate_username(first_name, last_name):
    """to generate  user name"""
    code = generateOTP()
    username = first_name + last_name + code
    collection = connection.user_profile
    if collection.find_one({'username': username}):
        generate_username(first_name, last_name)
    else:
        return username


def username_generate(first_name, last_name):
    """to generate  user name"""
    full_name = first_name + " " + last_name
    full_name = full_name.lower().split()
    collection = connection.user_profile
    username_list = []
    for i in range(0, 10):
        if len(full_name) > 1:
            first_letter = full_name[0][0]
            three_letters_surname = full_name[-1][:4].rjust(3, 'x')
            number = '{:03d}'.format(random.randrange(1, 999))
            username = '{}{}{}'.format(first_letter, three_letters_surname, number)
            if collection.find_one({'username': username}):
                continue
            else:
                username_list.append(username)
    return username_list


def check_coins(coins_for_question, user_id):
    """to check that user can give coins as a reward"""
    collection = connection.user_profile
    user_cursor = collection.find({'_id': ObjectId(user_id)})
    for data in user_cursor:
        available_coins = data['coin']
    coin_left = available_coins - coins_for_question
    if coin_left <= 0:
        can_give_coins = False
    else:
        can_give_coins = True
    return can_give_coins


def User_Profile(user_id, application_type=None):
    """return the user_profile"""
    collection = connection.user_profile
    user_detail = []
    user_cursor = collection.find({'_id': ObjectId(user_id)})
    for data in user_cursor:
        if data != []:
            if application_type == "webapp":
                s3_url, status_code = s3_function.generate_presigned_url_from_s3(data['profile_pic'])
                response_dict = {'username': data['username'], 'first_name': data['name'],
                                 'last_name': data['last_name'], 'Email': data['email'],
                                 'Institute': data['organisation'], 'role': data['role'],
                                 'mobile': data['mobile'], 'avatar_url': s3_url, 'avatar_path': data['profile_pic'],
                                 'avail_coin': float(round(data['coin'], 2))}
                keys = ["about", "facebook_url", "linkedin_url", "user_type"]
                for dict_key in keys:
                    if dict_key in data.keys():
                        response_dict[dict_key] = data[dict_key]
                    else:
                        response_dict[dict_key] = ""
                return response_dict
            else:
                password = data['Password']
                decrypted_password = len(decryption_function(password))
                user_detail.append(
                    {'username': data['username'], 'first_name': data['name'], 'last_name': data['last_name'],
                     'Password': decrypted_password, 'Email': data['email'], 'Institute': data['organisation'],
                     'role': data['role'], 'mobile': data['mobile'], 'profile_pic': data['profile_pic'],
                     'avail_coin': float(round(data['coin'], 2))})
        else:
            user_detail = []
    return user_detail


def update_user_profile(user_id, name, last_name, mobile, profile_pic, username, about=None, facebook=None,
                        linkedin=None, user_type=None, application_type=None):
    """edit the user profile fields"""
    collection = connection.user_profile
    user_query = {"_id": ObjectId(user_id)}
    update_data = {}
    if not is_empty(username):
        if collection.find_one({'username': username}):
            existing_user_id = list(collection.find({'username': username}, {"_id": 1}))
            if user_id == str(existing_user_id[0]['_id']):
                status, msg = username_restriction(username)
                if not status:
                    return msg, []
                update_data["username"] = username
            else:
                raise InvalidUsage(f"This username {username} already exist. Please use a different username", 400)

        else:
            status, msg = username_restriction(username)
            if not status:
                return msg, []
            update_data["username"] = username
    if not is_empty(name):
        if len(name) < 3 or len(name) > 100:
            raise InvalidUsage("First name should have at least 3 and max 99 characters.", 400)
        if not name.isalpha():
            raise InvalidUsage("First name should only contain alphabets.", 400)
        update_data["name"] = name
    if not is_empty(last_name):
        if len(last_name) < 3 or len(last_name) > 100:
            raise InvalidUsage("Last name should have at least 3 and max 99 characters.", 400)
        if not last_name.isalpha():
            raise InvalidUsage("Last name should only contain alphabets.", 400)
        update_data["last_name"] = last_name
    if not is_empty(mobile):
        update_data["mobile"] = mobile
    if not is_empty(profile_pic):
        update_data["profile_pic"] = profile_pic
    if not is_empty(about):
        update_data["about"] = about
    if not is_empty(facebook):
        update_data["facebook_url"] = facebook
    if not is_empty(linkedin):
        update_data["linkedin_url"] = linkedin
    if not is_empty(user_type):
        update_data["user_type"] = user_type
    status = "Update Successfully"
    user_detail = []
    collection.update(user_query, {"$set": update_data})
    user_cursor = collection.find({'_id': ObjectId(user_id)})
    for data in user_cursor:
        if data:
            if application_type == "webapp":
                s3_url, status_code = s3_function.generate_presigned_url_from_s3(data['profile_pic'])
                response_dict = {'username': data['username'], 'first_name': data['name'],
                                 'last_name': data['last_name'],
                                 'Password': "xxxxxxxxx", 'Email': data['email'], 'Institute': data['organisation'],
                                 'mobile': data['mobile'], 'avatar_url': s3_url, 'avatar_path': data['profile_pic'],
                                 'avail_coin': float(round(data['coin'], 2))}
                keys = ["about", "facebook_url", "linkedin_url", "user_type"]
                for dict_key in keys:
                    if dict_key in data.keys():
                        response_dict[dict_key] = data[dict_key]
                    else:
                        response_dict[dict_key] = ""
                return status, response_dict
            else:
                user_detail.append(
                    {'username': data['username'], 'first_name': data['name'], 'last_name': data['last_name'],
                     'Password': "xxxxxxxxx", 'Email': data['email'], 'Institute': data['organisation'],
                     'mobile': data['mobile'], 'profile_pic': data['profile_pic'],
                     'avail_coin': float(round(data['coin'], 2))})
    return status, user_detail


def match_session_token(user_id, session_token):
    """module to match session token or authorize user"""
    user_collection = connection.user_profile
    user_cursor = user_collection.find({"_id": ObjectId(user_id)}, {"session_token": 1})
    for data in user_cursor:
        stored_session_token = str(data['session_token'])
    if stored_session_token == session_token:
        return True
    else:
        return False


def teacher_student_question(course_category_id, role, teacher_id):
    '''this to map users with the associated teachers of subscribed courses'''
    response = []
    if len(mongo_session.get_user_teacher_student_question("user_profile",
                                                           {"_id": ObjectId(teacher_id),
                                                            "role": role})['message']) > 0:
        if role == 'teacher':
            subscribed_users = mongo_session.get_valid_users_teacher_student_question('courses_bank',
                                                                                      {"created_by": ObjectId(
                                                                                          teacher_id)},
                                                                                      {"subscribers": 1})['message']
        elif role == 'super_admin':
            subscribed_users = mongo_session.get_valid_users_teacher_student_question('courses_bank',
                                                                                      {"active": True},
                                                                                      {"subscribers": 1})['message']
        # print('x',subscribed_users)
        if len(subscribed_users) > 0:
            response = mongo_session.get_question_data_teacher_student_question(
                'question_bank',
                {"course_category_id": ObjectId(course_category_id)},
                {"questions": 1})['message']
            message = "success"
            return response, message
        else:
            message = "No student is available"
    else:
        message = "Can't show data"
    return response, message


def teacher_student_answer(course_category_id, role, teacher_id):
    '''this to map users with the associated teachers of same institute'''
    user_collection = connection.user_profile
    question_collection = connection.question_bank
    answer_collection = connection.answer_bank
    category_collection = connection.Course_Category

    response_array = []

    try:
        if len(mongo_session.get_user_teacher_student_question("user_profile",
                                                               {"_id": ObjectId(teacher_id), "role": role})[
                   'message']) > 0:
            subscribed_users = mongo_session.get_valid_users_teacher_student_question('courses_bank', {
                "created_by": ObjectId(teacher_id), "course_category_id": ObjectId(course_category_id)},
                                                                                      {"Subscribed_Users": 1})[
                'message']
            course_category_name = \
            mongo_session.get_category_name('Course_Category', {"_id": ObjectId(course_category_id)},
                                            {"name": 1, "_id": 0})['message']

            if len(mongo_session.get_answer_teacher_student_answer("answer_bank", {"user_id": {"$in": subscribed_users},
                                                                                   "Course_Category": course_category_name})[
                       'message']) > 0:
                answer_dict = mongo_session.get_answer_info_teacher_student_answer("answer_bank", {
                    "user_id": {"$in": subscribed_users}, "Course_Category": course_category_name})['message']

                for data in answer_dict:
                    answer = {}
                    answer['username'] = mongo_session.get_username_teacher_student_answer("user_profile", {
                        "_id": ObjectId(data['user_id'])}, {"username": 1})['message']
                    rating_aggregate_cursor = answer_collection.aggregate(
                        [{"$match": {"user_id": data['user_id'], "_id": ObjectId(data["_id"])}},
                         {"$project": {"av_rating": {"$avg": "$Rating.Rating"}}}])
                    for rate in rating_aggregate_cursor:
                        rating = rate["av_rating"]
                    if rating != None:
                        answer["Rating"] = float(round(rating, 2))
                    else:
                        answer["Rating"] = 0.0

                    if data['Feedback']:
                        answer_feedback = []
                        for feedback in data['Feedback']:
                            feedback_cursor = list(
                                user_collection.find({"_id": ObjectId(feedback['user_id'])}, {"username": 1}))
                            if feedback_cursor:
                                feedback['username'] = feedback_cursor[0]['username']
                                seconds = (datetime.now() - feedback['Timestamp']).total_seconds()
                                humanreadable_format = Content.convert_time_into_humanreadable_form(seconds)
                                feedback['Timestamp'] = humanreadable_format
                                answer_feedback.append(feedback)
                        answer['Feedback'] = answer_feedback
                    else:
                        answer['Feedback'] = []

                    answer['approval_status'] = data['approval_status']
                    if answer['approval_status'] == 1:
                        answer['approval_status'] = "approved"
                    else:
                        answer['approval_status'] = ""
                    upload_file_name = data['file_path']
                    response_from_s3 = config.s3_connection.generate_presigned_url('get_object',
                                                                                   Params={'Bucket': config.bucket,
                                                                                           'Key': upload_file_name},
                                                                                   ExpiresIn=604800)
                    answer['file_path'] = response_from_s3
                    answer['_id'] = data['_id']
                    answer["Course_Category"] = data['Course_Category']
                    answer["Liked"] = data['Liked']
                    answer["Disliked"] = data['Disliked']

                    single_response_dict = {}
                    if question_collection.find({"_id": ObjectId(data['question_id'])}).count() > 0:
                        question_cursor = question_collection.find({"_id": ObjectId(data['question_id'])},
                                                                   {"questions": 1})
                        for question in question_cursor:
                            asked_question = question['questions']
                            status = False
                            for current_response in response_array:
                                if current_response['Question'] == asked_question:
                                    current_response['answer'].append(answer)
                                    status = True
                                    break
                            if status == False:
                                single_response_dict['Question'] = asked_question
                                single_response_dict['answer'] = [answer]
                                response_array.append(single_response_dict)
                    else:
                        single_response_dict['Question'] = ""
                        single_response_dict['answer'] = [answer]
                        response_array.append(single_response_dict)

                message = "success"
                return response_array, message

            else:
                message = "No student is available for this institute"
        else:
            message = "Can't show data"

        return response_array, message
    except:
        message = "Session Timeout"
    return response_array, message


def logout_end_session(user_id, deviceToken):
    """To logout and end session by deleting the stored session_token"""
    try:
        device_token_list = [deviceToken]
        condition = {"_id": ObjectId(user_id)}
        query_status = mongo_session.delete_device_ids_answer_question(collection='user_profile', condition=condition,
                                                                       id_list=device_token_list)
        if query_status['status'] == 200:
            return True
        else:
            return False
    except:
        return False


def get_users_info(role, organisation):
    """ to get information of all users
    :param role: role of the accessor
    :type role: str(slug)
    :param organisation: org of the accessor
    :type organisation: str
    :returns username, org, grade, institute_type, role, active status of the user
    :rtype list"""
    columns = {"username": 1, "organisation": 1, "grade": 1, "institute_type": 1, "_id": 1, "role": 1,
               "active": 1, "email":1}
    roles_info = mongo_session.access_specific_fields(collection="roles",
                                                      columns={"name": 1, "display_name": 1, "_id": 1},
                                                      return_keys=["name", "display_name", "_id"])

    roles_dict = dict()
    for i in roles_info:
        roles_dict[i["name"]] = i["display_name"]
    condition = None
    if role not in ["super_admin", "school_admin"]:
        raise InvalidUsage("Permission Denied", 403)
    if role == "school_admin":
        condition = {"organisation": organisation}
    # Get various information of users present in db(username, org, grade, institute_type, role, active status)
    users_info = mongo_session.access_specific_fields(collection='user_profile',
                                                      condition=condition,
                                                      columns=columns,
                                                      return_keys=["username", "organisation", "grade",
                                                                   "institute_type", "_id", "role", "active",
                                                                   "email"])

    for user in users_info:
        user["display_name"] = roles_dict[user["role"]] if user["role"] in roles_dict.keys() else user["role"]
        user["user_id"] = str(user.pop("_id"))
    return users_info


def get_users_list(role, organisation, page, user_role):
    """ to get information of all users
    :param role: role of the accessor
    :type role: str(slug)
    :param organisation: org of the accessor
    :type organisation: str
    :param page: page number for pagination
    :type page: int
    :returns username, org, grade, institute_type, role, active status of the user
    :rtype list"""
    columns = {"username": 1, "organisation": 1, "grade": 1, "institute_type": 1, "_id": 1, "role": 1,
               "active": 1, "email":1, "name": 1, "last_name": 1}
    roles_info = mongo_session.access_specific_fields(collection="roles",
                                                      columns={"name": 1, "display_name": 1, "_id": 1},
                                                      return_keys=["name", "display_name", "_id"])

    roles_dict = dict()
    for i in roles_info:
        roles_dict[i["name"]] = i["display_name"]
    condition = None
    if role not in ["super_admin", "school_admin"]:
        raise InvalidUsage("Permission Denied", 403)
    if role == "school_admin":
        if len(user_role) > 0:
            condition = {
                    "organisation": organisation,
                    "role": user_role
                    }
        else:
            condition = {
                    "organisation": organisation
                    }
    elif role == "super_admin" and len(user_role) > 0:
        condition = {
                "role": user_role
                }
    # Get various information of users present in db(username, org, grade, institute_type, role, active status)
    users_info = mongo_session.access_specific_fields(collection='user_profile',
                                                      condition=condition,
                                                      columns=columns,
                                                      return_keys=["username", "organisation", "grade",
                                                                   "institute_type", "_id", "role", "active", 
                                                                   "email", "name", "last_name"
                                                                   ])

    for user in users_info:
        user["display_name"] = user.pop("name") + " " + user.pop("last_name")
        user["user_id"] = str(user.pop("_id"))
    # return users_info
    users_per_page = 30
    response_data = [users_info[i: i + users_per_page] for i in range(0, len(users_info), users_per_page)]
    if int(page) > len(response_data):
        response = []
        raise InvalidUsage("No Content Available on this Page", 400)
    else:
        message = "Data retrieved successfully"
        response = {
                "message": message,
                "total_pages": len(response_data),
                "user_details": response_data[int(page) - 1],
                "current_page": int(page)
            }
    return response


def get_users_csv(users):
    """ to get csv of all users
    :type users: dictionary
    :returns dataframe
    """
    refined_users = []
    required_columns = ["username", "organisation", "grade", "institute_type", "role", "active", "email"]
    for user in users:
        refined_user = {} 
        for columns in required_columns:
            refined_user[columns] = user[columns]
        refined_users.append(refined_user)
    df = pd.DataFrame.from_dict(refined_users)
    return df


def email_address_validation(email):
    "to check whether entered email address is valid or not"
    try:
        return re.match(r"^[A-Za-z0-9\.\+_-]+@[A-Za-z0-9\._-]+\.[a-zA-Z]*$", email)

    except Exception as e:
        print(e)
        return {"status": 400, "message": "Enter a valid email_id"}


def password_check(passwd):
    val = True
    msg = ""
    if len(passwd) < 8 or len(passwd) > 30 or passwd.isspace():
        if len(passwd) > 30:
            msg = "Password length should not be greater than 30"
        else:
            msg = "Password length should be greater than 8"
        val = False
    return val, msg


def username_restriction(username):
    val = True
    msg = ""
    if len(username) < 3 or len(username) > 50:
        msg = 'Username length should be greater than 3.'
        val = False

    if any(char.isspace() for char in username):
        msg = 'Username should not contain white spaces.'
        val = False
    if not username.isalnum():
        msg = "Username should only contain alphanumeric values."
        val = False
    return val, msg


def change_user_status(role, other_user_id, active):
    """To activate or deactivate a db user.
    :param role: role of the user which is making changes.
    :type role: str(slug).
    :param other_user_id: user whose status need to be changed.
    :type other_user_id: str(mongo_id)
    :param active: status to set.
    :type active: str(true, false)"""
    active = active.lower()
    if active not in ["true", "false"]:
        raise InvalidUsage("Bad Request", 400)
    active = True if active == 'true' else False
    activated = 'Activated' if active else 'Deactivated'

    if role != 'super_admin':
        raise InvalidUsage("Super admin can activate or deactivate user", 403)
    user = mongo_session.check_existance_return_info(collection="user_profile",
                                                     condition={"_id": ObjectId(other_user_id)})
    if not user:
        raise InvalidUsage('User to be ' + activated + ' does not exist', 400)
    update_active_key = mongo_session.update_field_based_on_user_id(collection='user_profile',
                                                                    id=ObjectId(other_user_id),
                                                                    field='active',
                                                                    value=active)
    if update_active_key['status'] == 200:
        return {"status": 200, "message": 'User  ' + activated + ' Successfully', "active": active}


def show_all_permission(permissions):
    if config.show_permissions not in permissions:
        raise InvalidUsage("You can't view permissions.", 403)
    all_permissions_data = mongo_session.get_all_data(collection='permissions')
    return {"message": all_permissions_data['message'],
            "status": all_permissions_data['status']}


def get_roles_permissions(permissions):
    if config.show_permissions not in permissions:
        raise InvalidUsage("You can't view permissions.", 403)
    all_roles_with_permissions = mongo_session.get_all_data(collection='roles')
    return {"message": all_roles_with_permissions['message'],
            "status": all_roles_with_permissions['status']}


def add_or_remove_permissions_for_role(permissions, permissions_slug, add_or_del_flag, update_role_id):
    if config.show_permissions not in permissions:
        raise InvalidUsage("You can't view permissions.", 403)
    update_role_id = ObjectId(update_role_id)
    if add_or_del_flag:
        add_value_to_array = mongo_session.add_to_an_array_field(collection='roles',
                                                                 id=update_role_id,
                                                                 field='permissions',
                                                                 values_array=permissions_slug)
        if add_value_to_array['status'] == 200 and add_value_to_array['document_updated'] == 1:
            return {"status": 200, "message": 'permission added', "flag": add_or_del_flag}
        else:
            return {"status": 400, "message": 'role not present'}
    else:
        del_value_from_array = mongo_session.del_value_from_array(collection='roles', id=update_role_id,
                                                                  field='permissions', value=permissions_slug)
        if del_value_from_array['status'] == 200 and del_value_from_array['document_updated'] == 1:
            return {"status": 200, "message": 'permission removed', "flag": add_or_del_flag}
        else:
            return {"status": 400, "message": 'role not present'}


def store_video_state(course_id, session_id, video_time, user_id):
    if not mongo_session.verify_course_store_video_state(
            collection="course_sessions",
            condition={"_id": ObjectId(session_id)},
            columns={"_id": 1})['message'] == session_id:
        raise Exception("Oops, Video doesn't exist anymore.")
    user_profile_store_status = mongo_session.store_video_data_user_profile(
        collection="user_profile",
        user_id=user_id,
        course_id=course_id,
        video_time=video_time,
        session_id=session_id)
    status_code = user_profile_store_status['status']
    message = user_profile_store_status['message']
    return message, status_code


def fetch_user_type():
    collection = "user_type"
    user_type_info = mongo_session.get_all_data(collection)
    response = {"data": user_type_info['message'], "status": user_type_info["status"]}
    return response

