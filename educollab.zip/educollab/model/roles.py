from bson import ObjectId

from db_wrapper.tasks import Mongo

mongo_session = Mongo()
import traceback


def fetch_roles_info(role):
    """
    fetch roles information using role slugs
    Params:
        role (req) : slug value for particular role
    """
    if role not in ["super_admin", "school_admin"]:
        return [], "only super admin can view roles", 403
    try:
        roles_info = []
        if role == "school_admin":
            condition = {"name": {"$nin": ["super_admin", "school_admin"]}}
        else:
            condition = {"name": {"$nin": ["super_admin"]}}
        roles_query = mongo_session.get_data_for_particular_columns_with_condition(
            collection="roles",
            condition=condition,
            columns={"_id": 1, "name": 1, "display_name": 1})
        if roles_query['status'] != 200:
            return [], "error while fetching data", 500
        for each_role in roles_query['message']:
            roles_info.append({
                "_id": str(each_role['_id']),
                "name": each_role['name'],
                "displayName": each_role['display_name']
            })
        return roles_info, "Success", 200
    except Exception as e:
        traceback.print_exc()
        return [], e, 500


def add_new_role(new_role, user_role):
    if user_role != "super_admin":
        return [], "only super admin can add roles", 403
    try:
        slug_list = new_role.lower().split(' ')
        combined_slug = "_".join(slug_list)
        find_query = mongo_session.find_data_in_db(collection="roles", condition={"name": combined_slug}, columns={})

        if find_query['status'] != 200:
            return {}, "unable to communicate with db", 500
        if find_query['message']:
            return {}, "a role with same name already exist", 409

        doc_to_insert = {"name": combined_slug, "display_name": new_role, "permissions": []}
        add_query = mongo_session.insert_documnet(collection='roles', doc_to_insert=doc_to_insert)
        if add_query['status'] != 200:
            return {}, "unable to add data", 500

        roles_query = mongo_session.get_data_for_particular_columns_with_condition(
                                    collection="roles",
                                    condition={"_id": ObjectId(add_query['_id'].inserted_id)},
                                    columns={"_id": 1, "name": 1, "display_name": 1})
        if roles_query['status'] != 200:
            return [], "error while fetching data", 400
        role_info = roles_query['message'][0]
        data = {"_id": role_info['_id'], "displayName": role_info['display_name'], "name": role_info['name']}
        return data, "New Role Added", 201
    except Exception as e:
        traceback.print_exc()
        return {}, e, 500
