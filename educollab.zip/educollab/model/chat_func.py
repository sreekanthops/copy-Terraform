from db_wrapper.tasks import Mongo
from routes.exception import InvalidUsage
from utils.time_conversions import utc_datetime_now
from bson import ObjectId

mongo_session = Mongo()


def create_group_chat(members, group_name, admins, created_by, group_description, subheading, resource_bank_resource_id,
                      s3_key_info, course_id=None, course_work_id=None, cw_instance_id=None):
    """
    This function creates room for a group of users. The creator of the group is by default the
    admin of the group.
    """
    room_members = {}
    for member in members:
        room_members[member] = {"created_by": ObjectId(created_by),
                                "created_at": utc_datetime_now(),
                                "status": "active"}

    photo_id = resource_bank_resource_id
    url = s3_key_info

    admin_list = []
    for admin in admins:
        admin_list.append({"admin_id": ObjectId(admin), "added_by": ObjectId(created_by), "status": "active"})

    doc_to_insert = {
        "name": group_name,
        "created_by": ObjectId(created_by),
        "created_at": utc_datetime_now(),
        "admins": admin_list,
        "room_members": room_members,
        "group_photo": {
            "avatar_url": url,
            "edited_by": ObjectId(created_by),
            "photo_id": ObjectId(photo_id) if photo_id else ""
        },
        "sub_heading": subheading if subheading else "",
        "group_description": {
            "description": group_description if group_description else "",
            "edited_by": ObjectId(created_by) if group_description else ""
        },
        "type": "group"
    }
    if course_id:
        doc_to_insert['course_id'] = ObjectId(course_id)
    if course_work_id:
        doc_to_insert['course_work_id'] = ObjectId(course_work_id)
    if cw_instance_id:
        doc_to_insert['cw_instance_id'] = ObjectId(cw_instance_id)

    response = mongo_session.insert_documnet(collection="chat_rooms",
                                             doc_to_insert=doc_to_insert)
    room_info = mongo_session.check_existance_return_info(collection='chat_rooms',
                                                          condition={
                                                              '_id': ObjectId(response['_id'].inserted_id)
                                                          },
                                                          whole_doc=True)
    if not room_info:
        raise InvalidUsage("Room not found", 400)
    room_info['_id'] = str(room_info['_id'])
    room_info['created_by'] = str(room_info['created_by'])
    room_info['admins'][0]['admin_id'] = str(room_info['admins'][0]['admin_id'])
    room_info['admins'][0]['added_by'] = str(room_info['admins'][0]['added_by'])
    room_info['group_description']['edited_by'] = str(room_info['group_description']['edited_by'])
    room_info['group_photo']['edited_by'] = str(room_info['group_photo']['edited_by'])
    room_info['group_photo']['photo_id'] = str(room_info['group_photo']['photo_id'])
    for member in room_info['room_members']:
        room_info['room_members'][member]['created_by'] = str(
            room_info['room_members'][member]['created_by'])
    if course_id:
        room_info['course_id'] = str(room_info['course_id'])
    if course_work_id:
        room_info['course_work_id'] = str(room_info['course_work_id'])
    if cw_instance_id:
        room_info['cw_instance_id'] = str(room_info['cw_instance_id'])
    return room_info


def update_course_groupchat(user_id, room_id, group_name, photo_url=None, photo_id=None, admins=None,
                            remove_users=None, more_users=None, new_users=None):
    room_info = mongo_session.check_existance_return_info(collection='chat_rooms',
                                                          condition={"_id": ObjectId(room_id)},
                                                          whole_doc=True)
    if photo_id:
        update_info = {"$set": {"group_photo": {"avatar_url": photo_url, "edited_by": ObjectId(user_id),
                                                "photo_id": ObjectId(photo_id)}}}
        response = mongo_session.update_db_data(collection='chat_rooms',
                                                condition={'_id': ObjectId(room_id)},
                                                update_info=update_info)
    if admins:
        admin_list = []
        for admin in admins:
            admin_list.append({"admin_id": ObjectId(admin), "added_by": ObjectId(user_id), "status": "active"})

        update_info = {"$set": {"admins": admin_list}}
        response = mongo_session.update_db_data(collection='chat_rooms',
                                                condition={'_id': ObjectId(room_id)},
                                                update_info=update_info)

    if group_name:
        update_info = {"$set": {"name": group_name}}
        response = mongo_session.update_db_data(collection='chat_rooms',
                                                condition={'_id': ObjectId(room_id)},
                                                update_info=update_info)

    if remove_users is not None:
        for users in remove_users:
            if users in room_info['room_members']:
                del room_info['room_members'][users]

            index = 0
            for admin in room_info['admins']:
                if ObjectId(users) == admin['admin_id']:
                    room_info['admins'].pop(index)
                index += 1

        update_info = {"$set": {"room_members": room_info['room_members'], "admins": room_info['admins']}}
        response = mongo_session.update_db_data(collection='chat_rooms',
                                                condition={'_id': ObjectId(room_id)},
                                                update_info=update_info)

    if more_users is not None:
        for users in more_users:
            room_info['room_members'][users] = {"created_by": ObjectId(user_id),
                                                "created_at": utc_datetime_now(),
                                                "status": "active"}

        update_info = {"$set": {"room_members": room_info['room_members']}}
        response = mongo_session.update_db_data(collection='chat_rooms',
                                                condition={'_id': ObjectId(room_id)},
                                                update_info=update_info)

    if new_users is not None:
        new_user_detail = {}
        for users in new_users:
            new_user_detail[users] = {"created_by": ObjectId(user_id),
                                      "created_at": utc_datetime_now(),
                                      "status": "active"}

        update_info = {"$set": {"room_members": new_user_detail}}
        response = mongo_session.update_db_data(collection='chat_rooms',
                                                condition={'_id': ObjectId(room_id)},
                                                update_info=update_info)
