from config import s3_connection, bucket
from db_wrapper.tasks import Mongo
from model.User import User_Profile
import copy


mongo_session = Mongo()


def convert(seconds):
    seconds = seconds % (24 * 3600)
    hour = seconds // 3600
    seconds %= 3600
    minutes = seconds // 60
    seconds %= 60

    return "%d:%02d:%02d" % (hour, minutes, seconds)


def time_format(time_data):
    t = time_data.split('.')
    if len(str(t[1])) == 1:
        time_data = time_data + '00'
    elif len(str(t[1])) == 2:
        time_data = time_data + '0'
    return time_data


def create_vtt(data, job_name):
    transcriptions = copy.deepcopy(data)
    template = """WEBVTT"""
    if transcriptions['results']['items']:
        for t in transcriptions['results']['items']:
            if t.get('start_time'):
                start_time = convert(int(t['start_time'].split('.')[0])) + '.' + t['start_time'].split('.')[1] + '0'
                start_time = time_format(start_time)
                end_time = convert(int(t['end_time'].split('.')[0])) + '.' + t['end_time'].split('.')[1] + '0'
                end_time = time_format(end_time)
                t['word'] = t['alternatives'][0]['content']
                t.pop('alternatives')
                text = """\n 
{} --> {}
- {}""".format(start_time, end_time, t['word'])
                template += text
    s3_connection.put_object(Body=template, Bucket=bucket, Key='vtt_transcriptions/{}.vtt'.format(job_name),
                             ContentType='text/vtt')
    # return "https://s3-%s.amazonaws.com/%s" % (bucket, 'vtt_transcriptions/{}.vtt'.format(job_name))


def get_transcript(transcript_data):
    transcript_list = []
    for tr_data in transcript_data['results']['items']:
        if tr_data['alternatives'][0]['content'].isalnum():
            transcript_list.append(" " + tr_data['alternatives'][0]['content'])
        else:
            transcript_list.append(tr_data['alternatives'][0]['content'])
    final_transcript = "".join(transcript_list)
    return final_transcript


def transcript_update(user_id, s3_key, role, suggestion, transcript_status, starttime, endtime):
    user_data = User_Profile(user_id)
    username = user_data[0]['username']
    dbdata = mongo_session.get_all_data_for_particular_condition_fields(collection="video_transcriptions",
                                                                        condition={"s3_key": s3_key})
    if dbdata['status'] != 200:
        raise Exception(dbdata['message'])
    transcript_data = dbdata['message'][0]['transcription']
    job_name = dbdata['message'][0]['vtt'].split("/")[-1].split(".")[0]
    if role in ['teacher', 'super_admin']:
        if transcript_status.lower() == "self":
            for tr_data in transcript_data['results']['items']:
                if "start_time" and "end_time" in list(tr_data.keys()):
                    if tr_data['start_time'] == starttime and tr_data['end_time'] == endtime:
                        tr_data['alternatives'][0]['content'] = suggestion
            final_transcript = get_transcript(transcript_data)
            transcript_data['results']['transcripts'][0]['transcript'] = final_transcript
            # updating vtt file
            create_vtt(transcript_data, job_name)
        else:
            if transcript_status.lower() == "approve":
                for tr_data in transcript_data['results']['items']:
                    if "start_time" and "end_time" in list(tr_data.keys()):
                        if tr_data['start_time'] == starttime and tr_data['end_time'] == endtime:
                            tr_data['alternatives'][0]['content'] = tr_data['pendings']['suggestion']
                            tr_data.pop('pendings', None)
                final_transcript = get_transcript(transcript_data)
                transcript_data['results']['transcripts'][0]['transcript'] = final_transcript
                # updating vtt file
                create_vtt(transcript_data, job_name)

            elif transcript_status.lower() == "decline":
                for tr_data in transcript_data['results']['items']:
                    if "start_time" and "end_time" in list(tr_data.keys()):
                        if tr_data['start_time'] == starttime and tr_data['end_time'] == endtime:
                            tr_data.pop('pendings', None)

    elif role == "student":
        for tr_data in transcript_data['results']['items']:
            if "start_time" and "end_time" in list(tr_data.keys()):
                if tr_data['start_time'] == starttime and tr_data['end_time'] == endtime:
                    tr_data["pendings"] = {"user_id": user_id, "username": username, "suggestion": suggestion}

    update_transcript_status = mongo_session.update_record_into_db(
        collection="video_transcriptions",
        condition={"s3_key": s3_key},
        update_info={"$set": {"transcription": transcript_data}})
    if update_transcript_status["status"] != 200:
        raise Exception("Some internal error, Please try again later.")
    return "Transcript edit successfully", 200