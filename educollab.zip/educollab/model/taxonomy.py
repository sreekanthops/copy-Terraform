from db_wrapper.tasks import Mongo
from model.User import User_Profile
from bson import ObjectId
from model import Content

mongo_session = Mongo()


def check_existing_tag():
    check_taxonomy_status = mongo_session.get_all_data(collection="Course_Category")
    if check_taxonomy_status["status"] != 200:
        raise Exception("Some internal error, Please try again later.")
    taxonomy_list = []
    for doc in check_taxonomy_status["message"]:
        taxonomy_list.append(str(doc["name"]).lower())
    return taxonomy_list


def check_sub_category_level(parent_id):
    parent_list = mongo_session.get_all_data_for_particular_condition_fields(collection="Course_Category",
                                                                             condition={"_id": ObjectId(parent_id)})
    parent_category = parent_list['message'][0]['name']
    category_dict = Content.course_category()
    for category in category_dict:
        category_list = category['Course_Category'].split(' / ')
        if parent_category in category_list:
            child_level = category_list.index(parent_category)
    return child_level


def edit_tag(role, tag_id, category_name):
    if role != "super_admin":
        raise Exception("Oops.. Only super-admin can edit category.")
    check_category_list = check_existing_tag()
    if category_name.lower() in check_category_list:
        raise Exception("Same Category already exists.")
    update_taxonomy_status = mongo_session.update_record_into_db(
        collection="Course_Category",
        condition={"_id": ObjectId(tag_id)},
        update_info={"$set": {'name': category_name}})
    if update_taxonomy_status["status"] != 200:
        raise Exception("Some internal error, Please try again later.")
    return "Taxonomy edit successfully", 200


def add_tag(role, parent_id, category_name):
    if role != "super_admin":
        raise Exception("Oops.. Only super-admin can add new category.")
    check_category_list = check_existing_tag()
    if category_name.lower() in check_category_list:
        raise Exception("Same Category already exists.")
    board_data = mongo_session.get_all_data(collection="boards_bank")
    if board_data['status'] != 200:
        raise Exception("Some internal error, Please try again later.")
    board_list = []
    for doc in board_data["message"]:
        board_list.append({"board_id": ObjectId(doc["_id"]), "board_name": doc["board"]})
    if parent_id is None:
        doc_to_insert = {"name": category_name,
                         "boards": board_list,
                         "parent_id": parent_id}
    else:
        # checking sub-category level
        child_level = check_sub_category_level(parent_id=parent_id)
        if child_level > 5:
            return "Not able to add new Sub-category", 200
        doc_to_insert = {"name": category_name,
                         "boards": board_list,
                         "parent_id": ObjectId(parent_id)}
    add_taxonomy_status = mongo_session.insert_documnet(collection="Course_Category", doc_to_insert=doc_to_insert)
    if add_taxonomy_status["status"] != 200:
        raise Exception("Some internal error, Please try again later.")
    return "Taxonomy added successfully", 200


def get_tag(role):
    """return the category list"""
    if role != "super_admin":
        raise Exception("Oops.. Only super-admin can view category.")
    get_taxonomy_status = mongo_session.get_all_data(collection="Course_Category")
    if get_taxonomy_status["status"] != 200:
        raise Exception("Some internal error, Please try again later.")
    taxonomy_list = []
    for doc in get_taxonomy_status["message"]:
        taxonomy_list.append({"name": doc["name"], "id": str(doc["_id"]), "parent_id": str(doc["parent_id"])})
    return taxonomy_list, 200
