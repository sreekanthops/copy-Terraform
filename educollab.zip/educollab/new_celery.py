
import celery_config
from celery import Celery

import requests
from services.storage.s3_services import s3_storage

s3_function = s3_storage()

celery_app = Celery("tasks",
                    broker=celery_config.broker_url,
                    backend=celery_config.result_backend)
celery_app.config_from_object(celery_config)


# @celery_app.task(name="zoom_multipart_upload_s3")
# def zoom_multipart_upload_s3(jwt_token, download_url, s3_key, filename=None):
#     """
#        jwt token in str
#        read and upload to s3 using multipart upload
#
#        Call requests.get(url, stream) to download a file from url
#        and set stream to True to allow iter_content on the Response object to iterate the data
#        while maintaining an open connection.
#        Use Response.iter_content(chunk_size) to load a fixed chunk_size in bytes each time
#        while iter_content is iterated."""
#     print("hurray", type(jwt_token))
#     URL = f"{download_url}/?access_token={jwt_token}"
#     response = requests.get(URL,
#                             stream=True,
#                             headers={"Authorization":
#                                          f"Bearer {jwt_token}"})
#
#     response.raise_for_status()
#     # chunk size in bytes--kb---mb  for now keep 5 mb
#     print(" file size", response.headers['Content-length'])
#
#     # if file size is smaller than the said limit use single upload operation
#     if int(response.headers['Content-length']) > 1024 * 1024 * 6:
#         mpu_id = s3_function.create_multipart_upload_id(s3_key)
#         parts = []
#         part_index = 1
#         uploaded_bytes = 0
#
#         for chunk in response.iter_content(chunk_size=1024 * 1024 * 5):
#             # chunk size 5mb for now
#             # filter out keep-alive new chunks
#             if chunk:
#                 uploaded_part = s3_function.upload_chunk(chunk, mpu_id, s3_key, part_index)
#                 if uploaded_part:
#                     parts.append(uploaded_part)
#
#                     uploaded_bytes += len(chunk)
#                     print("each chunk size", uploaded_bytes)
#                     part_index += 1
#         status = s3_function.complete_multipart_upload(mpu_id, parts, s3_key)
#         print("result", status)
#     else:
#         with open(filename, 'wb') as recorded_local_file:
#             recorded_local_file.write(response.content)
#             recorded_local_file.close()
#         # use only one go to upload file to s3
#         s3_res = s3_function.upload_data_to_s3_private(file=filename,
#                                                        Content_Type="video/mp4",
#                                                        s3_key=s3_key)
#         status = True if s3_res["status"] == 200 else False
#     return status

